/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  javax.inject.Inject
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  javax.servlet.http.HttpSession
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.security.core.Authentication
 *  org.springframework.security.core.context.SecurityContext
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.security.core.userdetails.User
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jieyun.deskpool.web.controller;

import com.alibaba.fastjson.JSON;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.service.RDPService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.SpiceService;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.ConnectStatus;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DpClientType;
import com.jieyun.deskpool.shared.RoleType;
import com.jieyun.deskpool.utils.DpClientUtils;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.misc.BASE64Decoder;

@Controller(value="connectController")
@RequestMapping(value={"/connect"})
public class ConnectController {
    private static final Logger logger = LoggerFactory.getLogger(ConnectController.class);
    @Inject
    private RDPService rdpService;
    @Inject
    private SpiceService spiceService;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @RequestMapping(value={"/connect"})
    public void connect(HttpServletRequest request, HttpServletResponse response) {
        DpClientType clientType = DpClientUtils.parse(request.getHeader("User-Agent"));
        String protocal = request.getParameter("protocol");
        if (clientType.needRdpUri() || StringUtils.equalsIgnoreCase((String)protocal, (String)Desktop.Protocol.RDPC.name())) {
            try {
                String rdpUri = this.getRDPResponse(request, response, clientType);
                logger.info(rdpUri);
                response.sendRedirect(rdpUri);
                return;
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }
	if (StringUtils.equalsIgnoreCase((String)protocal, (String)Desktop.Protocol.STREAM.name())) {
	    try {
        	String streamStr = this.getRDPResponse(request, response, clientType);
        	logger.info(streamStr);

        	response.reset();
        	response.setContentType("text/html;charset=UTF-8");
        	response.setCharacterEncoding("UTF-8");

        	PrintWriter writer = response.getWriter();
        	writer.println("<!DOCTYPE html>");
        	writer.println("<html><head><meta charset='utf-8'><title>Launching Web Terminal</title></head>");
        	writer.println("<body>");
        	writer.println("<script>");
        	writer.println("top.location.href='" + streamStr + "';");
        	writer.println("</script>");
        	writer.println("Launching Web Terminal...");
        	writer.println("</body></html>");
        	writer.close();
            return;
    	}
    	    catch (Exception e) {
            e.printStackTrace();
            return;
    	}
	}
        if (StringUtils.equalsIgnoreCase((String)protocal, (String)Desktop.Protocol.PCOIP.name())) {
            String pcoipStr = null;
            try {
                try {
                    response.reset();
                    pcoipStr = this.getRDPResponse(request, response, clientType);
                    String rdpcharset = "UTF-8";
                    response.setContentType("application/vm; " + rdpcharset);
                    response.setCharacterEncoding(rdpcharset);
                    response.addHeader("Content-Disposition", ConnectController.browserAttachmentType(request) + "; filename=" + "desktop" + Calendar.getInstance().getTimeInMillis() + ".vm");
                    response.addHeader("Content-Length", "" + pcoipStr.length());
                    try {
                        Throwable e = null;
                        Object var8_39 = null;
                        try (PrintWriter writer = response.getWriter();){
                            writer.println(pcoipStr);
                            return;
                        }
                        catch (Throwable throwable) {
                            if (e == null) {
                                e = throwable;
                                throw e;
                            } else {
                                if (e == throwable) throw e;
                                e.addSuppressed(throwable);
                            }
                            throw e;
                        }
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
                catch (Throwable t) {
                    t.printStackTrace();
                    if (!StringUtils.isBlank(pcoipStr)) return;
                    request.getSession().getServletContext().log("PCoIPResponse is blank ");
                }
                return;
            }
            finally {
                if (StringUtils.isBlank((String)pcoipStr)) {
                    request.getSession().getServletContext().log("PCoIPResponse is blank ");
                }
            }
        }
        if (StringUtils.equalsIgnoreCase((String)protocal, (String)Desktop.Protocol.SPICE.name())) {
            String rdpStr = null;
            try {
                try {
                    response.reset();
                    rdpStr = this.getRDPResponse(request, response, clientType);
                    String rdpcharset = "UTF-8";
                    response.setContentType("application/virt-viewer; " + rdpcharset);
                    response.setCharacterEncoding(rdpcharset);
                    response.addHeader("Content-Disposition", ConnectController.browserAttachmentType(request) + "; filename=" + "desktop" + Calendar.getInstance().getTimeInMillis() + ".vv");
                    response.addHeader("Content-Length", "" + rdpStr.length());
                    try {
                        Throwable e = null;
                        Object var8_41 = null;
                        try (PrintWriter writer = response.getWriter();){
                            writer.println(rdpStr);
                            return;
                        }
                        catch (Throwable throwable) {
                            if (e == null) {
                                e = throwable;
                                throw e;
                            } else {
                                if (e == throwable) throw e;
                                e.addSuppressed(throwable);
                            }
                            throw e;
                        }
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
                catch (Throwable t) {
                    t.printStackTrace();
                    if (!StringUtils.isBlank(rdpStr)) return;
                    request.getSession().getServletContext().log("RdpResponse is blank ");
                }
                return;
            }
            finally {
                if (StringUtils.isBlank((String)rdpStr)) {
                    request.getSession().getServletContext().log("RdpResponse is blank ");
                }
            }
        }
        if (StringUtils.equalsIgnoreCase((String)protocal, (String)Desktop.Protocol.SGW.name())) {
            String rdpStr = null;
            try {
                try {
                    response.reset();
                    rdpStr = this.getRDPResponse(request, response, clientType);
                    String rdpcharset = "UTF-8";
                    response.setContentType("application/rdpx; " + rdpcharset);
                    response.setCharacterEncoding(rdpcharset);
                    response.addHeader("Content-Disposition", ConnectController.browserAttachmentType(request) + "; filename=" + "desktop" + Calendar.getInstance().getTimeInMillis() + ".rdpx");
                    response.addHeader("Content-Length", "" + rdpStr.length());
                    try {
                        Throwable e = null;
                        Object var8_43 = null;
                        try (PrintWriter writer = response.getWriter();){
                            writer.println(rdpStr);
                            return;
                        }
                        catch (Throwable throwable) {
                            if (e == null) {
                                e = throwable;
                                throw e;
                            } else {
                                if (e == throwable) throw e;
                                e.addSuppressed(throwable);
                            }
                            throw e;
                        }
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
                catch (Throwable t) {
                    t.printStackTrace();
                    if (!StringUtils.isBlank(rdpStr)) return;
                    request.getSession().getServletContext().log("RdpResponse is blank ");
                }
                return;
            }
            finally {
                if (StringUtils.isBlank((String)rdpStr)) {
                    request.getSession().getServletContext().log("RdpResponse is blank ");
                }
            }
        }
        String rdpStr = null;
        try {
            try {
                response.reset();
                rdpStr = this.getRDPResponse(request, response, clientType);
                String rdpcharset = "UTF-8";
                response.setContentType("application/rdp; " + rdpcharset);
                response.setCharacterEncoding(rdpcharset);
                response.addHeader("Content-Disposition", ConnectController.browserAttachmentType(request) + "; filename=" + "desktop" + Calendar.getInstance().getTimeInMillis() + ".rdp");
                response.addHeader("Content-Length", "" + rdpStr.length());
                try {
                    Throwable e = null;
                    Object var8_45 = null;
                    try (PrintWriter writer = response.getWriter();){
                        writer.println(rdpStr);
                        return;
                    }
                    catch (Throwable throwable) {
                        if (e == null) {
                            e = throwable;
                            throw e;
                        } else {
                            if (e == throwable) throw e;
                            e.addSuppressed(throwable);
                        }
                        throw e;
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                    return;
                }
            }
            catch (Throwable t) {
                t.printStackTrace();
                if (!StringUtils.isBlank(rdpStr)) return;
                request.getSession().getServletContext().log("RdpResponse is blank ");
            }
            return;
        }
        finally {
            if (StringUtils.isBlank((String)rdpStr)) {
                request.getSession().getServletContext().log("RdpResponse is blank ");
            }
        }
    }

    private String getRDPResponse(HttpServletRequest request, HttpServletResponse response, DpClientType clientType) {
        String rdpStr = "";
        String protocalStr = request.getParameter("protocol");
        Desktop.Protocol protocol = Desktop.Protocol.valueOf(protocalStr);
        String instanceId = request.getParameter("instanceId");
        if (StringUtils.isBlank((String)instanceId)) {
            return "rdp.response.instanceId.isNull";
        }
        if (StringUtils.isBlank((String)protocalStr)) {
            return "rdp.response.protocol.isNull";
        }
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication authentication = context.getAuthentication();
        Object user = null;
        String loginUsername = "";
        try {
            user = authentication.getPrincipal();
            if (user instanceof String) {
                loginUsername = (String)user;
            } else if (user instanceof User) {
                loginUsername = ((User)user).getUsername();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        logger.info(request.getHeader("Cookie"));
        logger.info(request.toString());
        HttpSession session = request.getSession();
        ConnectStatus connectStatus = (ConnectStatus)session.getAttribute("dp_instance_connectStatus");
        if (connectStatus == null) {
            return "rdp.response.connectStatus.isNull cookie " + request.getHeader("Cookie");
        }
        IInstanceBean instance = connectStatus.readInstanceBean();
        if (instance != null && instance.isSpice() && StringUtils.equalsIgnoreCase((String)protocalStr, (String)Desktop.Protocol.SPICE.name())) {
            rdpStr = this.spiceService.getSpiceOutput(loginUsername, request.getRemoteAddr(), connectStatus);
            logger.info("getSpiceOutput {} ", (Object)rdpStr);
        } else {
            rdpStr = this.rdpService.getRDPOutput(loginUsername, request.getRemoteAddr(), connectStatus, clientType, protocol);
        }
        IAccountBean accountBean = Services.getAccountService().findByName(loginUsername);
        if (!accountBean.getRoles().contains((Object)RoleType.ROLE_ADMIN)) {
            new TrackerService.Writer.connInfo().connect(connectStatus.readSessionBean()).message("session.connect.download.config", connectStatus.readSessionBean(), new String[]{"$protocol", connectStatus.getProtocol().toString(), "$clientIP", connectStatus.getClientIP()});
        }
        return rdpStr;
    }

    public static String browserAttachmentType(HttpServletRequest req) {
        String userAgent = req.getHeader("user-agent");
        if (userAgent == null) {
            userAgent = "";
        }
        if ((userAgent = userAgent.toLowerCase()) != null && (userAgent.contains("mozilla") || userAgent.contains("linux") || userAgent.contains("msie") || userAgent.contains("applewebkit") && userAgent.contains("macintosh"))) {
            return "inline";
        }
        return "attachment";
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @RequestMapping(value={"/status/report"})
    @ResponseBody
    public String connectStateReport(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session;
        String reason = request.getParameter("reason");
        if (StringUtils.isNotBlank((String)reason)) {
            reason = new String(new BASE64Decoder().decodeBuffer(reason));
        }
        if ((session = request.getSession(false)) != null) {
            HttpSession httpSession = session;
            synchronized (httpSession) {
                LastConnectStatus connectStatus = new LastConnectStatus();
                Map map = (Map)JSON.parseObject((String)reason, Map.class);
                String status = (String)map.get("status");
                if (!"0".equals(status) && !"1".equals(status)) {
                    connectStatus.reason = new String(new BASE64Decoder().decodeBuffer(status));
                    session.setAttribute("dp_instance_lastConnectStatus", (Object)connectStatus);
                }
            }
        }
        return "{\"result:\":\"ok\"}";
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @RequestMapping(value={"/status/read"})
    @ResponseBody
    public Object readStatus(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            HttpSession httpSession = session;
            synchronized (httpSession) {
                String autoConnect;
                LastConnectStatus responseObj = new LastConnectStatus();
                responseObj.autoConnect = autoConnect = this.selectAutoConnect(request);
                LastConnectStatus connectStatus = (LastConnectStatus)session.getAttribute("dp_instance_lastConnectStatus");
                if (connectStatus != null) {
                    responseObj.reason = connectStatus.reason;
                }
                session.removeAttribute("dp_instance_lastConnectStatus");
                return responseObj;
            }
        }
        return null;
    }

    private ConnectStatus getConnectStatus(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return (ConnectStatus)session.getAttribute("dp_instance_connectStatus");
    }

    private String selectAutoConnect(HttpServletRequest request) {
        ConnectStatus connectStatus = this.getConnectStatus(request);
        if (connectStatus == null) {
            return null;
        }
        return Services.getUserSessionService().popCommand(connectStatus.getInstanceId());
    }

    private static class LastConnectStatus {
        public String reason;
        public int readed = 0;
        public String autoConnect;

        private LastConnectStatus() {
        }
    }
}
