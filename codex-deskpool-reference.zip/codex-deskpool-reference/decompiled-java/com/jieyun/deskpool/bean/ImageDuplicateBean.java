/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IImageDuplicateBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.ImageDuplicate;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ImageStatus;
import java.util.List;

public class ImageDuplicateBean
extends DefaultBean<ImageDuplicate>
implements IImageDuplicateBean,
IImageDuplicateBean.Update {
    @Override
    public void Init(IImageBean image, IServerBean server) {
        this.setName(image.getName());
        this.setStatus(ImageStatus.INITIAL);
        this.setImage(image);
        this.setServer(server);
        this.setVersions(image.getVersions());
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public IImageDuplicateBean.Update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public Id getImageId() {
        return this.getIdParam("image");
    }

    @Override
    public IImageBean getImage() {
        Id beanId = this.getImageId();
        return beanId == null ? null : Services.getImageService().findOne(beanId);
    }

    @Override
    public Id getServerId() {
        return this.getIdParam("server");
    }

    @Override
    public IServerBean getServerBean() {
        Id beanId = this.getServerId();
        return beanId == null ? null : Services.getServerService().findOne(beanId);
    }

    private IImageDuplicateBean.Update setImage(IImageBean image) {
        this.setIdParam("image", image.Id());
        return this;
    }

    private IImageDuplicateBean.Update setServer(IServerBean server) {
        this.setIdParam("server", server.Id());
        return this;
    }

    @Override
    public ImageStatus getStatus() {
        return (ImageStatus)((Object)this.getParam("status"));
    }

    private IImageDuplicateBean.Update setStatus(ImageStatus status) {
        this.setParam((Object)"status", (Object)status);
        return this;
    }

    @Override
    public List<String> getVersions() {
        return this.getParamList("versions", String.class);
    }

    @Override
    public String getVersion() {
        List<String> list = this.getVersions();
        if (list.isEmpty()) {
            return this.getName();
        }
        return list.get(0);
    }

    @Override
    public IImageDuplicateBean.Update addVersion(String imagename) {
        List<String> list = this.getVersions();
        list.add(0, imagename);
        this.setVersions(list);
        return this;
    }

    private IImageDuplicateBean.Update setVersions(List versions) {
        this.setParam("versions", versions);
        return this;
    }

    @Override
    public String getServiceName() {
        return "imageDuplicateService";
    }

    @Override
    public IImageDuplicateBean.Update enterStatus(ImageStatus status) {
        this.setStatus(status);
        this.save();
        return this;
    }
}
