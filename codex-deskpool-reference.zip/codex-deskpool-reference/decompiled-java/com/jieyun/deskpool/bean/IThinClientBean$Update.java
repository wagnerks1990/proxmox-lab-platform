/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ITCGroupBean;
import com.jieyun.deskpool.bean.IThinClientBean;
import com.jieyun.deskpool.domain.ThinClient;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ThinClientCerStatus;
import com.jieyun.deskpool.shared.ThinClientStatus;
import java.util.Date;

public static interface IThinClientBean.Update
extends IThinClientBean,
Bean.Update<ThinClient> {
    public IThinClientBean.Update setSn(String var1);

    public IThinClientBean.Update setHostName(String var1);

    public IThinClientBean.Update setStatus(ThinClientStatus var1);

    public IThinClientBean.Update setTcGroupId(Id var1);

    public IThinClientBean.Update setExcuteTime(Date var1);

    public IThinClientBean.Update setMacAddr(String var1);

    public IThinClientBean.Update setVersion(String var1);

    public IThinClientBean.Update setUpdateTime(Date var1);

    public IThinClientBean.Update setIpAddr(String var1);

    public IThinClientBean.Update setDeviceType(String var1);

    public IThinClientBean.Update enterStatus(ThinClientStatus var1);

    public IThinClientBean.Update setType(String var1);

    public IThinClientBean.Update setTcGroup(ITCGroupBean var1);

    public IThinClientBean.Update setCerStatus(ThinClientCerStatus var1);
}
