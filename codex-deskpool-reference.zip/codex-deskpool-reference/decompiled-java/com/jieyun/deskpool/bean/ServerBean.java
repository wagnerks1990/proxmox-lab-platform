/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  com.alibaba.fastjson.JSONException
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jieyun.deskpool.bean;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.jieyun.deskpool.agent.PoolManager;
import com.jieyun.deskpool.agent.ServerCommandEngine;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.ServerEntity;
import com.jieyun.deskpool.api.data.ServerEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.INodeSignatureBean;
import com.jieyun.deskpool.bean.IParcelBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.PatchBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.distributed.rpc.DispatchPoint;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.domain.Server;
import com.jieyun.deskpool.front.ImportedVM;
import com.jieyun.deskpool.front.ServerConfig;
import com.jieyun.deskpool.front.ServerFront;
import com.jieyun.deskpool.service.JYConfigServiceException;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.LicenseService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.GpuDevice;
import com.jieyun.deskpool.shared.GpuResource;
import com.jieyun.deskpool.shared.HypervisorConfigParams;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.MediateDevice;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.Resource;
import com.jieyun.deskpool.shared.ServerStatus;
import com.jieyun.deskpool.shared.TemplateAppType;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.shared.VPower;
import com.jieyun.deskpool.utils.Base64Util;
import com.jieyun.deskpool.utils.Credentials;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.MD5Utils;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.utils.TemplateAppDirUtils;
import com.jieyun.deskpool.vm.HostInfo;
import com.jieyun.deskpool.vm.Stopwatch;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.common.NodeConfig;
import com.jieyun.deskpool.vm.manager.ServerManager;
import com.jieyun.deskpool.vm.vmware.api.ResourceUrl;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class ServerBean
extends DefaultBean<Server>
implements IServerBean,
IServerBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(ServerBean.class);
    @Autowired
    ServerEntityBinding serverEntityBinding;

    @PostConstruct
    public void init() {
    }

    @Override
    @DispatchPoint
    public ServerConfig getServerConfig() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        try {
            if (serverManager != null) {
                return serverManager.getServerConfig();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return new ServerConfig();
    }

    @Override
    public Resource.Core getCore() {
        return (Resource.Core)this.getParam("core");
    }

    @Override
    public void setCore(Resource.Core core) {
        this.setParam((Object)"core", core);
    }

    @Override
    public IServerBean.Update getUpdate() {
        return (IServerBean.Update)this.refresh();
    }

    @Override
    public Resource.Memory getMemory() {
        return (Resource.Memory)this.getParam("memory");
    }

    @Override
    public void setMemory(Resource.Memory memory) {
        this.setParam((Object)"memory", memory);
    }

    @Override
    public Resource.Storage getStorage1() {
        return (Resource.Storage)this.getParam("storage1");
    }

    @Override
    public void setStorage1(Resource.Storage storage1) {
        this.setParam((Object)"storage1", storage1);
    }

    @Override
    public Resource.Storage getStorage2() {
        return (Resource.Storage)this.getParam("storage2");
    }

    @Override
    public void setStorage2(Resource.Storage storage2) {
        this.setParam((Object)"storage2", storage2);
    }

    @Override
    public void setCapacity(Resource.Capacity capacity) {
        this.setParam((Object)"capacity", capacity);
    }

    @Override
    public Resource.Capacity getCapacity() {
        return (Resource.Capacity)this.getParam("capacity");
    }

    @Override
    public boolean isHaCluster() {
        return this.booleanValue(this.getParam("haCluster"));
    }

    @Override
    public void setHaCluster(boolean isHaCluster) {
        this.setParam((Object)"haCluster", isHaCluster);
    }

    @Override
    public boolean accepting() {
        return false;
    }

    @Override
    public Credentials getCredentials() {
        Credentials cred = new Credentials((String)this.getParam("host_user"), (String)this.getParam("host_password"));
        return cred;
    }

    @Override
    public void shutdown() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        serverManager.shutdown();
    }

    @Override
    public void restart() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        serverManager.restart();
    }

    @Override
    public void destroyInstances() {
    }

    @Override
    @DispatchPoint
    public ImportedVM refrechImportableCheck(String name) {
        return VMControlFactory.get(Config.Store.get()).getServerManager().refrechImportableCheck(name);
    }

    @Override
    @DispatchPoint
    public List<ImportedVM> getImportableVM() {
        return VMControlFactory.get(Config.Store.get()).getServerManager().getImportableVM(this);
    }

    @Override
    @DispatchPoint
    public List<ImportedVM> getImportableTemplate() {
        return VMControlFactory.get(Config.Store.get()).getServerManager().getImportableTemplate(this);
    }

    @Override
    @DispatchPoint
    public boolean vmExists(String vmid) {
        return VMControlFactory.get(Config.Store.get()).getServerManager().vmExists(vmid);
    }

    @Override
    public IClusterBean getClusterBean() {
        IClusterBean clusterBean = (IClusterBean)Services.getClusterService().createOne();
        Long clusterId = (Long)this.getParam("cluster");
        if (clusterId == null) {
            return null;
        }
        clusterBean.managedById(Id.construct(clusterId));
        return clusterBean;
    }

    @Override
    public void createUserdb(UserDB userdb) {
        IClusterBean clusterBean = this.getClusterBean();
        clusterBean.setUserdb(userdb);
        clusterBean.save();
    }

    @Override
    public void createDatastore(String datastore, String network) {
        this.setParam((Object)"datastore", datastore);
        this.setParam((Object)"network", network);
        logger.info(" datastore:{} network:{}", (Object)datastore, (Object)network);
        this.merge();
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public String getDatastore() {
        return (String)this.getParam("datastore");
    }

    @Override
    public String getImagestore() {
        return (String)this.getParam("imagestore");
    }

    @Override
    public String getDiskstore() {
        return (String)this.getParam("diskstore");
    }

    @Override
    public String getNetwork() {
        return (String)this.getParam("network");
    }

    @Override
    public ServerStatus getStatus() {
        return (ServerStatus)((Object)this.getParam("status"));
    }

    @Override
    public String getHost_type() {
        return (String)this.getParam("host_type");
    }

    @Override
    public String getHost_user() {
        return (String)this.getParam("host_user");
    }

    @Override
    public String getHost_vmmver() {
        return (String)this.getParam("host_vmmver");
    }

    @Override
    public String getHost_password() {
        return (String)this.getParam("host_password");
    }

    @Override
    public String getHost_address() {
        return (String)this.getParam("host_address");
    }

    @Override
    public String getHostinfo_version() {
        return (String)this.getParam("hostinfo_version");
    }

    @Override
    public void setHostinfo_version(String hostinfo_version) {
        this.setParam((Object)"hostinfo_version", hostinfo_version);
    }

    @Override
    public String getHost_macAddr() {
        return (String)this.getParam("host_macAddr");
    }

    @Override
    public IClusterBean getCluster() {
        Long beanId = (Long)this.getParam("cluster");
        return beanId == null ? null : (IClusterBean)Services.getClusterService().findOne(Id.construct(beanId));
    }

    @Override
    public void setName(String name) {
        this.setParam((Object)"name", name);
    }

    @Override
    public void setDatastore(String datastore) {
        this.setParam((Object)"datastore", datastore);
    }

    @Override
    public void setDiskstore(String diskstore) {
        this.setParam((Object)"diskstore", diskstore);
    }

    @Override
    public void setImagestore(String imagestore) {
        this.setParam((Object)"imagestore", imagestore);
    }

    @Override
    public void setNetwork(String network) {
        this.setParam((Object)"network", network);
    }

    @Override
    public void setStatus(ServerStatus status) {
        this.setParam((Object)"status", (Object)status);
    }

    @Override
    public void setHost_type(String host_type) {
        this.setParam((Object)"host_type", host_type);
    }

    @Override
    public void setHost_user(String host_user) {
        this.setParam((Object)"host_user", host_user);
    }

    @Override
    public void setHost_vmmver(String host_vmmver) {
        this.setParam((Object)"host_vmmver", host_vmmver);
    }

    @Override
    public void setHost_password(String host_password) {
        this.setParam((Object)"host_password", host_password);
    }

    @Override
    public void setHost_address(String host_address) {
        this.setParam((Object)"host_address", host_address);
    }

    @Override
    public void setHost_macAddr(String host_macAddr) {
        this.setParam((Object)"host_macAddr", host_macAddr);
    }

    @Override
    public void setCluster(IClusterBean cluster) {
        if (cluster == null) {
            this.setParam("cluster", null);
        } else {
            this.setParam((Object)"cluster", cluster.Id().getId());
        }
    }

    @Override
    public void setGpuResource(GpuResource gpuResource) {
        this.setParam((Object)"gpuResource", gpuResource);
    }

    public HostInfo getHostInfo() {
        return null;
    }

    @Override
    public GpuResource getGpuResource() {
        return (GpuResource)this.getParam("gpuResource");
    }

    @Override
    public VPower getPower() {
        double cores = 4.0;
        double cpu = 2.0;
        double mem = 8192.0;
        try {
            cores = this.getCore().getSize().intValue();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            mem = this.getMemory().getSize().longValue();
        }
        catch (Exception exception) {
            // empty catch block
        }
        Props props = Props.instance();
        double cpuFactor = props.get("server.core.factor", 5.0);
        double cpuOverhead = props.get("server.core.overhead", 0.5);
        double ramFactor = props.get("server.mem.factor", 1.0);
        double ramOverhead = props.get("server.mem.overhead", 2048.0);
        cores = (cores - cpuOverhead) * cpuFactor;
        if (cores < 0.0) {
            cores = 0.0;
        }
        if ((mem = (mem - ramOverhead) * ramFactor) < 0.0) {
            mem = 0.0;
        }
        return new VPower(cores, cpu, mem);
    }

    @Override
    public IServerBean.Update freshen() {
        if (this.isWitness()) {
            this.enterOnline();
            return this;
        }
        try {
            return VMControlFactory.get(Config.Store.get()).getServerManager().freshen(this);
        }
        catch (Exception ex) {
            logger.error(ex.getMessage());
            this.enterOffline("communication");
            return this;
        }
    }

    @Override
    public IServerBean save() {
        if (this.isNew()) {
            this.freshen();
            this.persist();
        } else {
            this.merge();
        }
        return this;
    }

    @Override
    public NetworkConfig getNetworkConfig() {
        NetworkConfig config = NetworkConfigFactory.createNetworkConfig();
        return config;
    }

    @Override
    public PoolInfo countInstancebyStatus() {
        return this.countInstancebyStatus(null);
    }

    @Override
    public PoolInfo countInstancebyStatus(ITemplateBean template) {
        List<IInstanceBean> allInstances = Services.getInstanceService().findByServer(this.Id());
        Stopwatch timer = new Stopwatch("[ServerBean.countInstancebyStatus(serverName = " + this.getName() + ")]");
        PoolInfo poolInfo = PoolManager.countByStatus(allInstances, template);
        timer.stop();
        return poolInfo;
    }

    @Override
    public boolean isLocal() {
        IServerBean current = Services.getServerService().getCurrent();
        return current.Id().equals(this.Id());
    }

    @Override
    public boolean isMaster() {
        return (Boolean)this.getParam("master");
    }

    @Override
    public void setMaster(boolean master) {
        this.setParam((Object)"master", master);
    }

    @Override
    public void storeRemoveAll() {
        List<IInstanceBean> instanceList = Services.getInstanceService().findByServer(this.Id());
        for (IInstanceBean instance : instanceList) {
            instance.remove();
        }
        for (IParcelBean parcel : Services.getParcelService().getParcel(this.Id())) {
            parcel.remove();
            logger.info("del Parcel version=" + parcel.getVersion() + "," + this.getResourceAddress());
        }
        this.remove();
    }

    @Override
    @DispatchPoint
    public void leaveCluster() {
        ClusterNodeBean.instance().leaveCluster();
    }

    @Override
    @DispatchPoint
    public void deactive() {
        throw new JYServiceRuntimeException("not implemented");
    }

    @Override
    @DispatchPoint
    public void quiesce() {
        throw new JYServiceRuntimeException("not implemented");
    }

    @Override
    @DispatchPoint
    public void restartServer() {
        try {
            Services.getSystemService().restartServer();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e.getErrorList());
        }
    }

    @Override
    @DispatchPoint
    public void restartService() {
        try {
            Services.getSystemService().restartService();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e.getErrorList());
        }
    }

    @Override
    @DispatchPoint
    public void shutdownService() {
        try {
            Services.getSystemService().stopService();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e.getErrorList());
        }
    }

    @Override
    @DispatchPoint
    public void restorFactorySetting() {
        try {
            Services.getSystemService().restorFactorySetting();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e.getErrorList());
        }
    }

    @Override
    @DispatchPoint
    public NetworkConfigVO readNetworkConfig() {
        NetworkConfig networkConfig = this.getNetworkConfig();
        NetworkConfigVO params = new NetworkConfigVO();
        params.setAddress(networkConfig.address());
        params.setBroadcast(networkConfig.broadcast());
        params.setGateway(networkConfig.gateway());
        params.setMacaddress(networkConfig.macaddress());
        params.setNetmask(networkConfig.netmask());
        params.setType(networkConfig.type());
        return params;
    }

    @Override
    @DispatchPoint
    public void updateHypervisorParams(HypervisorConfigParams params) {
        Config.VM cfg = Config.Store.get().copy().vm();
        cfg.setParam("host_address", params.getHostAddress());
        cfg.setParam("host_user", params.getUsername());
        cfg.setParam("host_password", params.getPassword());
        cfg.setParam("host_resource", params.getResourcepool());
        cfg.setParam("datastore", params.getDatastorePool());
        cfg.setParam("diskstore", params.getDiskStore());
        cfg.setParam("imagestore", params.getImageStore());
        cfg.setParam("network", params.getNetworkPool());
        try {
            Services.getServerService().checkConnection(cfg);
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e);
        }
        Config config = Config.Store.get();
        config.setVm(cfg);
        config.store();
        this.save();
        try {
            IServerBean serverBean = Services.getServerService().setCurrent(config);
            serverBean.freshen().save();
            new TrackerService.Writer.Server().configure(serverBean).complete("server.configure.modify", new String[0]);
        }
        catch (JYConfigServiceException e) {
            e.printStackTrace();
        }
    }

    @Override
    @DispatchPoint
    public void saveNetworkParams(NetworkConfigVO params) {
        ServerCommandEngine.Worker.UpdateNetworkConfigMessage msg = (ServerCommandEngine.Worker.UpdateNetworkConfigMessage)ServerCommandEngine.MessageFactory.instance().create(ServerCommandEngine.Worker.UpdateNetworkConfigMessage.class);
        msg.setParams(params);
        msg.setServerBean(this);
        msg.send();
    }

    @Override
    public void assignId(Id id) {
        this.setAssignedId(id);
    }

    @Override
    public String asString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Server:[").append(this.getName()).append("]");
        sb.append(" datastore:").append(this.getDatastore());
        sb.append(" network:").append(this.getNetwork());
        sb.append(" datastore:").append(this.getDatastore());
        sb.append(" status:").append((Object)this.getStatus());
        sb.append(" address:").append(this.getHost_address());
        sb.append(" user:").append(this.getHost_user());
        sb.append(" Hostinfo_version:").append(this.getHostinfo_version());
        sb.append(" password:").append("xxxx");
        return sb.toString();
    }

    @Override
    public List<String> getMACAddr() {
        try {
            return VMControlFactory.get(Config.Store.get()).getServerManager().getMACAddr();
        }
        catch (Exception e) {
            logger.error(e.toString());
            return new ArrayList<String>();
        }
    }

    @Override
    @DispatchPoint
    public ServerFront.HostInfoFront getHostInfoFront() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        try {
            if (serverManager != null) {
                return serverManager.getHostInfoFront();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return new ServerFront.HostInfoFront();
    }

    @Override
    @DispatchPoint
    public List<ServerFront.NodeInfoFront> getNodeInfoList() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        try {
            if (serverManager != null) {
                return serverManager.getNodesInfoFront();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return new ArrayList<ServerFront.NodeInfoFront>();
    }

    public void serverFault() {
    }

    @Override
    public void enterOnline() {
        this.setStatus(ServerStatus.STATUS_ACTIVATED);
    }

    @Override
    public void enterOffline(String reason) {
        try {
            if ("license".equals(reason)) {
                new TrackerService.Writer.Server().serverBroken(this).message("error.server.broken.nolicense", new String[0]);
            } else if ("serverClusterlicense".equals(reason)) {
                new TrackerService.Writer.Server().serverBroken(this).message("error.server.cluster.broken.nolicense", new String[0]);
            } else {
                new TrackerService.Writer.Server().serverBroken(this).message("error.server.broken", new String[]{"$address", this.getHost_address()});
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.setStatus(ServerStatus.STATUS_BROKEN);
    }

    @Override
    public boolean isOnline() {
        return ServerStatus.STATUS_ACTIVATED.equals((Object)this.getStatus());
    }

    @Override
    public NodeStatus getNodeStatus() {
        return (NodeStatus)((Object)this.getParam("nodeStatus"));
    }

    @Override
    public void setNodeStatus(NodeStatus status) {
        this.setParam((Object)"nodeStatus", (Object)status);
    }

    @Override
    public String getServiceName() {
        return "serverService";
    }

    @Override
    public ApiResult<ServerEntity> apiGet() {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        result.setEntity(this.serverEntityBinding.bindingForEntity(new ServerEntity(), this));
        return result;
    }

    @Override
    public ApiResult apiDelete() {
        return null;
    }

    private String nullToEmpty(String str) {
        return str == null ? "" : str;
    }

    @Override
    public ApiResult<ServerEntity> apiPut(ServerEntity entity) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        try {
            Config.VM cvm = new Config.VM(entity.getType());
            cvm.setParam("host_id", entity.getId().toString());
            cvm.setParam("host_address", this.nullToEmpty(entity.getAddress()));
            cvm.setParam("host_user", this.nullToEmpty(entity.getUsername()));
            cvm.setParam("host_password", this.nullToEmpty(entity.getPassword()));
            cvm.setParam("datastore", this.nullToEmpty(entity.getDatastore()));
            cvm.setParam("diskstore", this.nullToEmpty(entity.getDiskstore()));
            cvm.setParam("imagestore", this.nullToEmpty(entity.getImagestore()));
            cvm.setParam("network", this.nullToEmpty(entity.getNetwork()));
            cvm.asString();
            Config config = Config.Store.get();
            config.setVm(cvm);
            config.store();
            Services.getServerService().setCurrent(config);
        }
        catch (JYConfigServiceException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public String getResourcepool() {
        return (String)this.getParam("resourcepool");
    }

    @Override
    public void setResourcepool(String resourcepool) {
        this.setParam((Object)"resourcepool", resourcepool);
    }

    @Override
    @DispatchPoint
    public void applyPatch(byte[] fileData, String patchName) {
        try {
            PatchBean patch = new PatchBean();
            patch.loadPatchFile(fileData, patchName);
            patch.checkin();
            logger.info("serverName {} start patch", (Object)this.getName());
            PatchBean activePatchBean = PatchBean.readPreapplay();
            activePatchBean.apply();
        }
        catch (Exception e) {
            logger.error("Server Address :{},err:{}", (Object)this.getHost_address(), (Object)e.toString());
        }
    }

    @Override
    @DispatchPoint
    public String getServerMd5() {
        String rootWarPath = String.valueOf(System.getProperty("catalina.home")) + "/webapps/ROOT.war";
        return MD5Utils.getMd5ByFile(new File(rootWarPath));
    }

    @Override
    @DispatchPoint
    public void checkIPCollision(String requestedAddress) {
        NetUtils.checkIPCollision(requestedAddress);
    }

    @Override
    @DispatchPoint
    public boolean validateSignature() {
        String macAddress;
        String clusterName = ClusterNodeBean.getInstance().readClusterName();
        IClusterBean cluster = Services.getClusterService().getCluster();
        if (StringUtils.isEmpty((CharSequence)clusterName) || cluster == null) {
            logger.info(" find INodeSignatureBean  failed ,the clusterName:{},the cluster:{}", (Object)clusterName, (Object)cluster);
            return false;
        }
        String string = macAddress = StringUtils.isEmpty((CharSequence)this.getHost_macAddr()) ? this.getMACAddress() : this.getHost_macAddr();
        if (StringUtils.isNotEmpty((CharSequence)macAddress)) {
            String signature = MD5Utils.getMd5ByStr(String.valueOf(clusterName) + macAddress + cluster.getClusterLicense());
            for (INodeSignatureBean node : Services.getNodeSignatureServices().findAll()) {
                if (!StringUtils.equals((CharSequence)signature, (CharSequence)node.getSignature())) continue;
                return true;
            }
            logger.info("the serverBean[{}] find INodeSignatureBean  failed", (Object)this.getName());
        } else {
            logger.info("the serverBean[{}], the macAddress  is null", (Object)this.getName());
        }
        return false;
    }

    @Override
    @DispatchPoint
    public void syncLicense(byte[] licenseBuf) {
        LicenseService.loadByByteArray(licenseBuf, true);
    }

    @Override
    public void setNetworkStr(NetworkConfigVO vo) {
        this.setParam((Object)"networkStr", vo == null ? null : Base64Util.encodeData(JSON.toJSONString((Object)vo)));
    }

    @Override
    public void setNodeInfoListStr(List<ServerFront.NodeInfoFront> nodeList) {
        this.setParam((Object)"nodeInfoListStr", nodeList == null ? null : Base64Util.encodeData(JSON.toJSONString(nodeList)));
    }

    @Override
    public NetworkConfigVO getNetworkByStr() {
        String str = (String)this.getParam("networkStr");
        if (str == null) {
            return new NetworkConfigVO();
        }
        str = Base64Util.decodeData(str);
        return (NetworkConfigVO)JSON.parseObject((String)str, NetworkConfigVO.class);
    }

    @Override
    public List<ServerFront.NodeInfoFront> getNodeInfoListByStr() {
        String str = (String)this.getParam("nodeInfoListStr");
        if (str == null) {
            return new ArrayList<ServerFront.NodeInfoFront>();
        }
        str = Base64Util.decodeData(str);
        return JSON.parseArray((String)str, ServerFront.NodeInfoFront.class);
    }

    @Override
    public String getResourceAddress() {
        ResourceUrl resourceUrl;
        if ("vmware".equals(this.getHost_type()) && (resourceUrl = ResourceUrl.parse(this.getResourcepool())) != null && resourceUrl.isSingleHost()) {
            return resourceUrl.getResourceName();
        }
        return this.getHost_address();
    }

    @Override
    public boolean vmExistsOnLocal(String vmid) {
        return VMControlFactory.get(Config.Store.get()).getServerManager().vmExistsOnLocal(vmid);
    }

    @Override
    public void setWitness(boolean witness) {
        this.setParam((Object)"witness", witness);
    }

    @Override
    public boolean isWitness() {
        return (Boolean)this.getParam("witness");
    }

    @Override
    @DispatchPoint
    public void setMaxConnectionTime(int maxConnection) {
        Props props = Props.instance();
        props.set("user.conntime.max", maxConnection);
        props.store();
    }

    @Override
    @DispatchPoint
    public String getMACAddress() {
        List<String> maclist = this.getMACAddr();
        return this.getMACAddress(maclist);
    }

    @Override
    public String getMACAddress(List<String> macList) {
        if (macList == null || macList.size() == 0) {
            return "";
        }
        String hostMacAddr = this.getHost_macAddr();
        if (StringUtils.isNotEmpty((CharSequence)hostMacAddr)) {
            for (String macAddress : macList) {
                if (!StringUtils.equals((CharSequence)hostMacAddr, (CharSequence)macAddress)) continue;
                return macAddress;
            }
        }
        return macList.get(0);
    }

    @Override
    public String getBestNode(String vmName, VPower templatePower) {
        if (!this.isHaCluster() || !Config.Store.get().vmIs(Config.VM.Type.pve)) {
            return null;
        }
        Map<String, Double> nodeUseRate = this.getNodeUsageRate(templatePower);
        if (nodeUseRate.size() == 0) {
            return null;
        }
        if (nodeUseRate.size() == 1) {
            return nodeUseRate.keySet().iterator().next();
        }
        boolean loadbalancing = Props.instance().get("server.load.balancing", false);
        if (loadbalancing) {
            ArrayList<Map.Entry<String, Double>> list = new ArrayList<Map.Entry<String, Double>>(nodeUseRate.entrySet());
            Collections.sort(list, new Comparator<Map.Entry<String, Double>>(){

                @Override
                public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                    return o1.getValue().compareTo(o2.getValue());
                }
            });
            return (String)((Map.Entry)list.get(0)).getKey();
        }
        ArrayList<String> list = new ArrayList<String>(nodeUseRate.keySet());
        Collections.sort(list);
        return (String)list.get(Math.abs(vmName.hashCode() % list.size()));
    }

    private double getPower(String nodeName, Map<String, Double> powerMap) {
        Double power = powerMap.get(nodeName);
        return power == null ? 0.0 : power;
    }

    @Override
    public Map<String, NodeConfig> getOlinNode() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        return serverManager.getOlinNode();
    }

    @Override
    public Map<String, Double> getNodeUsageRate(VPower templatePower) {
        NodeConfig nodeConfig2;
        if (!this.isHaCluster() || !Config.Store.get().vmIs(Config.VM.Type.pve)) {
            return null;
        }
        HashMap<String, Double> powerMap = new HashMap<String, Double>();
        List<IInstanceBean> allInstances = Services.getInstanceService().findByServer(this.Id());
        Map<String, NodeConfig> onLineMaps = this.getOlinNode();
        for (NodeConfig nodeConfig2 : onLineMaps.values()) {
            powerMap.put(nodeConfig2.getNodesName(), templatePower == null ? 0.0 : templatePower.ratio(nodeConfig2.getPower()));
        }
        nodeConfig2 = null;
        String nodeName = null;
        double power = 0.0;
        for (IInstanceBean instance : allInstances) {
            InstanceStatus status = instance.getStatus();
            nodeConfig2 = onLineMaps.get(instance.getUpdate().getNodeName());
            if (nodeConfig2 == null || status.equals((Object)InstanceStatus.STANDING)) continue;
            nodeName = nodeConfig2.getNodesName();
            power = this.getPower(nodeName, powerMap);
            powerMap.put(nodeName, power += instance.getPower().ratio(nodeConfig2.getPower()));
        }
        Iterator it = powerMap.entrySet().iterator();
        double maxServerLoad = Props.instance().get("server.load.max", 0.95);
        Map.Entry entry = null;
        while (it.hasNext()) {
            entry = it.next();
            if (entry.getValue() != null && !((Double)entry.getValue() > maxServerLoad)) continue;
            it.remove();
        }
        return powerMap;
    }

    @Override
    public String getFloatServerIp() {
        String floatIp = ClusterNodeBean.getFloatIp();
        if (StringUtils.isEmpty((CharSequence)floatIp)) {
            floatIp = NetUtils.getHostIP();
        }
        return floatIp;
    }

    @Override
    public boolean isShared(String storage) {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        return serverManager.isShared(storage);
    }

    @Override
    public boolean checkStorageType(List<String> storageList) {
        if (storageList.size() <= 1 || !Config.Store.get().vmIs(Config.VM.Type.pve)) {
            return true;
        }
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        return serverManager.checkStorageType(storageList);
    }

    @Override
    public void setDiskType(String type) {
        this.setParam((Object)"diskType", type);
    }

    @Override
    public String getDiskType() {
        return (String)this.getParam("diskType");
    }

    @Override
    public String[] getLocalTemplateAppData() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        return serverManager.getLocalTemplateAppData(DpFileUtils.joinPathWindows(this.getDatastore(), TemplateAppDirUtils.getDir(TemplateAppType.LOCAL)));
    }

    @Override
    @DispatchPoint
    public void backImage(Id image) {
        Services.getImageService().findOne(image).back();
    }

    @Override
    public void syncLocalImageData() {
        Services.getTemplateAppService().syncLocal();
    }

    @Override
    public boolean existFile(String dir, String fileName) {
        return VMControlFactory.get(Config.Store.get()).getVMOperations().exist(dir, fileName);
    }

    @Override
    public IServerBean.Update setGpuDevices(List<GpuDevice> gpuDevices) {
        this.setParam("gpuDevices", gpuDevices);
        return this;
    }

    @Override
    public IServerBean.Update setMediateDevices(List<MediateDevice> mediateDevices) {
        this.setParam("mediateDevices", mediateDevices);
        return this;
    }

    @Override
    public List<GpuDevice> getGpuDevices() {
        List<GpuDevice> gpuDeviceList = null;
        try {
            gpuDeviceList = this.getParamList("gpuDevices", GpuDevice.class);
        }
        catch (JSONException ex) {
            ex.printStackTrace();
        }
        return gpuDeviceList;
    }

    @Override
    public List<MediateDevice> getMediateDevices() {
        String jsonStr = (String)this.getParam("mediateDevices");
        List<MediateDevice> mediateDevices = null;
        try {
            mediateDevices = this.getParamList("mediateDevices", MediateDevice.class);
        }
        catch (JSONException ex) {
            ex.printStackTrace();
        }
        return mediateDevices;
    }

    @Override
    public List<MediateDevice> getMediateDevices(boolean update) {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        this.setMediateDevices(serverManager.getMediateDevices(this));
        return this.getParamList("mediateDevices", MediateDevice.class);
    }
}
