/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IThinClientCertificateBean;
import com.jieyun.deskpool.domain.ThinClientCertificate;
import java.util.Date;

public static interface IThinClientCertificateBean.update
extends IThinClientCertificateBean,
Bean.Update<ThinClientCertificate> {
    public IThinClientCertificateBean.update setName(String var1);

    public IThinClientCertificateBean.update setCreateTime(Date var1);

    public IThinClientCertificateBean.update setFileUuid(String var1);

    public IThinClientCertificateBean.update setRemark(String var1);

    public IThinClientCertificateBean.update setEnable(boolean var1);
}
