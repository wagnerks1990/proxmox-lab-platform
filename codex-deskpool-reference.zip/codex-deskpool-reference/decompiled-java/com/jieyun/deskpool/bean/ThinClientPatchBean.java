/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IThinClientPatchBean;
import com.jieyun.deskpool.domain.ThinClientPatch;
import com.jieyun.deskpool.utils.Base64Util;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.DpGZipUtil;
import com.jieyun.deskpool.utils.DpThinClientPatchUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;

public class ThinClientPatchBean
extends DefaultBean<ThinClientPatch>
implements IThinClientPatchBean,
IThinClientPatchBean.Update {
    @Override
    public String getServiceName() {
        return "thinClientPatchService";
    }

    @Override
    public IThinClientPatchBean.Update setVersion(String version) {
        this.setParam((Object)"version", version);
        return this;
    }

    @Override
    public IThinClientPatchBean.Update setPatchName(String patchName) {
        this.setParam((Object)"patchName", patchName);
        return this;
    }

    @Override
    public IThinClientPatchBean.Update setFileName(String fileName) {
        this.setParam((Object)"fileName", fileName);
        return this;
    }

    @Override
    public IThinClientPatchBean.Update setPatchPath(String patchPath) {
        this.setParam((Object)"patchPath", patchPath);
        return this;
    }

    @Override
    public IThinClientPatchBean.Update setPatchMd5(String patchMd5) {
        this.setParam((Object)"patchMd5", patchMd5);
        return this;
    }

    @Override
    public IThinClientPatchBean.Update setRemark(String remark) {
        this.setParam((Object)"remark", remark);
        return this;
    }

    @Override
    public String getVersion() {
        return (String)this.getParam("version");
    }

    @Override
    public String getPatchName() {
        return (String)this.getParam("patchName");
    }

    @Override
    public String getFileName() {
        return (String)this.getParam("fileName");
    }

    @Override
    public String getPatchPath() {
        return (String)this.getParam("patchPath");
    }

    @Override
    public String getPatchMd5() {
        return (String)this.getParam("patchMd5");
    }

    @Override
    public String getRemark() {
        return (String)this.getParam("remark");
    }

    @Override
    public IThinClientPatchBean.Update getUpdate() {
        return (IThinClientPatchBean.Update)this.refresh();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean unpackUpdatePackage() {
        String scriptStr;
        FileOutputStream outs;
        FileInputStream is;
        String workDirPath;
        block11: {
            String packagePath = this.getPatchPath();
            String fileName = this.getFileName();
            workDirPath = packagePath.substring(0, packagePath.lastIndexOf(fileName));
            is = null;
            outs = null;
            is = new FileInputStream(new File(packagePath));
            byte[] md5 = new byte[1024];
            byte[] script = new byte[204800];
            String md5Str = null;
            if (((InputStream)is).read(md5, 0, 1024) == 1024) {
                md5Str = Base64Util.decodeData(new String(md5).trim());
                DpFileUtils.createAndWrite(String.valueOf(workDirPath) + "jyupdate.md5", md5Str);
            }
            scriptStr = null;
            if (((InputStream)is).read(script, 0, 204800) == 204800) {
                scriptStr = Base64Util.decodeData(new String(script).trim());
                DpFileUtils.createAndWrite(String.valueOf(workDirPath) + "jyupdate.sh", scriptStr);
            }
            File tar = new File(String.valueOf(workDirPath) + "jyupdate.tar.gz");
            outs = new FileOutputStream(tar);
            byte[] buffer = new byte[1024];
            int n = 0;
            while ((n = ((InputStream)is).read(buffer)) != -1) {
                outs.write(buffer, 0, n);
            }
            if (DpFileUtils.md5IsContains(md5Str, String.valueOf(workDirPath) + "jyupdate.sh") && DpFileUtils.md5IsContains(md5Str, String.valueOf(workDirPath) + "jyupdate.tar.gz")) break block11;
            DpFileUtils.closeQuietly(is);
            DpFileUtils.closeQuietly(outs);
            return false;
        }
        try {
            scriptStr = scriptStr.replace("tar zxvf jyupdate.tar.gz -C ./", "").replace("umount /tm/nfs", "").replace("umount /tmp/nfs", "");
            String version = null;
            if (scriptStr.contains("~/logoupdate")) {
                scriptStr = scriptStr.replace("~/logoupdate", "/home/root/logoupdate");
                String logoUpdate = "/home/root/logoupdate";
                int uiVersionStart = scriptStr.indexOf(logoUpdate) - 16;
                version = scriptStr.substring(uiVersionStart, uiVersionStart + 14);
            } else if (scriptStr.contains("~/lastupdate")) {
                scriptStr = scriptStr.replace("~/lastupdate", "/home/root/lastupdate");
                String lastUpdate = "/home/root/lastupdate";
                int lastUpdateStart = scriptStr.lastIndexOf(lastUpdate) - 16;
                version = scriptStr.substring(lastUpdateStart, lastUpdateStart + 14);
            }
            this.setVersion(version);
            DpFileUtils.createAndWrite(String.valueOf(workDirPath) + "jyupdate.sh", scriptStr);
            DpGZipUtil.unTarGz(String.valueOf(workDirPath) + "jyupdate.tar.gz", workDirPath);
            DpThinClientPatchUtils.chomdPatch(this.getFileUuid());
        }
        catch (Exception ex) {
            try {
                DpFileUtils.delete(this.getPatchPath());
                ex.printStackTrace();
            }
            catch (Throwable throwable) {
                DpFileUtils.closeQuietly(is);
                DpFileUtils.closeQuietly(outs);
                throw throwable;
            }
            DpFileUtils.closeQuietly(is);
            DpFileUtils.closeQuietly(outs);
            return false;
        }
        DpFileUtils.closeQuietly(is);
        DpFileUtils.closeQuietly(outs);
        return true;
    }

    @Override
    public void delete() {
        String id = this.Id().toSerializeId();
        this.remove();
        DpFileUtils.delete(DpThinClientPatchUtils.getPatchFilePath(id));
    }

    @Override
    public IThinClientPatchBean.Update setFileUuid(String fileUuid) {
        this.setParam((Object)"fileUuid", fileUuid);
        return this;
    }

    @Override
    public String getFileUuid() {
        return (String)this.getParam("fileUuid");
    }

    @Override
    public Date getCreatetime() {
        return (Date)this.getParam("createtime");
    }

    @Override
    public IThinClientPatchBean.Update setCreatetime(Date createtime) {
        this.setParam((Object)"createtime", createtime);
        return this;
    }

    @Override
    public String getNfsPath() {
        File patchFile;
        String patch = this.getPatchPath();
        if (StringUtils.isNotEmpty((CharSequence)patch) && (patchFile = new File(patch)).exists()) {
            return patchFile.getParent();
        }
        return null;
    }
}
