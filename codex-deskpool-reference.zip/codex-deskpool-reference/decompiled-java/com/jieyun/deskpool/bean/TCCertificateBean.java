/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.ITCCertificateBean;
import com.jieyun.deskpool.domain.TCCertificate;
import com.jieyun.deskpool.utils.DpStringUtils;
import java.util.regex.Pattern;

public class TCCertificateBean
extends DefaultBean<TCCertificate>
implements ITCCertificateBean,
ITCCertificateBean.Update {
    @Override
    public String getServiceName() {
        return "tcCertificateService";
    }

    @Override
    public ITCCertificateBean.Update setType(String type) {
        this.setParam((Object)"type", type);
        return this;
    }

    @Override
    public ITCCertificateBean.Update setSnReg(String snReg) {
        this.setParam((Object)"snReg", snReg);
        return this;
    }

    @Override
    public String getType() {
        return (String)this.getParam("type");
    }

    @Override
    public String getSnReg() {
        return (String)this.getParam("snReg");
    }

    @Override
    public ITCCertificateBean.Update getUpdate() {
        return (ITCCertificateBean.Update)this.refresh();
    }

    @Override
    public boolean isEffective(String sn) {
        String snReg = this.getSnReg();
        if (DpStringUtils.paramsIsNotNull(sn, snReg)) {
            sn = sn.toLowerCase().trim();
            snReg = snReg.toLowerCase().trim();
            return Pattern.matches(snReg, sn);
        }
        return false;
    }
}
