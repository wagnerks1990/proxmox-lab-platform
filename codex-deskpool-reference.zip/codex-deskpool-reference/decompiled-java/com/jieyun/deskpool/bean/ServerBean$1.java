/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import java.util.Comparator;
import java.util.Map;

class ServerBean.1
implements Comparator<Map.Entry<String, Double>> {
    ServerBean.1() {
    }

    @Override
    public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
        return o1.getValue().compareTo(o2.getValue());
    }
}
