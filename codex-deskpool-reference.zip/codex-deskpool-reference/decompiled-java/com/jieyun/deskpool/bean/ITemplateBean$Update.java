/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Template;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DeviceMapping;
import com.jieyun.deskpool.shared.IPPolicy;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.RfxAdaptor;
import com.jieyun.deskpool.shared.StoragePolicy;
import com.jieyun.deskpool.shared.TemplatePolicy;
import com.jieyun.deskpool.shared.VgpuType;
import java.util.List;

public static interface ITemplateBean.Update
extends ITemplateBean,
Bean.Update<Template> {
    public ITemplateBean.Update setName(String var1);

    public ITemplateBean.Update setDescription(String var1);

    public ITemplateBean.Update setImage(IImageBean var1);

    public ITemplateBean.Update setPrefix(String var1);

    public ITemplateBean.Update setSuffix(String var1);

    public ITemplateBean.Update setDefault(boolean var1);

    public ITemplateBean.Update setMemory(Integer var1);

    public ITemplateBean.Update setCores(Integer var1);

    public ITemplateBean.Update setSockets(Integer var1);

    public ITemplateBean.Update setDevicmap(DeviceMapping var1);

    public ITemplateBean.Update setPolicy(TemplatePolicy var1);

    public ITemplateBean.Update setStoragePolicy(StoragePolicy var1);

    public ITemplateBean.Update setPoolInfo(PoolInfo var1);

    public ITemplateBean.Update setPoolType(PoolType var1);

    public ITemplateBean.Update setNetwork(String var1);

    public ITemplateBean.Update setEnableVlanTag(boolean var1);

    public ITemplateBean.Update setVlanid(Integer var1);

    public ITemplateBean.Update setColorDepth(Desktop.ColorDepth var1);

    public ITemplateBean.Update rebuildRetiredInstances(Id var1);

    public ITemplateBean.Update regenerateInstances();

    public void setRfxAdaptor(RfxAdaptor var1);

    public ITemplateBean.Update save();

    public ITemplateBean.Update setImageId(Id var1);

    public ITemplateBean.Update setProtocols(List<Desktop.Protocol> var1);

    public ITemplateBean.Update setEnableGfxH264(Boolean var1);

    public ITemplateBean.Update setIPPolicy(IPPolicy var1);

    public ITemplateBean.Update setEnableSgw(boolean var1);

    public ITemplateBean.Update setVgpu(VgpuType var1);

    public ITemplateBean.Update setGpuDevice(String var1);
}
