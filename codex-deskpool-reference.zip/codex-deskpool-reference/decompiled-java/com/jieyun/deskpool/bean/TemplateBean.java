/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.PoolEntity;
import com.jieyun.deskpool.api.data.PoolEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Template;
import com.jieyun.deskpool.service.ImageService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TemplateService;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DeviceMapping;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.IPPolicy;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.NetworkModel;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.RefreshPolicy;
import com.jieyun.deskpool.shared.RfxAdaptor;
import com.jieyun.deskpool.shared.StoragePolicy;
import com.jieyun.deskpool.shared.TemplatePolicy;
import com.jieyun.deskpool.shared.TemplateStatus;
import com.jieyun.deskpool.shared.VMNetworkConfig;
import com.jieyun.deskpool.shared.VPower;
import com.jieyun.deskpool.shared.VgpuType;
import com.jieyun.deskpool.utils.DpStringUtils;
import com.jieyun.deskpool.utils.IPv4Util;
import com.jieyun.deskpool.utils.Props;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class TemplateBean
extends DefaultBean<Template>
implements ITemplateBean,
ITemplateBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(TemplateBean.class);
    private static final int SCHEDULING_DELAY = Props.instance().get("server.Scheduling.delay", 10);
    @Autowired
    ImageService imageService;
    @Autowired
    TemplateService templateService;
    @Autowired
    PoolEntityBinding poolEntityBinding;

    @Override
    public void postConstruct() {
        TemplatePolicy policy = new TemplatePolicy();
        policy.setMaximum(0);
        policy.setPrestart(0);
        policy.setReassignOnhold(false);
        policy.setRefresh(RefreshPolicy.ON_LOGOUT);
        policy.setSequenceName(!Props.instance().get("instance.name.random", true));
        policy.setFastRegenerate(true);
        this.setPolicy(policy);
        StoragePolicy storagepolicy = new StoragePolicy();
        storagepolicy.setSecondDiskSize(null);
        storagepolicy.setUserDiskSet(null);
        storagepolicy.setUserDiskSize(null);
        this.setStatus(TemplateStatus.ACTIVE);
    }

    @Override
    public Template getData() {
        return null;
    }

    @Override
    public ITemplateBean.Update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public ITemplateBean.Update setDescription(String description) {
        this.setParam((Object)"description", description);
        return this;
    }

    @Override
    public ITemplateBean.Update setImage(IImageBean image) {
        this.setParam((Object)"image", image.Id().getId());
        return this;
    }

    @Override
    public ITemplateBean.Update setImageId(Id imageId) {
        this.setParam((Object)"image", imageId.getId());
        return this;
    }

    @Override
    public ITemplateBean.Update setPrefix(String prefix) {
        this.setParam((Object)"prefix", prefix);
        return this;
    }

    @Override
    public ITemplateBean.Update setSuffix(String suffix) {
        this.setParam((Object)"suffix", suffix);
        return this;
    }

    @Override
    public ITemplateBean.Update setDefault(boolean isdefault) {
        ITemplateBean oldDefault;
        if (isdefault && (oldDefault = Services.getTemplateService().getDefaultTemplate()) != null) {
            oldDefault.getUpdate().setDefault(false).save();
        }
        this.setParam((Object)"isdefault", isdefault);
        return this;
    }

    @Override
    public ITemplateBean.Update setMemory(Integer memory) {
        this.setParam((Object)"memory", memory);
        return this;
    }

    @Override
    public ITemplateBean.Update setCores(Integer cores) {
        this.setParam((Object)"cores", cores);
        return this;
    }

    @Override
    public ITemplateBean.Update setSockets(Integer sockets) {
        this.setParam((Object)"sockets", sockets);
        return this;
    }

    @Override
    public ITemplateBean.Update setDevicmap(DeviceMapping devicmap) {
        this.setParam((Object)"devicmap", devicmap);
        return this;
    }

    @Override
    public ITemplateBean.Update setPolicy(TemplatePolicy templatepolicy) {
        this.setParam((Object)"templatepolicy", templatepolicy);
        return this;
    }

    @Override
    public ITemplateBean.Update setStoragePolicy(StoragePolicy storagepolicy) {
        this.setParam((Object)"storagepolicy", storagepolicy);
        return this;
    }

    @Override
    public ITemplateBean.Update setPoolInfo(PoolInfo poolinfo) {
        this.setParam((Object)"poolinfo", poolinfo);
        return this;
    }

    @Override
    public ITemplateBean.Update setNetwork(String network) {
        this.setParam((Object)"network", network);
        return this;
    }

    @Override
    public ITemplateBean.Update setEnableVlanTag(boolean enableVlanTag) {
        this.setParam((Object)"enableVlanTag", enableVlanTag);
        return this;
    }

    @Override
    public ITemplateBean.Update setVlanid(Integer vlanid) {
        this.setParam((Object)"vlanid", vlanid);
        return this;
    }

    @Override
    public ITemplateBean.Update setColorDepth(Desktop.ColorDepth depth) {
        this.setParam((Object)"colordepth", (Object)depth);
        return this;
    }

    @Override
    public PoolType getPoolType() {
        return (PoolType)((Object)this.getParam("poolType"));
    }

    @Override
    public ITemplateBean.Update setPoolType(PoolType poolType) {
        this.setParam((Object)"poolType", (Object)poolType);
        return this;
    }

    @Override
    public boolean isDedicated() {
        return PoolType.DEDICATED.equals((Object)this.getPoolType());
    }

    @Override
    public boolean isPooled() {
        return PoolType.POOLED.equals((Object)this.getPoolType());
    }

    @Override
    public boolean isPersistent() {
        if (this.isDedicated()) {
            return true;
        }
        return RefreshPolicy.NEVER.equals((Object)this.getPolicy().getRefresh());
    }

    @Override
    public boolean isSequenceName() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getSequenceName();
            if (result == null) {
                return !Props.instance().get("instance.name.random", true);
            }
            return result;
        }
        return false;
    }

    @Override
    public boolean isReassignOnhold() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getReassignOnhold();
            if (result == null) {
                return false;
            }
            return result;
        }
        return false;
    }

    @Override
    public boolean isReserveForUser() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getReserveForUser();
            if (result == null) {
                return false;
            }
            return result;
        }
        return false;
    }

    @Override
    public boolean isEnableSchedule() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getEnableSchedule();
            if (result == null) {
                return false;
            }
            return result;
        }
        return false;
    }

    @Override
    public boolean inStatus(TemplateStatus status) {
        return status.equals((Object)this.getStatus());
    }

    public List<IGroupBean> getClassGroup() {
        return Services.getGroupService().findByTemplate(this.Id());
    }

    @Override
    public boolean updateStatus(List<IGroupBean> classList) {
        TemplateStatus currentStatus;
        TemplateStatus newStatus = currentStatus = this.getStatus();
        if (this.isEnableSchedule()) {
            boolean duringClass = false;
            if (classList != null) {
                for (IGroupBean group : classList) {
                    if (!group.isActiveTemplate(this.Id())) continue;
                    newStatus = TemplateStatus.ACTIVE;
                    duringClass = true;
                }
            }
            if (!duringClass) {
                Date now = new Date();
                newStatus = Services.getScheduleEventService().getByTemplate(this.Id(), now);
            }
        } else {
            newStatus = TemplateStatus.ACTIVE;
        }
        if (!newStatus.equals((Object)currentStatus)) {
            logger.info("updateStatus : Template {} status from {} to {}", new Object[]{this, currentStatus, newStatus});
            this.setStatus(newStatus);
            return true;
        }
        return false;
    }

    @Override
    public boolean updateStatus() {
        List<IGroupBean> grouplist = this.getClassGroup();
        return this.updateStatus(grouplist);
    }

    public ITemplateBean.Update setStatus(TemplateStatus status) {
        this.setParam((Object)"status", (Object)status);
        return this;
    }

    @Override
    public TemplateStatus getStatus() {
        return (TemplateStatus)((Object)this.getParam("status", (Object)TemplateStatus.ACTIVE));
    }

    @Override
    public boolean isFastGenerate() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getFastRegenerate();
            if (result == null) {
                return false;
            }
            return result;
        }
        return false;
    }

    @Override
    public boolean isEnableModifyBinding() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getEnableModifyBinding();
            if (result == null) {
                return true;
            }
            return result;
        }
        return true;
    }

    @Override
    public boolean isForceSuffixMatch() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getForceSuffixMatch();
            if (result == null) {
                return false;
            }
            return result;
        }
        return false;
    }

    @Override
    public boolean isAutoFillBinding() {
        TemplatePolicy policy = this.getPolicy();
        if (policy != null) {
            Boolean result = policy.getAutoFillBinding();
            if (result == null) {
                return true;
            }
            return result;
        }
        return true;
    }

    @Override
    public boolean isDynamic() {
        return this.isPooled() && this.getPolicy().getRefresh().equals((Object)RefreshPolicy.ON_LOGOUT);
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public String getDescription() {
        return (String)this.getParam("description");
    }

    @Override
    public IImageBean getImage() {
        Long imageid = (Long)this.getParam("image");
        return imageid == null ? null : this.imageService.findOne(Id.construct(imageid));
    }

    @Override
    public Id getImageId() {
        Long imageid = (Long)this.getParam("image");
        return imageid == null ? null : Id.construct(imageid);
    }

    @Override
    public String getPrefix() {
        return (String)this.getParam("prefix");
    }

    @Override
    public String getSuffix() {
        return (String)this.getParam("suffix");
    }

    @Override
    public boolean isDefault() {
        return this.booleanValue(this.getParam("isdefault"));
    }

    @Override
    public Integer getMemory() {
        return (Integer)this.getParam("memory");
    }

    @Override
    public Integer getCores() {
        return (Integer)this.getParam("cores");
    }

    @Override
    public Integer getSockets() {
        return (Integer)this.getParam("sockets");
    }

    @Override
    public DeviceMapping getDevicmap() {
        return (DeviceMapping)this.getParam("devicmap");
    }

    @Override
    public TemplatePolicy getPolicy() {
        TemplatePolicy policy = (TemplatePolicy)this.getParam("templatepolicy");
        if (policy == null) {
            policy = new TemplatePolicy();
        }
        if (policy.getSequenceName() == null) {
            policy.setSequenceName(!Props.instance().get("instance.name.random", true));
        }
        return policy;
    }

    @Override
    public List<Desktop.Protocol> getProtocols() {
        return this.getParamList("protocols", Desktop.Protocol.class);
    }

    @Override
    public ITemplateBean.Update setProtocols(List<Desktop.Protocol> protocols) {
        this.setParam("protocols", protocols);
        return this;
    }

    @Override
    public boolean isEnableGfxH264() {
        return this.booleanValue(this.getParam("enableGfxH264"));
    }

    @Override
    public ITemplateBean.Update setEnableGfxH264(Boolean enableGfxH264) {
        this.setParam((Object)"enableGfxH264", enableGfxH264);
        return this;
    }

    @Override
    public StoragePolicy getStoragePolicy() {
        StoragePolicy policy = (StoragePolicy)this.getParam("storagepolicy");
        if (policy == null) {
            policy = new StoragePolicy();
        }
        return policy;
    }

    @Override
    public PoolInfo getPoolInfo() {
        PoolInfo poolinfo = (PoolInfo)this.getParam("poolinfo");
        if (poolinfo == null) {
            poolinfo = new PoolInfo();
            poolinfo.setIdle(0);
            poolinfo.setInuse(0);
            poolinfo.setBroken(0);
            poolinfo.setOnhold(0);
            poolinfo.setStarting(0);
            poolinfo.setOther(0);
            poolinfo.setTotal(0);
            poolinfo.setRunning(0);
        }
        return poolinfo;
    }

    @Override
    public String getGuestos() {
        IImageBean image = this.getImage();
        return image.getImageInfo().getGuestos();
    }

    @Override
    public String getNetwork() {
        return (String)this.getParam("network");
    }

    @Override
    public boolean isEnableVlanTag() {
        return this.booleanValue(this.getParam("enableVlanTag"));
    }

    @Override
    public Integer getVlanid() {
        return (Integer)this.getParam("vlanid");
    }

    @Override
    public Desktop.ColorDepth getColorDepth() {
        RfxAdaptor rfx = this.getRfxAdaptor();
        if (rfx != null && rfx.isEnable()) {
            return Desktop.ColorDepth.COLOR32BIT;
        }
        return (Desktop.ColorDepth)((Object)this.getParam("colordepth", (Object)Desktop.ColorDepth.COLOR16BIT));
    }

    @Override
    List<ErrorMessage> validate() {
        ITemplateBean foundBean;
        List<ErrorMessage> errList = super.validate();
        if (this.getPolicy().getMaximum() < this.getPolicy().getPrestart()) {
            errList.add(new ErrorMessage("error.bean.template.max.less.prestart"));
        }
        if ((foundBean = this.templateService.findByName(this.getName())) != null && (this.isNew() || !foundBean.Id().equals(this.Id()))) {
            errList.add(new ErrorMessage("error.bean.template.name.duplicated"));
        }
        if ((foundBean = this.templateService.findByPrefix(this.getPrefix())) != null && (this.isNew() || !foundBean.Id().equals(this.Id()))) {
            errList.add(new ErrorMessage("error.bean.template.prefix.duplicated"));
        }
        return errList;
    }

    @Override
    public ITemplateBean.Update save() {
        List<IInstanceBean> instanceList;
        ITemplateBean compared = (ITemplateBean)this.refresh();
        if (this.isDedicated() && !compared.getImageId().equals(this.getImageId()) && (instanceList = Services.getInstanceService().findByTemplate(this.Id())).size() > 0) {
            throw new JYServiceRuntimeException("error.bean.template.instance.notempty", "\u684c\u9762\u6c60\u5185\u8fd8\u6709\u865a\u62df\u673a\u65f6\uff0c\u4e0d\u5141\u8bb8\u4e3a\u684c\u9762\u6c60\u9009\u62e9\u5176\u4ed6\u6a21\u677f\u3002");
        }
        super.save();
        return this;
    }

    @Override
    public VPower getPower() {
        double cores = 1.0;
        double cpu = 1.0;
        double mem = 1024.0;
        if (this.getCores() != null) {
            cores = this.getCores() * this.getSockets();
        }
        if (this.getMemory() != null) {
            mem = this.getMemory().intValue();
        }
        return new VPower(cores, cpu, mem);
    }

    @Override
    public RfxAdaptor getRfxAdaptor() {
        return (RfxAdaptor)this.getParam("rfxAdaptor");
    }

    @Override
    public void setRfxAdaptor(RfxAdaptor rfxAdaptor) {
        this.setParam((Object)"rfxAdaptor", rfxAdaptor);
    }

    @Override
    public ITemplateBean.Update getUpdate() {
        this.lock();
        return (ITemplateBean.Update)this.refresh();
    }

    @Override
    public boolean shouldCheckpint() {
        return this.isPooled();
    }

    @Override
    public void enforceSchedule() {
        block5: {
            boolean isSpecified;
            List<IInstanceBean> instances;
            Desktop.SchedulingModel scheduling;
            block4: {
                scheduling = this.getSchedulingModel();
                instances = Services.getInstanceService().findByTemplate(this.Id());
                isSpecified = this.isSpecified();
                logger.debug("enforceTemplateSchedule {} status {} ,scheduling:{},isSpecified\uff1a{}", new Object[]{this.getName(), this.getStatus(), scheduling, isSpecified});
                if (!this.inStatus(TemplateStatus.ACTIVE)) break block4;
                for (IInstanceBean instance : instances) {
                    if (!instance.isLocal() || !instance.isSleeped()) continue;
                    instance.delaystart(SCHEDULING_DELAY);
                }
                break block5;
            }
            if (!this.inStatus(TemplateStatus.SLEEP)) break block5;
            for (IInstanceBean instance : instances) {
                if (!instance.isLocal()) continue;
                if (InstanceStatus.RUNNING.equals((Object)instance.getStatus()) || InstanceStatus.SHUTDOWN.equals((Object)instance.getStatus())) {
                    if (scheduling == Desktop.SchedulingModel.FREE && instance.isLastLogin() || isSpecified) continue;
                    if (instance.isCheckpointed()) {
                        instance.regenerate();
                        continue;
                    }
                    instance.destroy();
                    continue;
                }
                if (!instance.isSleeped() || !isSpecified) continue;
                instance.delaystart(SCHEDULING_DELAY);
            }
        }
    }

    @Override
    public boolean hasSecondDisk() {
        Integer secondDiskSize = this.getSecondDiskSize();
        return secondDiskSize != null && secondDiskSize > 0;
    }

    @Override
    public Integer getSecondDiskSize() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return storagepolicy.getSecondDiskSize();
    }

    @Override
    public long getSecondDiskSizeMB() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return (long)storagepolicy.getSecondDiskSize().intValue() * 1024L;
    }

    @Override
    public boolean hasUserDisk() {
        return this.hasUserDiskSize() && this.hasUserDiskSet();
    }

    public boolean hasUserDiskSize() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return storagepolicy.getUserDiskSize() != null && storagepolicy.getUserDiskSize() > 0;
    }

    public boolean hasUserDiskSet() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return StringUtils.isNotBlank((CharSequence)storagepolicy.getUserDiskSet());
    }

    @Override
    public Integer getUserDiskSize() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return storagepolicy.getUserDiskSize();
    }

    @Override
    public long getUserDiskSizeMB() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return (long)storagepolicy.getUserDiskSize().intValue() * 1024L;
    }

    @Override
    public String getUserDiskSet() {
        StoragePolicy storagepolicy = this.getStoragePolicy();
        return storagepolicy.getUserDiskSet();
    }

    @Override
    public void destroy() {
        List<IAccountBean> list = Services.getAccountService().findByTemplate(this.Id());
        for (IAccountBean user : list) {
            user.removeTemplate(this);
            user.save();
        }
        List<IGroupBean> grplist = Services.getGroupService().findByTemplate(this.Id());
        for (IGroupBean group : grplist) {
            group.removeTemplate(this);
            group.save();
        }
        List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(this.Id());
        if (instanceList.size() > 0) {
            List<ErrorMessage> errList = super.validate();
            errList.add(new ErrorMessage("error.bean.template.instance.existed"));
            throw new JYServiceRuntimeException(errList);
        }
        this.remove();
        new TrackerService.Writer.Template().delete(this).complete("template.delete.complete", this, new String[0]);
    }

    @Override
    public String getServiceName() {
        return "templateService";
    }

    @Override
    public String getSecondDiskName(IInstanceBean instance) {
        return String.valueOf(instance.getName()) + "diskD";
    }

    @Override
    public String getUserDiskName(IAccountBean user) {
        return String.valueOf(user.getName()) + "_" + this.getUserDiskSet();
    }

    @Override
    public ITemplateBean.Update rebuildRetiredInstances(Id imageId) {
        if (imageId != null && !imageId.equals(this.getImageId())) {
            this.setImageId(imageId).save();
        }
        List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(this.Id());
        for (IInstanceBean instance : instanceList) {
            instance.getUpdate().rebuild();
        }
        return this;
    }

    @Override
    public boolean isFreshOnboot() {
        return this.getPolicy().getRefresh().equals((Object)RefreshPolicy.SERVER_BOOT);
    }

    @Override
    public ITemplateBean.Update regenerateInstances() {
        if (!this.shouldCheckpint()) {
            logger.error("Template {} can't be regenerate. ", (Object)this);
            return this;
        }
        try {
            List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(this.Id());
            for (IInstanceBean instance : instanceList) {
                instance.regenerate();
            }
        }
        catch (Exception ex) {
            logger.error("Template {} regenerate error {} ", (Object)this, (Object)ex.getMessage());
        }
        return this;
    }

    @Override
    public ApiResult<PoolEntity> apiGet() {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        result.setEntity(this.poolEntityBinding.bindingForEntity(new PoolEntity(), this));
        return result;
    }

    @Override
    public ApiResult<PoolEntity> apiPut(PoolEntity entity) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        try {
            ITemplateBean bean = this.poolEntityBinding.bindingForBean(entity, this);
            bean.save();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<PoolEntity> apiDelete() {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        try {
            this.destroy();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getErrorList());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public Desktop.SchedulingModel getSchedulingModel() {
        Desktop.SchedulingModel model = Desktop.SchedulingModel.OTHER;
        Desktop.SchedulingModel groupModel = null;
        for (IGroupBean group : Services.getGroupService().findByTemplate(this.Id())) {
            groupModel = group.getSchedulingModel();
            if (groupModel.compareTo(model) <= 0) continue;
            model = group.getSchedulingModel();
        }
        return model;
    }

    @Override
    public boolean isSingleImage() {
        return this.getSchedulingModel() == Desktop.SchedulingModel.FREE;
    }

    @Override
    public boolean isSpecified() {
        for (IGroupBean group : Services.getGroupService().findByTemplate(this.Id())) {
            if (group.getSchedulingModel() != Desktop.SchedulingModel.SPECIFIED || !this.Id().equals(group.getSpecifiedPoolId())) continue;
            return true;
        }
        return false;
    }

    @Override
    public String getOu() {
        TemplatePolicy policy = this.getPolicy();
        String ou = null;
        if (policy != null) {
            ou = policy.getOu();
        }
        return ou == null ? "" : ou;
    }

    @Override
    public IPPolicy getIpPolicy() {
        IPPolicy policy = (IPPolicy)this.getParam("ipPolicy");
        if (policy == null) {
            policy = new IPPolicy();
        }
        return policy;
    }

    @Override
    public int getVmIndex(String vm) {
        String preFix = this.getPrefix();
        String suffix = this.getSuffix();
        if (StringUtils.isNotEmpty((CharSequence)vm) && StringUtils.isNotEmpty((CharSequence)preFix) && StringUtils.isNotEmpty((CharSequence)suffix)) {
            String indexStr = vm.replace(preFix, "");
            return DpStringUtils.stringToInt(indexStr) - DpStringUtils.stringToInt(suffix);
        }
        return -1;
    }

    @Override
    public ITemplateBean.Update setIPPolicy(IPPolicy ipPolicy) {
        this.setParam((Object)"ipPolicy", ipPolicy);
        return this;
    }

    @Override
    public VMNetworkConfig getVMNetWorkConfig(String vmName) {
        IPPolicy ipPolicy = this.getIpPolicy();
        if (ipPolicy.isEnable()) {
            int ipIndex = this.getVmIndex(vmName);
            String ip = IPv4Util.getIp(ipPolicy.getStartIp(), ipPolicy.getEndIp(), ipIndex);
            if (StringUtils.isNotEmpty((CharSequence)ip)) {
                VMNetworkConfig vmNetworkConfig = new VMNetworkConfig();
                vmNetworkConfig.setIp(ip);
                vmNetworkConfig.setSubnetMask(ipPolicy.getSubnetMask());
                vmNetworkConfig.setGateWay(ipPolicy.getGateWay());
                vmNetworkConfig.setDnsServer(ipPolicy.getFirstDNS());
                vmNetworkConfig.setDnsServer1(ipPolicy.getLastDNS());
                vmNetworkConfig.setMode(NetworkModel.HAND);
                vmNetworkConfig.setLinux(this.isLinux());
                return vmNetworkConfig;
            }
        }
        return null;
    }

    @Override
    public List<IInstanceBean> getInstance() {
        return Services.getInstanceService().findByTemplate(this.Id());
    }

    @Override
    public boolean isLinux() {
        IImageBean image = this.getImage();
        return image == null ? false : image.isLinux();
    }

    @Override
    public boolean isDrift() {
        return this.isPooled() && this.getPolicy().getRefresh().equals((Object)RefreshPolicy.DISCONNET);
    }

    @Override
    public ITemplateBean.Update setEnableSgw(boolean enableSgw) {
        this.setParam((Object)"enableSgw", enableSgw);
        return this;
    }

    @Override
    public boolean isEnableSgw() {
        return this.booleanValue(this.getParam("enableSgw"));
    }

    @Override
    public String getGpuDevice() {
        return (String)this.getParam("gpuDevice");
    }

    @Override
    public VgpuType getVgpu() {
        return (VgpuType)this.getParam("vgpu");
    }

    @Override
    public ITemplateBean.Update setGpuDevice(String gpuDevice) {
        logger.info("setGpuDevice :{}", (Object)gpuDevice);
        this.setParam((Object)"gpuDevice", gpuDevice);
        return this;
    }

    @Override
    public ITemplateBean.Update setVgpu(VgpuType vgpu) {
        this.setParam((Object)"vgpu", vgpu);
        return this;
    }
}
