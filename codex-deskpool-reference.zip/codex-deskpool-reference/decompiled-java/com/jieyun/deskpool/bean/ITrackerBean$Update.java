/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ITrackerBean;
import com.jieyun.deskpool.domain.Tracker;

public static interface ITrackerBean.Update
extends ITrackerBean,
Bean.Update<Tracker> {
}
