/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.ILicenseLogBean;
import com.jieyun.deskpool.domain.LicenseLog;

public class LicenseLogBean
extends DefaultBean<LicenseLog>
implements ILicenseLogBean,
ILicenseLogBean.Update {
    @Override
    public String getServiceName() {
        return "licenseLogService";
    }

    @Override
    public void setProduct(String product) {
        this.setParam((Object)"product", product);
    }

    @Override
    public void setAssignee(String assignee) {
        this.setParam((Object)"assignee", assignee);
    }

    @Override
    public void setVersion(String version) {
        this.setParam((Object)"version", version);
    }

    @Override
    public void setExpireDays(String expireDays) {
        this.setParam((Object)"expireDays", expireDays);
    }

    @Override
    public void setLicenseType(String licenseType) {
        this.setParam((Object)"licenseType", licenseType);
    }

    @Override
    public void setDesktopLimit(String desktopLimit) {
        this.setParam((Object)"desktopLimit", desktopLimit);
    }

    @Override
    public void setFeatureCode(String featureCode) {
        this.setParam((Object)"featureCode", featureCode);
    }

    @Override
    public void setCreateTime(String createTime) {
        this.setParam((Object)"createTime", createTime);
    }

    @Override
    public String getProduct() {
        return (String)this.getParam("product");
    }

    @Override
    public String getAssignee() {
        return (String)this.getParam("assignee");
    }

    @Override
    public String getVersion() {
        return (String)this.getParam("version");
    }

    @Override
    public String getExpireDays() {
        return (String)this.getParam("expireDays");
    }

    @Override
    public String getLicenseType() {
        return (String)this.getParam("licenseType");
    }

    @Override
    public String getDesktopLimit() {
        return (String)this.getParam("desktopLimit");
    }

    @Override
    public String getFeatureCode() {
        return (String)this.getParam("featureCode");
    }

    @Override
    public String getCreateTime() {
        return (String)this.getParam("createTime");
    }

    @Override
    public ILicenseLogBean.Update getUpdate() {
        return (ILicenseLogBean.Update)this.refresh();
    }

    @Override
    public void setSessionLimit(String sessionLimit) {
        this.setParam((Object)"sessionLimit", sessionLimit);
    }

    @Override
    public String getSessionLimit() {
        return (String)this.getParam("sessionLimit");
    }

    @Override
    public void setCreateIp(String createIp) {
        this.setParam((Object)"createIp", createIp);
    }

    @Override
    public String getCreateIp() {
        return (String)this.getParam("createIp");
    }
}
