/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.INodeSignatureBean;
import com.jieyun.deskpool.domain.NodeSignature;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.utils.MD5Utils;

public class NodeSignatureBean
extends DefaultBean<NodeSignature>
implements INodeSignatureBean,
INodeSignatureBean.Update {
    @Override
    public String getServiceName() {
        return "nodeSignatureService";
    }

    @Override
    public String getSignature() {
        return (String)this.getParam("signature");
    }

    @Override
    public INodeSignatureBean.Update setServerId(Id serverId) {
        this.setIdParam("server", serverId);
        return this;
    }

    @Override
    public INodeSignatureBean.Update getUpdate() {
        return (INodeSignatureBean.Update)this.refresh();
    }

    @Override
    public INodeSignatureBean.Update setSignature(String singnature) {
        this.setParam((Object)"signature", singnature);
        return this;
    }

    @Override
    public INodeSignatureBean.Update setCluster(Id clusterId) {
        this.setIdParam("cluster", clusterId);
        return this;
    }

    @Override
    public Id getClusterId() {
        return this.getIdParam("cluster");
    }

    @Override
    public Id getServerId() {
        return this.getIdParam("server");
    }

    @Override
    public INodeSignatureBean.Update init(Id clusterId, String clusterName, String macAddr, String clusterLicese) {
        this.setCluster(clusterId);
        this.setSignature(MD5Utils.getMd5ByStr(String.valueOf(clusterName) + macAddr + clusterLicese));
        this.save();
        return this;
    }
}
