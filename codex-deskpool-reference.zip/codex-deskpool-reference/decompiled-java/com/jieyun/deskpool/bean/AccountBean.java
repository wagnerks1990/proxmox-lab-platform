/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.UserEntity;
import com.jieyun.deskpool.api.data.UserEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.handler.AccountBeanHandler;
import com.jieyun.deskpool.bean.utils.VmAccountPasswordUtils;
import com.jieyun.deskpool.domain.Account;
import com.jieyun.deskpool.domain.VmAccount;
import com.jieyun.deskpool.service.AccountService;
import com.jieyun.deskpool.service.GroupService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TemplateService;
import com.jieyun.deskpool.service.ldap.ad.AdGroup;
import com.jieyun.deskpool.service.ldap.ad.AdGroupService;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.RedirectionPolicy;
import com.jieyun.deskpool.shared.RoleType;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.shared.UserSetting;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.store.StoreObject;
import com.jieyun.deskpool.store.StorePersister;
import com.jieyun.deskpool.store.spec.DpSpec;
import com.jieyun.deskpool.web.security.EncryptUtils;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

public class AccountBean
extends DefaultBean<Account>
implements IAccountBean,
IAccountBean.Update {
    @Autowired
    TemplateService templateService;
    @Autowired
    GroupService groupService;
    @Autowired
    AccountService accountService;
    @Autowired
    UserEntityBinding userEntityBinding;

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public void setName(String name) {
        this.setParam((Object)"name", name);
    }

    @Override
    public String getFirstname() {
        return (String)this.getParam("firstname");
    }

    @Override
    public void setFirstname(String firstname) {
        this.setParam((Object)"firstname", firstname);
    }

    @Override
    public String getLastname() {
        return (String)this.getParam("lastname");
    }

    @Override
    public void setLastname(String lastname) {
        this.setParam((Object)"lastname", lastname);
    }

    @Override
    public String getPassword() {
        return (String)this.getParam("password");
    }

    @Override
    public void setPassword(String password) {
        this.setParam((Object)"password", password);
    }

    @Override
    public List<RoleType> getRoles() {
        return this.getParamList("roles", RoleType.class);
    }

    @Override
    public void setRoles(List<RoleType> roles) {
        this.setParam("roles", roles);
    }

    @Override
    public void addRole(RoleType role) {
        this.addCollParamBean("roles", (Object)role);
    }

    @Override
    public void removeRole(RoleType role) {
        this.removeCollParamBean("roles", (Object)role);
    }

    @Override
    public List<Id> getTemplateIDs() {
        return this.getParamList("templates", Id.class);
    }

    @Override
    public List<String> getBackupCodes() {
        return this.getParamList("backupCodes", String.class);
    }

    @Override
    public void setBackupCodes(List<String> backupCodeList) {
        this.setParam("backupCodes", backupCodeList);
    }

    @Override
    public String getTotpSecret() {
        return (String)this.getParam("totpSecret");
    }

    @Override
    public void setTotpSecret(String totpSecret) {
        this.setParam((Object)"totpSecret", totpSecret);
    }

    @Override
    public List<ITemplateBean> getTemplates() {
        ArrayList<ITemplateBean> beanList = new ArrayList<ITemplateBean>();
        List<Id> idList = this.getTemplateIDs();
        for (Id beanId : idList) {
            ITemplateBean oneBean = (ITemplateBean)this.templateService.findOne(beanId);
            if (oneBean == null) continue;
            beanList.add(oneBean);
        }
        return beanList;
    }

    @Override
    public void addTemplate(ITemplateBean template) {
        if (template != null) {
            this.addCollParamBean("templates", template.Id());
        }
    }

    @Override
    public void removeTemplate(ITemplateBean template) {
        if (template != null) {
            this.removeCollParamBean("templates", template.Id());
        }
    }

    @Override
    public void setTemplateIDs(List<Id> ids) {
        this.setParam("templates", ids);
    }

    @Override
    public void setTemplates(List<ITemplateBean> templates) {
        ArrayList<Id> list = new ArrayList<Id>();
        for (ITemplateBean item : templates) {
            list.add(item.Id());
        }
        this.setParam("templates", list);
    }

    @Override
    public List<IGroupBean> getGroups() {
        IClusterBean cluster = Services.getClusterService().getCluster();
        if (cluster == null) {
            return this.listGroupByUserdbLocal();
        }
        if (UserDB.AD.equals((Object)cluster.getUserdb())) {
            List<AdGroup> adGroupList = AdGroupService.getInstance().listGroupByUser(this.getName());
            ArrayList<IGroupBean> groupBeanList = new ArrayList<IGroupBean>();
            GroupService groupService = Services.getGroupService();
            for (AdGroup adGroup : adGroupList) {
                IGroupBean groupBean = groupService.findByName(adGroup.getName());
                if (groupBean == null) continue;
                groupBean.setDescription(adGroup.getDescription());
                groupBeanList.add(groupBean);
            }
            return groupBeanList;
        }
        return this.listGroupByUserdbLocal();
    }

    private List<IGroupBean> listGroupByUserdbLocal() {
        ArrayList<IGroupBean> beanList = new ArrayList<IGroupBean>();
        List<Id> idList = this.getParamList("groups", Id.class);
        GroupService groupService = Services.getGroupService();
        for (Id beanId : idList) {
            IGroupBean oneBean = (IGroupBean)groupService.findOne(beanId);
            if (oneBean == null) continue;
            beanList.add(oneBean);
        }
        return beanList;
    }

    @Override
    public void setGroups(List<IGroupBean> groups) {
        ArrayList<Id> list = new ArrayList<Id>();
        for (IGroupBean item : groups) {
            list.add(item.Id());
        }
        this.setGroupIDs(list);
    }

    @Override
    public void setGroupIDs(List<Id> ids) {
        this.setParam("groups", ids);
    }

    @Override
    public List<Id> getGroupIDs() {
        IClusterBean cluster = Services.getClusterService().getCluster();
        if (cluster == null) {
            return new ArrayList<Id>();
        }
        if (UserDB.AD.equals((Object)cluster.getUserdb())) {
            List<AdGroup> adGroupList = AdGroupService.getInstance().listGroupByUser(this.getName());
            ArrayList<Id> groupBeanList = new ArrayList<Id>();
            GroupService groupService = Services.getGroupService();
            for (AdGroup adGroup : adGroupList) {
                IGroupBean groupBean = groupService.findByName(adGroup.getName());
                if (groupBean == null) continue;
                groupBean.setDescription(adGroup.getDescription());
                groupBeanList.add(groupBean.Id());
            }
            return groupBeanList;
        }
        return this.getParamList("groups", Id.class);
    }

    @Override
    public void addGroup(IGroupBean group) {
        if (group != null) {
            this.addCollParamBean("groups", group.Id());
        }
    }

    @Override
    public void removeGroup(IGroupBean group) {
        if (group != null) {
            this.removeCollParamBean("groups", group.Id());
        }
    }

    @Override
    public UserSetting getSetting() {
        UserSetting setting = (UserSetting)this.getParam("setting");
        if (setting == null) {
            setting = new UserSetting();
        }
        return setting;
    }

    @Override
    public void setSetting(UserSetting setting) {
        this.setParam((Object)"setting", setting);
    }

    @Override
    List<ErrorMessage> validate() {
        List<ErrorMessage> errList = super.validate();
        IAccountBean foundBean = this.accountService.findByName(this.getName());
        if (foundBean != null && (this.isNew() || !foundBean.Id().equals(this.Id()))) {
            errList.add(new ErrorMessage("error.bean.account.name.duplicated"));
        }
        return errList;
    }

    public AccountBeanHandler getHandler() {
        return AccountBeanHandler.get(this);
    }

    @Override
    public IAccountBean.Update getUpdate() {
        return (IAccountBean.Update)this.refresh();
    }

    @Override
    public boolean hasTemplate(ITemplateBean template) {
        return this.hasTemplate(template.Id());
    }

    @Override
    public boolean hasTemplate(Id templateid) {
        List<Id> ids = this.getTemplateIDs();
        if (ids.contains(templateid)) {
            return true;
        }
        List<IGroupBean> grplist = this.getGroups();
        for (IGroupBean item : grplist) {
            if (!item.isEnable() || !item.hasTemplate(templateid)) continue;
            return true;
        }
        return false;
    }

    @Override
    public VmAccount getVmAccount(Id instanceId) {
        if (instanceId == null) {
            return null;
        }
        StorePersister persister = StoreContext.getPersister();
        StoreObject object = persister.findOne(new DpSpec().byClass(VmAccount.class).andEquals("accountUser", this.getName()).andEquals("instanceId", instanceId.getId()));
        if (object == null) {
            return null;
        }
        return (VmAccount)object.getDomain();
    }

    @Override
    public void bindVmAccount(VmAccount account, String rawPassword) {
        String encodePassword = VmAccountPasswordUtils.encode(rawPassword);
        VmAccount getAccount = this.getVmAccount(Id.construct(account.getInstanceId()));
        if (getAccount == null) {
            account.setAccountUser(this.getName());
            account.setPassword(encodePassword);
            account.setId(Id.construct().getId());
            StoreObject store = StoreObject.wrapNew(account);
            StoreContext.getPersister().add(store);
        } else {
            account.setAccountUser(this.getName());
            account.setPassword(encodePassword);
            account.setId(getAccount.getId());
            StoreObject store = StoreObject.wrapNew(account);
            StoreContext.getPersister().replace(store);
        }
    }

    @Override
    public boolean validatePassword(String password) {
        String orgPassword = this.getPassword();
        if (StringUtils.isBlank((String)password)) {
            if (StringUtils.isBlank((String)orgPassword)) {
                return true;
            }
            return EncryptUtils.match("", orgPassword);
        }
        return EncryptUtils.match(password, orgPassword);
    }

    @Override
    public void updatePassword(String password) {
        this.setPassword(EncryptUtils.encrypt(password));
        this.save();
    }

    @Override
    public void remove() {
        StorePersister persister = StoreContext.getPersister();
        List<StoreObject> list = persister.find(new DpSpec().byClass(VmAccount.class).andEquals("accountUser", this.getName()));
        for (StoreObject obj : list) {
            persister.remove(obj);
        }
        super.remove();
    }

    @Override
    public boolean isEnable() {
        return (Boolean)this.getParam("enable");
    }

    @Override
    public void setEnable(boolean enable) {
        this.setParam((Object)"enable", enable);
    }

    @Override
    public String getServiceName() {
        return "accountService";
    }

    @Override
    public ApiResult<UserEntity> apiGet() {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        result.setEntity(this.userEntityBinding.bindingForEntity(new UserEntity(), this));
        return result;
    }

    @Override
    public ApiResult<UserEntity> apiPut(UserEntity entity) {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        try {
            IAccountBean bean = this.userEntityBinding.bindingForBean(entity, this);
            bean.save();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<UserEntity> apiDelete() {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        try {
            this.remove();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getErrorList());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public boolean checkACL(String operation, String entity, String para1, String para2) {
        return true;
    }

    @Override
    public boolean isGroupAdmin() {
        List<RoleType> roles = this.getRoles();
        return roles != null && roles.contains((Object)RoleType.ROLE_GROUP_ADMIN);
    }

    @Override
    public void setTcId(String tcId) {
        this.setParam((Object)"tcId", tcId);
    }

    @Override
    public IAccountBean.Update setLastInstanceId(Id lastInstanceId) {
        this.setIdParam("lastInstanceId", lastInstanceId);
        return this;
    }

    @Override
    public String getTcId() {
        return (String)this.getParam("tcId");
    }

    @Override
    public Id getLastInstanceId() {
        return this.getIdParam("lastInstanceId");
    }

    @Override
    public Desktop.UserAuthentication getUserAuthentication() {
        Desktop.UserAuthentication userAuthentication = null;
        Desktop.UserAuthentication groupUserAuth = null;
        for (IGroupBean group : this.getGroups()) {
            groupUserAuth = group.getUserAuth();
            if (userAuthentication == null) {
                userAuthentication = groupUserAuth;
                continue;
            }
            if (userAuthentication.compareTo(groupUserAuth) >= 0) continue;
            userAuthentication = groupUserAuth;
        }
        return userAuthentication != null ? userAuthentication : Desktop.UserAuthentication.ACCOUNT;
    }

    @Override
    public boolean isAutoBindTcId() {
        for (IGroupBean group : this.getGroups()) {
            if (!group.isAutoBindId()) continue;
            return true;
        }
        return false;
    }

    @Override
    public boolean isClearLastInstance() {
        if (this.getLastInstanceId() == null) {
            return false;
        }
        for (IGroupBean group : this.getGroups()) {
            if (!group.isSingleDesktop() || group.isClear()) continue;
            return false;
        }
        return true;
    }

    @Override
    public RedirectionPolicy getRedirectionPolicy() {
        RedirectionPolicy redirectionPolicy = (RedirectionPolicy)this.getParam("redirectionPolicy");
        if (redirectionPolicy == null) {
            redirectionPolicy = new RedirectionPolicy();
        }
        return redirectionPolicy;
    }

    @Override
    public void setRedirectionPolicy(RedirectionPolicy redirectionPolicy) {
        this.setParam((Object)"redirectionPolicy", redirectionPolicy);
    }
}
