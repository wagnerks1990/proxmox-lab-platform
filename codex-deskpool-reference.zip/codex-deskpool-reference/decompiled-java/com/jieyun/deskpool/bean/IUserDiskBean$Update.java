/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IUserDiskBean;
import com.jieyun.deskpool.domain.UserDisk;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.StoragePolicy;

public static interface IUserDiskBean.Update
extends IUserDiskBean,
Bean.Update<UserDisk> {
    public IUserDiskBean.Update setName(String var1);

    public IUserDiskBean.Update setAccount(IAccountBean var1);

    public IUserDiskBean.Update setAccountId(Id var1);

    public IUserDiskBean.Update mountToVM(IInstanceBean var1);

    public IUserDiskBean.Update unmountFromVM(IInstanceBean var1);

    public IUserDiskBean.Update unmountFromVM();

    public IUserDiskBean.Update setPolicy(StoragePolicy var1);

    public IUserDiskBean.Update enterStatus(Desktop.UserDiskStatus var1);

    public IUserDiskBean.Update setDatastore(String var1);

    public IUserDiskBean.Update setCreated(boolean var1);

    public IUserDiskBean.Update setFilesize(Long var1);

    public IUserDiskBean.Update setPath(String var1);

    public IUserDiskBean.Update setPrefix(String var1);

    public IUserDiskBean.Update setStorageType(String var1);

    public IUserDiskBean.Update init(String var1, IAccountBean var2, StoragePolicy var3, String var4);
}
