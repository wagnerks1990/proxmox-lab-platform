/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IThinClientPatchBean;
import com.jieyun.deskpool.domain.ThinClientPatch;
import java.util.Date;

public static interface IThinClientPatchBean.Update
extends IThinClientPatchBean,
Bean.Update<ThinClientPatch> {
    public IThinClientPatchBean.Update setVersion(String var1);

    public IThinClientPatchBean.Update setPatchName(String var1);

    public IThinClientPatchBean.Update setFileName(String var1);

    public IThinClientPatchBean.Update setPatchPath(String var1);

    public IThinClientPatchBean.Update setPatchMd5(String var1);

    public IThinClientPatchBean.Update setRemark(String var1);

    public IThinClientPatchBean.Update setFileUuid(String var1);

    public IThinClientPatchBean.Update setCreatetime(Date var1);
}
