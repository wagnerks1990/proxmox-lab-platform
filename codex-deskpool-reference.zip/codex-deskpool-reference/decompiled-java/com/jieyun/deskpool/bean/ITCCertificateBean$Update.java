/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ITCCertificateBean;
import com.jieyun.deskpool.domain.TCCertificate;

public static interface ITCCertificateBean.Update
extends ITCCertificateBean,
Bean.Update<TCCertificate> {
    public ITCCertificateBean.Update setType(String var1);

    public ITCCertificateBean.Update setSnReg(String var1);
}
