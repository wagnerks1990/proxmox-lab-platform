/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.InstanceEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IResource;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.IUserDiskBean;
import com.jieyun.deskpool.domain.Instance;
import com.jieyun.deskpool.shared.AdminOperation;
import com.jieyun.deskpool.shared.AgentStatus;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.PrepState;
import com.jieyun.deskpool.shared.PrepTask;
import com.jieyun.deskpool.shared.TrackerOperation;
import com.jieyun.deskpool.shared.VMNetworkConfig;
import com.jieyun.deskpool.shared.VirtualGpuInstance;
import com.jieyun.deskpool.vm.common.NodeConfig;
import java.util.Date;
import java.util.List;

public interface IInstanceBean
extends Bean<Instance>,
IResource {
    public String getImageVersion();

    public boolean isRetired();

    public Update clearPrepTask();

    public Update clearLoginTime();

    public Update clearClientLocation();

    public Update clearVmParam(String var1);

    public Update enterStatus(InstanceStatus var1);

    public IInstanceBean logoff();

    public IInstanceBean disconnect();

    public void createInstance();

    public void start();

    public void restart();

    public void shutdown();

    public void freeze();

    public void thaw();

    public void templatize(IImageBean var1);

    public void templatize(Id var1);

    public void suspend();

    public void resume();

    public IInstanceBean terminate();

    public void destroy();

    public boolean preDestroy();

    public void destroyImplicitly();

    public void destroyExplicitly();

    public void checkpoint(boolean var1);

    public void regenerate();

    public void recover();

    public void regenerate(boolean var1);

    public IImageBean getImage();

    public IInstanceBean preserve();

    public IInstanceBean broken(String var1);

    public IInstanceBean retire();

    public IInstanceBean condemn();

    public void agentInstall();

    public void agentInstall(String var1);

    public void release();

    public void rereserve();

    public String getName();

    public String getCopyfrom();

    public String getVmname();

    public InstanceStatus getStatus();

    public boolean isStableStatus();

    public String getDescription();

    public Id getTemplateId();

    public ITemplateBean getTemplate();

    public Date getRollout();

    public AgentStatus getAgentStatus();

    public IServerBean getServer();

    public Id getServerId();

    public boolean hasPrepTask();

    public boolean inPrep();

    public PrepTask getPrepTask();

    public boolean inPrepState(PrepState var1);

    public PrepState getPrepState();

    public Date getLoginTime();

    public boolean hasLoginTime();

    public String getClientLocation();

    public String getUsername();

    public Desktop.AssignStatus getAssignStatus();

    public IAccountBean getUser();

    public String getIpaddress();

    public IInstanceBean bindVirtualMachine(IServerBean var1, String var2);

    public IInstanceBean bindVirtualMachine(IServerBean var1, String var2, String var3);

    public void store();

    public IInstanceBean save();

    public boolean hasResource();

    public boolean isImporting();

    public boolean isImageEditing();

    public boolean isImageCopying();

    public boolean isBusy();

    public boolean isSleeped();

    public boolean hasVmParam(String var1);

    public Object getVmParam(String var1);

    public Object getVmParam(String var1, Object var2);

    public String getVmParam(String var1, String var2);

    public Integer getVmParam(String var1, Integer var2);

    public String getVNCConsoleURL();

    public boolean isAssigned();

    public boolean isVncAvailable();

    public boolean isSessionActive();

    public boolean isAgentInstalling();

    public boolean isAgentInstalled();

    public boolean isSpice();

    public boolean isAgentV2();

    public boolean isCandidate();

    public boolean validComputerName(String var1);

    public Update getUpdate();

    public boolean isAutoInstallAgent();

    public Boolean isImageInstance();

    public String newRandomName();

    public List<AdminOperation> getAdminOperation();

    public List<AdminOperation> getUserOperation();

    public boolean alive();

    public void setAgentInstanceId();

    public boolean isReadyToRun();

    public boolean isCheckpointed();

    public boolean inTemplate(ITemplateBean var1);

    public boolean setUsbPolicy(String var1, String var2);

    public boolean shouldCheckpint();

    public TrackerOperation getTrackerOperation();

    public boolean agentAlive();

    public boolean postDestroy();

    public boolean upgradeAgent(String var1);

    public boolean upgradeAgent();

    public String getDatastore();

    public String getImagestore();

    public String getDiskstore();

    public boolean hasSecondDisk();

    public String getSecondDisk();

    public boolean hasUserDisk();

    public IUserDiskBean getUserDisk();

    public void attachUserDisk(IUserDiskBean var1);

    public void detachUserDisk(IUserDiskBean var1);

    public void attachUserDisk(Id var1);

    public void detachUserDisk(Id var1);

    public String getAgentVersion();

    public String getSysDiskSize();

    public ApiResult<InstanceEntity> apiGet();

    public ApiResult<InstanceEntity> apiPut(InstanceEntity var1);

    public ApiResult<InstanceEntity> apiDelete();

    public String getSpiceConfig();

    @Override
    public void lock();

    public boolean tryLock();

    @Override
    public void unlock();

    public String readInstallAgentScript();

    public void vmPrepare();

    public void vmUnPrepare();

    public NodeStatus getNodeStatus();

    public void setNodeStatus(NodeStatus var1);

    public boolean isLocal();

    public boolean isStatic();

    public boolean isWaitGegenerate();

    public boolean isLastLogin();

    public String getOu();

    public String getServerIP();

    public boolean autoBindIp();

    public VMNetworkConfig getVMNetworkConfig();

    public void setVmDataByAgent();

    public String getServerHost();

    public void refreshServerHost(NodeConfig var1);

    public String getNodeName();

    public boolean isSaveVMNetworkConfig();

    public boolean configuringNetwork();

    public boolean configuringNetwork(VMNetworkConfig var1, boolean var2);

    public void delaystart(int var1);

    public String getSgwcSk();

    public boolean isLinux();

    public void disconRegenerate();

    public String getComputerName();

    public void updateComputerName(String var1);

    public VirtualGpuInstance getVgpu();

    public static interface Update
    extends IInstanceBean,
    Bean.Update<Instance> {
        public Update setName(String var1);

        public Update setCopyfrom(String var1);

        public Update setVmname(String var1);

        public Update setDescription(String var1);

        public Update setTemplate(ITemplateBean var1);

        public Update setRollout(Date var1);

        public Update setAgentStatus(AgentStatus var1);

        public Update setServer(IServerBean var1);

        public Update setPrepState(PrepState var1);

        public Update setPrepTask(PrepTask var1);

        public Update fakePrepFinished();

        public Update setLoginTime(Date var1);

        public Update setClientLocation(String var1);

        public Update setUser(IAccountBean var1);

        public Update setIpaddress(String var1);

        public Update setVmParam(String var1, Object var2);

        public Update setSessionActive(boolean var1);

        public Update setCandidate(boolean var1);

        public Update setAutoInstallAgent(boolean var1);

        public IInstanceBean setImage(IImageBean var1);

        public Update setIsImageInstance(Boolean var1);

        public Update setCheckpointed();

        public Update clearCheckpointed();

        public Update eraseToCheckpoint();

        public Update setTrackerOperation(TrackerOperation var1);

        public Update setVncAvailable(boolean var1);

        public Update setSecondDisk(String var1, Integer var2);

        public Update setImageVersion(String var1);

        public Update rebuild();

        public Update setWaitGegenerate(boolean var1);

        public Update setServerHost(String var1);

        public Update setNodeName(String var1);

        public Update setVMNetworkConfig(VMNetworkConfig var1);

        public Update setComputerName(String var1);

        public Update setSgwcSk(String var1);

        public Update setVgpu(VirtualGpuInstance var1);
    }
}
