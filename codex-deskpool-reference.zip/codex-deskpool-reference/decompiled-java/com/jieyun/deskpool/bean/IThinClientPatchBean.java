/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.ThinClientPatch;
import java.util.Date;

public interface IThinClientPatchBean
extends Bean<ThinClientPatch> {
    public Update getUpdate();

    public String getVersion();

    public String getPatchName();

    public String getFileName();

    public String getPatchPath();

    public String getPatchMd5();

    public String getRemark();

    public String getFileUuid();

    public boolean unpackUpdatePackage();

    public void delete();

    public Date getCreatetime();

    public String getNfsPath();

    public static interface Update
    extends IThinClientPatchBean,
    Bean.Update<ThinClientPatch> {
        public Update setVersion(String var1);

        public Update setPatchName(String var1);

        public Update setFileName(String var1);

        public Update setPatchPath(String var1);

        public Update setPatchMd5(String var1);

        public Update setRemark(String var1);

        public Update setFileUuid(String var1);

        public Update setCreatetime(Date var1);
    }
}
