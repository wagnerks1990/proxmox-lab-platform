/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITCGroupBean;
import com.jieyun.deskpool.domain.TCGroup;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.TCBaseConfig;
import com.jieyun.deskpool.shared.TCConnectConfig;
import com.jieyun.deskpool.tcapi.constant.TCConfigConstant;
import com.jieyun.deskpool.tcapi.domain.BaseConnConfig;
import com.jieyun.deskpool.utils.IPv4Util;
import com.jieyun.deskpool.utils.MasccanUtils;
import com.jieyun.deskpool.utils.NetUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TCGroupBean
extends DefaultBean<TCGroup>
implements ITCGroupBean,
ITCGroupBean.Update {
    @Override
    public String getServiceName() {
        return "tcGroupService";
    }

    @Override
    public void setStartIp(String startIp) {
        this.setParam((Object)"startIp", startIp);
    }

    @Override
    public void setEndIp(String endIp) {
        this.setParam((Object)"endIp", endIp);
    }

    @Override
    public List<String> getAllIp() {
        return IPv4Util.getIpRange(this.getStartIp(), this.getEndIp());
    }

    @Override
    public String getStartIp() {
        if (this.getEnableLocalIP()) {
            return NetUtils.getFisrtIP();
        }
        return (String)this.getParam("startIp");
    }

    @Override
    public String getEndIp() {
        if (this.getEnableLocalIP()) {
            return NetUtils.getLastIP();
        }
        return (String)this.getParam("endIp");
    }

    @Override
    public BaseConnConfig getConnection() {
        IServerBean server = Services.getServerService().getCurrent();
        BaseConnConfig conn = new BaseConnConfig();
        conn.setAutoConnect(true);
        conn.setName(TCConfigConstant.CONNECT_NAME);
        conn.setType(TCConfigConstant.CONNECT_TYPE);
        conn.setServerAddress(server.getFloatServerIp());
        TCConnectConfig config = this.getTCConnectConfig();
        if (config.isEnableTcSignVer()) {
            String groupName = this.getGroupName();
            conn.setUsername(String.format("@%s", groupName != null ? groupName : ""));
            conn.setRememberMe(true);
        }
        return conn;
    }

    @Override
    public ITCGroupBean.Update getUpdate() {
        return (ITCGroupBean.Update)this.refresh();
    }

    @Override
    public void setEnable(boolean enable) {
        this.setParam((Object)"enable", enable);
    }

    @Override
    public boolean isEnable() {
        return (Boolean)this.getParam("enable");
    }

    @Override
    public void setName(String name) {
        this.setParam((Object)"name", name);
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public void setRemark(String remark) {
        this.setParam((Object)"remark", remark);
    }

    @Override
    public String getRemark() {
        return (String)this.getParam("remark");
    }

    @Override
    public String getGroupName() {
        IGroupBean groupBean;
        Id groupId;
        TCConnectConfig config = this.getTCConnectConfig();
        if (config != null && (groupId = config.getGroupId()) != null && (groupBean = (IGroupBean)Services.getGroupService().findOne(groupId)) != null) {
            return groupBean.getName();
        }
        return null;
    }

    @Override
    public void setTCBaseConfig(TCBaseConfig config) {
        this.setParam((Object)"baseConfig", config);
    }

    @Override
    public void setTCConnectConfig(TCConnectConfig connectConfig) {
        this.setParam((Object)"tcConnectConfig", connectConfig);
    }

    @Override
    public TCBaseConfig getTCBaseConfig() {
        TCBaseConfig tcBaseConfig = (TCBaseConfig)this.getParam("baseConfig");
        return tcBaseConfig == null ? new TCBaseConfig() : tcBaseConfig;
    }

    @Override
    public TCConnectConfig getTCConnectConfig() {
        TCConnectConfig config = (TCConnectConfig)this.getParam("tcConnectConfig");
        return config == null ? new TCConnectConfig() : config;
    }

    @Override
    public void setEnableLocalIP(boolean enableLocalIP) {
        this.setParam((Object)"enableLocalIP", enableLocalIP);
    }

    @Override
    public boolean getEnableLocalIP() {
        return (Boolean)this.getParam("enableLocalIP");
    }

    @Override
    public boolean isAddConnection() {
        return false;
    }

    @Override
    public boolean updateTCConfig() {
        TCBaseConfig baseConfig = this.getTCBaseConfig();
        return this.getTCConnectConfig().isEnableDeskpoolConnect() || baseConfig.isAutoUpdateHost() || baseConfig.isEnableLanague() || baseConfig.isEnableResolution() || baseConfig.isEnableVNC();
    }

    @Override
    public void setMonitorNoUpdateConfig(boolean monitorNoUpdateConfig) {
        this.setParam((Object)"monitorNoUpdateConfig", monitorNoUpdateConfig);
    }

    @Override
    public boolean isMonitorNoUpdateConfig() {
        return (Boolean)this.getParam("monitorNoUpdateConfig");
    }

    @Override
    public List<String> getAllOnLineIp() {
        if (MasccanUtils.masscanFlag()) {
            return MasccanUtils.getOpenIps(this.getStartIp(), this.getEndIp());
        }
        return new ArrayList<String>(0);
    }

    @Override
    public List<String> getAllOffLineIp(List<String> onLineIPs) {
        List<String> allIps = this.getAllIp();
        Iterator<String> it = allIps.iterator();
        String ip = null;
        while (it.hasNext()) {
            ip = it.next();
            if (!onLineIPs.contains(ip)) continue;
            it.remove();
        }
        return allIps;
    }

    @Override
    public void sysncStatus(List<String> onLineIps, List<String> offLineIps) {
        Services.getThinClientService().sysncStatus(onLineIps, offLineIps);
    }

    @Override
    public void sysncStatus() {
        if (MasccanUtils.masscanFlag()) {
            List<String> onLineIps = this.getAllOnLineIp();
            Services.getThinClientService().sysncStatus(onLineIps, this.getAllOffLineIp(onLineIps));
        }
    }

    @Override
    public void sysncStatus(List<String> onLineIps) {
        Services.getThinClientService().sysncStatus(onLineIps, this.getAllOffLineIp(onLineIps));
    }

    @Override
    public boolean enableMonitoring() {
        return this.isEnable() && (this.updateTCConfig() || this.isMonitorNoUpdateConfig());
    }
}
