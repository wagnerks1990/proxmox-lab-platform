/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.GroupEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Groups;
import com.jieyun.deskpool.domain.ScheduleEvent;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.Id;
import java.util.List;

public interface IGroupBean
extends Bean<Groups> {
    public String getName();

    public void setName(String var1);

    public String getDescription();

    public void setDescription(String var1);

    public List<ITemplateBean> getTemplates();

    public void setTemplates(List<ITemplateBean> var1);

    public void addTemplate(ITemplateBean var1);

    public void removeTemplate(ITemplateBean var1);

    public List<Id> getTemplateIDs();

    public boolean hasTemplate(ITemplateBean var1);

    public boolean hasTemplate(Id var1);

    public void setTemplateIDs(List<Id> var1);

    public boolean isEnable();

    public void setEnable(boolean var1);

    public String getAccessCode();

    public void setAccessCode(String var1);

    public ITemplateBean getActiveTemplate();

    public Id getActiveTemplateId();

    public boolean isActiveTemplate(Id var1);

    public void setActiveTemplateId(Id var1);

    public void setActiveTemplate(ITemplateBean var1);

    public void beginClass(Id var1);

    public void endClass(Id var1);

    public Desktop.ClassStatus getClassStatus();

    public List<ScheduleEvent> getTimetable();

    public ApiResult<GroupEntity> apiGet();

    public ApiResult<GroupEntity> apiPut(GroupEntity var1);

    public ApiResult<GroupEntity> apiDelete();

    public void setUserAuth(Desktop.UserAuthentication var1);

    public void setAutoBingId(boolean var1);

    public void setSingleDesktop(boolean var1);

    public Desktop.UserAuthentication getUserAuth();

    public boolean isAutoBindId();

    public boolean isSingleDesktop();

    public void setClear(boolean var1);

    public boolean isClear();

    public Desktop.SchedulingModel getSchedulingModel();

    public Id getSpecifiedPoolId();

    public void setSchedulingModel(Desktop.SchedulingModel var1);

    public void setSpecifiedPoolId(Id var1);

    public void setAccessId(String var1);

    public String getAccessId();

    public void setDisableUpdatePwd(boolean var1);

    public boolean isDisableUpdatePwd();

    public static interface Update
    extends IGroupBean,
    Bean.Update<Groups> {
    }
}
