/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IQuartScheduleBean;
import com.jieyun.deskpool.domain.QuartJob;
import java.util.Date;
import java.util.List;

public interface IQuartJobBean
extends Bean<QuartJob> {
    public long getQuartScheduleId();

    public String getQuartClass();

    public String getCron();

    public String getJobName();

    public Date getStartDate();

    public Update getUpdate();

    public String getQuartCron();

    public String getQuartGroup();

    public String getQuartCron(String var1);

    public String syncJob();

    public void excute();

    public IQuartScheduleBean getQuartSchedule();

    public List<IInstanceBean> findInstance();

    public int getExcuteCount();

    public static interface Update
    extends IQuartJobBean,
    Bean.Update<QuartJob> {
        public Update setQuartScheduleId(long var1);

        public Update setQuartClass(String var1);

        public Update setCron(String var1);

        public Update setJobName(String var1);

        public Update setStartDate(Date var1);
    }
}
