/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IParcelBean;
import com.jieyun.deskpool.domain.Parcel;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.Lineage;
import com.jieyun.deskpool.shared.ParcelStatus;
import com.jieyun.deskpool.shared.Portion;
import com.jieyun.deskpool.shared.VirtualSystemSubType;

public static interface IParcelBean.Update
extends IParcelBean,
Bean.Update<Parcel> {
    public IParcelBean.Update setName(String var1);

    public IParcelBean.Update setImageId(Id var1);

    public IParcelBean.Update setServer(Id var1);

    public IParcelBean.Update setSource(Id var1);

    public IParcelBean.Update setPortion(Portion var1);

    public IParcelBean.Update setStatus(ParcelStatus var1);

    public IParcelBean.Update setLineage(Lineage var1);

    public IParcelBean.Update setVersion(String var1);

    public IParcelBean.Update initialize(IImageBean var1, Lineage var2, Id var3, String var4);

    public IParcelBean.Update initialize(IImageBean var1, Lineage var2, String var3);

    public IParcelBean.Update initialize(IImageBean var1, Portion var2, Lineage var3, Id var4, String var5);

    public IParcelBean.Update initialize(IImageBean var1, Portion var2, Lineage var3, Id var4, String var5, String var6);

    public IParcelBean.Update setVMName(String var1);

    public IParcelBean.Update enterStatus(ParcelStatus var1);

    public IParcelBean.Update setDumpfile(String var1);

    public IParcelBean.Update setSubType(VirtualSystemSubType var1);
}
