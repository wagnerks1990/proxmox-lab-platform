/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.aspectj.runtime.internal.AroundClosure
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.InstanceBean;
import org.aspectj.runtime.internal.AroundClosure;

public class InstanceBean$AjcClosure1
extends AroundClosure {
    public InstanceBean$AjcClosure1(Object[] objectArray) {
        super(objectArray);
    }

    public Object run(Object[] objectArray) {
        Object[] objectArray2 = this.state;
        InstanceBean.persist_aroundBody0((InstanceBean)objectArray[0]);
        return null;
    }
}
