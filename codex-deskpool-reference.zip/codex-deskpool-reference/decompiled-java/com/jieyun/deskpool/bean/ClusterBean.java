/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Cluster;
import com.jieyun.deskpool.domain.SgwServerConfig;
import com.jieyun.deskpool.domain.SystemConfig;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.LicenseStatus;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.utils.AppProps;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class ClusterBean
extends DefaultBean<Cluster>
implements IClusterBean,
IClusterBean.Update {
    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public UserDB getUserdb() {
        return (UserDB)((Object)this.getParam("userdb"));
    }

    @Override
    public String getLdap_domain() {
        return (String)this.getParam("ldap_domain", "");
    }

    @Override
    public String getLdap_user() {
        return (String)this.getParam("ldap_user", "");
    }

    @Override
    public String getLdap_password() {
        return (String)this.getParam("ldap_password", "");
    }

    @Override
    public String getLdap_address() {
        return (String)this.getParam("ldap_address", "");
    }

    @Override
    public void setName(String name) {
        this.setParam((Object)"name", name);
    }

    @Override
    public void setUserdb(UserDB userdb) {
        this.setParam((Object)"userdb", (Object)userdb);
    }

    @Override
    public void setLdap_domain(String ldap_domain) {
        this.setParam((Object)"ldap_domain", ldap_domain);
    }

    @Override
    public void setLdap_user(String ldap_user) {
        this.setParam((Object)"ldap_user", ldap_user);
    }

    @Override
    public void setLdap_password(String ldap_password) {
        this.setParam((Object)"ldap_password", ldap_password);
    }

    @Override
    public void setLdap_address(String ldap_address) {
        this.setParam((Object)"ldap_address", ldap_address);
    }

    @Override
    public String getLdap_netbios_domain() {
        return (String)this.getParam("ldap_netbios_domain");
    }

    @Override
    public void setLdap_netbios_domain(String ldap_netbios_domain) {
        this.setParam((Object)"ldap_netbios_domain", ldap_netbios_domain);
    }

    @Override
    public String getServiceName() {
        return "clusterService";
    }

    @Override
    public IClusterBean.Update enterLicenseStatus(LicenseStatus status) {
        if (!status.equals((Object)this.getLicenseStatus())) {
            this.setParam((Object)"licenseStatus", (Object)status);
            this.save();
        }
        return this;
    }

    @Override
    public LicenseStatus getLicenseStatus() {
        return (LicenseStatus)((Object)this.getParam("licenseStatus"));
    }

    @Override
    public IClusterBean.Update getUpdate() {
        return (IClusterBean.Update)this.refresh();
    }

    @Override
    public IClusterBean setCreateTime(Date createTime) {
        this.setParam((Object)"createTime", createTime);
        return this;
    }

    @Override
    public Date getCreateTime() {
        return (Date)this.getParam("createTime");
    }

    @Override
    public IClusterBean.Update updateFloatIp(String floatIp) {
        this.setParam((Object)"floatIp", floatIp);
        return this;
    }

    @Override
    public String getFloatIp() {
        return (String)this.getParam("floatIp");
    }

    @Override
    public IClusterBean.Update setClusterLicense(String clusterLicense) {
        this.setParam((Object)"clusterLicense", clusterLicense);
        return this;
    }

    @Override
    public String getClusterLicense() {
        return (String)this.getParam("clusterLicense");
    }

    @Override
    public IClusterBean.Update setSysConfig(SystemConfig sysConfig) {
        this.setParam((Object)"systemConfig", sysConfig);
        return this;
    }

    @Override
    public SystemConfig getSysConfig() {
        SystemConfig sysConfig = (SystemConfig)this.getParam("systemConfig");
        return sysConfig == null ? new SystemConfig() : sysConfig;
    }

    @Override
    public void setLdapIps(List<String> ldapIps) {
        this.setParam("ldapIps", ldapIps);
    }

    @Override
    public List<String> getLdapIps() {
        return this.getParamList("ldapIps", String.class);
    }

    @Override
    public IClusterBean.Update setImageResponsitoryAddr(String imageRepositoryAddr) {
        this.setParam((Object)"imageRepositoryAddr", imageRepositoryAddr);
        List<String> imageRepositoryAddrList = this.getImageRepositoryAddrList();
        if (!imageRepositoryAddrList.contains(imageRepositoryAddr)) {
            imageRepositoryAddrList.add(imageRepositoryAddr);
            this.setParam("imageRepositoryAddrList", imageRepositoryAddrList);
        }
        return this;
    }

    @Override
    public String getImageRepositoryAddr() {
        return (String)this.getParam("imageRepositoryAddr");
    }

    @Override
    public String getDefaultImageRepositoryAddr() {
        String[] stringArray;
        String imageRepositoryAddrDb = this.getImageRepositoryAddr();
        if (StringUtils.isNotEmpty((CharSequence)imageRepositoryAddrDb)) {
            return imageRepositoryAddrDb;
        }
        String repository = AppProps.instance().get("image.repository.addr");
        if (StringUtils.isNotEmpty((CharSequence)repository) && (stringArray = repository.split(",")).length != 0) {
            String str = stringArray[0];
            return str;
        }
        return "";
    }

    @Override
    public List<String> getImageRepositoryAddrFromAppProps() {
        ArrayList<String> list = new ArrayList<String>();
        String repository = AppProps.instance().get("image.repository.addr");
        if (StringUtils.isNotEmpty((CharSequence)repository)) {
            String[] stringArray = repository.split(",");
            int n = stringArray.length;
            int n2 = 0;
            while (n2 < n) {
                String str = stringArray[n2];
                list.add(str);
                ++n2;
            }
        }
        return list;
    }

    @Override
    public List<String> getImageRepositoryAddrList() {
        return this.getParamList("imageRepositoryAddrList", String.class);
    }

    @Override
    public Map<String, String> getImageRepositoryMaps() {
        HashMap<String, String> map = new HashMap<String, String>();
        List<String> list = this.getImageRepositoryAddrFromAppProps();
        list.addAll(this.getImageRepositoryAddrList());
        for (String str : list) {
            if (map.containsKey(str)) continue;
            map.put(str, str);
        }
        return map;
    }

    @Override
    public IClusterBean.Update setImageResponsitoryAddrList(List<String> imageResponsitoryAddrList) {
        this.setParam("imageRepositoryAddrList", imageResponsitoryAddrList);
        return this;
    }

    @Override
    public String getDefaultImageRepositoryDr() {
        String defaultImageRepositoryDr = AppProps.instance().get("image.repository.default.drname");
        return StringUtils.isEmpty((CharSequence)defaultImageRepositoryDr) ? "imagerepository.dr" : defaultImageRepositoryDr;
    }

    @Override
    public IServerBean getTemplateAPPServer() {
        Long beanId = (Long)this.getParam("templateAPPServerId");
        return beanId == null ? null : Services.getServerService().findOne(Id.construct(beanId));
    }

    @Override
    public IClusterBean.Update setTemplateAPPServerId(IServerBean templateAPPServer) {
        this.setParam((Object)"templateAPPServerId", templateAPPServer.Id().getId());
        return this;
    }

    @Override
    public SgwServerConfig getSgwServerConfig() {
        SgwServerConfig sgwsConfig = (SgwServerConfig)this.getParam("sgwsConfig");
        return sgwsConfig == null ? new SgwServerConfig() : sgwsConfig;
    }

    @Override
    public IClusterBean.Update setSgwsConfig(SgwServerConfig sgwsConfig) {
        this.setParam((Object)"sgwsConfig", sgwsConfig);
        return this;
    }

    @Override
    public IClusterBean.Update enableSgws() {
        SgwServerConfig config = this.getSgwServerConfig();
        config.setEnableSgws(true);
        this.setParam((Object)"sgwsConfig", config);
        return this;
    }

    @Override
    public IClusterBean.Update disableSgws() {
        SgwServerConfig config = this.getSgwServerConfig();
        config.setEnableSgws(false);
        this.setParam((Object)"sgwsConfig", config);
        return this;
    }

    @Override
    public boolean isOpenSgws() {
        return this.getSgwServerConfig().isEnableSgws();
    }
}
