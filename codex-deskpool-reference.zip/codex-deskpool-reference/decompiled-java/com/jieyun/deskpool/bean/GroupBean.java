/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.GroupEntity;
import com.jieyun.deskpool.api.data.GroupEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Groups;
import com.jieyun.deskpool.domain.ScheduleEvent;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.Id;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class GroupBean
extends DefaultBean<Groups>
implements IGroupBean,
IGroupBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(GroupBean.class);
    @Autowired
    GroupEntityBinding groupEntityBinding;

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public void setName(String name) {
        this.setParam((Object)"name", name);
    }

    @Override
    public String getDescription() {
        return (String)this.getParam("description");
    }

    @Override
    public void setDescription(String description) {
        this.setParam((Object)"description", description);
    }

    @Override
    public boolean isEnable() {
        return this.booleanValue(this.getParam("enable"));
    }

    @Override
    public void setEnable(boolean enable) {
        this.setParam((Object)"enable", enable);
    }

    @Override
    public String getAccessCode() {
        return (String)this.getParam("accessCode");
    }

    @Override
    public void setAccessCode(String accessCode) {
        this.setParam((Object)"accessCode", accessCode);
    }

    @Override
    public ITemplateBean getActiveTemplate() {
        Id templateid = this.getIdParam("activeTemplate");
        return templateid == null ? null : (ITemplateBean)Services.getTemplateService().findOne(templateid);
    }

    @Override
    public Id getActiveTemplateId() {
        return this.getIdParam("activeTemplate");
    }

    @Override
    public boolean isActiveTemplate(Id templateId) {
        if (templateId == null) {
            return false;
        }
        return templateId.equals(this.getActiveTemplateId());
    }

    @Override
    public void setActiveTemplateId(Id templateId) {
        this.setIdParam("activeTemplate", templateId);
    }

    @Override
    public void setActiveTemplate(ITemplateBean template) {
        this.setActiveTemplateId(template.Id());
    }

    @Override
    public List<Id> getTemplateIDs() {
        return this.getParamList("templates", Id.class);
    }

    @Override
    public List<ITemplateBean> getTemplates() {
        ArrayList<ITemplateBean> beanList = new ArrayList<ITemplateBean>();
        List<Id> idList = this.getTemplateIDs();
        for (Id beanId : idList) {
            ITemplateBean oneBean = (ITemplateBean)Services.getTemplateService().findOne(beanId);
            if (oneBean == null) continue;
            beanList.add(oneBean);
        }
        return beanList;
    }

    @Override
    public void addTemplate(ITemplateBean template) {
        if (template != null) {
            this.addCollParamBean("templates", template.Id());
        }
    }

    @Override
    public void removeTemplate(ITemplateBean template) {
        if (template != null) {
            this.removeCollParamBean("templates", template.Id());
        }
    }

    @Override
    public void setTemplateIDs(List<Id> ids) {
        this.setParam("templates", ids);
    }

    @Override
    public void setTemplates(List<ITemplateBean> templates) {
        ArrayList<Id> list = new ArrayList<Id>();
        for (ITemplateBean item : templates) {
            list.add(item.Id());
        }
        this.setParam("templates", list);
    }

    @Override
    public boolean hasTemplate(ITemplateBean template) {
        return this.hasTemplate(template.Id());
    }

    @Override
    public boolean hasTemplate(Id templateid) {
        List<Id> ids = this.getTemplateIDs();
        return ids.contains(templateid);
    }

    @Override
    List<ErrorMessage> validate() {
        List<ErrorMessage> errList = super.validate();
        IGroupBean foundBean = Services.getGroupService().findByName(this.getName());
        if (foundBean != null && (this.isNew() || !foundBean.Id().equals(this.Id()))) {
            errList.add(new ErrorMessage("error.bean.group.name.duplicated"));
        }
        return errList;
    }

    @Override
    public String getServiceName() {
        return "groupService";
    }

    @Override
    public void beginClass(Id templateId) {
        logger.info("{} beginClass {} ", (Object)this.getName(), (Object)templateId);
        try {
            ITemplateBean template = (ITemplateBean)Services.getTemplateService().findOne(templateId);
            if (template != null) {
                this.setActiveTemplateId(templateId);
                this.save();
                if (template.updateStatus()) {
                    template.save();
                    template.enforceSchedule();
                }
            }
        }
        catch (Exception ex) {
            logger.info("beginClass Error:", (Throwable)ex);
        }
    }

    @Override
    public void endClass(Id templateId) {
        logger.info("{} endClass {} ", (Object)this.getName(), (Object)templateId);
        if (templateId == null || templateId.empty()) {
            templateId = this.getActiveTemplateId();
        }
        if (templateId == null) {
            logger.info("active pool is is empty");
            return;
        }
        try {
            ITemplateBean template = (ITemplateBean)Services.getTemplateService().findOne(templateId);
            if (template != null) {
                this.setActiveTemplateId(null);
                this.save();
                if (template.updateStatus()) {
                    template.save();
                    template.enforceSchedule();
                }
            }
        }
        catch (Exception ex) {
            logger.info("endClass Error:", (Throwable)ex);
        }
    }

    @Override
    public Desktop.ClassStatus getClassStatus() {
        return null;
    }

    @Override
    public List<ScheduleEvent> getTimetable() {
        return null;
    }

    @Override
    public ApiResult<GroupEntity> apiGet() {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        result.setEntity(this.groupEntityBinding.bindingForEntity(new GroupEntity(), this));
        return result;
    }

    @Override
    public ApiResult<GroupEntity> apiPut(GroupEntity entity) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        try {
            IGroupBean bean = this.groupEntityBinding.bindingForBean(entity, this);
            bean.save();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<GroupEntity> apiDelete() {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        try {
            this.remove();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getErrorList());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public void setUserAuth(Desktop.UserAuthentication userAuth) {
        this.setParam((Object)"userAuth", (Object)userAuth);
    }

    @Override
    public void setAutoBingId(boolean flag) {
        this.setParam((Object)"autoBingId", flag);
    }

    @Override
    public void setSingleDesktop(boolean flag) {
        this.setParam((Object)"singleDesktop", flag);
    }

    @Override
    public Desktop.UserAuthentication getUserAuth() {
        return (Desktop.UserAuthentication)((Object)this.getParam("userAuth"));
    }

    @Override
    public boolean isAutoBindId() {
        return this.booleanValue(this.getParam("autoBingId"));
    }

    @Override
    public boolean isSingleDesktop() {
        return this.booleanValue(this.getParam("singleDesktop"));
    }

    @Override
    public void setClear(boolean isClear) {
        this.setParam((Object)"clear", isClear);
    }

    @Override
    public boolean isClear() {
        return this.booleanValue(this.getParam("clear"));
    }

    @Override
    public Desktop.SchedulingModel getSchedulingModel() {
        return (Desktop.SchedulingModel)((Object)this.getParam("schedulingModel"));
    }

    @Override
    public Id getSpecifiedPoolId() {
        return this.getIdParam("specifiedPool");
    }

    @Override
    public void setSchedulingModel(Desktop.SchedulingModel model) {
        this.setParam((Object)"schedulingModel", (Object)model);
    }

    @Override
    public void setSpecifiedPoolId(Id specifiedPool) {
        this.setIdParam("specifiedPool", specifiedPool);
    }

    @Override
    public void setAccessId(String accessId) {
        this.setParam((Object)"accessId", accessId);
    }

    @Override
    public String getAccessId() {
        return (String)this.getParam("accessId");
    }

    @Override
    public void setDisableUpdatePwd(boolean disableUpdatePwd) {
        this.setParam((Object)"disableUpdatePwd", disableUpdatePwd);
    }

    @Override
    public boolean isDisableUpdatePwd() {
        return this.booleanValue(this.getParam("disableUpdatePwd"));
    }
}
