/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.Message;
import com.jieyun.deskpool.shared.MessageColor;
import com.jieyun.deskpool.shared.MessagePriority;
import java.util.Date;

public interface IMessageBean
extends Bean<Message> {
    public String getName();

    public void setName(String var1);

    public String getMsgid();

    public void setMsgid(String var1);

    public MessagePriority getPriority();

    public void setPriority(MessagePriority var1);

    public MessageColor getColor();

    public void setColor(MessageColor var1);

    public Date getCreatetime();

    public void setCreatetime(Date var1);

    public static interface Update
    extends IMessageBean,
    Bean.Update<Message> {
    }
}
