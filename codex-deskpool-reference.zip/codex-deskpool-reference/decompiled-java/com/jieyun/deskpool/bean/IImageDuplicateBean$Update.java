/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IImageDuplicateBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.ImageDuplicate;
import com.jieyun.deskpool.shared.ImageStatus;

public static interface IImageDuplicateBean.Update
extends IImageDuplicateBean,
Bean.Update<ImageDuplicate> {
    public IImageDuplicateBean.Update setName(String var1);

    public IImageDuplicateBean.Update addVersion(String var1);

    public IImageDuplicateBean.Update enterStatus(ImageStatus var1);

    public void Init(IImageBean var1, IServerBean var2);
}
