/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.quartz.JobKey
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IQuartJobBean;
import com.jieyun.deskpool.bean.IQuartScheduleBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.QuartSchedule;
import com.jieyun.deskpool.quart.mgr.DpQuartMgr;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TemplateService;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.utils.DpStringUtils;
import com.jieyun.deskpool.utils.SpringUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.quartz.JobKey;

public class QuartScheduleBean
extends DefaultBean<QuartSchedule>
implements IQuartScheduleBean,
IQuartScheduleBean.Update {
    @Override
    public String getServiceName() {
        return "quartScheduleService";
    }

    @Override
    public IQuartScheduleBean.Update setQuartName(String quartName) {
        this.setParam((Object)"quartName", quartName);
        return this;
    }

    @Override
    public IQuartScheduleBean.Update setRemark(String remark) {
        this.setParam((Object)"remark", remark);
        return this;
    }

    @Override
    public String getQuartName() {
        return (String)this.getParam("quartName");
    }

    @Override
    public String getRemark() {
        return (String)this.getParam("remark");
    }

    @Override
    public List<IQuartJobBean> findQuartJob() {
        return Services.getQuartJobService().findListBySchedule(this.Id().getId());
    }

    @Override
    public IQuartScheduleBean.Update getUpdate() {
        return (IQuartScheduleBean.Update)this.refresh();
    }

    @Override
    public IQuartScheduleBean.Update setCycle(Set<String> cycle) {
        this.setParam((Object)"cycle", cycle);
        return this;
    }

    @Override
    public Set<String> getCycle() {
        return this.getParam("cycle") == null ? new HashSet() : (Set)this.getParam("cycle");
    }

    @Override
    public void deleteAndJob() {
        Services.getQuartJobService().deleteBySchedule(this.Id().getId());
        this.remove();
    }

    @Override
    public void startQuartJob() {
        String weeks = DpStringUtils.joinSortSet(this.getCycle());
        String group = this.getQuartGroup();
        DpQuartMgr dpQuartMgr = (DpQuartMgr)SpringUtils.context.getBean("dpQuartMgr");
        if (dpQuartMgr != null) {
            Set<JobKey> jobsSet = dpQuartMgr.getByGroup(group);
            JobKey jobKey = null;
            for (IQuartJobBean quartJobBean : this.findQuartJob()) {
                jobKey = JobKey.jobKey((String)quartJobBean.getJobName(), (String)group);
                if (jobsSet.contains(jobKey)) {
                    dpQuartMgr.syncTrigger(quartJobBean.getJobName(), group, quartJobBean.getQuartCron(weeks));
                    jobsSet.remove(jobKey);
                    continue;
                }
                dpQuartMgr.addJob(quartJobBean, quartJobBean.getQuartCron(weeks));
            }
            for (JobKey jobKey1 : jobsSet) {
                dpQuartMgr.removeByJobKey(jobKey1);
            }
        }
    }

    @Override
    public String getQuartGroup() {
        return this.Id().toString();
    }

    @Override
    public List<IInstanceBean> findInstance() {
        ArrayList<IInstanceBean> instanceList = new ArrayList<IInstanceBean>();
        for (ITemplateBean template : this.getTemplates()) {
            instanceList.addAll(template.getInstance());
        }
        return instanceList;
    }

    @Override
    public IQuartScheduleBean.Update setExcuteCount(int excuteCount) {
        this.setParam((Object)"excuteCount", excuteCount);
        return this;
    }

    @Override
    public int getExcuteCount() {
        return (Integer)this.getParam("excuteCount");
    }

    @Override
    public List<Id> getTemplateIds() {
        return this.getParamList("templates", Id.class);
    }

    @Override
    public String getTemplatesJoinName() {
        StringBuilder temPlateJoinName = new StringBuilder();
        for (ITemplateBean templateBean : this.getTemplates()) {
            if (templateBean == null) continue;
            temPlateJoinName.append(templateBean.getName());
            temPlateJoinName.append(" ");
        }
        return temPlateJoinName.toString();
    }

    @Override
    public List<ITemplateBean> getTemplates() {
        ArrayList<ITemplateBean> list = new ArrayList<ITemplateBean>();
        TemplateService tempService = Services.getTemplateService();
        for (Id templateId : this.getTemplateIds()) {
            list.add((ITemplateBean)tempService.findOne(templateId));
        }
        return list;
    }

    @Override
    public IQuartScheduleBean.Update setTemplates(List<Id> list) {
        this.setParam("templates", list);
        return this;
    }
}
