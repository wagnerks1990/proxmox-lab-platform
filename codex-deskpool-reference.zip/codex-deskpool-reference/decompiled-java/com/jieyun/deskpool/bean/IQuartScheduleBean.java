/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IQuartJobBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.QuartSchedule;
import com.jieyun.deskpool.shared.Id;
import java.util.List;
import java.util.Set;

public interface IQuartScheduleBean
extends Bean<QuartSchedule> {
    public String getQuartName();

    public String getRemark();

    public String getQuartGroup();

    public List<IQuartJobBean> findQuartJob();

    public Update getUpdate();

    public Set<String> getCycle();

    public void deleteAndJob();

    public void startQuartJob();

    public List<IInstanceBean> findInstance();

    public int getExcuteCount();

    public List<ITemplateBean> getTemplates();

    public List<Id> getTemplateIds();

    public String getTemplatesJoinName();

    public static interface Update
    extends IQuartScheduleBean,
    Bean.Update<QuartSchedule> {
        public Update setQuartName(String var1);

        public Update setRemark(String var1);

        public Update setCycle(Set<String> var1);

        public Update setExcuteCount(int var1);

        public Update setTemplates(List<Id> var1);
    }
}
