/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.ThinClientCertificate;
import java.util.Date;

public interface IThinClientCertificateBean
extends Bean<ThinClientCertificate> {
    public String getName();

    public Date getCreateTime();

    public String getFileUuid();

    public String getRemark();

    public update getUpdate();

    public void delete();

    public void create();

    public String getFileDir();

    public boolean isEnable();

    public static interface update
    extends IThinClientCertificateBean,
    Bean.Update<ThinClientCertificate> {
        public update setName(String var1);

        public update setCreateTime(Date var1);

        public update setFileUuid(String var1);

        public update setRemark(String var1);

        public update setEnable(boolean var1);
    }
}
