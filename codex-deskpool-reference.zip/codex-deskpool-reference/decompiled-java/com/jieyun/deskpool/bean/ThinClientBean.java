/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.ITCGroupBean;
import com.jieyun.deskpool.bean.IThinClientBean;
import com.jieyun.deskpool.bean.IThinClientPatchBean;
import com.jieyun.deskpool.domain.ThinClient;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ThinClientCerStatus;
import com.jieyun.deskpool.shared.ThinClientStatus;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.VNCTokenManager;
import com.jieyun.deskpool.vm.manager.ThinClientManagerImpl;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;

public class ThinClientBean
extends DefaultBean<ThinClient>
implements IThinClientBean,
IThinClientBean.Update {
    @Override
    public String getServiceName() {
        return "thinClientService";
    }

    @Override
    public IThinClientBean.Update setSn(String sn) {
        this.setParam((Object)"sn", sn);
        return this;
    }

    @Override
    public IThinClientBean.Update setHostName(String hostName) {
        this.setParam((Object)"hostName", hostName);
        return this;
    }

    @Override
    public IThinClientBean.Update setStatus(ThinClientStatus status) {
        this.setParam((Object)"status", (Object)status);
        return this;
    }

    @Override
    public IThinClientBean.Update setTcGroupId(Id tcGroupId) {
        if (tcGroupId != null) {
            this.setParam((Object)"tcGroupId", tcGroupId.getId());
        }
        return this;
    }

    @Override
    public IThinClientBean.Update setExcuteTime(Date excuteTime) {
        this.setParam((Object)"excuteTime", excuteTime);
        return this;
    }

    @Override
    public String getSn() {
        return (String)this.getParam("sn");
    }

    @Override
    public String getHostName() {
        return (String)this.getParam("hostName");
    }

    @Override
    public ThinClientStatus getStatus() {
        return (ThinClientStatus)((Object)this.getParam("status"));
    }

    @Override
    public Id getGroupId() {
        return this.getIdParam("tcGroupId");
    }

    @Override
    public ITCGroupBean getTCGroup() {
        Id id = this.getGroupId();
        if (id != null) {
            return (ITCGroupBean)Services.getTcGroupService().findOne(this.getGroupId());
        }
        return null;
    }

    @Override
    public Date getExcuteTime() {
        return (Date)this.getParam("excuteTime");
    }

    @Override
    public String getTcGroupName() {
        return (String)this.getParam("tcGroupName");
    }

    @Override
    public IThinClientBean.Update getUpdate() {
        return (IThinClientBean.Update)this.refresh();
    }

    @Override
    public IThinClientBean.Update setMacAddr(String macAddr) {
        this.setParam((Object)"macAddr", macAddr);
        return this;
    }

    @Override
    public IThinClientBean.Update setVersion(String version) {
        this.setParam((Object)"version", version);
        return this;
    }

    @Override
    public IThinClientBean.Update setUpdateTime(Date updateTime) {
        this.setParam((Object)"updateTime", updateTime);
        return this;
    }

    @Override
    public String getMacAddr() {
        return (String)this.getParam("macAddr");
    }

    @Override
    public String getVersion() {
        return (String)this.getParam("version");
    }

    @Override
    public Date getUpdateTime() {
        return (Date)this.getParam("updateTime");
    }

    @Override
    public IThinClientBean.Update setIpAddr(String ipAddr) {
        this.setParam((Object)"ipAddr", ipAddr);
        return this;
    }

    @Override
    public String getIpAddr() {
        return (String)this.getParam("ipAddr");
    }

    @Override
    public String getVncUrl() {
        String ip = NetUtils.getHostIP();
        if (StringUtils.isEmpty((CharSequence)ip)) {
            ip = NetUtils.getServerIp();
        }
        return String.format("http://%s:8787/vnc_lite.html?path=?token=%s", ip, VNCTokenManager.getToken(String.valueOf(this.getIpAddr()) + ":" + "5900"));
    }

    @Override
    public void start() {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.start(this);
    }

    @Override
    public void restart() {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.restart(this);
    }

    @Override
    public void shutdown() {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.shutdown(this);
    }

    @Override
    public void reset() {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.reset(this);
    }

    @Override
    public IThinClientBean.Update setDeviceType(String deviceType) {
        this.setParam((Object)"deviceType", deviceType);
        return this;
    }

    @Override
    public String getDeviceType() {
        return (String)this.getParam("deviceType");
    }

    @Override
    public IThinClientBean.Update enterStatus(ThinClientStatus status) {
        if (this.getStatus() != status) {
            this.setStatus(status);
            this.save();
        }
        return this;
    }

    @Override
    public IThinClientBean.Update setType(String type) {
        this.setParam((Object)"type", type);
        return this;
    }

    @Override
    public String getType() {
        return (String)this.getParam("type");
    }

    @Override
    public IThinClientBean.Update setTcGroup(ITCGroupBean groupBean) {
        Id tcGroupId = null;
        if (groupBean != null) {
            tcGroupId = groupBean.Id();
        }
        this.setTcGroupId(tcGroupId);
        return this;
    }

    @Override
    public void sysUpdate(IThinClientPatchBean patch) {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.sysUpdate(this, patch);
    }

    @Override
    public String toString() {
        return "thinclient[" + this.getHostName() + "]";
    }

    @Override
    public void deleteTCMCertificate() {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.deleteTCMCertificate(this);
    }

    @Override
    public void encryptKey(String filePath) {
        ThinClientManagerImpl thinClientMgr = new ThinClientManagerImpl();
        thinClientMgr.encryptKey(this, filePath);
    }

    @Override
    public IThinClientBean.Update setCerStatus(ThinClientCerStatus cerStatus) {
        this.setParam((Object)"cerStatus", (Object)cerStatus);
        return this;
    }

    @Override
    public ThinClientCerStatus getCerStatus() {
        return (ThinClientCerStatus)((Object)this.getParam("cerStatus"));
    }
}
