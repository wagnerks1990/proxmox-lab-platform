/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.infinispan.notifications.cachemanagerlistener.event.MergeEvent
 *  org.infinispan.remoting.transport.Address
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.infinispan.notifications.cachemanagerlistener.event.MergeEvent;
import org.infinispan.remoting.transport.Address;

public class MergeClusterHandler
implements Runnable {
    MergeEvent mevent = null;

    public MergeClusterHandler(MergeEvent mevent) {
        this.mevent = mevent;
    }

    @Override
    public void run() {
        Stopwatch timer = new Stopwatch("[MergeClusterHandler.run()] ");
        List subgroups = this.mevent.getSubgroupsMerged();
        if (subgroups.isEmpty()) {
            return;
        }
        timer.record(subgroups.toString());
        Collections.sort(subgroups, new Comparator<List<Address>>(){

            @Override
            public int compare(List<Address> o1, List<Address> o2) {
                int restult = 0;
                Address least = null;
                if (o1.size() < o2.size()) {
                    restult = 1;
                } else if (o1.size() > o2.size()) {
                    restult = -1;
                } else if (o1.size() == 0) {
                    restult = 0;
                } else {
                    restult = -1;
                    least = null;
                    for (Address a : o1) {
                        if (least != null && a.hashCode() >= least.hashCode()) continue;
                        least = a;
                    }
                    for (Address a : o2) {
                        if (a.hashCode() >= least.hashCode()) continue;
                        restult = 1;
                        break;
                    }
                }
                return restult;
            }
        });
        while (true) {
            try {
                timer.record("StoreContext.checkState()");
                StoreContext.checkState();
            }
            catch (Exception e) {
                e.printStackTrace();
                continue;
            }
            break;
        }
        Address localAddress = this.mevent.getLocalAddress();
        if (subgroups.size() >= 2 && ((List)subgroups.get(0)).size() > ((List)subgroups.get(1)).size()) {
            if (!((List)subgroups.get(0)).contains(localAddress)) {
                StoreContext.setMinorityNodeFlag(true);
                StoreContext.setMergedFlag(true);
            } else {
                StoreContext.setMinorityNodeFlag(false);
                StoreContext.setMergedFlag(false);
            }
        } else {
            StoreContext.setMinorityNodeFlag(false);
            StoreContext.setMergedFlag(false);
        }
        timer.record("isMasterLocal:" + MasterCoordinator.instance().isMasterLocal() + ";MergedFlag:" + StoreContext.isMergeScheduled() + ";MinorityNodeFlag:" + StoreContext.isMinorityNode());
        timer.stop();
    }
}
