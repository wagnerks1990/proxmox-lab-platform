/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jgroups.Address
 *  org.jgroups.Event
 *  org.jgroups.JChannel
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.local.rules;

import com.jieyun.deskpool.DeskpoolVersion;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.local.ConfigServerBean;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IClusterGroupRemote;
import com.jieyun.deskpool.distributed.topo.DeskpoolAddress;
import com.jieyun.deskpool.distributed.transfer.data.ClusterGroupInfo;
import com.jieyun.deskpool.distributed.transfer.data.MemberIdentify;
import java.util.ArrayList;
import java.util.List;
import org.jgroups.Address;
import org.jgroups.Event;
import org.jgroups.JChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestClusterMemberRule {
    private static final Logger Logger = LoggerFactory.getLogger(TestClusterMemberRule.class);

    public ClusterGroupInfo test() {
        List<DeskpoolAddress> addressList = this.findActiveClusterAddress();
        if (addressList != null && addressList.size() > 1) {
            DeskpoolAddress address;
            block4: {
                try {
                    address = this.findOne(addressList);
                    if (address != null) break block4;
                    return null;
                }
                catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }
            IClusterGroupRemote remote = (IClusterGroupRemote)RMIUtils.getRemoteProxy(address.getAddress(), "ClusterGroup");
            MemberIdentify identify = new MemberIdentify();
            identify.setHypervisor(ConfigServerBean.get().getHostType());
            Package myPackage = DeskpoolVersion.class.getPackage();
            DeskpoolVersion version = myPackage.getAnnotation(DeskpoolVersion.class);
            identify.setDeskpoolVersion(version.version());
            ClusterGroupInfo response = remote.restoreMember(identify);
            return response;
        }
        Logger.info("================================================");
        Logger.info("================================================");
        Logger.info("====  THE  SERVER IS MASTER     ================");
        Logger.info("================================================");
        Logger.info("================================================");
        return null;
    }

    private List<DeskpoolAddress> findActiveClusterAddress() {
        ArrayList<DeskpoolAddress> list = new ArrayList<DeskpoolAddress>();
        try (JChannel ch = null;){
            try {
                ch = new JChannel("jgroups.xml");
                ch.connect(ClusterNodeBean.instance().readClusterName());
                List memberList = ch.getView().getMembers();
                if (memberList != null) {
                    for (Address address : memberList) {
                        Object phyAddress = ch.down(new Event(87, (Object)address));
                        if (phyAddress == null) continue;
                        list.add(DeskpoolAddress.create(phyAddress.toString()));
                    }
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                if (ch != null) {
                    ch.close();
                }
            }
        }
        return list;
    }

    private DeskpoolAddress findOne(List<DeskpoolAddress> list) {
        for (DeskpoolAddress address : list) {
            if (address.isLocal()) continue;
            return address;
        }
        return null;
    }
}
