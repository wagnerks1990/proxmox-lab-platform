/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IDeskpoolServerRemote;
import com.jieyun.deskpool.distributed.topo.DeskpoolAddress;
import com.jieyun.deskpool.distributed.topo.ServerRegistry;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.Services;
import java.util.List;

public class ExitMaintanceHandler
extends Handler {
    private boolean notify = false;

    @Override
    public void handle() {
        if (this.notify) {
            try {
                List<DeskpoolAddress> addressList = ServerRegistry.instance().findActiveAddress();
                for (DeskpoolAddress address : addressList) {
                    IDeskpoolServerRemote remote = (IDeskpoolServerRemote)RMIUtils.getRemoteProxy(address.getAddress(), "DeskpoolServerRemote");
                    remote.exitMaintance();
                }
            }
            catch (Throwable t) {
                t.printStackTrace();
            }
        }
        try {
            Services.getSystemService().exitMaintenanceMode();
        }
        catch (JYServiceException e) {
            e.printStackTrace();
        }
    }

    public void setNotify(boolean notify) {
        this.notify = notify;
    }
}
