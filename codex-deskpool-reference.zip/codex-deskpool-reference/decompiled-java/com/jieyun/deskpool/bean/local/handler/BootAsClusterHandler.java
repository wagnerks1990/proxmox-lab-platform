/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.bean.local.rules.TestClusterMemberRule;
import com.jieyun.deskpool.distributed.agent.SystemStatusObject;
import com.jieyun.deskpool.distributed.transfer.data.ClusterGroupInfo;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.service.JYConfigServiceException;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.ServerService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.SystemStatus;
import com.jieyun.deskpool.store.Store;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.DpFileUtils;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BootAsClusterHandler
extends Handler {
    private static DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final int RETRIES_COUNT = 3;
    private static final Logger logger = LoggerFactory.getLogger(BootAsClusterHandler.class);

    @Override
    public void handle() {
        ClusterNodeBean node = ClusterNodeBean.instance();
        if (!node.isConfigHypervisor() || !node.isDefineClusterIdentify()) {
            SystemStatusObject.instance().setSystemStatus(SystemStatus.INIT);
            return;
        }
        ClusterGroupInfo clusterGroupInfo = this.getClusterGroupInfo();
        logger.info("StoreContext.createClusterStore start");
        if (clusterGroupInfo != null) {
            ClusterNodeBean.instance().syncGroupInfo(clusterGroupInfo);
            try {
                StringBuilder backFileName = new StringBuilder(System.getProperty("user.home"));
                backFileName.append(File.separator);
                backFileName.append("restart");
                backFileName.append(File.separator);
                backFileName.append("jy_bak_");
                backFileName.append(format.format(new Date()));
                backFileName.append(".zip");
                DpFileUtils.GenZipDirectory(backFileName.toString(), System.getProperty("jy.configHome"));
                String fileName = String.valueOf(System.getProperty("jy.configHome")) + File.separator + "store" + File.separator + "data";
                DpFileUtils.delete(fileName);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            StoreContext.createClusterStore();
            Store.resetFederation();
        } else {
            StoreContext.createClusterStore();
        }
        logger.info("StoreContext.createClusterStore end");
        ServerService serverService = Services.getServerService();
        logger.info("serverService.updateCurrent start");
        Config config = Config.Store.get();
        try {
            serverService.updateCurrent(config);
        }
        catch (JYConfigServiceException e) {
            e.printStackTrace();
        }
        logger.info("serverService.updateCurrent end");
        if (serverService.getCurrent() == null) {
            throw new RuntimeException("Current server is null !");
        }
    }

    private ClusterGroupInfo getClusterGroupInfo() {
        TestClusterMemberRule testClusterMemberRule = new TestClusterMemberRule();
        int i = 0;
        while (i++ < 3) {
            try {
                return testClusterMemberRule.test();
            }
            catch (Exception e) {
                logger.error("the remote getClusterGroupInfo fail! will retries [the count = " + i + "]");
                try {
                    Thread.sleep(5000L);
                }
                catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
                if (i != 3) continue;
                throw e;
            }
        }
        throw new JYServiceRuntimeException("the remote server init fail!");
    }
}
