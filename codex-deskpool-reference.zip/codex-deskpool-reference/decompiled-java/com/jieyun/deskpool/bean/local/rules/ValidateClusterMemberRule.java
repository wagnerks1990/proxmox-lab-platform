/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.rules;

import com.jieyun.deskpool.bean.local.ConfigServerBean;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IClusterGroupRemote;
import com.jieyun.deskpool.distributed.rpc.exception.JYRemoteException;
import com.jieyun.deskpool.distributed.transfer.data.MemberIdentify;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import java.util.Locale;
import javax.naming.NamingException;

public class ValidateClusterMemberRule {
    private String host;
    private String username;
    private String password;
    private Locale locale;

    public void test() {
        this.validateJoinMember(this.host, this.username, this.password, this.locale);
    }

    private void validateJoinMember(String host, String username, String password, Locale locale) {
        try {
            IClusterGroupRemote remote = (IClusterGroupRemote)RMIUtils.getRemoteProxy(host, "ClusterGroup");
            remote.validateAdmin(username, password);
            MemberIdentify identify = new MemberIdentify();
            identify.setHypervisor(ConfigServerBean.get().getHostType());
            remote.join(identify);
        }
        catch (Exception e) {
            Throwable t = e.getCause();
            if (t instanceof JYRemoteException) {
                throw new JYServiceRuntimeException(t.getMessage());
            }
            if (e instanceof NamingException) {
                JYServiceRuntimeException je = new JYServiceRuntimeException("cluster.hostaddress.error");
                je.initCause(e);
                throw je;
            }
            if (e instanceof JYServiceRuntimeException) {
                throw (JYServiceRuntimeException)e;
            }
            JYServiceRuntimeException je = new JYServiceRuntimeException("cluster.rpc.error");
            je.initCause(e);
            throw je;
        }
    }

    public String getHost() {
        return this.host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Locale getLocale() {
        return this.locale;
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
    }
}
