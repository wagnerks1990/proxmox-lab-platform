/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local;

import com.jieyun.deskpool.bean.local.ClusterNodeBean;

static class ClusterNodeBean.1
extends Thread {
    private final /* synthetic */ ClusterNodeBean.C val$c;

    ClusterNodeBean.1(ClusterNodeBean.C c) {
        this.val$c = c;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void run() {
        try {
            ClusterNodeBean.C c = this.val$c;
            synchronized (c) {
                this.val$c.wait();
                System.out.println("Wait timeout");
            }
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
