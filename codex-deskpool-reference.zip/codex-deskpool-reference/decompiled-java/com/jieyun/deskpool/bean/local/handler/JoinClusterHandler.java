/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.local.ConfigServerBean;
import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.bean.local.rules.JoinOrCreateClusterLocalRule;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IClusterGroupRemote;
import com.jieyun.deskpool.distributed.rpc.exception.JYRemoteException;
import com.jieyun.deskpool.distributed.transfer.data.ClusterGroupInfo;
import com.jieyun.deskpool.distributed.transfer.data.MemberIdentify;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.service.ClusterService;
import com.jieyun.deskpool.service.JYConfigServiceException;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.LicenseService;
import com.jieyun.deskpool.service.ServerService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.Props;
import java.rmi.RemoteException;
import java.util.List;
import javax.naming.NamingException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JoinClusterHandler
extends Handler {
    private static final Logger logger = LoggerFactory.getLogger(JoinClusterHandler.class);
    private String host;
    private String username;
    private String password;

    @Override
    public void handle() {
        new JoinOrCreateClusterLocalRule().test();
        try {
            IClusterGroupRemote remote = (IClusterGroupRemote)RMIUtils.getRemoteProxy(this.host, "ClusterGroup");
            remote.validateAdmin(this.username, this.password);
            MemberIdentify identify = new MemberIdentify();
            identify.setHypervisor(ConfigServerBean.get().getHostType());
            identify.setHostAddress(ConfigServerBean.get().getHostAddress());
            identify.setResourceID(Config.Store.get().vm().getParam("host_resource"));
            ClusterGroupInfo response = remote.join(identify);
            if (!response.isSupprotCluster()) {
                throw new JYServiceRuntimeException("license.servercluster.notsupport");
            }
            if (StringUtils.isEmpty((CharSequence)response.getClusterName())) {
                ClusterNodeBean.instance().saveClusterName(ClusterNodeBean.instance().getNewClusterName());
            } else {
                ClusterNodeBean.instance().saveClusterName(response.getClusterName());
            }
            StoreContext.createClusterStore();
            ClusterNodeBean.instance().syncGroupInfo(response);
            IServerBean serverBean = this.getServerBean(identify);
            if (serverBean != null) {
                Config config = Config.Store.get();
                Config.VM vm = config.vm();
                vm.setParam("host_id", serverBean.Id().toSerializeId());
                config.store();
                Props.instance().refresh();
                Config.Store.init();
                StoreContext.stop();
                StoreContext.createClusterStore();
                this.saveCurrentServer(false);
            } else {
                this.saveCurrentServer(true);
            }
            this.reshType(response.getHostType());
        }
        catch (Exception e) {
            Throwable t = e.getCause();
            if (t instanceof JYRemoteException) {
                throw new JYServiceRuntimeException(t.getMessage());
            }
            if (e instanceof NamingException) {
                JYServiceRuntimeException je = new JYServiceRuntimeException("cluster.hostaddress.error");
                je.initCause(e);
                throw je;
            }
            if (e instanceof JYServiceRuntimeException) {
                throw (JYServiceRuntimeException)e;
            }
            e.printStackTrace();
            JYServiceRuntimeException je = new JYServiceRuntimeException("cluster.rpc.error");
            je.initCause(e);
            throw je;
        }
    }

    private void saveCurrentServer(boolean isInsert) {
        ServerService serverService = Services.getServerService();
        Config config = Config.Store.get();
        try {
            if (isInsert) {
                serverService.createCurrent(config);
            } else {
                serverService.updateCurrent(config);
            }
        }
        catch (JYConfigServiceException e) {
            e.printStackTrace();
        }
        ClusterService clusterService = Services.getClusterService();
        IClusterBean cluster = clusterService.getCluster();
        if (cluster == null) {
            cluster = (IClusterBean)clusterService.createOne();
            cluster.setName(ClusterNodeBean.instance().readClusterName());
            cluster.setCreateTime(LicenseService.SoftwareDog.getInstance().getInstalled());
            cluster.save();
        }
        IServerBean currentServer = Services.getServerService().getCurrent();
        currentServer.setCluster(cluster);
        currentServer.save();
    }

    public String getHost() {
        return this.host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public IServerBean getServerBean(MemberIdentify identify) throws RemoteException {
        ServerService serverService = Services.getServerService();
        List serverBeanList = serverService.findAll();
        String hostAddress = identify.getHostAddress();
        for (IServerBean ben : serverBeanList) {
            if (!StringUtils.equals((CharSequence)hostAddress, (CharSequence)ben.getHost_address())) continue;
            if (identify.getResourceID() == null) {
                return ben;
            }
            if (!identify.getResourceID().equals(ben.getResourcepool())) continue;
            return ben;
        }
        return null;
    }

    private void reshType(String type) {
        IServerBean currernt = Services.getServerService().getCurrent();
        Config config = Config.Store.get();
        Config.VM.Type vmType = config.vm().type();
        logger.info("the server isWitness[{}],type[{}] ", (Object)type, (Object)vmType);
        if (vmType == Config.VM.Type.witness && StringUtils.isNotEmpty((CharSequence)type)) {
            Config.VM vm = config.vm();
            vm.setParam("type", type);
            config.store();
            currernt.setHost_type(type);
            currernt.save();
        }
    }
}
