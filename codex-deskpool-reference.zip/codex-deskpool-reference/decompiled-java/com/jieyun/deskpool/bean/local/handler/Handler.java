/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.agent.utils.JYEventHandler;

public abstract class Handler
extends JYEventHandler {
}
