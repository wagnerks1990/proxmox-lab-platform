/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.bean.local.handler.LeaveClusterHandler;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.utils.Script;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestorFactorySettingHandler
extends Handler {
    private static final Logger logger = LoggerFactory.getLogger(RestorFactorySettingHandler.class);
    private static DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");

    @Override
    public void handle() {
        System.out.println("RestorFactorySettingHandler");
        if (ClusterNodeBean.instance().isActiveClusterNode()) {
            new LeaveClusterHandler().handle();
        }
        Services.getSystemService().stopFloatIp();
        logger.info("restorFactorySetting");
        String cmd = "mv -f /root/jy /root/jy_bak_" + format.format(new Date());
        Script.runSimpleBashRemoteScript(cmd, 1200);
        logger.info(cmd);
        cmd = "reboot";
        Script.runSimpleBashRemoteScript(cmd, 1200);
    }
}
