/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.local.handler.Handler;

public class RestoreClusterHandler
extends Handler {
    @Override
    public void handle() {
    }
}
