/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.local;

import com.jieyun.deskpool.agent.ServerCommandEngine;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.INodeSignatureBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.handler.BootAsClusterHandler;
import com.jieyun.deskpool.bean.local.handler.BootAsLocalHandler;
import com.jieyun.deskpool.bean.local.handler.CreateClusterHandler;
import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.bean.local.handler.JoinClusterHandler;
import com.jieyun.deskpool.bean.local.handler.LeaveClusterHandler;
import com.jieyun.deskpool.distributed.topo.DeskpoolAddress;
import com.jieyun.deskpool.distributed.topo.ServerRegistry;
import com.jieyun.deskpool.distributed.transfer.data.ClusterGroupInfo;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.front.ServerConfig;
import com.jieyun.deskpool.front.ServerFront;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.LicenseService;
import com.jieyun.deskpool.service.LocaleService;
import com.jieyun.deskpool.service.ServerService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.SystemStatus;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.DpStringUtils;
import com.jieyun.deskpool.utils.MD5Utils;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.manager.ServerManager;
import com.jieyun.deskpool.vm.vmware.api.ResourceUrl;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClusterNodeBean {
    private static final Logger logger = LoggerFactory.getLogger(ClusterNodeBean.class);
    private static boolean NET_WORK_CLOSE_FLAG = true;
    private static ClusterNodeBean instance = new ClusterNodeBean();
    private String newClusterName;
    private NodeStatus nodeStatus;

    public NodeStatus getNodeStatus() {
        return this.nodeStatus;
    }

    public void setNodeStatus(NodeStatus nodeStatus) {
        this.nodeStatus = nodeStatus;
    }

    private ClusterNodeBean() {
    }

    public void enterState(SystemStatus status) {
        if (status != null) {
            System.out.print(" enterStatus " + (Object)((Object)status));
        }
        Services.getSystemService().enterStatus(status);
    }

    public boolean isMaster() {
        return false;
    }

    public void settingHypervisorConfig(Config.VM cvm) {
        try {
            ServerService serverService = Services.getServerService();
            serverService.checkConnection(cvm);
            if (Config.VM.Type.xen.equals((Object)cvm.type())) {
                ServerConfig serverConfig = serverService.getServerConfig(cvm);
                List<ServerConfig.ResourcePool> resources = serverConfig.getResourceList();
                List<String> nodeList = serverConfig.getNodeList();
                if (!resources.isEmpty()) {
                    cvm.setParam("host_resource", resources.get(0).getName());
                    StringBuilder ips = new StringBuilder();
                    for (String ip : nodeList) {
                        ips.append(ip);
                        ips.append(",");
                    }
                    if (ips.length() != 0) {
                        cvm.setParam("node_ips", ips.substring(0, ips.length() - 1));
                    }
                }
            }
            cvm.setParam("host_id", "" + Id.construct());
            Config config = Config.Store.get();
            config.setVm(cvm);
            config.store();
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public void saveResourcePool(ServerFront server) {
        Config config = Config.Store.get();
        Config.VM cvm = config.vm();
        if (server.getResourcepool() != null) {
            cvm.setParam("host_resource", server.getResourcepool());
        }
        cvm.setParam("datastore", server.getDatastore());
        cvm.setParam("network", server.getNetwork());
        cvm.setParam("imagestore", server.getImagestore());
        cvm.setParam("diskstore", server.getDiskstore());
        config.store();
    }

    public ServerConfig readServerConfig() {
        ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
        try {
            if (serverManager != null) {
                return serverManager.getServerConfig();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return new ServerConfig();
    }

    public List<ServerConfig.DataStore> getDatastores(String resourceUrl) {
        if (StringUtils.isNotEmpty((String)resourceUrl)) {
            ResourceUrl resource = ResourceUrl.parse(resourceUrl);
            ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
            try {
                if (serverManager != null && resource != null) {
                    if (resource.isSingleHost()) {
                        return serverManager.getDatastores(resource.getDatacenter(), resource.getResourceName());
                    }
                    return serverManager.getServerConfig().getDataStoreList();
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return new ArrayList<ServerConfig.DataStore>();
    }

    public static ClusterNodeBean instance() {
        return instance;
    }

    public Id getServerId() {
        String sid = Config.Store.get().vm().getParam("host_id");
        if (sid != null && !"".equals(sid)) {
            return Id.construct(sid);
        }
        return null;
    }

    public IServerBean getLocalServer() {
        return Services.getServerService().getCurrent();
    }

    public SystemStatus getSystemStatus() {
        return Services.getSystemService().getServiceStatus();
    }

    public void saveClusterName(String name) {
        Props props = Props.instance();
        props.set("cluster.name", name);
        props.store();
    }

    public void boot() {
        if (this.isConfigAsLocal()) {
            BootAsLocalHandler handler = (BootAsLocalHandler)this.getHandler(BootAsLocalHandler.class);
            handler.handle();
        } else {
            BootAsClusterHandler handler = (BootAsClusterHandler)this.getHandler(BootAsClusterHandler.class);
            handler.handle();
        }
    }

    public void reboot() {
    }

    public void syncGroupInfo(ClusterGroupInfo info) {
        byte[] clusterLicBuf = info.getLicenseBuf();
        LicenseService.loadByByteArray(clusterLicBuf, true);
        if (info.getSystemTime() != null) {
            Services.getSystemService().updateSystemTime(info.getSystemTime());
        }
        LocaleService.instance().forceSelect(info.getLocale());
        ClusterNodeBean.instance().enterState(info.getSystemStatus());
    }

    public boolean isConfigHypervisor() {
        Config.VM config = Config.Store.get().vm();
        return config.isVMIdentifyConfiged();
    }

    public boolean isDefineClusterIdentify() {
        Config.VM config = Config.Store.get().vm();
        if (!config.isVMIdentifyConfiged()) {
            return false;
        }
        String clusterName = this.readClusterName();
        return clusterName != null && !"".equals(clusterName.trim());
    }

    public boolean isActiveClusterNode() {
        return true;
    }

    public boolean testClusterLeaved() {
        Props props = Props.instance();
        String leaveFlag = props.get("cluster.leaved");
        return StringUtils.isNotBlank((String)leaveFlag) && "true".equals(leaveFlag);
    }

    public boolean testClusterStoreReady() {
        return StoreContext.enable();
    }

    public String getStorePath() {
        return String.valueOf(System.getProperty("jy.configHome")) + File.separator + "store" + File.separator + "data";
    }

    private boolean isConfigAsLocal() {
        return "local".equals(AppProps.instance().get("application.runas"));
    }

    public void restorFactorySetting() {
        try {
            Services.getSystemService().restorFactorySetting();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public void deleteClusterIdentify() {
        this.saveClusterName("deskpool-LEAVE-" + DpStringUtils.getRandomStr(5));
    }

    public void enterState() {
    }

    public void createCluster() {
        ServerCommandEngine.Worker.CreateClusterMessage message = (ServerCommandEngine.Worker.CreateClusterMessage)ServerCommandEngine.MessageFactory.instance().create(ServerCommandEngine.Worker.CreateClusterMessage.class, new CreateClusterHandler());
        message.send();
        ServerCommandEngine.Worker.CreateClusterMessage.Response response = message.awaitResponse();
        if (response.getResult() != null) {
            throw new JYServiceRuntimeException(response.getResult());
        }
    }

    public void createLocalCluster() {
        IClusterBean cluster = Services.getClusterService().getCluster();
        if (cluster == null) {
            cluster = (IClusterBean)Services.getClusterService().createOne();
        }
        cluster.setName(ClusterNodeBean.instance().readClusterName());
        cluster.setCreateTime(LicenseService.SoftwareDog.getInstance().getInstalled());
        cluster.save();
        IServerBean currentServer = Services.getServerService().getCurrent();
        currentServer.setCluster(cluster);
        currentServer.save();
    }

    public static void main(String[] args) throws Exception {
        final C c = new C();
        Thread t1 = new Thread(){

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            @Override
            public void run() {
                try {
                    C c2 = c;
                    synchronized (c2) {
                        c.wait();
                        System.out.println("Wait timeout");
                    }
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        t1.start();
        Thread t2 = new Thread(){

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            @Override
            public void run() {
                C c2 = c;
                synchronized (c2) {
                    try {
                        Thread.sleep(5000L);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    c.notify();
                }
            }
        };
        t2.start();
    }

    public synchronized void leaveCluster() {
        LeaveClusterHandler handler = (LeaveClusterHandler)this.getHandler(LeaveClusterHandler.class);
        ServerCommandEngine.Worker.LeaveClusterMessage message = (ServerCommandEngine.Worker.LeaveClusterMessage)ServerCommandEngine.MessageFactory.instance().create(ServerCommandEngine.Worker.LeaveClusterMessage.class, handler);
        message.send();
        message.response(360);
    }

    public synchronized void joinCluster(String host, String username, String password) {
        JoinClusterHandler handler = (JoinClusterHandler)this.getHandler(JoinClusterHandler.class);
        handler.setHost(host);
        handler.setUsername(username);
        handler.setPassword(password);
        ServerCommandEngine.Worker.CreateClusterMessage message = (ServerCommandEngine.Worker.CreateClusterMessage)ServerCommandEngine.MessageFactory.instance().create(ServerCommandEngine.Worker.CreateClusterMessage.class, handler);
        message.send();
        ServerCommandEngine.Worker.CreateClusterMessage.Response response = message.awaitResponse();
        if (response.getResult() != null) {
            throw new JYServiceRuntimeException(response.getResult());
        }
    }

    public void enterMaintanceMode(boolean notifyOther) {
        try {
            Services.getSystemService().enterMaintenanceMode();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public void exitMaintanceMode(boolean notify) {
        try {
            Services.getSystemService().exitMaintenanceMode();
        }
        catch (JYServiceException e) {
            e.printStackTrace();
        }
    }

    private <T> T getHandler(Class<? extends Handler> handlerClass) {
        try {
            return (T)handlerClass.newInstance();
        }
        catch (InstantiationException e) {
            e.printStackTrace();
        }
        catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String readClusterName() {
        return Props.instance().get("cluster.name");
    }

    public static ClusterNodeBean getInstance() {
        return instance;
    }

    public static void setInstance(ClusterNodeBean instance) {
        ClusterNodeBean.instance = instance;
    }

    public String getMacAddr() {
        try {
            ServerManager serverManager = VMControlFactory.get(Config.Store.get()).getServerManager();
            List<String> macList = serverManager.getMACAddr();
            if (macList != null && macList.size() > 0) {
                return macList.get(0);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new JYServiceRuntimeException("error.service.server.testconnect");
        }
        throw new JYServiceRuntimeException("server.find.macaddr.faild");
    }

    public String getNewClusterName() {
        String cluterName = this.readClusterName();
        if (cluterName != null) {
            this.newClusterName = cluterName;
        }
        return this.newClusterName;
    }

    public void setNewClusterName(String newClusterName) {
        this.newClusterName = newClusterName;
    }

    public static boolean isHaCluster() {
        if (Config.Store.get().vm().type() == Config.VM.Type.pve && Services.getServerService().getCurrent() != null) {
            return Services.getServerService().getCurrent().isHaCluster();
        }
        ResourceUrl resource = ResourceUrl.parse(Config.Store.get().vm().getParam("host_resource"));
        return resource != null && resource.isCluster();
    }

    public static boolean isActive() {
        ClusterNodeBean clusterNode = ClusterNodeBean.getInstance();
        if (clusterNode.testClusterLeaved() || clusterNode.isConfigAsLocal()) {
            return true;
        }
        ServerRegistry serverRegistry = ServerRegistry.instance();
        List serverList = Services.getServerService().findAll();
        int count = serverList.size();
        int onLineCout = 0;
        for (IServerBean server : serverList) {
            try {
                if (!serverRegistry.isActive(server.Id())) continue;
                ++onLineCout;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return onLineCout >= count / 2 + 1;
    }

    public static String getFloatIp() {
        IClusterBean cluster = Services.getClusterService().getCluster();
        return cluster != null ? cluster.getFloatIp() : null;
    }

    public static int getRdpPort() {
        return Services.getClusterService().getCluster().getSysConfig().getPingPort();
    }

    public static boolean supportLinux() {
        return Services.getClusterService().getCluster().getSysConfig().isEnableLinuxSupport();
    }

    public static String getRdpPortStr() {
        return String.valueOf(Services.getClusterService().getCluster().getSysConfig().getPingPort());
    }

    public static boolean isDisableNonPlatformLogin() {
        return Services.getClusterService().getCluster().getSysConfig().isDisableNonPlatformLogin();
    }

    public static void closeFloatIp() {
        if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
            NetworkConfig networkConfig = NetworkConfigFactory.createNetworkConfig();
            networkConfig.stopFloatIp();
        } else {
            try {
                String floatIpFile = "/etc/sysconfig/network-scripts/eth0:float";
                if (!DpFileUtils.exists(floatIpFile)) {
                    return;
                }
                String ifdown = "ifdown eth0:float";
                Runtime.getRuntime().exec("ifdown eth0:float");
                logger.info("{} ", (Object)ifdown);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void enteryCloseFloatIp() {
        NET_WORK_CLOSE_FLAG = false;
    }

    public static boolean isStartFloatIp() {
        return NET_WORK_CLOSE_FLAG;
    }

    public String getClusterNodeAddress(String userName) {
        int index;
        DeskpoolAddress address;
        List<DeskpoolAddress> addressList;
        int count;
        if (StoreContext.enable() && (count = (addressList = this.getAddrNoWitness()).size()) > 1 && StringUtils.isNotBlank((String)(address = addressList.get(index = (index = userName.hashCode() % count) > 0 ? index : Math.abs(index))).getAddress())) {
            return address.getAddress();
        }
        return null;
    }

    public String getWitnessAddr() {
        for (IServerBean server : Services.getServerService().findAll()) {
            if (!server.isWitness()) continue;
            NetworkConfigVO netWork = server.getNetworkByStr();
            return netWork != null ? netWork.getAddress() : null;
        }
        return null;
    }

    public List<DeskpoolAddress> getAddrNoWitness() {
        String withnessAddr = this.getWitnessAddr();
        List<DeskpoolAddress> addressList = ServerRegistry.instance().findActiveAddress();
        if (withnessAddr != null) {
            for (DeskpoolAddress deAddress : addressList) {
                if (!StringUtils.equals((String)withnessAddr, (String)deAddress.getAddress())) continue;
                addressList.remove(deAddress);
                break;
            }
        }
        return addressList;
    }

    public boolean isValid() {
        if (ClusterNodeBean.isHaCluster()) {
            return true;
        }
        String clusterName = ClusterNodeBean.getInstance().readClusterName();
        IClusterBean cluster = Services.getClusterService().getCluster();
        if (StringUtils.isEmpty((String)clusterName) || cluster == null) {
            logger.info(" find INodeSignatureBean  failed ,the clusterName:{},the cluster:{}", (Object)clusterName, (Object)cluster);
            return false;
        }
        String clusterLicense = cluster.getClusterLicense();
        for (IServerBean server : Services.getServerService().findAll()) {
            if (!this.serverIsValid(server, clusterName, clusterLicense)) continue;
            return true;
        }
        logger.error("the clusterNodeBean find ");
        return false;
    }

    private boolean serverIsValid(IServerBean server, String clusterName, String clusterLicense) {
        String macAddresss = server.getHost_macAddr();
        if (StringUtils.isEmpty((String)macAddresss) && server.isOnline() && NodeStatus.ONLINE.equals((Object)server.getNodeStatus())) {
            macAddresss = server.getMACAddress();
        }
        if (StringUtils.isNotEmpty((String)macAddresss)) {
            String serverSignature = MD5Utils.getMd5ByStr(String.valueOf(clusterName) + macAddresss + clusterLicense);
            for (INodeSignatureBean node : Services.getNodeSignatureServices().findAll()) {
                if (!StringUtils.equals((String)serverSignature, (String)node.getSignature())) continue;
                return true;
            }
            logger.info("the serverBean[{}] find INodeSignatureBean  failed", (Object)server.getName());
        } else {
            logger.info("the serverBean[{}], the macAddress  is null", (Object)server.getName());
        }
        return false;
    }

    public void syncNodeSignature() {
        if (!this.isValid()) {
            return;
        }
        String clusterName = ClusterNodeBean.getInstance().readClusterName();
        if (StringUtils.isEmpty((String)clusterName)) {
            return;
        }
        IClusterBean cluster = Services.getClusterService().getCluster();
        if (cluster == null) {
            return;
        }
        List<INodeSignatureBean> list = Services.getNodeSignatureServices().findAll();
        String clusterLince = cluster.getClusterLicense();
        HashMap<String, INodeSignatureBean> findMap = new HashMap<String, INodeSignatureBean>();
        List serverList = Services.getServerService().findAll();
        for (IServerBean server : serverList) {
            this.checkNodeSignature(server, list, clusterName, clusterLince, findMap);
        }
        if (serverList.size() == findMap.size()) {
            this.clearInvalid(list, findMap);
        }
    }

    private void checkNodeSignature(IServerBean server, List<INodeSignatureBean> list, String clusterName, String clusterLince, Map<String, INodeSignatureBean> findMap) {
        try {
            INodeSignatureBean node2;
            String macAddresss = server.getHost_macAddr();
            if (StringUtils.isEmpty((String)macAddresss) && server.isOnline() && NodeStatus.ONLINE.equals((Object)server.getNodeStatus())) {
                macAddresss = server.getMACAddress();
            }
            if (StringUtils.isEmpty((String)macAddresss)) {
                return;
            }
            String signature = MD5Utils.getMd5ByStr(String.valueOf(clusterName) + macAddresss + clusterLince);
            for (INodeSignatureBean node2 : list) {
                if (!StringUtils.equals((String)node2.getSignature(), (String)signature)) continue;
                findMap.put(node2.Id().toSerializeId(), node2);
                return;
            }
            logger.info("checkNodeSignature: find fail! the INodeSignatureBean[{" + server.getName() + "}] will create. ");
            node2 = (INodeSignatureBean)Services.getNodeSignatureServices().createOne();
            node2.getUpdate().init(null, clusterName, macAddresss, clusterLince);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clearInvalid(List<INodeSignatureBean> list, Map<String, INodeSignatureBean> map) {
        for (INodeSignatureBean node : list) {
            if (map.containsKey(node.Id().toSerializeId())) continue;
            logger.info("the remove NodeSignatureBean[{}]:", (Object)node);
            node.remove();
        }
    }

    public synchronized String generateLicense() {
        String license = DpStringUtils.getRandomStr(10);
        for (INodeSignatureBean nodeSignatureBean : Services.getNodeSignatureServices().findAll()) {
            nodeSignatureBean.remove();
        }
        String clusterName = ClusterNodeBean.instance().readClusterName();
        boolean hasNodeSignatureBean = false;
        for (IServerBean serverBean : Services.getServerService().findAll()) {
            String macAddr;
            if (serverBean.getNodeStatus() != NodeStatus.ONLINE || !StringUtils.isNotEmpty((String)(macAddr = serverBean.getMACAddress())) || !StringUtils.isNotEmpty((String)clusterName)) continue;
            INodeSignatureBean node = (INodeSignatureBean)Services.getNodeSignatureServices().createOne();
            node.getUpdate().init(null, clusterName, macAddr, license);
            hasNodeSignatureBean = true;
        }
        if (hasNodeSignatureBean) {
            logger.info("generateLicense:the license=" + license);
            IClusterBean clusterBean = Services.getClusterService().getCluster();
            if (clusterBean != null) {
                clusterBean.getUpdate().setClusterLicense(license).save();
                return license;
            }
            return null;
        }
        logger.info("generateLicense:the macAddress is error =" + license);
        return null;
    }

    public static String getSystemLegencyFeatureCode() {
        IServerBean current = Services.getServerService().getCurrent();
        if (current == null) {
            return "";
        }
        String feature = current.isHaCluster() ? current.getName() : current.getMACAddress();
        if (StringUtils.isEmpty((String)feature)) {
            return "";
        }
        return MD5Utils.getMd5ByStr(feature);
    }

    public static String getSystemLegencyFeatureCodeInCache() {
        String feature;
        IServerBean current = Services.getServerService().getCurrent();
        if (current == null) {
            return "";
        }
        if (current.isHaCluster()) {
            feature = current.getName();
        } else {
            String macAddress = current.getHost_macAddr();
            if (StringUtils.isEmpty((String)macAddress)) {
                return "";
            }
            feature = macAddress;
        }
        return MD5Utils.getMd5ByStr(feature);
    }

    public static String getSystemFeatureCodeInCache() {
        String license;
        IServerBean current = Services.getServerService().getCurrent();
        if (current == null) {
            return "";
        }
        if (current.isHaCluster()) {
            return ClusterNodeBean.getHAClusterFeatureCode(current);
        }
        String feature = "";
        IClusterBean clusterBean = Services.getClusterService().getCluster();
        String string = license = clusterBean != null ? clusterBean.getClusterLicense() : null;
        if (StringUtils.isNotEmpty((String)license)) {
            feature = MD5Utils.getMd5ByStr(String.valueOf(license) + "DeskPool");
        }
        if (StringUtils.isEmpty((String)feature)) {
            logger.info("License Service system featureCode : {}", (Object)feature);
            return "";
        }
        return feature;
    }

    public static String getHAClusterFeatureCode(IServerBean current) {
        String license = ClusterNodeBean.getInstance().readClusterName();
        return MD5Utils.getMd5ByStr(String.valueOf(license) + "DeskPool");
    }

    public static String getSystemFeatureCode() {
        IServerBean current = Services.getServerService().getCurrent();
        if (current == null) {
            return "";
        }
        if (current.isHaCluster()) {
            return ClusterNodeBean.getHAClusterFeatureCode(current);
        }
        IClusterBean clusterBean = Services.getClusterService().getCluster();
        String feature = "";
        if (clusterBean != null) {
            String license = clusterBean.getClusterLicense();
            if (license == null && current.isMaster()) {
                license = ClusterNodeBean.instance().generateLicense();
                logger.info("the generateLicense license : {}", (Object)license);
            }
            if (StringUtils.isNotEmpty((String)license)) {
                feature = MD5Utils.getMd5ByStr(String.valueOf(license) + "DeskPool");
            }
        }
        if (StringUtils.isEmpty((String)feature)) {
            logger.info("License Service system featureCode : {}", (Object)feature);
        }
        return feature;
    }

    public boolean enableThinClientCertificate() {
        return Services.getThinClientCertificateService().enableThinClientCertificate();
    }

    public String getEnableCertificatePrivateKey() {
        return Services.getThinClientCertificateService().getEnableCertificatePrivateKey();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public IServerBean getTemplateAppServer() {
        IClusterBean clusterBean = Services.getClusterService().getCluster();
        if (clusterBean == null) {
            throw new JYServiceRuntimeException("error.cluster.err");
        }
        IServerBean serverBean = clusterBean.getTemplateAPPServer();
        if (serverBean == null) {
            ClusterNodeBean clusterNodeBean = this;
            synchronized (clusterNodeBean) {
                serverBean = clusterBean.getTemplateAPPServer();
                if (serverBean == null) {
                    IServerBean masterServer = Services.getServerService().getMaster();
                    clusterBean.getUpdate().setTemplateAPPServerId(masterServer).save();
                    return clusterBean.getTemplateAPPServer();
                }
            }
        }
        return serverBean;
    }

    public static class C {
        private String username;
    }
}
