/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.SystemService;

public class EnterMaintanceHandler
extends Handler {
    private boolean notifyOther = false;

    @Override
    public void handle() {
        SystemService systemService = Services.getSystemService();
        try {
            systemService.enterMaintenanceMode();
        }
        catch (JYServiceException e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public void setNotifyOther(boolean notifyOther) {
        this.notifyOther = notifyOther;
    }
}
