/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local;

public static class ClusterNodeBean.C {
    private String username;
}
