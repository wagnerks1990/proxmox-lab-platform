/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IDeskpoolServerRemote;
import com.jieyun.deskpool.distributed.topo.DeskpoolAddress;
import com.jieyun.deskpool.distributed.topo.ServerRegistry;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.Props;
import java.util.List;

public class LeaveClusterHandler
extends Handler {
    private List<DeskpoolAddress> addressList;

    @Override
    public void handle() {
        this.addressList = ServerRegistry.instance().findActiveAddress();
        StoreContext.stop();
        ClusterNodeBean.instance().deleteClusterIdentify();
        StoreContext.createLocalStore();
        IClusterBean cluster = Services.getClusterService().getCluster();
        cluster.getUpdate().updateFloatIp(null).save();
        Services.getSystemService().stopFloatIp();
        this.removeClusterDirtyData();
    }

    private void removeClusterDirtyData() {
        Props.instance().set("cluster.leaved", true).store();
        ClusterNodeBean serverBean = ClusterNodeBean.instance();
        DeskpoolAddress deskpoolAddress = this.findOneRemoteAddress();
        if (deskpoolAddress != null) {
            try {
                IDeskpoolServerRemote remote = (IDeskpoolServerRemote)RMIUtils.getRemoteProxy(deskpoolAddress.getAddress(), "DeskpoolServerRemote");
                remote.removeMeFromCluster(serverBean.getServerId());
            }
            catch (Exception e) {
                throw new JYServiceRuntimeException(e);
            }
        }
        List serverList = Services.getServerService().findAll();
        for (IServerBean server : serverList) {
            if (server.isLocal()) continue;
            server.storeRemoveAll();
        }
    }

    private DeskpoolAddress findOneRemoteAddress() {
        if (this.addressList == null) {
            return null;
        }
        for (DeskpoolAddress address : this.addressList) {
            if (address.isLocal()) continue;
            return address;
        }
        return null;
    }
}
