/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.AdminAccountBean;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.INodeSignatureBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.bean.local.rules.JoinOrCreateClusterLocalRule;
import com.jieyun.deskpool.bean.local.rules.TestClusterExistedRule;
import com.jieyun.deskpool.distributed.agent.SystemStatusObject;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.service.ClusterService;
import com.jieyun.deskpool.service.JYConfigServiceException;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.LicenseService;
import com.jieyun.deskpool.service.ServerService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.UsbPolicyService;
import com.jieyun.deskpool.shared.SystemStatus;
import com.jieyun.deskpool.store.ServicePortCache;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.DpStringUtils;

public class CreateClusterHandler
extends Handler {
    @Override
    public void handle() {
        ClusterNodeBean cluster = ClusterNodeBean.instance();
        cluster.setNewClusterName("deskpool-cluster-" + DpStringUtils.getRandomStr(5));
        new JoinOrCreateClusterLocalRule().test();
        new TestClusterExistedRule().test();
        ClusterNodeBean.instance().saveClusterName(ClusterNodeBean.instance().getNewClusterName());
        StoreContext.createClusterStore();
        try {
            for (INodeSignatureBean nodeSignature : Services.getNodeSignatureServices().findAll()) {
                nodeSignature.remove();
            }
            this.createCurrentServer();
        }
        catch (JYConfigServiceException e) {
            e.printStackTrace();
            throw new JYServiceRuntimeException(e.getErrorList());
        }
        this.settingDefaultData();
        SystemStatusObject.instance().setSystemStatus(SystemStatus.NORMAL);
    }

    private void createCurrentServer() throws JYConfigServiceException {
        ServerService serverService = Services.getServerService();
        Config config = Config.Store.get();
        serverService.createCurrent(config);
        ClusterService clusterService = Services.getClusterService();
        IClusterBean cluster = clusterService.getCluster();
        if (cluster == null) {
            cluster = (IClusterBean)clusterService.createOne();
            cluster.setName(ClusterNodeBean.instance().readClusterName());
            cluster.setCreateTime(LicenseService.SoftwareDog.getInstance().getInstalled());
            cluster.save();
        }
        IServerBean currentServer = Services.getServerService().getCurrent();
        currentServer.setCluster(cluster);
        currentServer.save();
    }

    private void settingDefaultData() {
        AdminAccountBean.settingClusterAdmin();
        ServicePortCache.init();
        UsbPolicyService usbPolicyService = Services.getUsbPolicyService();
        usbPolicyService.createDefaultIfAbsent();
    }
}
