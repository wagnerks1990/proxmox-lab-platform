/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local;

import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.front.ServerConfig;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.vm.VMControlFactory;

public class ConfigServerBean {
    public static ConfigServerBean get() {
        ConfigServerBean server = new ConfigServerBean();
        return server;
    }

    public String getHostAddress() {
        return Config.Store.get().vm().getParam("host_address");
    }

    public String getHostType() {
        return Config.Store.get().vm().getParam("type");
    }

    public ServerConfig readServerConfig() {
        return VMControlFactory.get(Config.Store.get()).getServerManager().getServerConfig();
    }

    public NetworkConfig readNetworkConfig() {
        NetworkConfig config = NetworkConfigFactory.createNetworkConfig();
        return config;
    }
}
