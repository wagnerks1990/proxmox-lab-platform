/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.handler;

import com.jieyun.deskpool.bean.local.handler.Handler;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.service.JYConfigServiceException;
import com.jieyun.deskpool.service.ServerService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.StoreContext;

public class BootAsLocalHandler
extends Handler {
    @Override
    public void handle() {
        StoreContext.createLocalStore();
        ServerService serverService = Services.getServerService();
        Config config = Config.Store.get();
        try {
            serverService.setCurrent(config);
        }
        catch (JYConfigServiceException e) {
            e.printStackTrace();
        }
    }
}
