/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.infinispan.remoting.transport.Address
 */
package com.jieyun.deskpool.bean.local.handler;

import java.util.Comparator;
import java.util.List;
import org.infinispan.remoting.transport.Address;

class MergeClusterHandler.1
implements Comparator<List<Address>> {
    MergeClusterHandler.1() {
    }

    @Override
    public int compare(List<Address> o1, List<Address> o2) {
        int restult = 0;
        Address least = null;
        if (o1.size() < o2.size()) {
            restult = 1;
        } else if (o1.size() > o2.size()) {
            restult = -1;
        } else if (o1.size() == 0) {
            restult = 0;
        } else {
            restult = -1;
            least = null;
            for (Address a : o1) {
                if (least != null && a.hashCode() >= least.hashCode()) continue;
                least = a;
            }
            for (Address a : o2) {
                if (a.hashCode() >= least.hashCode()) continue;
                restult = 1;
                break;
            }
        }
        return restult;
    }
}
