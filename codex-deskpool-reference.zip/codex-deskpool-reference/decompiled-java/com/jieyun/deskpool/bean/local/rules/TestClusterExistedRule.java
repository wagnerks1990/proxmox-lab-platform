/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jgroups.Address
 *  org.jgroups.Event
 *  org.jgroups.JChannel
 */
package com.jieyun.deskpool.bean.local.rules;

import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import java.util.List;
import org.jgroups.Address;
import org.jgroups.Event;
import org.jgroups.JChannel;

public class TestClusterExistedRule {
    public void test() {
        if (this.testClusterExisted()) {
            throw new JYServiceRuntimeException("cluster.existed");
        }
    }

    public boolean testClusterExisted() {
        try (JChannel ch = null;){
            ch = new JChannel("jgroups.xml");
            ch.connect(ClusterNodeBean.instance().getNewClusterName());
            List memberList = ch.getView().getMembers();
            for (Address address : memberList) {
                Object phyAddress = ch.down(new Event(87, (Object)address));
                System.out.println("Cluster Member : " + phyAddress);
            }
            boolean bl = memberList != null && memberList.size() > 1;
            return bl;
        }
    }
}
