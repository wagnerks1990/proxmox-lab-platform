/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.local.rules;

import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.store.StoreContext;

public class JoinOrCreateClusterLocalRule {
    public void test() {
        this.validateJoinOrCreateLocalState();
    }

    private void validateJoinOrCreateLocalState() {
        ClusterNodeBean server = ClusterNodeBean.instance();
        if (server.isDefineClusterIdentify()) {
            throw new JYServiceRuntimeException("cluster.join.definedClusterIdentify");
        }
        if (StoreContext.enable()) {
            throw new JYServiceRuntimeException("cluster.join.storeEnabled");
        }
    }
}
