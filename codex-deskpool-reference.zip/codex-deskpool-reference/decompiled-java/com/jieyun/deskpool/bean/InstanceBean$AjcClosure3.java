/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.aspectj.runtime.internal.AroundClosure
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.InstanceBean;
import org.aspectj.runtime.internal.AroundClosure;

public class InstanceBean$AjcClosure3
extends AroundClosure {
    public InstanceBean$AjcClosure3(Object[] objectArray) {
        super(objectArray);
    }

    public Object run(Object[] objectArray) {
        Object[] objectArray2 = this.state;
        InstanceBean.merge_aroundBody2((InstanceBean)objectArray[0]);
        return null;
    }
}
