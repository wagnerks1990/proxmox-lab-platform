/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.ServerEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.EntityApi;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IResource;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Server;
import com.jieyun.deskpool.front.ImportedVM;
import com.jieyun.deskpool.front.ServerConfig;
import com.jieyun.deskpool.front.ServerFront;
import com.jieyun.deskpool.shared.GpuDevice;
import com.jieyun.deskpool.shared.GpuResource;
import com.jieyun.deskpool.shared.HypervisorConfigParams;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.MediateDevice;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.Resource;
import com.jieyun.deskpool.shared.ServerStatus;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.shared.VPower;
import com.jieyun.deskpool.utils.Credentials;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.vm.common.NodeConfig;
import java.util.List;
import java.util.Map;

public interface IServerBean
extends Bean<Server>,
IResource,
EntityApi<ServerEntity> {
    public ServerConfig getServerConfig();

    public boolean accepting();

    public Credentials getCredentials();

    public void shutdown();

    public void restart();

    public void destroyInstances();

    public Update getUpdate();

    public ImportedVM refrechImportableCheck(String var1);

    public List<ImportedVM> getImportableVM();

    public List<ImportedVM> getImportableTemplate();

    public boolean vmExists(String var1);

    public IClusterBean getClusterBean();

    public void createUserdb(UserDB var1);

    public void createDatastore(String var1, String var2);

    public String getName();

    public String getDatastore();

    public String getNetwork();

    public ServerStatus getStatus();

    public String getHost_type();

    public String getHost_user();

    public String getHost_vmmver();

    public String getHost_password();

    public String getHost_address();

    public String getHostinfo_version();

    public IClusterBean getCluster();

    public boolean isMaster();

    public void setMaster(boolean var1);

    public void setName(String var1);

    public void setDatastore(String var1);

    public void setNetwork(String var1);

    public void setStatus(ServerStatus var1);

    public void setHost_type(String var1);

    public void setHost_user(String var1);

    public void setHost_vmmver(String var1);

    public void setHost_password(String var1);

    public void setHost_address(String var1);

    public void setHost_macAddr(String var1);

    public void setCluster(IClusterBean var1);

    public void setHostinfo_version(String var1);

    public void setGpuResource(GpuResource var1);

    public void setNodeStatus(NodeStatus var1);

    public NodeStatus getNodeStatus();

    public void assignId(Id var1);

    public Update freshen();

    public IServerBean save();

    public Resource.Core getCore();

    public void setCore(Resource.Core var1);

    public Resource.Memory getMemory();

    public void setMemory(Resource.Memory var1);

    public Resource.Storage getStorage1();

    public void setStorage1(Resource.Storage var1);

    public Resource.Storage getStorage2();

    public GpuResource getGpuResource();

    public void setStorage2(Resource.Storage var1);

    public void setCapacity(Resource.Capacity var1);

    public Resource.Capacity getCapacity();

    public NetworkConfig getNetworkConfig();

    public PoolInfo countInstancebyStatus();

    public PoolInfo countInstancebyStatus(ITemplateBean var1);

    public boolean isLocal();

    public void storeRemoveAll();

    public void leaveCluster();

    public void deactive();

    public void quiesce();

    public void shutdownService();

    public void restartService();

    public void restartServer();

    public void restorFactorySetting();

    public NetworkConfigVO readNetworkConfig();

    public void saveNetworkParams(NetworkConfigVO var1);

    public void updateHypervisorParams(HypervisorConfigParams var1);

    @Override
    public String asString();

    public List<String> getMACAddr();

    public ServerFront.HostInfoFront getHostInfoFront();

    public List<ServerFront.NodeInfoFront> getNodeInfoList();

    public boolean isOnline();

    public String getImagestore();

    public String getDiskstore();

    public void setImagestore(String var1);

    public void setDiskstore(String var1);

    public void setDiskType(String var1);

    public boolean isHaCluster();

    public void setHaCluster(boolean var1);

    @Override
    public ApiResult<ServerEntity> apiGet();

    public String getResourcepool();

    public void setResourcepool(String var1);

    public void applyPatch(byte[] var1, String var2);

    public String getServerMd5();

    public void checkIPCollision(String var1);

    public void syncLicense(byte[] var1);

    public NetworkConfigVO getNetworkByStr();

    public List<ServerFront.NodeInfoFront> getNodeInfoListByStr();

    public String getResourceAddress();

    public boolean vmExistsOnLocal(String var1);

    public void setWitness(boolean var1);

    public boolean isWitness();

    public void setMaxConnectionTime(int var1);

    public String getHost_macAddr();

    public String getMACAddress();

    public boolean validateSignature();

    public String getMACAddress(List<String> var1);

    public String getBestNode(String var1, VPower var2);

    public Map<String, NodeConfig> getOlinNode();

    public Map<String, Double> getNodeUsageRate(VPower var1);

    public String getFloatServerIp();

    public boolean isShared(String var1);

    public boolean checkStorageType(List<String> var1);

    public String getDiskType();

    public String[] getLocalTemplateAppData();

    public void syncLocalImageData();

    public void backImage(Id var1);

    public boolean existFile(String var1, String var2);

    public List<GpuDevice> getGpuDevices();

    public List<MediateDevice> getMediateDevices();

    public List<MediateDevice> getMediateDevices(boolean var1);

    public static interface Update
    extends IServerBean,
    Bean.Update<Server> {
        public void enterOnline();

        public void enterOffline(String var1);

        public void setNetworkStr(NetworkConfigVO var1);

        public void setNodeInfoListStr(List<ServerFront.NodeInfoFront> var1);

        public Update setGpuDevices(List<GpuDevice> var1);

        public Update setMediateDevices(List<MediateDevice> var1);
    }
}
