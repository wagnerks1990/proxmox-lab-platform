/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.bean.accessnetwork;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.accessnetwork.AccessMatchResult;
import com.jieyun.deskpool.bean.accessnetwork.IAccessNetworkBean;
import com.jieyun.deskpool.domain.AccessNetwork;
import com.jieyun.deskpool.shared.Subnet;
import com.jieyun.deskpool.utils.IPv4Util;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class AccessNetworkBean
extends DefaultBean<AccessNetwork>
implements IAccessNetworkBean {
    @Override
    public AccessMatchResult matchACL(String clientIP) {
        AccessNetwork domain = (AccessNetwork)this.getDomain();
        List<Subnet> subnets = domain.getSubnets();
        if (subnets != null) {
            Collections.sort(subnets, new Comparator<Subnet>(){

                @Override
                public int compare(Subnet o1, Subnet o2) {
                    return o2.getNetmask() - o1.getNetmask();
                }
            });
            for (Subnet subnet : subnets) {
                int[] subnetScope = IPv4Util.getIPIntScope(String.valueOf(subnet.getName()) + "/" + subnet.getNetmask());
                if (!this.match(subnetScope[0], subnetScope[1], subnet.getNetmask(), clientIP)) continue;
                AccessMatchResult result = new AccessMatchResult();
                result.setSubnet(subnet);
                result.setServiceACL(domain.getServiceACL());
                result.setAccessNetwork(this);
                return result;
            }
        }
        return null;
    }

    @Override
    public Bean<AccessNetwork> save() {
        List<Subnet> subnets = ((AccessNetwork)this.getDomain()).getSubnets();
        if (subnets != null) {
            Iterator<Subnet> itr = subnets.iterator();
            while (itr.hasNext()) {
                Subnet subnet = itr.next();
                if (!StringUtils.isBlank((String)subnet.getName())) continue;
                itr.remove();
            }
        }
        return super.save();
    }

    private boolean match(int start, int end, int netmask, String clientIP) {
        int[] clientScope = IPv4Util.getIPIntScope(String.valueOf(clientIP) + "/" + netmask);
        return clientScope[0] >= start && clientScope[1] <= end;
    }

    @Override
    public String getServiceName() {
        return "";
    }

    @Override
    public boolean allowRdp() {
        return ((AccessNetwork)this.getDomain()).getServiceACL() != null && ((AccessNetwork)this.getDomain()).getServiceACL().getRdp() != false;
    }
}
