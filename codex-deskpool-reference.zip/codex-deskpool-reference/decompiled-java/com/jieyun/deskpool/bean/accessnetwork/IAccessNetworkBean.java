/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.accessnetwork;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.accessnetwork.AccessMatchResult;
import com.jieyun.deskpool.domain.AccessNetwork;

public interface IAccessNetworkBean
extends Bean<AccessNetwork> {
    public AccessMatchResult matchACL(String var1);

    public boolean allowRdp();
}
