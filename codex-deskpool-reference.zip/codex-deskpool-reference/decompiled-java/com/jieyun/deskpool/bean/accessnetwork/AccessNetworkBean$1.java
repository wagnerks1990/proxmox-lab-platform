/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.accessnetwork;

import com.jieyun.deskpool.shared.Subnet;
import java.util.Comparator;

class AccessNetworkBean.1
implements Comparator<Subnet> {
    AccessNetworkBean.1() {
    }

    @Override
    public int compare(Subnet o1, Subnet o2) {
        return o2.getNetmask() - o1.getNetmask();
    }
}
