/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.accessnetwork;

import com.jieyun.deskpool.bean.accessnetwork.IAccessNetworkBean;
import com.jieyun.deskpool.shared.ServiceACL;
import com.jieyun.deskpool.shared.Subnet;

public class AccessMatchResult {
    private IAccessNetworkBean accessNetwork;
    private Subnet subnet;
    private ServiceACL serviceACL;

    public IAccessNetworkBean getAccessNetwork() {
        return this.accessNetwork;
    }

    public void setAccessNetwork(IAccessNetworkBean accessNetwork) {
        this.accessNetwork = accessNetwork;
    }

    public Subnet getSubnet() {
        return this.subnet;
    }

    public void setSubnet(Subnet subnet) {
        this.subnet = subnet;
    }

    public ServiceACL getServiceACL() {
        return this.serviceACL;
    }

    public void setServiceACL(ServiceACL serviceACL) {
        this.serviceACL = serviceACL;
    }
}
