/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ILicenseLogBean;
import com.jieyun.deskpool.domain.LicenseLog;

public static interface ILicenseLogBean.Update
extends ILicenseLogBean,
Bean.Update<LicenseLog> {
    public void setProduct(String var1);

    public void setAssignee(String var1);

    public void setVersion(String var1);

    public void setExpireDays(String var1);

    public void setLicenseType(String var1);

    public void setDesktopLimit(String var1);

    public void setFeatureCode(String var1);

    public void setCreateTime(String var1);

    public void setSessionLimit(String var1);

    public void setCreateIp(String var1);
}
