/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ITCGroupBean;
import com.jieyun.deskpool.domain.TCGroup;
import com.jieyun.deskpool.shared.TCBaseConfig;
import com.jieyun.deskpool.shared.TCConnectConfig;

public static interface ITCGroupBean.Update
extends ITCGroupBean,
Bean.Update<TCGroup> {
    public void setStartIp(String var1);

    public void setEndIp(String var1);

    public void setEnable(boolean var1);

    public void setName(String var1);

    public void setRemark(String var1);

    public void setTCBaseConfig(TCBaseConfig var1);

    public void setTCConnectConfig(TCConnectConfig var1);

    public void setEnableLocalIP(boolean var1);

    public void setMonitorNoUpdateConfig(boolean var1);
}
