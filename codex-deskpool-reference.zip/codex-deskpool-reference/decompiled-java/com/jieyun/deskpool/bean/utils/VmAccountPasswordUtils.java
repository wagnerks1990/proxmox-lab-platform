/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.utils;

import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class VmAccountPasswordUtils {
    private static byte[] key = null;
    private static String ALG = "AES";

    static {
        try {
            key = "jie&*%$#yun^%$desk38*(pool".getBytes("utf-8");
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static String encode(String rawPassword) {
        if (rawPassword == null) {
            return null;
        }
        try {
            SecretKey secretKey = VmAccountPasswordUtils.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALG);
            Cipher cipher = Cipher.getInstance(ALG);
            byte[] byteContent = rawPassword.getBytes("utf-8");
            cipher.init(1, key);
            byte[] result = cipher.doFinal(byteContent);
            return VmAccountPasswordUtils.parseByte2HexStr(result);
        }
        catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    private static SecretKey generateKey() {
        try {
            KeyGenerator _generator = KeyGenerator.getInstance(ALG);
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(key);
            _generator.init(128, secureRandom);
            return _generator.generateKey();
        }
        catch (Exception e) {
            throw new RuntimeException(" \u521d\u59cb\u5316\u5bc6\u94a5\u51fa\u73b0\u5f02\u5e38 ");
        }
    }

    public static String decode(String encodePassword) {
        if (encodePassword == null) {
            return null;
        }
        try {
            SecretKey secretKey = VmAccountPasswordUtils.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALG);
            Cipher cipher = Cipher.getInstance(ALG);
            cipher.init(2, key);
            byte[] result = cipher.doFinal(VmAccountPasswordUtils.parseHexStr2Byte(encodePassword));
            return new String(result, "utf-8");
        }
        catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    public static String parseByte2HexStr(byte[] buf) {
        StringBuffer sb = new StringBuffer();
        int i = 0;
        while (i < buf.length) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = String.valueOf('0') + hex;
            }
            sb.append(hex.toUpperCase());
            ++i;
        }
        return sb.toString();
    }

    public static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }
        byte[] result = new byte[hexStr.length() / 2];
        int i = 0;
        while (i < hexStr.length() / 2) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte)(high * 16 + low);
            ++i;
        }
        return result;
    }
}
