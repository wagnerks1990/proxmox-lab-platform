/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.bean.utils;

import com.jieyun.deskpool.shared.UsbRedirectPolicy;
import org.apache.commons.lang.StringUtils;
import sun.misc.BASE64Encoder;

public class UsbPolicyUtils {
    public static boolean isAllowNamelistStyle(UsbRedirectPolicy policy) {
        return policy.getPid().equalsIgnoreCase("0xffff") && "Allow".equals(policy.getType()) && policy.getVid().equalsIgnoreCase("0xffff") && "Allow".equals(policy.getType());
    }

    public static boolean isDenyNamelistStyle(UsbRedirectPolicy policy) {
        return policy.getPid().equalsIgnoreCase("0xffff") && "Deny".equals(policy.getType()) && policy.getVid().equalsIgnoreCase("0xffff") && "Deny".equals(policy.getType());
    }

    public static boolean isDeny(UsbRedirectPolicy policy) {
        return "Deny".equals(policy.getType());
    }

    public static String encodeContent(String value) {
        if (StringUtils.isBlank((String)value)) {
            return "";
        }
        try {
            byte[] keyArr = "powerwhelming".getBytes("UTF-8");
            byte[] byteArr = value.getBytes("UTF-8");
            int klen = keyArr.length;
            int i = 0;
            while (i < byteArr.length) {
                byteArr[i] = (byte)(byteArr[i] ^ keyArr[i % klen]);
                ++i;
            }
            return new BASE64Encoder().encodeBuffer(byteArr);
        }
        catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
