/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  org.apache.commons.lang.StringUtils
 *  org.aspectj.lang.JoinPoint$StaticPart
 *  org.aspectj.lang.Signature
 *  org.aspectj.runtime.internal.AroundClosure
 *  org.aspectj.runtime.reflect.Factory
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.aspectj.AnnotationTransactionAspect
 */
package com.jieyun.deskpool.bean;

import com.alibaba.fastjson.JSON;
import com.deskpool.constant.DeskpoolConfigConstant;
import com.jieyun.deskpool.agent.usersession.UserSessionManager;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.InstanceEntity;
import com.jieyun.deskpool.api.data.InstanceEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.IThinClientBean;
import com.jieyun.deskpool.bean.ITrackerBean;
import com.jieyun.deskpool.bean.IUserDiskBean;
import com.jieyun.deskpool.bean.InstanceBean$AjcClosure1;
import com.jieyun.deskpool.bean.InstanceBean$AjcClosure3;
import com.jieyun.deskpool.distributed.rpc.DispatchPoint;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.LocatedBean;
import com.jieyun.deskpool.distributed.topo.DeskpoolAddress;
import com.jieyun.deskpool.distributed.topo.ServerRegistry;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.domain.Instance;
import com.jieyun.deskpool.remoteos.UserSessionBroker;
import com.jieyun.deskpool.service.ClusterService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.service.ldap.ad.AdComputerService;
import com.jieyun.deskpool.shared.AdminOperation;
import com.jieyun.deskpool.shared.AgentStatus;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DpClientType;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.IPPolicy;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ImageInfo;
import com.jieyun.deskpool.shared.ImageStatus;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.PrepState;
import com.jieyun.deskpool.shared.PrepTask;
import com.jieyun.deskpool.shared.PrepType;
import com.jieyun.deskpool.shared.TemplateStatus;
import com.jieyun.deskpool.shared.TrackerOperation;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.shared.VMNetworkConfig;
import com.jieyun.deskpool.shared.VPower;
import com.jieyun.deskpool.shared.VirtualGpuInstance;
import com.jieyun.deskpool.utils.Base64Util;
import com.jieyun.deskpool.utils.DpClientUtils;
import com.jieyun.deskpool.utils.PathManager;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.utils.Util;
import com.jieyun.deskpool.vm.Stopwatch;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.common.NodeConfig;
import com.jieyun.deskpool.vm.manager.InstanceManager;
import com.jieyun.deskpool.web.faces.utils.FacesUtils;
import com.jieyun.deskpool.windows.agentclient.AgentClient;
import com.jieyun.deskpool.windows.agentclient.AgentFactory;
import com.jieyun.deskpool.windows.agentclient.IAgentClient;
import com.jieyun.deskpool.windows.agentclient.InstallManager;
import com.jieyun.deskpool.windows.agentclient.PrepareManager;
import com.jieyun.deskpool.windows.agenthandler.AgentHelper;
import com.jieyun.deskpool.windows.agenthandler.AgentVersion;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.runtime.internal.AroundClosure;
import org.aspectj.runtime.reflect.Factory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.aspectj.AnnotationTransactionAspect;

public class InstanceBean
extends DefaultBean<Instance>
implements IInstanceBean,
IInstanceBean.Update,
LocatedBean {
    private static final Logger logger;
    private static final Random random;
    Map<Object, Object> vmparams = new HashMap<Object, Object>();
    private IUserDiskBean cachedUserDisk = null;
    @Autowired
    InstanceEntityBinding instanceEntityBinding;
    private static final /* synthetic */ JoinPoint.StaticPart ajc$tjp_0;
    private static final /* synthetic */ JoinPoint.StaticPart ajc$tjp_1;

    static {
        InstanceBean.ajc$preClinit();
        logger = LoggerFactory.getLogger(InstanceBean.class);
        random = new Random();
    }

    @Override
    public void postConstruct() {
        this.setAgentStatus(AgentStatus.INITIAL);
        this.setStatus(InstanceStatus.NEW);
    }

    @Override
    public void postStoreObjectSet() {
        String paraStr = (String)this.getParam("params");
        if (paraStr != null && !"".equals(paraStr)) {
            this.vmparams = (Map)JSON.parseObject((String)paraStr, Map.class);
        }
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public IInstanceBean.Update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public String getCopyfrom() {
        return (String)this.getParam("copyfrom");
    }

    @Override
    public IInstanceBean.Update setCopyfrom(String copyfrom) {
        this.setParam((Object)"copyfrom", copyfrom);
        return this;
    }

    @Override
    public String getVmname() {
        return (String)this.getParam("vmname");
    }

    @Override
    public IInstanceBean.Update setVmname(String vmname) {
        this.setParam((Object)"vmname", vmname);
        return this;
    }

    @Override
    public InstanceStatus getStatus() {
        return (InstanceStatus)((Object)this.getParam("status"));
    }

    @Override
    public boolean isStableStatus() {
        switch (this.getStatus()) {
            case STANDING: 
            case RUNNING: 
            case SHUTDOWN: 
            case BROKEN: 
            case DESTROYED: {
                return true;
            }
        }
        return false;
    }

    private void setStatus(InstanceStatus status) {
        this.setParam((Object)"status", (Object)status);
    }

    @Override
    public void setAgentInstanceId() {
        Stopwatch timer = new Stopwatch("[InstanceBean.setAgentInstanceId]");
        try {
            try {
                IAgentClient agent = AgentFactory.getAgentClient(this);
                agent.setInstanceId();
            }
            catch (Exception e) {
                e.printStackTrace();
                timer.stop();
            }
        }
        finally {
            timer.stop();
        }
    }

    private TrackerService.Writer getTrackerWriter(TrackerOperation trackerOperation) {
        TrackerService.Writer operationWriter = null;
        if (trackerOperation == TrackerOperation.CREATE) {
            operationWriter = new TrackerService.Writer.Instance().create(this);
        } else if (this.getTrackerOperation() == TrackerOperation.REGENERATE) {
            operationWriter = new TrackerService.Writer.Instance().regenerate(this);
        } else if (this.getTrackerOperation() == TrackerOperation.RESTART) {
            operationWriter = new TrackerService.Writer.Instance().restart(this);
        } else if (this.getTrackerOperation() == TrackerOperation.START) {
            operationWriter = new TrackerService.Writer.Instance().start(this);
        }
        return operationWriter;
    }

    private void trackingStatus(InstanceStatus oldstatus, InstanceStatus newstatus) {
        TrackerService.Writer operationWriter;
        String messageid = "";
        if (oldstatus.equals((Object)newstatus)) {
            return;
        }
        if (newstatus == InstanceStatus.RUNNING) {
            messageid = "vm.start.running";
        } else if (newstatus == InstanceStatus.STARTINGIP) {
            messageid = "vm.start.waitnetwork";
        } else if (newstatus == InstanceStatus.STARTINGCONN) {
            messageid = "vm.start.waitservice";
        }
        if (!StringUtils.isBlank((String)messageid) && (operationWriter = this.getTrackerWriter(this.getTrackerOperation())) != null) {
            if (newstatus == InstanceStatus.RUNNING || this.isSleeped()) {
                operationWriter.complete(messageid, new String[0]);
            } else {
                operationWriter.message(messageid, new String[0]);
            }
        }
    }

    @Override
    public IInstanceBean.Update enterStatus(InstanceStatus status) {
        InstanceStatus oldStatus = this.getStatus();
        if (oldStatus == InstanceStatus.DESTROYED && status != InstanceStatus.DESTROYED) {
            logger.error("instance {} status from {} enter to {} is Rejected", new Object[]{this.getName(), oldStatus, status});
            return null;
        }
        if (oldStatus != status) {
            PrepTask preptask = this.getPrepTask();
            logger.info("instance {} status from {} enter to {} prep {}", new Object[]{this.getName(), oldStatus, status, preptask == null ? "NULL" : preptask.getPrepState()});
        }
        if (oldStatus != status) {
            this.trackingStatus(oldStatus, status);
        }
        if (status == InstanceStatus.RUNNING) {
            if (this.hasPrepTask() && this.getPrepState() == PrepState.Thawing) {
                this.clearPrepTask();
            }
            if (this.isAssigned() && this.shouldReserveForUser() && "yes".equals(this.getVmParam("autoconnect"))) {
                logger.info("set autoconnect flag for user {} instance {}", (Object)this.getUpdate(), (Object)this.getName());
                Services.getUserSessionService().pushCommand(this.Id(), "auto");
                this.clearVmParam("autoconnect");
            }
        } else {
            boolean boolPrepTaskRecovered = false;
            PrepTask curTask = this.getPrepTask();
            IInstanceBean.Update iu = (IInstanceBean.Update)this.refresh();
            PrepTask dbTask = iu.getPrepTask();
            if (!(dbTask == null || curTask != null && dbTask.equals(curTask))) {
                boolPrepTaskRecovered = true;
                this.setPrepTask(iu.getPrepTask());
            }
            if (boolPrepTaskRecovered) {
                logger.info("instance {} prepTask is recovered", (Object)this.getName());
            }
        }
        if (Props.instance().get("thinclient.linkage.shutdown", false) && oldStatus.equals((Object)InstanceStatus.RUNNING) && status.equals((Object)InstanceStatus.SHUTDOWN)) {
            this.shutdownTC();
        }
        this.setStatus(status);
        if (!this.isNew()) {
            this.merge();
        }
        if (oldStatus.equals((Object)InstanceStatus.RUNNING) && !status.equals((Object)InstanceStatus.RUNNING) && !status.equals((Object)InstanceStatus.STANDING)) {
            logger.info("instance {} status enter {} call close Session", (Object)this.getName(), (Object)status);
            UserSessionManager.instance().closeSession(this);
        }
        return this;
    }

    @Override
    public String getDescription() {
        return (String)this.getParam("description");
    }

    @Override
    public IInstanceBean.Update setDescription(String description) {
        this.setParam((Object)"description", description);
        return this;
    }

    @Override
    public Id getTemplateId() {
        Long beanId = (Long)this.getParam("template");
        return Id.construct(beanId);
    }

    @Override
    public ITemplateBean getTemplate() {
        Long beanId = (Long)this.getParam("template");
        return beanId == null ? null : (ITemplateBean)Services.getTemplateService().findOne(Id.construct(beanId));
    }

    @Override
    public IInstanceBean.Update setTemplate(ITemplateBean template) {
        this.setParam((Object)"template", template.Id().getId());
        return this;
    }

    @Override
    public Date getRollout() {
        return (Date)this.getParam("rollout");
    }

    @Override
    public IInstanceBean.Update setRollout(Date rollout) {
        this.setParam((Object)"rollout", rollout);
        return this;
    }

    @Override
    public AgentStatus getAgentStatus() {
        return (AgentStatus)((Object)this.getParam("agentStatus"));
    }

    @Override
    public IInstanceBean.Update setAgentStatus(AgentStatus agentStatus) {
        if (!this.isNew()) {
            logger.info("Instance {}  agentStatus from {} to {}", new Object[]{this.toString(), this.getAgentStatus(), agentStatus});
        }
        this.setParam((Object)"agentStatus", (Object)agentStatus);
        return this;
    }

    @Override
    public Id getServerId() {
        Long beanId = (Long)this.getParam("server");
        return Id.construct(beanId);
    }

    @Override
    public IServerBean getServer() {
        Long beanId = (Long)this.getParam("server");
        return beanId == null ? null : Services.getServerService().findOne(Id.construct(beanId));
    }

    @Override
    public IInstanceBean.Update setServer(IServerBean server) {
        this.setParam((Object)"server", server.Id().getId());
        return this;
    }

    @Override
    public boolean hasPrepTask() {
        PrepTask task = this.getPrepTask();
        return task != null;
    }

    @Override
    public boolean inPrep() {
        return this.hasPrepTask() && !this.inPrepState(PrepState.Completed);
    }

    @Override
    public boolean inPrepState(PrepState state) {
        PrepTask task = this.getPrepTask();
        if (task == null) {
            logger.error("Attemp to compare the instance {} 's prep state in case of Null PrepTask !", (Object)this.toString());
            return false;
        }
        return task.getPrepState() == state;
    }

    @Override
    public IInstanceBean.Update clearPrepTask() {
        this.setPrepTask(null);
        return this;
    }

    @Override
    public PrepTask getPrepTask() {
        return (PrepTask)this.getParam("prepTask");
    }

    @Override
    public PrepState getPrepState() {
        PrepTask task = this.getPrepTask();
        if (task == null) {
            logger.error("Instance {} doesn't has a PrepTask , getPrepState return null", (Object)this.toString());
            return null;
        }
        return task.getPrepState();
    }

    @Override
    public IInstanceBean.Update setPrepState(PrepState prepState) {
        PrepTask task = this.getPrepTask();
        if (task == null) {
            logger.error("Instance {} doesn't has a PrepTask , setPrepState does nothing!", (Object)this.toString());
            return this;
        }
        logger.info("Instance {} enter PrepState {} ", (Object)this.toString(), (Object)prepState);
        this.getPrepTask().setPrepState(prepState);
        return this;
    }

    @Override
    public IInstanceBean.Update setPrepTask(PrepTask prepTask) {
        this.setParam((Object)"prepTask", prepTask);
        return this;
    }

    @Override
    public IInstanceBean.Update setLoginTime(Date loginTime) {
        this.setParam((Object)"loginTime", loginTime);
        return this;
    }

    @Override
    public Date getLoginTime() {
        return (Date)this.getParam("loginTime");
    }

    @Override
    public boolean hasLoginTime() {
        return this.getLoginTime() != null;
    }

    @Override
    public boolean isSleeped() {
        InstanceStatus status = this.getStatus();
        return (InstanceStatus.STANDING.equals((Object)status) || InstanceStatus.SHUTDOWN.equals((Object)status)) && this.hasVmParam("sleeped");
    }

    @Override
    public IInstanceBean.Update clearLoginTime() {
        this.setLoginTime(null);
        return this;
    }

    @Override
    public IInstanceBean.Update setClientLocation(String clientLocation) {
        this.setParam((Object)"clientLocation", clientLocation);
        return this;
    }

    @Override
    public String getClientLocation() {
        return (String)this.getParam("clientLocation");
    }

    @Override
    public IInstanceBean.Update clearClientLocation() {
        if (StringUtils.isNotBlank((String)this.getClientLocation())) {
            this.setClientLocationCached(this.getClientLocation());
        }
        this.setClientLocation(null);
        return this;
    }

    @Override
    public boolean isAssigned() {
        return !Desktop.AssignStatus.UNASSIGNED.equals((Object)this.getAssignStatus());
    }

    @Override
    public Desktop.AssignStatus getAssignStatus() {
        String username = this.getUsername();
        if (StringUtils.isBlank((String)username)) {
            return Desktop.AssignStatus.UNASSIGNED;
        }
        IAccountBean user = this.getUser();
        if (user == null) {
            return Desktop.AssignStatus.INVALID;
        }
        if (user.hasTemplate(this.getTemplateId()) || user.getTemplateIDs().size() == 0 && this.getTemplate() != null && this.getTemplate().isDefault()) {
            return Desktop.AssignStatus.NORMAL;
        }
        return Desktop.AssignStatus.OUTDATED;
    }

    @Override
    public String getUsername() {
        return (String)this.getParam("username");
    }

    @Override
    public IAccountBean getUser() {
        String username = this.getUsername();
        return username == null ? null : Services.getAccountService().findByName(username);
    }

    @Override
    public IInstanceBean.Update setUser(IAccountBean user) {
        this.setParam((Object)"username", user == null ? null : user.getName());
        return this;
    }

    @Override
    public String getIpaddress() {
        return (String)this.getParam("ipaddress");
    }

    @Override
    public IInstanceBean.Update setIpaddress(String ipaddress) {
        logger.info("setIpaddress " + this.getName() + " " + ipaddress);
        this.setParam((Object)"ipaddress", ipaddress);
        return this;
    }

    @Override
    public void store() {
    }

    @Override
    @DispatchPoint
    public void createInstance() {
        InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
        instanceManager.createInstance(this);
    }

    @Override
    public IInstanceBean save() {
        if (this.isNew()) {
            InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
            logger.debug("InstanceBean.save -> call createInstance");
            this.persist();
            return instanceManager.createInstance(this);
        }
        this.merge();
        logger.debug("InstanceBean.save -> call persist");
        return this;
    }

    @Override
    public boolean hasResource() {
        return this.getServer().isOnline();
    }

    @Override
    public boolean isImporting() {
        return this.getImage() == null;
    }

    @Override
    public boolean isImageEditing() {
        if (this.getTemplate() != null) {
            return false;
        }
        IImageBean image = this.getImage();
        return image != null && ImageStatus.EDIT.equals((Object)image.getStatus());
    }

    @Override
    public boolean isImageCopying() {
        if (this.getTemplate() != null) {
            return false;
        }
        IImageBean image = this.getImage();
        return image != null && ImageStatus.INITIAL.equals((Object)image.getStatus());
    }

    @Override
    public boolean isBusy() {
        InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
        if (instanceManager == null) {
            return false;
        }
        return instanceManager.isBusy();
    }

    @Override
    public IInstanceBean logoff() {
        this.setVmParam("logoff", true);
        new UserSessionBroker(this, this.getIpaddress()).logoff();
        return this;
    }

    @Override
    public IInstanceBean disconnect() {
        this.setVmParam("disconnect", true);
        if (this.isLinux()) {
            return this;
        }
        new UserSessionBroker(this, this.getIpaddress()).disconnect();
        return this;
    }

    @Override
    @DispatchPoint
    public void restart() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.restart(this);
    }

    @Override
    @DispatchPoint
    public void start() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.start(this);
    }

    @Override
    @DispatchPoint
    public void shutdown() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.shutdown(this);
    }

    @Override
    public void freeze() {
        if (!this.isCandidate()) {
            InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
            instanceManager.freeze(this);
        }
    }

    @Override
    public void thaw() {
        if (this.isCandidate()) {
            InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
            instanceManager.thaw(this);
        }
    }

    @Override
    public boolean isCheckpointed() {
        return "yes".equals(this.getVmParam("checkpoint"));
    }

    @Override
    public boolean isStatic() {
        ITemplateBean template = this.getTemplate();
        return template != null && template.isPersistent();
    }

    @Override
    public IInstanceBean.Update setCheckpointed() {
        this.setVmParam("checkpoint", "yes");
        return this;
    }

    @Override
    public IInstanceBean.Update clearCheckpointed() {
        this.clearVmParam("checkpoint");
        return this;
    }

    @Override
    public boolean shouldCheckpint() {
        ITemplateBean template = this.getTemplate();
        if (this.inPrep() || this.isCheckpointed() || template == null) {
            return false;
        }
        return template.shouldCheckpint();
    }

    public boolean shouldReserveForUser() {
        ITemplateBean template = this.getTemplate();
        return template != null && template.isPooled() && template.isReserveForUser();
    }

    public boolean isTemplateActive() {
        boolean isActive = true;
        try {
            ITemplateBean template = this.getTemplate();
            if (template != null) {
                isActive = template.inStatus(TemplateStatus.ACTIVE);
            }
            logger.info("template {} active {}", (Object)template.getName(), (Object)isActive);
        }
        catch (Exception ex) {
            logger.error(ex.getMessage());
        }
        return isActive;
    }

    @Override
    public void checkpoint(boolean isSnapshotLive) {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.checkpoint(this, this.isTemplateActive(), isSnapshotLive);
    }

    @Override
    public void regenerate(boolean force) {
        if (this.isSleeped()) {
            logger.info("instance {} regenerate exited for instance already sleeped.", (Object)this.getName());
            return;
        }
        if (this.isCheckpointed()) {
            if (this.hasUserDisk()) {
                this.detachUserDisk(this.getUserDisk());
            }
            InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
            instanceManager.regenerate(this, this.isTemplateActive());
        } else {
            logger.info("try regenerate instance {} which is not checkpointed.", (Object)this.getName());
        }
    }

    @Override
    @DispatchPoint
    public void regenerate() {
        this.regenerate(false);
    }

    @Override
    public boolean isCandidate() {
        boolean candidate = false;
        PrepTask task = this.getPrepTask();
        if (task != null) {
            candidate = task.getCandidate();
        }
        return candidate;
    }

    @Override
    public IInstanceBean.Update setCandidate(boolean isCandidate) {
        PrepTask task = this.getPrepTask();
        if (task != null) {
            task.setCandidate(isCandidate);
        }
        return this;
    }

    @Override
    public void suspend() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.suspend(this);
    }

    @Override
    public void resume() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.resume(this);
    }

    @Override
    public void templatize(IImageBean image) {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.templatize(this, image);
    }

    @Override
    @DispatchPoint
    public void templatize(Id imageId) {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.templatize(this, Services.getImageService().findOne(imageId));
    }

    @Override
    @DispatchPoint
    public IInstanceBean terminate() {
        Stopwatch timer = new Stopwatch("[InstanceBean.terminate(" + this.toString() + ")]");
        if (this.getTemplate().isDynamic()) {
            this.destroy();
        } else {
            this.preserve();
        }
        timer.stop(this.toString());
        return this;
    }

    @Override
    public String toString() {
        return "vm[" + this.getName() + "]";
    }

    @Override
    public boolean preDestroy() {
        InstanceStatus status = this.getStatus();
        boolean queued = false;
        String ipaddress = this.getIpaddress();
        logger.info("preDestroy VM:" + this.getName());
        if (this.isAgentV2() && !StringUtils.isBlank((String)ipaddress)) {
            try {
                IAgentClient agent = AgentFactory.getAgentClient(this);
                if (agent != null && agent.ping(2000)) {
                    queued = agent.destroy();
                } else {
                    logger.error("preDestroy can't getAgentClient IP:" + ipaddress);
                }
            }
            catch (Exception e) {
                logger.error(e.getMessage());
            }
        }
        return queued;
    }

    @Override
    @DispatchPoint
    public void destroy() {
        if (InstanceStatus.DESTROYED.equals((Object)this.getStatus())) {
            return;
        }
        if (this.isStatic() && this.isAssigned()) {
            logger.warn(" Attempt to destroy a static instance {} ", (Object)this);
            return;
        }
        if (this.isCheckpointed()) {
            logger.info("Instance {}  is checkpointed, call regenerate", (Object)this.toString());
            this.regenerate();
        } else {
            InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
            instanceManager.destroy(this);
        }
    }

    @Override
    public boolean postDestroy() {
        VirtualGpuInstance vgpuInstance;
        Services.getAccountService().clearInstanceVmAccount(this.Id());
        List<ITrackerBean> trackerList = Services.getTrackerService().findByTarget(this.Id());
        if (trackerList != null) {
            for (ITrackerBean tracker : trackerList) {
                if (tracker.isDone()) break;
                tracker.setProgress(tracker.getProgress());
                tracker.setDone(true);
                tracker.keepSilent();
                tracker.save();
            }
        }
        if ((vgpuInstance = this.getVgpu()) != null && vgpuInstance.isSriov()) {
            Services.getGpuPoolService().unregisterVirtualFunctionUsage(vgpuInstance.getHostPCIeId(), this.Id());
        }
        try {
            AdComputerService adComputerService;
            String vmname;
            ClusterService clusterService = Services.getClusterService();
            IClusterBean clusterBean = clusterService.getCluster();
            if (clusterBean.getUserdb() == UserDB.AD && StringUtils.isNotBlank((String)(vmname = this.getName())) && (adComputerService = AdComputerService.instance()).computerNameExists(vmname)) {
                adComputerService.destroy(vmname);
            }
            return true;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void destroyImplicitly() {
        if (InstanceStatus.DESTROYED.equals((Object)this.getStatus()) && StringUtils.isEmpty((String)this.getVmname())) {
            return;
        }
        if (this.isStatic() && this.isAssigned()) {
            logger.warn(" Attempt to destroy a static instance {} ", (Object)this);
            return;
        }
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.destroy(this);
    }

    @Override
    @DispatchPoint
    public void destroyExplicitly() {
        if (InstanceStatus.DESTROYED.equals((Object)this.getStatus()) && StringUtils.isEmpty((String)this.getVmname())) {
            logger.warn(" destroyExplicitly  a VM Instance without vm name {}", (Object)this);
        }
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.destroy(this);
    }

    @Override
    public IInstanceBean preserve() {
        Stopwatch timer = new Stopwatch("InstanceBean.preserve(" + this.toString() + ")]");
        this.setVmParam("preserved", Util.secondsDateFormat.format(new Date()));
        this.setVmParam("comments", "On hold");
        this.clearClientLocation();
        this.clearLoginTime();
        this.setSessionActive(false);
        this.save();
        timer.stop();
        return this;
    }

    @Override
    public IInstanceBean broken(String reason) {
        if (reason == null) {
            reason = "";
        }
        this.setVmParam("broken", reason);
        this.enterStatus(InstanceStatus.BROKEN);
        return this;
    }

    @Override
    public IInstanceBean retire() {
        return this;
    }

    @Override
    public IInstanceBean condemn() {
        return this;
    }

    @Override
    public void release() {
    }

    @Override
    public void rereserve() {
    }

    @Override
    @DispatchPoint
    public boolean alive() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        return instanceManager.alive(this);
    }

    @Override
    public IInstanceBean.Update setVmParam(String k, Object v) {
        this.vmparams.put(k, v);
        return this;
    }

    @Override
    public boolean hasVmParam(String k) {
        return this.vmparams.containsKey(k);
    }

    @Override
    public IInstanceBean.Update clearVmParam(String k) {
        this.vmparams.remove(k);
        return this;
    }

    @Override
    public Object getVmParam(String k) {
        return this.vmparams.get(k);
    }

    @Override
    public String getVmParam(String k, String defaultValue) {
        String value = (String)this.vmparams.get(k);
        return value == null ? defaultValue : value;
    }

    @Override
    public Integer getVmParam(String k, Integer defaultValue) {
        Integer value = (Integer)this.vmparams.get(k);
        return value == null ? defaultValue : value;
    }

    @Override
    public Object getVmParam(String k, Object defaultValue) {
        Object value = this.vmparams.get(k);
        return value == null ? defaultValue : value;
    }

    @Override
    public IInstanceBean bindVirtualMachine(IServerBean server, String vmname) {
        this.setServer(server);
        InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
        return instanceManager.bindVirtualMachine(this, vmname);
    }

    @Override
    public boolean tryLock() {
        return false;
    }

    @Override
    @Transactional
    public void persist() {
        Object[] objectArray = new Object[]{this};
        AnnotationTransactionAspect.aspectOf().ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96c((Object)this, (AroundClosure)new InstanceBean$AjcClosure1(objectArray), ajc$tjp_0);
    }

    @Override
    @Transactional
    public void merge() {
        Object[] objectArray = new Object[]{this};
        AnnotationTransactionAspect.aspectOf().ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96c((Object)this, (AroundClosure)new InstanceBean$AjcClosure3(objectArray), ajc$tjp_1);
    }

    @Override
    public IImageBean getImage() {
        ITemplateBean template = this.getTemplate();
        if (template != null) {
            return template.getImage();
        }
        Long beanId = (Long)this.getParam("image");
        return beanId == null ? null : Services.getImageService().findOne(Id.construct(beanId));
    }

    @Override
    public IInstanceBean setImage(IImageBean image) {
        this.setParam((Object)"image", image.Id().getId());
        return this;
    }

    @Override
    List<ErrorMessage> validate() {
        List<ErrorMessage> errList = super.validate();
        IInstanceBean foundBean = Services.getInstanceService().findByName(this.getName());
        if (foundBean != null && (this.isNew() || !foundBean.Id().equals(this.Id()))) {
            errList.add(new ErrorMessage("error.bean.instance.name.duplicated"));
        }
        return errList;
    }

    @Override
    public String getVNCConsoleURL() {
        if (!this.isVncAvailable()) {
            return null;
        }
        if (this.getStatus() == InstanceStatus.SHUTDOWN) {
            logger.info("Instance {} is shutdown, can't get VNC URL .");
            return null;
        }
        InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
        return instanceManager.getVNCConsoleURL(this);
    }

    @Override
    public boolean isSessionActive() {
        return this.booleanValue(this.getParam("sessionActive"));
    }

    @Override
    public IInstanceBean.Update setSessionActive(boolean isActive) {
        this.setParam((Object)"sessionActive", isActive);
        return this;
    }

    @Override
    public Boolean isImageInstance() {
        return this.booleanValue(this.getParam("isImageInstance"));
    }

    @Override
    public IInstanceBean.Update setIsImageInstance(Boolean isImageInstance) {
        this.setParam((Object)"isImageInstance", isImageInstance);
        return this;
    }

    @Override
    @DispatchPoint
    public void agentInstall() {
        String appRootURL = PathManager.getDefaultAppRootURL();
        String vdiAgentURL = PathManager.getVdiAgentURL(appRootURL);
        this.agentInstall(vdiAgentURL);
    }

    @Override
    public void agentInstall(String agentURL) {
        if (this.isAgentInstalling() || this.isAgentInstalled()) {
            return;
        }
        logger.info("agentInstall: Queueing agent install for instance: {}", (Object)this.getName());
        this.setAgentStatus(AgentStatus.INPROGRESS);
        this.merge();
        logger.info(" user : {} password: {}", this.getVmParam("remote.user"), (Object)((String)this.getVmParam("remote.password")));
        new TrackerService.Writer.Working().installAgent(this).message("msg.installagent.start", new String[0]);
        try {
            InstallManager.launch(this, agentURL);
        }
        catch (Exception ex) {
            logger.error("InstallManager launch error :" + ex.getMessage());
        }
    }

    @Override
    public boolean isAgentInstalling() {
        return AgentStatus.INPROGRESS.equals((Object)this.getAgentStatus());
    }

    @Override
    public boolean isAgentInstalled() {
        return AgentStatus.YES.equals((Object)this.getAgentStatus());
    }

    @Override
    public String newRandomName() {
        String prefix = null;
        if (this.isImporting() || this.isImageEditing()) {
            prefix = this.getName();
        } else {
            ITemplateBean template = this.getTemplate();
            if (template != null) {
                prefix = template.getPrefix();
            }
        }
        return InstanceBean.newRandomName(prefix);
    }

    private static String prefix(String s, int len) {
        if (s == null) {
            s = "VDI";
        }
        s = s.replaceAll("[^A-Za-z0-9\\-]", "");
        if ((s = s.replaceFirst("^[^A-Za-z]+", "")).length() > len) {
            s = s.substring(0, len);
        } else if (s.length() == 0) {
            s = "VDI";
        }
        return s;
    }

    public static String newRandomName(String prefix) {
        return InstanceBean.prefix(prefix, 7) + "-" + InstanceBean.suffix(7);
    }

    private static String suffix(int len) {
        char[] suffix = new char[len];
        int i = 0;
        while (i < len) {
            suffix[i] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(random.nextInt("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".length()));
            ++i;
        }
        return String.valueOf(suffix);
    }

    @Override
    public boolean validComputerName(String name) {
        return name != null && name.matches("^[A-Za-z][A-Za-z0-9\\-]{0,14}$");
    }

    @Override
    public IInstanceBean.Update getUpdate() {
        this.lock();
        return (IInstanceBean.Update)this.refresh();
    }

    @Override
    public IInstanceBean.Update setAutoInstallAgent(boolean autoInstall) {
        this.setVmParam("auto.install", autoInstall);
        return this;
    }

    @Override
    public boolean isAutoInstallAgent() {
        return this.booleanValue(this.getVmParam("auto.install"));
    }

    @Override
    public boolean isSpice() {
        return "yes".equals(this.getVmParam("spice"));
    }

    @Override
    public IInstanceBean.Update setVncAvailable(boolean vncAvailable) {
        this.setVmParam("vnc.available", vncAvailable);
        return this;
    }

    @Override
    public boolean isVncAvailable() {
        return this.booleanValue(this.getVmParam("vnc.available"));
    }

    @Override
    public String asString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Instance:[").append(this.getName()).append("]");
        if (this.hasPrepTask()) {
            PrepTask task = this.getPrepTask();
            sb.append(" prepTask.state:").append((Object)task.getPrepState());
            sb.append(" prepTask.type:").append((Object)task.getPrepType());
            sb.append(" prepTask.candidate:").append(task.getCandidate());
        }
        return sb.toString();
    }

    @Override
    public VPower getPower() {
        double cores = Double.parseDouble(this.getVmParam("cores", "1.0D"));
        double cpu = Double.parseDouble(this.getVmParam("sockets", "1.0D"));
        double mem = Double.parseDouble(this.getVmParam("mem", "1024.0D"));
        return new VPower(cores, cpu, mem);
    }

    @Override
    public List<AdminOperation> getAdminOperation() {
        ArrayList<AdminOperation> list = new ArrayList<AdminOperation>();
        if (!this.isImageInstance().booleanValue()) {
            list.add(AdminOperation.DESTROY);
        }
        if (this.getStatus().equals((Object)InstanceStatus.RUNNING)) {
            list.add(AdminOperation.SHUTDOWN);
            list.add(AdminOperation.RESTART);
            list.add(AdminOperation.RDPCONNECT);
            list.add(AdminOperation.SHADOW);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.SHUTDOWN)) {
            list.add(AdminOperation.START);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
                list.add(AdminOperation.CHECKPOINT);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.STANDING) && this.getTemplate().isSingleImage()) {
            list.add(AdminOperation.START);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
                list.add(AdminOperation.CHECKPOINT);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.STARTINGCONN) || this.getStatus().equals((Object)InstanceStatus.STARTINGIP)) {
            list.add(AdminOperation.SHUTDOWN);
            list.add(AdminOperation.RESTART);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.STARTUP)) {
            list.add(AdminOperation.SHUTDOWN);
            list.add(AdminOperation.RESTART);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.PRESHUTDOWN)) {
            list.add(AdminOperation.SHUTDOWN);
            list.add(AdminOperation.RESTART);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.RESTARTING)) {
            list.add(AdminOperation.SHUTDOWN);
            list.add(AdminOperation.RESTART);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        }
        if (!this.getStatus().equals((Object)InstanceStatus.SHUTDOWN) && !this.getStatus().equals((Object)InstanceStatus.DESTROYED)) {
            boolean isVncAvailable = this.isVncAvailable();
            boolean isTC = false;
            if (!isVncAvailable) {
                try {
                    DpClientType clientType = DpClientUtils.parse(FacesUtils.getRequest().getHeader("User-Agent"));
                    if (clientType != null && DpClientType.JieyunTC == clientType) {
                        isTC = true;
                    }
                }
                catch (Exception e) {
                    logger.error("", (Throwable)e);
                }
            }
            if (isVncAvailable || DeskpoolConfigConstant.isPve() && !isTC && Props.instance().get("consoleproxy.enableVNCMaintain", true)) {
                list.add(AdminOperation.VNCCONNECT);
            }
        }
        return list;
    }

    @Override
    public List<AdminOperation> getUserOperation() {
        ArrayList<AdminOperation> list = new ArrayList<AdminOperation>();
        if (this.getStatus().equals((Object)InstanceStatus.STARTUP) && this.isCheckpointed()) {
            list.add(AdminOperation.REGENERATE);
        }
        if (this.getStatus().equals((Object)InstanceStatus.STARTINGIP)) {
            list.add(AdminOperation.SHUTDOWN);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.RESTARTING)) {
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.PRESHUTDOWN)) {
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.RUNNING)) {
            list.add(AdminOperation.SHUTDOWN);
            list.add(AdminOperation.RESTART);
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        } else if (this.getStatus().equals((Object)InstanceStatus.SHUTDOWN)) {
            if (!"yes".equalsIgnoreCase(Props.instance().get("admin.start", "no"))) {
                list.add(AdminOperation.START);
            }
            if (this.isCheckpointed()) {
                list.add(AdminOperation.REGENERATE);
            }
        }
        if (Props.instance().get("consoleproxy.enableVNCMaintain", true) && !this.getStatus().equals((Object)InstanceStatus.SHUTDOWN) && !this.getStatus().equals((Object)InstanceStatus.DESTROYED)) {
            boolean isTC = false;
            if (!this.isVncAvailable()) {
                try {
                    DpClientType clientType = DpClientUtils.parse(FacesUtils.getRequest().getHeader("User-Agent"));
                    if (clientType != null && DpClientType.JieyunTC == clientType) {
                        isTC = true;
                    }
                }
                catch (Exception e) {
                    logger.error("", (Throwable)e);
                }
            }
            if (this.isVncAvailable() || DeskpoolConfigConstant.isPve() && !isTC) {
                list.add(AdminOperation.VNCCONNECT);
            }
        }
        return list;
    }

    @Override
    public boolean isReadyToRun() {
        if (this.hasPrepTask()) {
            return this.inPrepState(PrepState.Completed) || this.inPrepState(PrepState.Thawing);
        }
        return !this.hasVmParam("prepvm") || !this.getVmParam("prepvm", "no").equals("yes");
    }

    @Override
    public IInstanceBean.Update fakePrepFinished() {
        PrepTask prepTask = new PrepTask();
        prepTask.setPrepType(PrepType.VDIPREP);
        prepTask.setCandidate(false);
        this.setPrepTask(prepTask);
        this.clearVmParam("prepvm");
        this.setPrepState(PrepState.Completed);
        return this;
    }

    @Override
    public boolean inTemplate(ITemplateBean template) {
        return template.Id().equals(this.getTemplateId());
    }

    @Override
    public boolean setUsbPolicy(String clientip, String policy) {
        String address = this.getIpaddress();
        if (address.isEmpty()) {
            logger.error("IInstanceBean.setUsbPolicy: No client IP found for ");
            return false;
        }
        Stopwatch timer = new Stopwatch("[InstanceBean.setUsbPolicy]");
        boolean succeeded = false;
        try {
            IAgentClient client = AgentFactory.getAgentClient(this);
            timer.record("USB policy:" + policy);
            succeeded = client.redirectUSB(clientip, policy);
        }
        catch (Throwable throwable) {
            timer.stop(succeeded ? "success" : "failed");
            throw throwable;
        }
        timer.stop(succeeded ? "success" : "failed");
        return succeeded;
    }

    @Override
    public IInstanceBean.Update eraseToCheckpoint() {
        logger.info("shouldReserveForUser {}", (Object)this.shouldReserveForUser());
        if (!this.shouldReserveForUser()) {
            this.setUser(null);
        }
        this.setIpaddress("");
        this.clearLoginTime();
        this.clearClientLocation();
        this.setSessionActive(false);
        return this;
    }

    @Override
    public IInstanceBean.Update setSecondDisk(String secondDiskName, Integer secondDiskSize) {
        this.setVmParam("secondDiskName", secondDiskName).setVmParam("secondDiskSize", "" + secondDiskSize);
        return this;
    }

    @Override
    public boolean hasSecondDisk() {
        return StringUtils.isNotBlank((String)this.getSecondDisk());
    }

    @Override
    public String getSecondDisk() {
        return this.getVmParam("secondDiskName", "");
    }

    @Override
    public boolean hasUserDisk() {
        return this.getUserDisk() != null;
    }

    @Override
    public IUserDiskBean getUserDisk() {
        if (this.cachedUserDisk == null) {
            this.cachedUserDisk = Services.getUserDiskService().findByInstanceId(this.Id());
        }
        return this.cachedUserDisk;
    }

    @Override
    public void detachUserDisk(IUserDiskBean userdisk) {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.detachUserDisk(this, userdisk);
    }

    @Override
    public void attachUserDisk(IUserDiskBean userdisk) {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.attachUserDisk(this, userdisk);
    }

    @Override
    public IInstanceBean.Update setTrackerOperation(TrackerOperation operation) {
        TrackerService.Writer trackerWriter = this.getTrackerWriter(this.getTrackerOperation());
        if (trackerWriter != null && trackerWriter.isOpen() && !this.getTrackerOperation().equals((Object)TrackerOperation.CREATE)) {
            trackerWriter.close();
        }
        this.setVmParam("tracker", operation.name());
        return this;
    }

    @Override
    public TrackerOperation getTrackerOperation() {
        String tracker = (String)this.getVmParam("tracker");
        if (StringUtils.isBlank((String)tracker)) {
            return null;
        }
        return TrackerOperation.valueOf(tracker);
    }

    @Override
    @DispatchPoint
    public String readInstallAgentScript() {
        Stopwatch timer = new Stopwatch("[ImageService.getInstallAgentScript(" + this + ")]");
        String installAgentScript = null;
        String appRootURL = "";
        try {
            if (!InstallManager.isAgentPackageAvailable()) {
                new TrackerService.Writer.Working().installAgent(this).failure("error.vm.install.agent.package", new String[0]);
                throw new JYServiceRuntimeException("error.import.no.agent.package");
            }
            if (StringUtils.isBlank((String)appRootURL)) {
                appRootURL = PathManager.getDefaultAppRootURL();
            }
            String vdiAgentURL = PathManager.getVdiAgentURL(appRootURL);
            installAgentScript = InstallManager.getManualInstalledScript(this.Id().toString(), vdiAgentURL);
        }
        catch (Throwable throwable) {
            timer.stop("installAgentScript: " + installAgentScript);
            throw throwable;
        }
        timer.stop("installAgentScript: " + installAgentScript);
        return installAgentScript;
    }

    @Override
    public boolean agentAlive() {
        try {
            IAgentClient agentClient = AgentFactory.getAgentClient(this);
            return agentClient.ping(2000);
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean isAgentV2() {
        AgentVersion version = AgentVersion.getInstance(this.getVmParam("agentversion", ""));
        return version.getMajor() >= 2;
    }

    @Override
    public String getAgentVersion() {
        return this.getVmParam("agentversion", "");
    }

    @Override
    public String getSysDiskSize() {
        ImageInfo imageInfo;
        String result = "";
        IImageBean image = this.getImage();
        if (image != null && (imageInfo = image.getImageInfo()) != null) {
            result = imageInfo.getImgsize();
        }
        return result;
    }

    @Override
    public boolean upgradeAgent() {
        return this.upgradeAgent(this.getIpaddress());
    }

    @Override
    public boolean upgradeAgent(String ip) {
        boolean succeeded = false;
        this.getUpdate().setVmParam("agentupgrading", "yes").save();
        if (!this.isAgentV2()) {
            new TrackerService.Writer.Instance().upgradeAgent(this).failure("vm.prepare.oldagent", new String[]{"$agent", this.getVmParam("agentversion", "")});
            return false;
        }
        Stopwatch timer = new Stopwatch("[VmEventHandler.upgradeAgent]");
        try {
            new TrackerService.Writer.Instance().upgradeAgent(this).message("vm.prepare.upgrade.agent", new String[0]);
            boolean monitorUpToDate = AgentHelper.isMonitorUpToDate(this);
            timer.record("monitorUpToDate before upgradeMonitor : " + monitorUpToDate);
            if (!monitorUpToDate) {
                AgentVersion before = AgentHelper.getMonitorVersion(this);
                timer.record("getMonitorVersion : " + before.toString());
                monitorUpToDate = AgentHelper.upgradeMonitor(this, ip);
                timer.record("monitorUpToDate after upgradeMonitor : " + monitorUpToDate);
            }
            if (monitorUpToDate) {
                succeeded = AgentHelper.upgradeAgent(this, ip);
            }
        }
        catch (Throwable throwable) {
            timer.stop(succeeded ? "success" : "failed");
            this.getUpdate().clearVmParam("agentupgrading").save();
            throw throwable;
        }
        timer.stop(succeeded ? "success" : "failed");
        this.getUpdate().clearVmParam("agentupgrading").save();
        return succeeded;
    }

    @Override
    public IInstanceBean bindVirtualMachine(IServerBean server, String vmname, String vmevent) {
        this.setServer(server);
        InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
        return instanceManager.bindVirtualMachine(this, vmname, vmevent);
    }

    @Override
    @DispatchPoint
    public void vmPrepare() {
        if (this.hasPrepTask()) {
            logger.error(" instance {} alread has a prepare task {}.", (Object)this.toString(), (Object)this.getPrepState());
            throw new JYServiceRuntimeException("error.prepare.inprocessing");
        }
        AgentClient vmAgent = AgentClient.newInstance(this.Id().toString(), this.getIpaddress());
        if (!this.alive() || !vmAgent.isRemoteServiceReady()) {
            throw new JYServiceRuntimeException("error.prepare.not.ready");
        }
        try {
            new PrepareManager(this).prepImageStart();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    @DispatchPoint
    public void vmUnPrepare() {
        PrepState state = this.getPrepState();
        if (state == PrepState.Thawing || !this.isCandidate()) {
            throw new JYServiceRuntimeException("error.import.already.unprepared");
        }
        try {
            new PrepareManager(this).backtoPrepareVm();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public NodeStatus getNodeStatus() {
        return (NodeStatus)((Object)this.getParam("nodeStatus"));
    }

    @Override
    public void setNodeStatus(NodeStatus status) {
        this.setParam((Object)"nodeStatus", (Object)status);
    }

    @Override
    public String getServiceName() {
        return "instanceService";
    }

    @Override
    public boolean isLocal() {
        IServerBean server = this.getServer();
        if (server == null) {
            return true;
        }
        return server.isLocal();
    }

    @Override
    public DeskpoolAddress locatedAddress() {
        ServerRegistry registry = ServerRegistry.instance();
        DeskpoolAddress address = registry.findAddress(this.getIdParam("serverId"));
        return address;
    }

    @Override
    public String getDatastore() {
        String result = "";
        result = this.getVmParam("datastore", "");
        logger.debug("getDatastore :" + result);
        return result;
    }

    @Override
    public String getImagestore() {
        String result = "";
        String imagestore = this.getVmParam("imagestore", "");
        result = StringUtils.isNotBlank((String)imagestore) ? imagestore : this.getDatastore();
        logger.debug("getImagestore :" + result);
        return result;
    }

    @Override
    public String getDiskstore() {
        String result = "";
        String diskstore = this.getVmParam("diskstore", "");
        result = StringUtils.isNotBlank((String)diskstore) ? diskstore : this.getDatastore();
        logger.info("getDiskstore :" + result);
        return result;
    }

    @Override
    public IInstanceBean.Update setImageVersion(String imgname) {
        this.setVmParam("imgversion", imgname);
        return this;
    }

    @Override
    public String getImageVersion() {
        return this.getVmParam("imgversion", "");
    }

    @Override
    public boolean isRetired() {
        IImageBean image = this.getImage();
        String imgVer = this.getImageVersion();
        boolean retired = false;
        if (image != null && !StringUtils.isEmpty((String)imgVer) && imgVer.compareTo(image.getVersion()) != 0) {
            retired = true;
        }
        return retired;
    }

    @Override
    @DispatchPoint
    public IInstanceBean.Update rebuild() {
        this.destroyExplicitly();
        return this;
    }

    @Override
    public void recover() {
        InstanceStatus status = this.getStatus();
        try {
            ITemplateBean template = this.getTemplate();
            if (template != null && (template.isDrift() || template.isFreshOnboot()) && this.isCheckpointed()) {
                this.regenerate();
            } else if (this.isAssigned()) {
                if (InstanceStatus.PRESHUTDOWN.equals((Object)status)) {
                    this.shutdown();
                } else if (InstanceStatus.STARTUP.equals((Object)status)) {
                    this.start();
                } else if (InstanceStatus.RESTARTING.equals((Object)status)) {
                    this.restart();
                } else if (InstanceStatus.STANDING.equals((Object)status) && this.hasVmParam("phase")) {
                    logger.info("recover instance {} by regenerate.", (Object)this.getName());
                    if (this.isCheckpointed()) {
                        this.regenerate();
                    } else if (this.shouldCheckpint()) {
                        boolean snapShotLive = Props.instance().get("policy.vm.snapshotlive", false);
                        this.checkpoint(snapShotLive);
                    }
                }
            } else if (!this.isImageInstance().booleanValue()) {
                if (InstanceStatus.DESTROYED.equals((Object)status)) {
                    logger.info("recover instance {} by destroy.", (Object)this.getName());
                    this.destroy();
                } else if (InstanceStatus.STANDING.equals((Object)status) && this.hasVmParam("phase")) {
                    if (this.isCheckpointed()) {
                        logger.info("recover instance {} by redo regenerate.", (Object)this.getName());
                        this.regenerate();
                    } else if (this.shouldCheckpint()) {
                        logger.info("recover instance {} by continue checkpoint.", (Object)this.getName());
                        boolean snapShotLive = Props.instance().get("policy.vm.snapshotlive", false);
                        this.checkpoint(snapShotLive);
                    }
                } else if (!InstanceStatus.RUNNING.equals((Object)status) && !this.isSleeped()) {
                    if (this.isCheckpointed()) {
                        logger.info("recover instance {} by regenerate.", (Object)this.getName());
                        this.regenerate();
                    } else {
                        logger.info("recover instance {} by destroyImplicitly.", (Object)this.getName());
                        this.destroyImplicitly();
                    }
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        VirtualGpuInstance vgpuInstance = this.getVgpu();
        if (vgpuInstance != null && vgpuInstance.isSriov()) {
            Services.getGpuPoolService().registerVirtualFunctionUsage(vgpuInstance.getHostPCIeId(), this.Id());
        }
    }

    @Override
    public ApiResult<InstanceEntity> apiGet() {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        result.setEntity(this.instanceEntityBinding.bindingForEntity(new InstanceEntity(), this));
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> apiPut(InstanceEntity entity) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        try {
            IInstanceBean bean = this.instanceEntityBinding.bindingForBean(entity, this);
            bean.save();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> apiDelete() {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        try {
            this.destroy();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getErrorList());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public String getSpiceConfig() {
        if (this.isSpice() && this.getStatus().equals((Object)InstanceStatus.RUNNING)) {
            InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
            return instanceManager.getSpiceConfig(this);
        }
        return "";
    }

    @Override
    @DispatchPoint
    public void attachUserDisk(Id userDiskId) {
        IUserDiskBean userDisk = Services.getUserDiskService().findOne(userDiskId);
        this.attachUserDisk(userDisk);
    }

    @Override
    @DispatchPoint
    public void detachUserDisk(Id userDiskId) {
        IUserDiskBean userDisk = Services.getUserDiskService().findOne(userDiskId);
        this.detachUserDisk(userDisk);
    }

    @Override
    public boolean persistOnOnly(Id serverId) {
        return this.getServerId().equals(serverId);
    }

    @Override
    public boolean isWaitGegenerate() {
        return (Boolean)this.getParam("waitGegenerate");
    }

    @Override
    public IInstanceBean.Update setWaitGegenerate(boolean waitGegenerate) {
        this.setParam((Object)"waitGegenerate", waitGegenerate);
        return this;
    }

    @Override
    public boolean isLastLogin() {
        IAccountBean account = this.getUser();
        return account == null ? false : this.Id().equals(account.getLastInstanceId());
    }

    private void shutdownTC() {
        String thinclient = this.getClientLocationCached();
        logger.info("shutdownTC: the instance[" + this.getName() + "] will shutdownTc " + thinclient);
        if (StringUtils.isNotBlank((String)thinclient)) {
            IThinClientBean thinClient = Services.getThinClientService().findByIP(thinclient);
            if (thinClient != null) {
                thinClient.shutdown();
            } else {
                logger.info("Can't found ThinClientBean with IP {}", (Object)thinclient);
            }
            this.setClientLocationCached(null);
        }
    }

    private String getClientLocationCached() {
        return (String)this.getParam("clientLocationCached");
    }

    private IInstanceBean.Update setClientLocationCached(String clientLocationCached) {
        logger.info("setClientLocationCached {}", (Object)clientLocationCached);
        this.setParam((Object)"clientLocationCached", clientLocationCached);
        return this;
    }

    @Override
    public String getOu() {
        ITemplateBean templateBean = this.getTemplate();
        return templateBean == null ? "" : templateBean.getOu();
    }

    @Override
    public VMNetworkConfig getVMNetworkConfig() {
        return (VMNetworkConfig)this.getParam("vmNetConfig");
    }

    @Override
    public boolean autoBindIp() {
        IPPolicy ipPolicy;
        ITemplateBean templateBean = this.getTemplate();
        if (templateBean != null && (ipPolicy = templateBean.getIpPolicy()) != null) {
            return ipPolicy.isEnable();
        }
        return false;
    }

    @Override
    public String getServerIP() {
        return null;
    }

    @Override
    @DispatchPoint
    public void setVmDataByAgent() {
        if (this.isSpice()) {
            InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
            instanceManager.setData(this);
        }
    }

    @Override
    public IInstanceBean.Update setServerHost(String serverIp) {
        this.setParam((Object)"serverHost", serverIp);
        return this;
    }

    @Override
    public String getServerHost() {
        return (String)this.getParam("serverHost");
    }

    @Override
    public void refreshServerHost(NodeConfig nodeConfig) {
        if (!StringUtils.equals((String)this.getServerHost(), (String)nodeConfig.getNodeAddr()) || !StringUtils.equals((String)this.getNodeName(), (String)nodeConfig.getNodesName())) {
            this.getUpdate().setServerHost(nodeConfig.getNodeAddr()).setNodeName(nodeConfig.getNodesName()).save();
        }
    }

    @Override
    public IInstanceBean.Update setNodeName(String nodeName) {
        this.setParam((Object)"nodeName", nodeName);
        return this;
    }

    @Override
    public String getNodeName() {
        return (String)this.getParam("nodeName");
    }

    @Override
    public boolean isSaveVMNetworkConfig() {
        ITemplateBean templateBean = this.getTemplate();
        if (templateBean == null) {
            return true;
        }
        VMNetworkConfig vmNetConfig = this.getVMNetworkConfig();
        VMNetworkConfig netconfig = templateBean.getVMNetWorkConfig(this.getVmname());
        if (vmNetConfig != null && netconfig != null) {
            return StringUtils.equals((String)vmNetConfig.toString(), (String)netconfig.toString());
        }
        return vmNetConfig == null && netconfig == null;
    }

    @Override
    public IInstanceBean.Update setVMNetworkConfig(VMNetworkConfig netConfig) {
        this.setParam((Object)"vmNetConfig", netConfig);
        return this;
    }

    @Override
    public boolean configuringNetwork() {
        VMNetworkConfig networkCfg;
        ITemplateBean templateBean = this.getTemplate();
        if (templateBean != null && (networkCfg = templateBean.getVMNetWorkConfig(this.getVmname())) != null) {
            return this.configuringNetwork(networkCfg, true);
        }
        return false;
    }

    @Override
    public boolean configuringNetwork(VMNetworkConfig netConfig, boolean autoConfigIp) {
        InstanceManager instanceManager = VMControlFactory.get(Config.Store.get()).getInstanceManager();
        instanceManager.setVMNetConfigMsg(this, netConfig, autoConfigIp);
        return true;
    }

    @Override
    @DispatchPoint
    public void delaystart(int delay) {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        instanceManager.delaystart(this, delay);
    }

    @Override
    public boolean isLinux() {
        Object guestos = this.getVmParam("guestos");
        if (guestos != null && guestos.toString().toLowerCase().contains("linux")) {
            return true;
        }
        IImageBean image = this.getImage();
        if (image == null) {
            Object object = this.getVmParam("os");
            return object != null && "linux".equals(object.toString().toLowerCase());
        }
        return image.isLinux();
    }

    @Override
    public void disconRegenerate() {
        InstanceManager instanceManager = VMControlFactory.get().getInstanceManager();
        int deplay = this.getTemplate().getPolicy().getDeplayRegenerate();
        instanceManager.disconRegenerate(this, deplay);
    }

    @Override
    public IInstanceBean.Update setComputerName(String computerName) {
        this.setParam((Object)"computerName", computerName);
        return this;
    }

    @Override
    public String getComputerName() {
        return (String)this.getParam("computerName");
    }

    @Override
    public void updateComputerName(String computerName) {
    }

    @Override
    public IInstanceBean.Update setSgwcSk(String sgwcSk) {
        this.setParam((Object)"sgwcSk", sgwcSk);
        return this;
    }

    @Override
    public String getSgwcSk() {
        Object object = this.getParam("sgwcSk");
        return object == null ? Base64Util.encodeData(this.getVmname()) : object.toString();
    }

    @Override
    public IInstanceBean.Update setVgpu(VirtualGpuInstance vgpu) {
        this.setParam((Object)"vgpu", vgpu);
        return this;
    }

    @Override
    public VirtualGpuInstance getVgpu() {
        return (VirtualGpuInstance)this.getParam("vgpu");
    }

    static final /* synthetic */ void persist_aroundBody0(InstanceBean ajc$this) {
        String paraStr = JSON.toJSONString(ajc$this.vmparams);
        ajc$this.setParam((Object)"params", paraStr);
        super.persist();
    }

    static final /* synthetic */ void merge_aroundBody2(InstanceBean ajc$this) {
        String paraStr = JSON.toJSONString(ajc$this.vmparams);
        ajc$this.setParam((Object)"params", paraStr);
        super.merge();
    }

    private static /* synthetic */ void ajc$preClinit() {
        Factory factory = new Factory("InstanceBean.java", InstanceBean.class);
        ajc$tjp_0 = factory.makeSJP("method-execution", (Signature)factory.makeMethodSig("1", "persist", "com.jieyun.deskpool.bean.InstanceBean", "", "", "", "void"), 1104);
        ajc$tjp_1 = factory.makeSJP("method-execution", (Signature)factory.makeMethodSig("1", "merge", "com.jieyun.deskpool.bean.InstanceBean", "", "", "", "void"), 1112);
    }
}
