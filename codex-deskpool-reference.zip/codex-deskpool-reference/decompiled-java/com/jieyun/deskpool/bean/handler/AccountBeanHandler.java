/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.handler;

import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.service.GroupService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.ldap.ad.AdGroup;
import com.jieyun.deskpool.service.ldap.ad.AdGroupService;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.shared.UserdbContext;
import java.util.ArrayList;
import java.util.List;

@Deprecated
public class AccountBeanHandler {
    private IAccountBean bean;

    public AccountBeanHandler(IAccountBean bean) {
        this.bean = bean;
    }

    public List<IGroupBean> getGroups() {
        if (UserdbContext.getInstance().userdbIs(UserDB.AD)) {
            List<AdGroup> adGroupList = AdGroupService.getInstance().listGroupByUser(this.bean.getName());
            ArrayList<IGroupBean> groupBeanList = new ArrayList<IGroupBean>();
            GroupService groupService = Services.getGroupService();
            for (AdGroup adGroup : adGroupList) {
                IGroupBean groupBean = groupService.findByName(adGroup.getName());
                if (groupBean == null) continue;
                groupBean.setDescription(adGroup.getDescription());
                groupBeanList.add(groupBean);
            }
            return groupBeanList;
        }
        ArrayList<IGroupBean> beanList = new ArrayList<IGroupBean>();
        List<Id> idList = this.bean.getGroupIDs();
        GroupService groupService = Services.getGroupService();
        for (Id beanId : idList) {
            IGroupBean oneBean = (IGroupBean)groupService.findOne(beanId);
            if (oneBean == null) continue;
            beanList.add(oneBean);
        }
        return beanList;
    }

    public static AccountBeanHandler get(IAccountBean bean) {
        return new AccountBeanHandler(bean);
    }
}
