/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.TemplateApp;
import com.jieyun.deskpool.shared.TemplateAppStatus;
import com.jieyun.deskpool.shared.TemplateAppType;
import com.jieyun.deskpool.shared.VirtualSystemSubType;
import java.util.Date;
import java.util.List;

public interface ITemplateAppBean
extends Bean<TemplateApp> {
    public String getName();

    public String getVersions();

    public Long getFileSize();

    public String getDownloadUrl();

    public String getImgSize();

    public String getGuestos();

    public Date getCreatetime();

    public String getDescription();

    public Update getUpdate();

    public IServerBean getServer();

    public void downloads();

    public TemplateAppStatus getTemplateAppStatus();

    public String getJson();

    public String getVersion();

    public List<String> getVersionsList();

    public TemplateAppType getTemplateAppType();

    public String getDownLoadZipPath();

    public String getFileName();

    public void delete();

    public void deleteDownloadZip();

    public String getAgentver();

    public String getMd5();

    public VirtualSystemSubType getSubType();

    public String getProtocol();

    public boolean isStable();

    public void cancelDownLoad();

    public void restore();

    public boolean isStataus(TemplateAppStatus ... var1);

    public String getTemplateAppPath(TemplateAppType var1);

    public String getSaveDir(String var1, String var2);

    public String getDownloadDir(String var1, TemplateAppType var2);

    public String getUsername();

    public String getPassword();

    public static interface Update
    extends ITemplateAppBean,
    Bean.Update<TemplateApp> {
        public Update setName(String var1);

        public Update setVersions(String var1);

        public Update setFileSize(Long var1);

        public Update setDownloadUrl(String var1);

        public Update setImgSize(String var1);

        public Update setGuestos(String var1);

        public Update setCreatetime(Date var1);

        public Update setServer(IServerBean var1);

        public Update setTemplateAppStatus(TemplateAppStatus var1);

        public Update setDescription(String var1);

        public Update bindImage(IImageBean var1);

        public Update setTemplateAppType(TemplateAppType var1);

        public Update setAgentver(String var1);

        public Update setMd5(String var1);

        public Update setProtocol(String var1);

        public Update setFileName(String var1);

        public Update setUsername(String var1);

        public Update setPassword(String var1);

        public Update setSubType(VirtualSystemSubType var1);
    }
}
