/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.domain.Image;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.ImageInfo;
import com.jieyun.deskpool.shared.ImageStatus;
import java.util.List;

public static interface IImageBean.Update
extends IImageBean,
Bean.Update<Image> {
    public IImageBean.Update setName(String var1);

    public IImageBean.Update setDescription(String var1);

    public IImageBean.Update setMode(Desktop.ImageMode var1);

    public IImageBean.Update setStatus(ImageStatus var1);

    public IImageBean.Update setSourcevm(String var1);

    public IImageBean.Update setDraftvm(String var1);

    public IImageBean.Update setTargetvm(String var1);

    public IImageBean.Update setImageInfo(ImageInfo var1);

    public IImageBean.Update setAutoInstallAgent(boolean var1);

    public IImageBean.Update setVersions(List<String> var1);

    public IImageBean.Update clearDraftVm();

    public IImageBean.Update addVersion(String var1);

    public IImageBean.Update setUsername(String var1);

    public IImageBean.Update setPassword(String var1);

    public IImageBean.Update setLinux(boolean var1);
}
