/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Server;
import com.jieyun.deskpool.front.ServerFront;
import com.jieyun.deskpool.shared.GpuDevice;
import com.jieyun.deskpool.shared.MediateDevice;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import java.util.List;

public static interface IServerBean.Update
extends IServerBean,
Bean.Update<Server> {
    public void enterOnline();

    public void enterOffline(String var1);

    public void setNetworkStr(NetworkConfigVO var1);

    public void setNodeInfoListStr(List<ServerFront.NodeInfoFront> var1);

    public IServerBean.Update setGpuDevices(List<GpuDevice> var1);

    public IServerBean.Update setMediateDevices(List<MediateDevice> var1);
}
