/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

public class IClusterSignatureBean {
}
