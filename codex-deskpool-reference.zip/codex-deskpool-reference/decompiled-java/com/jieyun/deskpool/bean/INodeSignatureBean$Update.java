/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.INodeSignatureBean;
import com.jieyun.deskpool.domain.NodeSignature;
import com.jieyun.deskpool.shared.Id;

public static interface INodeSignatureBean.Update
extends INodeSignatureBean,
Bean.Update<NodeSignature> {
    public INodeSignatureBean.Update setSignature(String var1);

    public INodeSignatureBean.Update setServerId(Id var1);

    public INodeSignatureBean.Update setCluster(Id var1);

    public INodeSignatureBean.Update init(Id var1, String var2, String var3, String var4);
}
