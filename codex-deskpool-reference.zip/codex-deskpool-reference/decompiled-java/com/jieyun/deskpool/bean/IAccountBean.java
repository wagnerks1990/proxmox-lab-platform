/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.UserEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Account;
import com.jieyun.deskpool.domain.VmAccount;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.RedirectionPolicy;
import com.jieyun.deskpool.shared.RoleType;
import com.jieyun.deskpool.shared.UserSetting;
import java.util.List;

public interface IAccountBean
extends Bean<Account> {
    public String getName();

    public void setName(String var1);

    public String getFirstname();

    public void setFirstname(String var1);

    public String getLastname();

    public void setLastname(String var1);

    public String getPassword();

    public void setPassword(String var1);

    public List<RoleType> getRoles();

    public void setRoles(List<RoleType> var1);

    public void addRole(RoleType var1);

    public void removeRole(RoleType var1);

    public List<Id> getTemplateIDs();

    public void setTemplateIDs(List<Id> var1);

    public List<ITemplateBean> getTemplates();

    public void setTemplates(List<ITemplateBean> var1);

    public void addTemplate(ITemplateBean var1);

    public void removeTemplate(ITemplateBean var1);

    public List<IGroupBean> getGroups();

    public void setGroups(List<IGroupBean> var1);

    public void setGroupIDs(List<Id> var1);

    public List<Id> getGroupIDs();

    public void addGroup(IGroupBean var1);

    public void removeGroup(IGroupBean var1);

    public UserSetting getSetting();

    public void setSetting(UserSetting var1);

    public Update getUpdate();

    public boolean hasTemplate(ITemplateBean var1);

    public boolean hasTemplate(Id var1);

    public boolean validatePassword(String var1);

    public void updatePassword(String var1);

    public VmAccount getVmAccount(Id var1);

    public void bindVmAccount(VmAccount var1, String var2);

    public boolean isEnable();

    public void setEnable(boolean var1);

    public ApiResult<UserEntity> apiGet();

    public ApiResult<UserEntity> apiPut(UserEntity var1);

    public ApiResult<UserEntity> apiDelete();

    public boolean checkACL(String var1, String var2, String var3, String var4);

    public boolean isGroupAdmin();

    public void setTcId(String var1);

    public String getTcId();

    public Id getLastInstanceId();

    public Desktop.UserAuthentication getUserAuthentication();

    public boolean isAutoBindTcId();

    public boolean isClearLastInstance();

    public RedirectionPolicy getRedirectionPolicy();

    public void setRedirectionPolicy(RedirectionPolicy var1);

    public String getTotpSecret();

    public void setTotpSecret(String var1);

    public List<String> getBackupCodes();

    public void setBackupCodes(List<String> var1);

    public static interface Update
    extends IAccountBean,
    Bean.Update<Account> {
        public Update setLastInstanceId(Id var1);
    }
}
