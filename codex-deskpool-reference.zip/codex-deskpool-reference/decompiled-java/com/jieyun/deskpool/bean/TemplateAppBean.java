/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateAppBean;
import com.jieyun.deskpool.distributed.rpc.DispatchPoint;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.domain.TemplateApp;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ImageInfo;
import com.jieyun.deskpool.shared.TemplateAppStatus;
import com.jieyun.deskpool.shared.TemplateAppType;
import com.jieyun.deskpool.shared.VirtualSystemSubType;
import com.jieyun.deskpool.utils.DpDateUtils;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.JSONUtils;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.utils.TemplateAppDirUtils;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.manager.ImageManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TemplateAppBean
extends DefaultBean<TemplateApp>
implements ITemplateAppBean,
ITemplateAppBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(TemplateAppBean.class);

    @Override
    public String getServiceName() {
        return "templateAppService";
    }

    @Override
    public ITemplateAppBean.Update setUsername(String username) {
        this.setParam((Object)"username", username);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setPassword(String password) {
        this.setParam((Object)"password", password);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setVersions(String versions) {
        this.setParam((Object)"versions", versions);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setDownloadUrl(String downloadUrl) {
        this.setParam((Object)"downloadUrl", downloadUrl);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setImgSize(String imgSize) {
        this.setParam((Object)"imgSize", imgSize);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setGuestos(String guestos) {
        this.setParam((Object)"guestos", guestos);
        return this;
    }

    @Override
    public ITemplateAppBean.Update setCreatetime(Date createtime) {
        this.setParam((Object)"createtime", createtime);
        return this;
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public String getVersions() {
        return (String)this.getParam("versions");
    }

    @Override
    public String getDownloadUrl() {
        return (String)this.getParam("downloadUrl");
    }

    @Override
    public String getImgSize() {
        return (String)this.getParam("imgSize");
    }

    @Override
    public String getGuestos() {
        return (String)this.getParam("guestos");
    }

    @Override
    public Date getCreatetime() {
        return (Date)this.getParam("createtime");
    }

    @Override
    public String getDescription() {
        return (String)this.getParam("description");
    }

    @Override
    public String getUsername() {
        return (String)this.getParam("username");
    }

    @Override
    public String getPassword() {
        return (String)this.getParam("password");
    }

    @Override
    public ITemplateAppBean.Update getUpdate() {
        return (ITemplateAppBean.Update)this.refresh();
    }

    @Override
    public ITemplateAppBean.Update setServer(IServerBean server) {
        this.setParam((Object)"server", server.Id().getId());
        return this;
    }

    @Override
    public IServerBean getServer() {
        Long beanId = (Long)this.getParam("server");
        return beanId == null ? null : Services.getServerService().findOne(Id.construct(beanId));
    }

    @Override
    public ITemplateAppBean.Update setFileSize(Long fileSize) {
        this.setParam((Object)"fileSize", fileSize);
        return this;
    }

    @Override
    public Long getFileSize() {
        return (Long)this.getParam("fileSize");
    }

    @Override
    public void downloads() {
        Config config = Config.Store.get();
        if (config.vmIs(Config.VM.Type.pve)) {
            IServerBean server = Services.getServerService().getCurrent();
            logger.info("TempateAppBean.downloads : {} {}", (Object)server.getHost_vmmver(), (Object)this.getDownloadUrl());
            if (server.getHost_vmmver() != null && server.getHost_vmmver().replace(" ", "").contains("Proxmox5") && this.getDownloadUrl().contains("zst")) {
                throw new JYServiceRuntimeException("error.sync.image.not.support.zst");
            }
        }
        ImageManager imageManager = VMControlFactory.get(Config.Store.get()).getImageManager();
        imageManager.download(this);
    }

    @Override
    public ITemplateAppBean.Update setTemplateAppStatus(TemplateAppStatus status) {
        this.setParam((Object)"status", (Object)status);
        return this;
    }

    @Override
    public TemplateAppStatus getTemplateAppStatus() {
        return (TemplateAppStatus)((Object)this.getParam("status"));
    }

    @Override
    public String getJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\r\n");
        sb.append(JSONUtils.getJSonAttrite("name", this.getName(), true));
        sb.append(JSONUtils.getJSonAttrite("versions", this.getVersions(), true));
        sb.append(JSONUtils.getJSonAttrite("fileSize", this.getFileSize(), true));
        sb.append(JSONUtils.getJSonAttrite("downloadUrl", this.getDownloadUrl(), true));
        sb.append(JSONUtils.getJSonAttrite("fileName", this.getFileName(), true));
        sb.append(JSONUtils.getJSonAttrite("imgSize", this.getImgSize(), true));
        sb.append(JSONUtils.getJSonAttrite("guestos", this.getGuestos(), true));
        sb.append(JSONUtils.getJSonAttrite("createtime", DpDateUtils.getDateString(this.getCreatetime()), true));
        sb.append(JSONUtils.getJSonAttrite("agentver", this.getAgentver(), true));
        sb.append(JSONUtils.getJSonAttrite("md5", this.getMd5(), true));
        sb.append(JSONUtils.getJSonAttrite("username", this.getUsername(), true));
        sb.append(JSONUtils.getJSonAttrite("password", this.getPassword(), true));
        sb.append(JSONUtils.getJSonAttrite("subType", this.getSubType() == null ? "" : this.getSubType().toString(), true));
        sb.append(JSONUtils.getJSonAttrite("description", this.getDescription(), false));
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ITemplateAppBean.Update bindImage(IImageBean imageBean) {
        this.setName(imageBean.getName());
        this.setVersions(StringUtils.join(imageBean.getVersions(), (String)","));
        ImageInfo info = imageBean.getImageInfo();
        this.setGuestos(info.getGuestos());
        this.setCreatetime(new Date());
        this.setImgSize(info.getImgsize());
        this.setDescription(imageBean.getDescription());
        this.setAgentver(info.getAgentversion());
        this.setTemplateAppStatus(TemplateAppStatus.NONE);
        this.setSubType(imageBean.getSubType());
        return this;
    }

    @Override
    public ITemplateAppBean.Update setDescription(String description) {
        this.setParam((Object)"description", description);
        return this;
    }

    @Override
    public String getVersion() {
        List<String> list = this.getVersionsList();
        if (list.size() > 0) {
            return list.get(0);
        }
        return null;
    }

    @Override
    public List<String> getVersionsList() {
        String versions = this.getVersions();
        if (StringUtils.isNotEmpty((CharSequence)versions)) {
            return Arrays.asList(versions.split(","));
        }
        return new ArrayList<String>();
    }

    @Override
    public ITemplateAppBean.Update setTemplateAppType(TemplateAppType type) {
        this.setParam((Object)"type", (Object)type);
        return this;
    }

    @Override
    public TemplateAppType getTemplateAppType() {
        return (TemplateAppType)((Object)this.getParam("type"));
    }

    @Override
    @DispatchPoint
    public void delete() {
        VMControlFactory.get(Config.Store.get()).getImageManager().delDir(this);
        this.remove();
    }

    @Override
    public String getDownLoadZipPath() {
        IServerBean server = Services.getServerService().getCurrent();
        Config config = Config.Store.get();
        if (config.vmIs(Config.VM.Type.pve)) {
            return Props.instance().get("pve.back.path", "/var/lib/vz/dump");
        }
        return DpFileUtils.joinPathWindows(server.getDatastore(), TemplateAppDirUtils.getDir(this.getTemplateAppType()), this.getName());
    }

    @Override
    public void deleteDownloadZip() {
        VMControlFactory.get(Config.Store.get()).getImageManager().delDir(this);
    }

    @Override
    public ITemplateAppBean.Update setAgentver(String agentver) {
        this.setParam((Object)"agentver", agentver);
        return this;
    }

    @Override
    public String getAgentver() {
        return (String)this.getParam("agentver");
    }

    @Override
    public ITemplateAppBean.Update setMd5(String md5) {
        this.setParam((Object)"md5", md5);
        return this;
    }

    @Override
    public String getMd5() {
        return (String)this.getParam("md5");
    }

    @Override
    public ITemplateAppBean.Update setProtocol(String protocol) {
        this.setParam((Object)"protocol", protocol);
        return this;
    }

    @Override
    public String getProtocol() {
        return (String)this.getParam("protocol");
    }

    @Override
    public boolean isStable() {
        TemplateAppStatus status = this.getTemplateAppStatus();
        return status == TemplateAppStatus.NONE || status == TemplateAppStatus.DOWNLOADED;
    }

    @Override
    @DispatchPoint
    public void cancelDownLoad() {
        boolean flag = VMControlFactory.get(Config.Store.get()).getImageManager().cancelDownLoad(this);
        if (!flag) {
            this.setTemplateAppStatus(TemplateAppStatus.NONE).save();
        }
    }

    @Override
    @DispatchPoint
    public void restore() {
        IServerBean server = Services.getServerService().getCurrent();
        Services.getImageService().CreateImageByTemplateApp(server, this);
    }

    @Override
    public ITemplateAppBean.Update setFileName(String fileName) {
        this.setParam((Object)"fileName", fileName);
        return this;
    }

    @Override
    public String getFileName() {
        return (String)this.getParam("fileName");
    }

    @Override
    public VirtualSystemSubType getSubType() {
        return (VirtualSystemSubType)((Object)this.getParam("subType", (Object)VirtualSystemSubType.unknowType));
    }

    @Override
    public ITemplateAppBean.Update setSubType(VirtualSystemSubType subType) {
        this.setParam("subType", (Object)subType, ((Object)((Object)subType)).getClass());
        return this;
    }

    @Override
    public boolean isStataus(TemplateAppStatus ... status) {
        if (status == null) {
            return false;
        }
        TemplateAppStatus currentStatus = this.getTemplateAppStatus();
        TemplateAppStatus[] templateAppStatusArray = status;
        int n = status.length;
        int n2 = 0;
        while (n2 < n) {
            TemplateAppStatus appStatus = templateAppStatusArray[n2];
            if (appStatus == currentStatus) {
                return true;
            }
            ++n2;
        }
        return false;
    }

    @Override
    public String getTemplateAppPath(TemplateAppType type) {
        return null;
    }

    @Override
    public String getSaveDir(String downloadPath, String imageName) {
        Config config = Config.Store.get();
        if (config.vmIs(Config.VM.Type.pve)) {
            return Props.instance().get("pve.back.path", "/var/lib/vz/dump");
        }
        return DpFileUtils.joinPathWindows(downloadPath, imageName);
    }

    @Override
    public String getDownloadDir(String dataStore, TemplateAppType type) {
        Config config = Config.Store.get();
        if (config.vmIs(Config.VM.Type.pve)) {
            return Props.instance().get("pve.back.path", "/var/lib/vz/dump");
        }
        return DpFileUtils.joinPathWindows(dataStore, TemplateAppDirUtils.getDir(type));
    }
}
