/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.TCCertificate;

public interface ITCCertificateBean
extends Bean<TCCertificate> {
    public String getType();

    public String getSnReg();

    public Update getUpdate();

    public boolean isEffective(String var1);

    public static interface Update
    extends ITCCertificateBean,
    Bean.Update<TCCertificate> {
        public Update setType(String var1);

        public Update setSnReg(String var1);
    }
}
