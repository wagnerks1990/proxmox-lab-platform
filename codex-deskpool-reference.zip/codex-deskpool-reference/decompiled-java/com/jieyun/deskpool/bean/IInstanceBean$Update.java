/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Instance;
import com.jieyun.deskpool.shared.AgentStatus;
import com.jieyun.deskpool.shared.PrepState;
import com.jieyun.deskpool.shared.PrepTask;
import com.jieyun.deskpool.shared.TrackerOperation;
import com.jieyun.deskpool.shared.VMNetworkConfig;
import com.jieyun.deskpool.shared.VirtualGpuInstance;
import java.util.Date;

public static interface IInstanceBean.Update
extends IInstanceBean,
Bean.Update<Instance> {
    public IInstanceBean.Update setName(String var1);

    public IInstanceBean.Update setCopyfrom(String var1);

    public IInstanceBean.Update setVmname(String var1);

    public IInstanceBean.Update setDescription(String var1);

    public IInstanceBean.Update setTemplate(ITemplateBean var1);

    public IInstanceBean.Update setRollout(Date var1);

    public IInstanceBean.Update setAgentStatus(AgentStatus var1);

    public IInstanceBean.Update setServer(IServerBean var1);

    public IInstanceBean.Update setPrepState(PrepState var1);

    public IInstanceBean.Update setPrepTask(PrepTask var1);

    public IInstanceBean.Update fakePrepFinished();

    public IInstanceBean.Update setLoginTime(Date var1);

    public IInstanceBean.Update setClientLocation(String var1);

    public IInstanceBean.Update setUser(IAccountBean var1);

    public IInstanceBean.Update setIpaddress(String var1);

    public IInstanceBean.Update setVmParam(String var1, Object var2);

    public IInstanceBean.Update setSessionActive(boolean var1);

    public IInstanceBean.Update setCandidate(boolean var1);

    public IInstanceBean.Update setAutoInstallAgent(boolean var1);

    public IInstanceBean setImage(IImageBean var1);

    public IInstanceBean.Update setIsImageInstance(Boolean var1);

    public IInstanceBean.Update setCheckpointed();

    public IInstanceBean.Update clearCheckpointed();

    public IInstanceBean.Update eraseToCheckpoint();

    public IInstanceBean.Update setTrackerOperation(TrackerOperation var1);

    public IInstanceBean.Update setVncAvailable(boolean var1);

    public IInstanceBean.Update setSecondDisk(String var1, Integer var2);

    public IInstanceBean.Update setImageVersion(String var1);

    public IInstanceBean.Update rebuild();

    public IInstanceBean.Update setWaitGegenerate(boolean var1);

    public IInstanceBean.Update setServerHost(String var1);

    public IInstanceBean.Update setNodeName(String var1);

    public IInstanceBean.Update setVMNetworkConfig(VMNetworkConfig var1);

    public IInstanceBean.Update setComputerName(String var1);

    public IInstanceBean.Update setSgwcSk(String var1);

    public IInstanceBean.Update setVgpu(VirtualGpuInstance var1);
}
