/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.LicenseLog;

public interface ILicenseLogBean
extends Bean<LicenseLog> {
    public String getProduct();

    public String getAssignee();

    public String getVersion();

    public String getExpireDays();

    public String getLicenseType();

    public String getDesktopLimit();

    public String getFeatureCode();

    public String getCreateTime();

    public Update getUpdate();

    public String getSessionLimit();

    public String getCreateIp();

    public static interface Update
    extends ILicenseLogBean,
    Bean.Update<LicenseLog> {
        public void setProduct(String var1);

        public void setAssignee(String var1);

        public void setVersion(String var1);

        public void setExpireDays(String var1);

        public void setLicenseType(String var1);

        public void setDesktopLimit(String var1);

        public void setFeatureCode(String var1);

        public void setCreateTime(String var1);

        public void setSessionLimit(String var1);

        public void setCreateIp(String var1);
    }
}
