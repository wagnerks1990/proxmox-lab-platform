/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  org.aspectj.lang.JoinPoint$StaticPart
 *  org.aspectj.lang.Signature
 *  org.aspectj.runtime.internal.AroundClosure
 *  org.aspectj.runtime.reflect.Factory
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.context.annotation.Scope
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.aspectj.AnnotationTransactionAspect
 */
package com.jieyun.deskpool.bean;

import com.alibaba.fastjson.JSON;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.DefaultBean$AjcClosure1;
import com.jieyun.deskpool.bean.DefaultBean$AjcClosure3;
import com.jieyun.deskpool.bean.DefaultBean$AjcClosure5;
import com.jieyun.deskpool.domain.Being;
import com.jieyun.deskpool.service.BeanFactory;
import com.jieyun.deskpool.service.IBeanService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.StoreObject;
import com.jieyun.deskpool.utils.SpringUtils;
import java.util.ArrayList;
import java.util.List;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.runtime.internal.AroundClosure;
import org.aspectj.runtime.reflect.Factory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.aspectj.AnnotationTransactionAspect;

@Scope(value="prototype")
public abstract class DefaultBean<T extends Being>
implements Bean.Update<T> {
    private static final Logger logger;
    protected Class<T> entityClass;
    @Autowired
    BeanFactory beanFactory;
    protected StoreObject storeObject = null;
    private Id assignedId;
    private static final /* synthetic */ JoinPoint.StaticPart ajc$tjp_0;
    private static final /* synthetic */ JoinPoint.StaticPart ajc$tjp_1;
    private static final /* synthetic */ JoinPoint.StaticPart ajc$tjp_2;

    static {
        DefaultBean.ajc$preClinit();
        logger = LoggerFactory.getLogger((String)DefaultBean.class.getSimpleName());
    }

    @Override
    public void lock() {
    }

    @Override
    public void unlock() {
    }

    @Override
    public final void setStoreObject(StoreObject obj) {
        if (obj == null) {
            throw new RuntimeException(" StoreObject is null !");
        }
        this.storeObject = obj;
    }

    protected void addCollParamBean(String setfieldName, Object value) {
        String jsonStr = (String)this.getParam(setfieldName);
        List<Object> idList = jsonStr == null || "".equals(jsonStr) ? new ArrayList<Object>() : JSON.parseArray((String)jsonStr, value.getClass());
        idList.add(value);
        jsonStr = JSON.toJSONString(idList);
        this.setParam((Object)setfieldName, jsonStr);
    }

    protected void addCollId(String fieldName, Id id) {
        String jsonStr = (String)this.getParam(fieldName);
        List<Id> idList = jsonStr == null || "".equals(jsonStr) ? new ArrayList<Id>() : JSON.parseArray((String)jsonStr, Id.class);
        idList.add(id);
        jsonStr = JSON.toJSONString(idList);
        this.setParam((Object)fieldName, jsonStr);
    }

    protected void removeCollParamBean(String setfieldName, Object value) {
        String jsonStr = (String)this.getParam(setfieldName);
        if (jsonStr == null || "".equals(jsonStr)) {
            return;
        }
        List idList = JSON.parseArray((String)jsonStr, value.getClass());
        idList.remove(value);
        if (idList.size() > 0) {
            jsonStr = JSON.toJSONString((Object)idList);
            this.setParam((Object)setfieldName, jsonStr);
        } else {
            this.setParam(setfieldName, null);
        }
    }

    protected void addCollParam(String setfieldName, Being value) {
        String jsonStr = (String)this.getParam(setfieldName);
        List<Id> idList = jsonStr == null || "".equals(jsonStr) ? new ArrayList<Id>() : JSON.parseArray((String)jsonStr, Id.class);
        idList.add(Id.construct(value.getId()));
        jsonStr = JSON.toJSONString(idList);
        this.setParam((Object)setfieldName, jsonStr);
    }

    protected void setParam(String fieldName, List list) {
        if (list == null || list.size() == 0) {
            this.setParam((Object)fieldName, null);
        } else {
            String jsonStr = JSON.toJSONString((Object)list);
            this.setParam((Object)fieldName, jsonStr);
        }
    }

    protected <W> List<W> getParamList(String fieldName, Class<W> clazz) {
        String jsonStr = (String)this.getParam(fieldName);
        if (jsonStr == null || "".equals(jsonStr)) {
            return new ArrayList();
        }
        List list = JSON.parseArray((String)jsonStr, clazz);
        return list;
    }

    protected void setIdParam(Object k, Id v) {
        if (v != null) {
            this.storeObject.setParam(k.toString(), v.getId());
        } else {
            this.storeObject.setParam(k.toString(), null);
        }
    }

    protected void setParam(Object k, Object v) {
        if (Id.class.isInstance(v)) {
            throw new RuntimeException("please use setIdParam instead of setParam");
        }
        this.storeObject.setParam(k.toString(), v);
    }

    protected void setParam(Object k, Object v, Class paramClass) {
        this.storeObject.setParam(k.toString(), v);
    }

    protected Object getParam(Object k, Object defaultValue) {
        Object v = this.getParam(k);
        if (v == null) {
            return defaultValue;
        }
        return v;
    }

    protected Id getIdParam(Object k) {
        Long v = (Long)this.getParam(k);
        if (v == null) {
            return null;
        }
        return Id.construct(v);
    }

    protected Object getParam(Object k) {
        return this.storeObject.getParam(k.toString());
    }

    protected void setAssignedId(Id id) {
        if (id == null) {
            throw new RuntimeException("id is null");
        }
        this.assignedId = id;
    }

    @Override
    @Transactional
    public void persist() {
        Object[] objectArray = new Object[]{this};
        AnnotationTransactionAspect.aspectOf().ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96c((Object)this, (AroundClosure)new DefaultBean$AjcClosure1(objectArray), ajc$tjp_0);
    }

    @Override
    public T getDomain() {
        return (T)this.storeObject.getDomain();
    }

    @Override
    @Transactional
    public void remove() {
        Object[] objectArray = new Object[]{this};
        AnnotationTransactionAspect.aspectOf().ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96c((Object)this, (AroundClosure)new DefaultBean$AjcClosure3(objectArray), ajc$tjp_1);
    }

    @Transactional
    public void merge() {
        Object[] objectArray = new Object[]{this};
        AnnotationTransactionAspect.aspectOf().ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96c((Object)this, (AroundClosure)new DefaultBean$AjcClosure5(objectArray), ajc$tjp_2);
    }

    @Override
    public <W> W refresh() {
        if (this.isNew()) {
            return (W)this;
        }
        String beanName = this.getClass().getSimpleName();
        beanName = String.valueOf(beanName.substring(0, 1).toLowerCase()) + beanName.substring(1);
        IBeanService beanService = (IBeanService)SpringUtils.context.getBean(String.valueOf(beanName.replaceAll("Bean", "")) + "Service");
        Object newbean = beanService.createOne();
        try {
            newbean.managedById(this.Id());
        }
        catch (Exception e) {
            e.printStackTrace();
            newbean = this;
        }
        return (W)newbean;
    }

    @Override
    public boolean isDeattach() {
        String beanName = this.getClass().getSimpleName();
        beanName = String.valueOf(beanName.substring(0, 1).toLowerCase()) + beanName.substring(1);
        IBeanService beanService = (IBeanService)SpringUtils.context.getBean(String.valueOf(beanName.replaceAll("Bean", "")) + "Service");
        if (this.Id() != null) {
            return beanService.findOne(this.Id()) == null;
        }
        return false;
    }

    @Override
    public void createId() {
        this.storeObject.setId(Id.construct(System.nanoTime()));
    }

    @Override
    public Id Id() {
        return this.storeObject.getId();
    }

    @Override
    public String asString() {
        StringBuffer sb = new StringBuffer();
        sb.append(String.valueOf(this.getClass().getSimpleName()) + " : ");
        sb.append(this.Id());
        int index = sb.lastIndexOf(",");
        if (index != -1) {
            sb.deleteCharAt(index);
        }
        return sb.toString();
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(String.valueOf(this.getClass().getSimpleName()) + " [");
        sb.append(this.Id()).append("]");
        return sb.toString();
    }

    @Override
    public void postConstruct() {
    }

    @Override
    public void postStoreObjectSet() {
    }

    @Override
    public Bean<T> save() {
        try {
            if (this.isNew()) {
                this.persist();
            } else {
                this.merge();
            }
            DefaultBean defaultBean = this;
            return defaultBean;
        }
        finally {
            this.unlock();
        }
    }

    List<ErrorMessage> validate() {
        return new ArrayList<ErrorMessage>();
    }

    @Override
    public boolean isNew() {
        return this.storeObject.getId() == null;
    }

    protected boolean booleanValue(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean) {
            return (Boolean)value;
        }
        if (value instanceof String) {
            return Boolean.valueOf((String)value);
        }
        return false;
    }

    @Override
    public void managedById(Id id) {
        StoreObject newObj = StoreObject.findById(id, this.getDomain().getClass());
        if (newObj == null) {
            throw new RuntimeException(" obj not found ! ");
        }
        this.setStoreObject(newObj);
        this.postStoreObjectSet();
    }

    @Override
    public boolean persistOnOnly(Id serverId) {
        return false;
    }

    static final /* synthetic */ void persist_aroundBody0(DefaultBean ajc$this) {
        List<ErrorMessage> errList = ajc$this.validate();
        if (errList.size() > 0) {
            logger.info("persist failed for validate:{}", (Object)errList.get(0).getErrorId());
            throw new JYServiceRuntimeException(errList);
        }
        Id id = null;
        id = ajc$this.assignedId != null ? ajc$this.assignedId : Id.construct();
        ajc$this.storeObject.setId(id);
        ajc$this.storeObject.persist();
        logger.debug("persist {}  ", (Object)ajc$this.toString());
    }

    static final /* synthetic */ void remove_aroundBody2(DefaultBean ajc$this) {
        ajc$this.storeObject.remove();
    }

    static final /* synthetic */ void merge_aroundBody4(DefaultBean ajc$this) {
        List<ErrorMessage> errList = ajc$this.validate();
        if (errList.size() > 0) {
            logger.error("validate error ID:" + errList.get(0).getErrorId());
            throw new JYServiceRuntimeException(errList);
        }
        ajc$this.storeObject.merge();
    }

    private static /* synthetic */ void ajc$preClinit() {
        Factory factory = new Factory("DefaultBean.java", DefaultBean.class);
        ajc$tjp_0 = factory.makeSJP("method-execution", (Signature)factory.makeMethodSig("1", "persist", "com.jieyun.deskpool.bean.DefaultBean", "", "", "", "void"), 221);
        ajc$tjp_1 = factory.makeSJP("method-execution", (Signature)factory.makeMethodSig("1", "remove", "com.jieyun.deskpool.bean.DefaultBean", "", "", "", "void"), 245);
        ajc$tjp_2 = factory.makeSJP("method-execution", (Signature)factory.makeMethodSig("1", "merge", "com.jieyun.deskpool.bean.DefaultBean", "", "", "", "void"), 252);
    }
}
