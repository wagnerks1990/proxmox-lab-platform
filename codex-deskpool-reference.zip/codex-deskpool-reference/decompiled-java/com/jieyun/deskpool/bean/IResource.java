/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.shared.VPower;

public interface IResource {
    public VPower getPower();
}
