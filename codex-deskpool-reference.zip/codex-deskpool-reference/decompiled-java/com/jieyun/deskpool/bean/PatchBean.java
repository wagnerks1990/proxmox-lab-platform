/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.FileUtils
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.DeskpoolVersion;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.utils.ConfigHomeUtils;
import com.jieyun.deskpool.utils.Script;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PatchBean {
    private static final Logger logger = LoggerFactory.getLogger(PatchBean.class);
    private boolean applyed = false;
    private String name = null;
    private String path = null;
    private Status status = Status.TMP;
    private ReentrantLock lock = new ReentrantLock();

    public void loadPatchFile(InputStream in, String uploadedFilename) {
        if (!this.lock.tryLock()) {
            return;
        }
        try {
            String pMV;
            if (Status.TMP != this.status) {
                throw new IllegalStateException("Status is not tmp");
            }
            String name = uploadedFilename;
            if (StringUtils.isBlank((String)name)) {
                throw new JYServiceRuntimeException("upgrade.patch.loadPatchFile.name.isNull", "\u975e\u6cd5\u7684\u8865\u4e01\u6587\u4ef6");
            }
            if (!name.matches("^deskpoolv\\d{2}p\\d{2}\\.patch$")) {
                throw new JYServiceRuntimeException("upgrate.patch.loadPatchFile.invalidFile", "\u975e\u6cd5\u7684\u8865\u4e01\u6587\u4ef6");
            }
            Package pack = DeskpoolVersion.class.getPackage();
            DeskpoolVersion curVersion = pack.getAnnotation(DeskpoolVersion.class);
            String curMV = String.valueOf(curVersion.mver()) + curVersion.sver();
            if (!curMV.equals(pMV = name.replaceAll("[a-zA-Z\\-\\.]*", "").substring(0, 2))) {
                throw new JYServiceRuntimeException("upgrate.patch.loadPatchFile.version.notMatch", "\u8865\u4e01\u6587\u4ef6\u4e0d\u9002\u7528\u4e8e\u5f53\u524dDeskpool\u7248\u672c\u3002");
            }
            try {
                try {
                    File tmpFile = new File(String.valueOf(System.getProperty("java.io.tmpdir")) + File.separator + uploadedFilename);
                    FileUtils.copyInputStreamToFile((InputStream)in, (File)tmpFile);
                    this.preApplayCheck(tmpFile);
                    this.status = Status.PATCHFILE_READY;
                    this.path = tmpFile.getAbsolutePath();
                    this.name = uploadedFilename;
                }
                catch (IOException e) {
                    e.printStackTrace();
                    try {
                        in.close();
                    }
                    catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            finally {
                try {
                    in.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        finally {
            this.lock.unlock();
        }
    }

    public void loadPatchFile(byte[] in, String uploadedFilename) {
        if (!this.lock.tryLock()) {
            return;
        }
        try {
            String pMV;
            if (Status.TMP != this.status) {
                throw new IllegalStateException("Status is not tmp");
            }
            String name = uploadedFilename;
            if (StringUtils.isBlank((String)name)) {
                throw new JYServiceRuntimeException("upgrade.patch.loadPatchFile.name.isNull", "\u975e\u6cd5\u7684\u8865\u4e01\u6587\u4ef6");
            }
            if (!name.matches("^deskpoolv\\d{2}p\\d{2}\\.patch$")) {
                throw new JYServiceRuntimeException("upgrate.patch.loadPatchFile.invalidFile", "\u975e\u6cd5\u7684\u8865\u4e01\u6587\u4ef6");
            }
            Package pack = DeskpoolVersion.class.getPackage();
            DeskpoolVersion curVersion = pack.getAnnotation(DeskpoolVersion.class);
            String curMV = String.valueOf(curVersion.mver()) + curVersion.sver();
            if (!curMV.equals(pMV = name.replaceAll("[a-zA-Z\\-\\.]*", "").substring(0, 2))) {
                throw new JYServiceRuntimeException("upgrate.patch.loadPatchFile.version.notMatch", "\u8865\u4e01\u6587\u4ef6\u4e0d\u9002\u7528\u4e8e\u5f53\u524dDeskpool\u7248\u672c\u3002");
            }
            try {
                File tmpFile = new File(String.valueOf(System.getProperty("java.io.tmpdir")) + File.separator + uploadedFilename);
                FileUtils.writeByteArrayToFile((File)tmpFile, (byte[])in);
                this.preApplayCheck(tmpFile);
                this.status = Status.PATCHFILE_READY;
                this.path = tmpFile.getAbsolutePath();
                this.name = uploadedFilename;
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        finally {
            this.lock.unlock();
        }
    }

    public String checkPatchUpdate() {
        return null;
    }

    public void checkin() {
        if (!this.lock.tryLock()) {
            return;
        }
        try {
            if (Status.PATCHFILE_READY != this.status) {
                throw new IllegalStateException("Status is not PATCHFILE_READY");
            }
            if (StringUtils.isBlank((String)this.name)) {
                throw new IllegalStateException("name is null");
            }
            if (StringUtils.isBlank((String)this.path)) {
                throw new IllegalStateException("filepath is null");
            }
            File preapplayDir = new File(ConfigHomeUtils.getPatchLocation().getPreApplydir());
            File[] subFile = preapplayDir.listFiles();
            if (subFile != null) {
                File[] fileArray = preapplayDir.listFiles();
                int n = fileArray.length;
                int n2 = 0;
                while (n2 < n) {
                    File sub = fileArray[n2];
                    sub.delete();
                    ++n2;
                }
            }
            try {
                FileUtils.copyFile((File)new File(this.path), (File)new File(preapplayDir.getAbsoluteFile() + File.separator + this.name));
                this.status = Status.PREAPPLY;
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        finally {
            this.lock.unlock();
        }
    }

    public boolean apply() {
        if (!this.lock.tryLock()) {
            return false;
        }
        try {
            if (Status.PREAPPLY != this.status) {
                throw new IllegalStateException("Status is not PREAPPLY");
            }
            IServerBean server = Services.getServerService().getCurrent();
            new TrackerService.Writer.Server().patch(server).complete("server.patch.applypatch", new String[]{"$name", this.getName()});
            String shellCmd = "jypatch.sh " + this.getName();
            logger.info("Run shell : " + shellCmd);
            String result = Script.runSimpleBashRemoteScript(shellCmd, 10000);
            boolean bl = result != null;
            return bl;
        }
        finally {
            this.lock.unlock();
        }
    }

    public boolean apply2() {
        if (!this.lock.tryLock()) {
            return false;
        }
        try {
            if (Status.PREAPPLY != this.status) {
                throw new IllegalStateException("Status is not PREAPPLY");
            }
            String shellCmd = "nohup jypatch.sh " + this.getName() + " &";
            try {
                Runtime.getRuntime().exec(shellCmd);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        }
        finally {
            this.lock.unlock();
        }
    }

    public void remove() {
        new File(this.path).delete();
    }

    private void preApplayCheck(File file) {
        String shellCmd = "jycheck.sh " + file.getAbsolutePath();
        logger.info("Run shell : " + shellCmd);
        String result = Script.runSimpleBashRemoteScript(shellCmd, 60000);
        logger.info("result: " + result);
        if (StringUtils.isEmpty((String)result) || result.contains("base.md5: Not found in archive") || result.contains("patch is invalid")) {
            file.delete();
            throw new JYServiceRuntimeException("upgrate.patch.preApplayCheck.invalid", "\u8865\u4e01\u6587\u4ef6\u4e0d\u9002\u7528\u4e8e\u5f53\u524dDeskpool\u7248\u672c\u3002");
        }
    }

    public static PatchBean loadByPath(String path) {
        PatchBean patch = new PatchBean();
        File patchFile = new File(path);
        if (patchFile.isFile()) {
            patch.name = patchFile.getName();
            patch.path = path;
            patch.status = Status.TMP;
        }
        return patch;
    }

    public static PatchBean readPreapplay() {
        PatchBean bean = new PatchBean();
        File activeDir = new File(ConfigHomeUtils.getPatchLocation().getPreApplydir());
        if (!activeDir.isDirectory()) {
            logger.info("No reapplay patch in {} . ", (Object)activeDir);
            return null;
        }
        File[] child = activeDir.listFiles();
        if (child.length == 0) {
            logger.info("No reapplay patch in {} . ", (Object)activeDir);
            return null;
        }
        File activePatchFile = child[0];
        bean.path = activePatchFile.getAbsolutePath();
        bean.name = activePatchFile.getName();
        bean.status = Status.PREAPPLY;
        return bean;
    }

    public boolean isApplyed() {
        return this.applyed;
    }

    public void setApplyed(boolean applyed) {
        this.applyed = applyed;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Status getStatus() {
        return this.status;
    }

    public static enum Status {
        TMP,
        PATCHFILE_READY,
        CHECKIN,
        PREAPPLY,
        APPLYED;

    }
}
