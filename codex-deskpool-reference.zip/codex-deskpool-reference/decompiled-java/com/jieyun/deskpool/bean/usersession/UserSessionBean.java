/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.joda.time.DateTime
 *  org.joda.time.ReadableInstant
 *  org.joda.time.Seconds
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jieyun.deskpool.bean.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.agent.usersession.UserSessionManager;
import com.jieyun.deskpool.agent.usersession.UserSessionServant;
import com.jieyun.deskpool.agent.usersession.handler.AllocateGatewayStatusHandler;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.SessionEntity;
import com.jieyun.deskpool.api.data.SessionEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.IUserDiskBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.bean.usersession.UserSessionUtils;
import com.jieyun.deskpool.bean.utils.VmAccountPasswordUtils;
import com.jieyun.deskpool.distributed.rpc.DispatchPoint;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.domain.VmAccount;
import com.jieyun.deskpool.service.AccountService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.JieyunLicense;
import com.jieyun.deskpool.service.PortMappingService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TemplateService;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.ConnectStatus;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DeviceMapping;
import com.jieyun.deskpool.shared.DomainInfo;
import com.jieyun.deskpool.shared.DpClientType;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.shared.ServerStatus;
import com.jieyun.deskpool.shared.TemplatePolicy;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.shared.UserSessionToken;
import com.jieyun.deskpool.shared.UserSetting;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.DpStringUtils;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.utils.SpringUtils;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.ReadableInstant;
import org.joda.time.Seconds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import sun.misc.BASE64Encoder;

public class UserSessionBean
extends DefaultBean<UserSession>
implements IUserSessionBean,
IUserSessionBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(UserSessionBean.class);
    private static TemplateResourceHolder templateLockHolder = new TemplateResourceHolder();
    private ITemplateBean cacheTemplateBean;
    private JYServiceRuntimeException exception;
    private static ConcurrentHashMap<String, Lock> instanceListLock = new ConcurrentHashMap();
    private static LimitLock limitLock = new LimitLock();
    @Autowired
    SessionEntityBinding sessionEntityBinding;

    @Override
    public IUserSessionBean.Update getUpdate() {
        this.lock();
        return (IUserSessionBean.Update)this.refresh();
    }

    @Override
    public Id getInstanceId() {
        return this.getIdParam("instanceId");
    }

    @Override
    public void setInstanceId(Id instanceId) {
        this.setIdParam("instanceId", instanceId);
    }

    @Override
    public void setInstanceIP(String instanceIP) {
        this.setParam((Object)"instanceIP", instanceIP);
    }

    @Override
    public Id getAccountId() {
        return this.getIdParam("accountId");
    }

    public IAccountBean getAccount() {
        return (IAccountBean)Services.getAccountService().findOne(this.getAccountId());
    }

    @Override
    public String getClientIP() {
        return (String)this.getParam("clientIP");
    }

    @Override
    public String getAccountName() {
        return (String)this.getParam("accountName");
    }

    @Override
    public String getInstanceIP() {
        return (String)this.getParam("instanceIP");
    }

    @Override
    public IPortMappingBean getPortMapping() {
        return (IPortMappingBean)((PortMappingService)SpringUtils.context.getBean(PortMappingService.class)).findOne(Id.construct(((UserSession)this.getDomain()).getPortMappingId()));
    }

    @Override
    public String getTemplateName() {
        return (String)this.getParam("templateName");
    }

    @Override
    public UserSessionStatus getStatus() {
        return (UserSessionStatus)((Object)this.getParam("status"));
    }

    @Override
    public IInstanceBean getAssignedInstance() {
        return (IInstanceBean)Services.getInstanceService().findOne(Id.construct(((UserSession)this.getDomain()).getInstanceId()));
    }

    @Override
    public void setConnectedTemplate(ITemplateBean templateBean) {
        this.cacheTemplateBean = templateBean;
    }

    @Override
    public ITemplateBean getConnectedTemplate() {
        if (this.cacheTemplateBean == null) {
            this.cacheTemplateBean = Services.getTemplateService().findByName(this.getTemplateName());
        }
        return this.cacheTemplateBean;
    }

    @Override
    public boolean testValid() {
        return this.getStatus() != UserSessionStatus.INVALIDATE && this.getStatus() != UserSessionStatus.GATEWAY_ALLOCATE_FAILED && !this.isDeattach();
    }

    @Override
    public void enterStatus(UserSessionStatus status) {
        UserSessionStatus currentStatus = ((UserSession)this.getDomain()).getStatus();
        if (UserSessionStatus.INVALIDATE == currentStatus) {
            UserSessionLog.getLogger().info("{} - status is INVALIDATE , can not change status . ", (Object)this);
        }
        if (!((UserSession)this.getDomain()).getStatus().equals((Object)status)) {
            UserSessionLog.getLogger().info("UserSession[{} - {}] status from [{}] to [{}]", new Object[]{((UserSession)this.getDomain()).getAccountName(), this.getInstanceIP(), currentStatus, status});
        }
        ((UserSession)this.getDomain()).setStatus(status);
        ((UserSession)this.getDomain()).setDateUpdated(new Date());
    }

    @Override
    public JYServiceRuntimeException getException() {
        return this.exception;
    }

    @Override
    public void setException(JYServiceRuntimeException e) {
        this.exception = e;
    }

    @Override
    public boolean testTheSameSource(String clientIP) {
        return StringUtils.isNotBlank((CharSequence)clientIP) && clientIP.equals(this.getClientIP());
    }

    @Override
    public void setPortMappingId(Id id) {
        this.setIdParam("portMappingId", id);
    }

    private Lock allocateLock(IInstanceBean instance) {
        ReentrantLock newLock;
        String key = String.valueOf(instance.Id().getId() * 500L);
        Lock lock = instanceListLock.get(key);
        if (lock == null && (lock = instanceListLock.putIfAbsent(key, newLock = new ReentrantLock())) == null) {
            lock = newLock;
        }
        return lock;
    }

    @Override
    public ConnectStatus readConnectStatus(String password) {
        ConnectStatus connectStatus = new ConnectStatus();
        connectStatus.setDeskpoolUser(((UserSession)this.getDomain()).getAccountName());
        connectStatus.setUsername("");
        connectStatus.setPassword(password);
        connectStatus.setProtocol(this.getProtocol());
        connectStatus.setClientIP(this.getClientIP());
        connectStatus.setStatusCode(Desktop.Status.USERSESSION_WAITING);
        if (((UserSession)this.getDomain()).getStatus() == UserSessionStatus.NEW || ((UserSession)this.getDomain()).getStatus() == UserSessionStatus.NEW_WAITING || ((UserSession)this.getDomain()).getStatus() == UserSessionStatus.NEW_ACCEPTED) {
            return connectStatus;
        }
        if (((UserSession)this.getDomain()).getStatus() == UserSessionStatus.INSTANCE_ASSIGN_WAITING) {
            return connectStatus;
        }
        IInstanceBean instance = this.getAssignedInstance();
        if (instance == null) {
            ITemplateBean templateBean = this.getTemplate();
            if (templateBean != null && templateBean.isForceSuffixMatch()) {
                connectStatus.setStatusParams(new String[]{DpStringUtils.getSuffixNumber(((UserSession)this.getDomain()).getAccountName())});
                connectStatus.setStatusCode(Desktop.Status.NO_DESKTOP_FORCESUFFIXMATCH);
            } else {
                connectStatus.setStatusCode(Desktop.Status.NO_DESKTOP);
            }
            return connectStatus;
        }
        connectStatus.setInstanceId(instance.Id());
        UserSessionStatus status = ((UserSession)this.getDomain()).getStatus();
        if (this.getException() != null) {
            connectStatus.setErrorMsgList(this.getException().getErrorList());
        } else {
            IPortMappingBean portMappingBean = this.getPortMapping();
            if (portMappingBean != null) {
                if (PortMappingStatus.ALLOCATE_WAITING == ((PortMapping)portMappingBean.getDomain()).getStatus()) {
                    connectStatus.setStatusCode(Desktop.Status.GATEWAY_ALLOCATE_WAITING);
                    return connectStatus;
                }
                if (PortMappingStatus.ALLOCATE_FAILURE == ((PortMapping)portMappingBean.getDomain()).getStatus()) {
                    connectStatus.setStatusCode(Desktop.Status.GATEWAY_ALLOCATE_FAILURE);
                    return connectStatus;
                }
            }
            if (UserSessionStatus.RESOURCE_ALL_READY == status) {
                InstanceStatus instanceStatus;
                IServerBean server = instance.getServer();
                ServerStatus serverStatus = server.getStatus();
                if (serverStatus != ServerStatus.STATUS_ACTIVATED) {
                    connectStatus.setStatusCode(Desktop.Status.SERVER_FAULT);
                }
                if ((instanceStatus = instance.getStatus()) == InstanceStatus.SHUTDOWN) {
                    connectStatus.setStatusCode(Desktop.Status.DESKTOP_SHUTDOWN);
                } else if (instanceStatus == InstanceStatus.BROKEN) {
                    connectStatus.setStatusCode(Desktop.Status.DESKTOP_BROKEN);
                } else if (instanceStatus != InstanceStatus.RUNNING) {
                    connectStatus.setStatusCode(Desktop.Status.DESKTOP_STARTING);
                } else if (instanceStatus == InstanceStatus.RUNNING && instance.alive()) {
                    connectStatus.setStatusCode(Desktop.Status.NORMAL);
                    connectStatus.writeInstanceBean(this.getAssignedInstance());
                    connectStatus.writeSessionBean(this);
                }
            }
        }
        if (connectStatus.getStatusCode() == Desktop.Status.NORMAL) {
            TemplatePolicy policy;
            new TrackerService.Writer.connInfo().connect(connectStatus.readSessionBean()).message("session.connect.create.config", connectStatus.readSessionBean(), new String[0]);
            StringBuilder redirectUrlBuf = new StringBuilder("connect/connect.do?");
            Desktop.Protocol protocol = ((UserSession)this.getDomain()).getProtocol();
            List<Desktop.Protocol> proList = instance.getTemplate().getProtocols();
            logger.info("DpClientType:{},protocols:{},proList:{}", new Object[]{this.getClientType(), protocol, proList});
            if ((this.getClientType() == DpClientType.Windows || this.getClientType() == DpClientType.DeskpoolClient) && proList.contains((Object)Desktop.Protocol.RDP)) {
                protocol = Desktop.Protocol.RDP;
            }
            redirectUrlBuf.append("t=").append(new Date().getTime()).append("&instanceId=").append(instance.Id());
            redirectUrlBuf.append("&protocol=").append(protocol.name());
            redirectUrlBuf.append("&p=").append("p");
            String redirectUrlStr = redirectUrlBuf.toString();
            redirectUrlStr = String.valueOf(((UserSession)this.getDomain()).getContextPath()) + redirectUrlStr + ";JSESSIONID=" + ((UserSession)this.getDomain()).getJsessionId();
            if (this.getClientType() == DpClientType.JieyunTC && Desktop.Protocol.JYRDP == connectStatus.getProtocol()) {
                String encodeUrl = new BASE64Encoder().encodeBuffer(redirectUrlStr.getBytes());
                connectStatus.setRedirectUrl("jyrdp://" + encodeUrl);
            } else {
                connectStatus.setRedirectUrl(redirectUrlStr);
            }
            if (instance.getTemplate().getPoolType() == PoolType.POOLED && (policy = instance.getTemplate().getPolicy()) != null && policy.getAutoFillBinding().booleanValue() && !policy.getEnableModifyBinding().booleanValue()) {
                connectStatus.setUsername(policy.getUsername());
                connectStatus.setPassword(policy.getPassword());
                connectStatus.setUseAD(false);
                return connectStatus;
            }
            VmAccount vmAccount = ((UserSession)this.getDomain()).getVmAccount();
            if (vmAccount != null && vmAccount.isEnable()) {
                connectStatus.setUsername(vmAccount.getUsername());
                connectStatus.setPassword(VmAccountPasswordUtils.decode(vmAccount.getPassword()));
                connectStatus.setDomain(vmAccount.getDomain());
                connectStatus.setUseAD(false);
            } else {
                DomainInfo domainInfo = Services.getClusterService().getDomainInfo();
                if (StringUtils.isNotBlank((CharSequence)domainInfo.getNetBiosDomain())) {
                    connectStatus.setUsername(String.valueOf(domainInfo.getNetBiosDomain()) + "\\" + connectStatus.getDeskpoolUser());
                    connectStatus.setNetBiosDomain(domainInfo.getNetBiosDomain());
                    connectStatus.setDomain(domainInfo.getName());
                    connectStatus.setFqdn(String.valueOf(instance.getVmname()) + "." + connectStatus.getDomain());
                    if (protocol == Desktop.Protocol.PCOIP) {
                        connectStatus.setUsername(connectStatus.getDeskpoolUser());
                    }
                } else {
                    connectStatus.setUsername("");
                    connectStatus.setPassword("");
                }
            }
        }
        return connectStatus;
    }

    private boolean isUseUsbdevice(IInstanceBean instance) {
        ITemplateBean templateBean = instance.getTemplate();
        if (templateBean != null) {
            DeviceMapping deviceMapping = templateBean.getDevicmap();
            return deviceMapping != null && deviceMapping.getUsbdevice() != false;
        }
        return false;
    }

    @Override
    public boolean isLocal() {
        return this.getServerId().equals(Services.getServerService().getCurrent().Id());
    }

    @Override
    public void touch(boolean flush) {
        UserSessionLog.getLogger().debug("UserSession is touched.");
        ((UserSession)this.getDomain()).setDateUpdated(new Date());
        if (flush) {
            this.save();
        }
    }

    @Override
    public int lastUpdatePeriod() {
        if (((UserSession)this.getDomain()).getDateUpdated() == null) {
            return 3600;
        }
        return Seconds.secondsBetween((ReadableInstant)new DateTime((Object)((UserSession)this.getDomain()).getDateUpdated()), (ReadableInstant)new DateTime()).getSeconds();
    }

    @Override
    @DispatchPoint
    public void destroy() {
        this.releasePortMapping(this);
        this.remove();
    }

    @Override
    public Id getServerId() {
        return this.getIdParam("serverId");
    }

    @Override
    public IServerBean getServer() {
        return Services.getServerService().findOne(this.getServerId());
    }

    public boolean isDestroyed() {
        return Services.getUserSessionService().findOne(this.Id()) == null;
    }

    private void releasePortMapping(IUserSessionBean userSessionBean) {
        IPortMappingBean portMappingBean = userSessionBean.getPortMapping();
        if (portMappingBean != null) {
            userSessionBean.setPortMappingId(null);
            ((PortMapping)portMappingBean.getDomain()).setStatus(PortMappingStatus.MARK_RELEASE);
            portMappingBean.save();
            portMappingBean.release();
        }
    }

    @Override
    public String toString() {
        UserSession session = (UserSession)this.getDomain();
        if (session == null) {
            return "null";
        }
        return session.toString();
    }

    @Override
    public String getServiceName() {
        return "";
    }

    @Override
    @DispatchPoint
    public void active(Id instanceId, String username, String computerIP, String computerName, String clientIP) {
        UserSessionServant.instance().activedSession(this, instanceId, username, computerIP, computerName, clientIP);
    }

    @Override
    @DispatchPoint
    public void end() {
        UserSessionServant.instance().endSession(this);
    }

    @Override
    @DispatchPoint
    public void close() {
        UserSessionServant.instance().closeSession(this);
    }

    @Override
    public void connectTemplate(UserSessionToken token) {
        TemplateService templateService = Services.getTemplateService();
        ITemplateBean templateBean = templateService.findByName(token.getTemplateName());
        if (templateBean == null) {
            throw new JYServiceRuntimeException("usersession.create.template.isNull", "\u6a21\u7248\u4e3a\u7a7a");
        }
        AccountService accountService = Services.getAccountService();
        IAccountBean accountBean = accountService.findByName(token.getDpUsername());
        if (accountBean == null) {
            throw new JYServiceRuntimeException("usersession.create.accountNotFound", "\u7528\u6237\u4e0d\u5b58\u5728");
        }
        this.connectTemplate(templateBean, accountBean);
    }

    public void connectTemplate() {
        ITemplateBean templateBean = this.getTemplate();
        IAccountBean account = this.getAccount();
        this.connectTemplate(templateBean, account);
    }

    @Override
    public void connectTemplate(ITemplateBean templateBean, IAccountBean accountBean) {
        Stopwatch timer = new Stopwatch("[connectTemplate(user = " + accountBean.getName() + ")]");
        this.touch(false);
        IInstanceBean instanceBean = null;
        this.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_WAITING);
        this.setConnectedTemplate(templateBean);
        UserSessionManager.TemplateSessionLock lock = null;
        lock = templateLockHolder.createIfAbsent(templateBean.Id());
        lock.lock();
        try {
            instanceBean = UserSessionUtils.getAssignedInstance(accountBean, templateBean, ((UserSession)this.getDomain()).getConnectInstanceName());
            if (instanceBean == null) {
                instanceBean = UserSessionUtils.allocateInstance(accountBean, templateBean);
            }
            if (instanceBean != null) {
                this.setInstanceId(instanceBean.Id());
                this.setInstanceName(instanceBean.getName());
                this.enterStatus(UserSessionStatus.INSTANCE_ASSIGNED);
                this.setInstanceIP(instanceBean.getIpaddress());
                this.setTemplateId(templateBean.Id());
                this.setAccountId(accountBean.Id());
                if (templateBean.isSingleImage()) {
                    accountBean = accountBean.getUpdate().setLastInstanceId(instanceBean.Id());
                }
                accountBean.save();
            } else {
                this.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_FAILURE);
            }
        }
        finally {
            lock.unlock();
            timer.stop();
        }
    }

    @Override
    public void connectProcess(UserSessionToken token) {
        Stopwatch timer = new Stopwatch("[connectProcess(user = " + this.getAccountName() + ",status=" + (Object)((Object)this.getStatus()) + ")]");
        try {
            String curClientIP;
            boolean connected;
            if (UserSessionStatus.NEW_WAITING == this.getStatus() && !(connected = this.tryConnectTemplate())) {
                return;
            }
            String tokenClientIP = token.getClientIP();
            if (!tokenClientIP.equals(curClientIP = this.getClientIP())) {
                throw new JYServiceRuntimeException("usersession.clientIP.notmatch", "\u5e10\u6237\u5728\u5176\u5b83\u5730\u70b9\u767b\u5f55");
            }
            if (UserSessionStatus.INVALIDATE == this.getStatus()) {
                throw new JYServiceRuntimeException("usersession.invalidate", "\u8fde\u63a5\u5df2\u5931\u6548\u3002");
            }
            if (UserSessionStatus.GATEWAY_ALLOCATE_FAILED == this.getStatus()) {
                throw new JYServiceRuntimeException("usersession.gateway.allocateFailure", "\u7f51\u5173\u7533\u8bf7\u5931\u8d25\u3002");
            }
            if (UserSessionStatus.INSTANCE_ASSIGN_FAILURE == this.getStatus()) {
                return;
            }
            IInstanceBean instanceBean = (IInstanceBean)Services.getInstanceService().findOne(this.getInstanceId());
            if (instanceBean == null) {
                this.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_FAILURE);
                return;
            }
            ITemplateBean template = instanceBean.getTemplate();
            if (!instanceBean.hasVmParam("phase") && !instanceBean.inPrep() & (instanceBean.getStatus() == InstanceStatus.SHUTDOWN || instanceBean.getStatus() == InstanceStatus.STANDING && template.isSingleImage()) && !"yes".equalsIgnoreCase(Props.instance().get("admin.start", "no"))) {
                instanceBean.start();
            }
            if (instanceBean.getStatus() != InstanceStatus.RUNNING) {
                UserSessionLog.getLogger().info("session({},{}) : instance not running . ", (Object)this.getAccountName(), (Object)instanceBean.getName());
                return;
            }
            if (template.hasUserDisk()) {
                if (JieyunLicense.get().getFeature().userDisk()) {
                    String diskname = template.getUserDiskName(this.getAccount());
                    IUserDiskBean userdisk = Services.getUserDiskService().findByName(diskname);
                    if (userdisk == null) {
                        userdisk = Services.getUserDiskService().createUserDisk(diskname, this.getAccount(), template.getStoragePolicy(), instanceBean.getServer());
                        timer.record("create new userdisk " + userdisk.getName() + ",datastore=" + userdisk.getDatastore());
                    } else if (userdisk.isCreated() && userdisk.isMounted()) {
                        if (!instanceBean.Id().equals(userdisk.getInstanceId())) {
                            if (userdisk.getInstance() != null) {
                                timer.record(" userdisk has mounted by other instance [" + userdisk.getInstance().getName() + "]");
                            } else {
                                timer.record(" userdisk " + userdisk.asString() + "'s instance has been destroy! set userdisk to umounted.");
                                userdisk = userdisk.getUpdate().unmountFromVM();
                                userdisk.save();
                            }
                        } else {
                            timer.record(" userdisk " + userdisk.asString() + " already mounted");
                            if (!this.getAccountId().equals(userdisk.getAccountId())) {
                                timer.record(" update userdisk " + userdisk.asString() + " user id to " + this.getAccountId());
                                userdisk = userdisk.getUpdate().setAccountId(this.getAccountId());
                                userdisk.save();
                            }
                        }
                    }
                    if (!userdisk.isCreated() || !userdisk.isMounted()) {
                        timer.record(" attach userdisk " + userdisk.asString() + " to " + instanceBean.getName());
                        instanceBean.attachUserDisk(userdisk.Id());
                    }
                } else {
                    timer.record("No user disk License! user disk is not processed.");
                }
            }
            if (StringUtils.isBlank((CharSequence)instanceBean.getIpaddress())) {
                UserSessionLog.getLogger().info("session({},{}) : instance ip blank . ", (Object)this.getAccountName(), (Object)instanceBean.getName());
                return;
            }
            if (!instanceBean.alive()) {
                UserSessionLog.getLogger().info("session({},{}) : instance not alive . ", (Object)this.getAccountName(), (Object)instanceBean.getName());
                return;
            }
            try {
                if (this.getStatus() == UserSessionStatus.INSTANCE_ASSIGNED) {
                    this.setInstanceIP(instanceBean.getIpaddress());
                    new AllocateGatewayStatusHandler(this, instanceBean).handle();
                    if (this.getStatus() == UserSessionStatus.GATEWAY_ALLOCATED || this.getStatus() == UserSessionStatus.GATEWAY_PASSING) {
                        this.enterStatus(UserSessionStatus.RESOURCE_ALL_READY);
                    }
                }
                if (UserSessionStatus.RESOURCE_ALL_READY == this.getStatus()) {
                    IAccountBean account = this.getAccount();
                    if ("true".equals(token.getSgw())) {
                        this.setProtocol(Desktop.Protocol.SGW);
                    } else {
                        this.selectDesktopProtocol(template, account.getSetting());
                    }
                    if (((UserSession)this.getDomain()).getVmAccount() == null) {
                        ((UserSession)this.getDomain()).setVmAccount(account.getVmAccount(instanceBean.Id()));
                    }
                }
            }
            catch (Throwable t) {
                t.printStackTrace();
                UserSessionLog.getLogger().info("connectProcess Exception : {}", (Object)t.getMessage());
                return;
            }
        }
        finally {
            timer.stop();
            this.save();
        }
    }

    public void selectDesktopProtocol(ITemplateBean template, UserSetting setting) {
        Desktop.Protocol protocol = Desktop.Protocol.RDP;
        List<Desktop.Protocol> protocolList = template.getProtocols();
        if (protocolList != null && protocolList.size() > 0) {
            protocol = setting != null && setting.getProtocol() != null && protocolList.contains((Object)setting.getProtocol()) ? setting.getProtocol() : protocolList.get(0);
        } else if (setting != null && setting.getProtocol() != null) {
            protocol = setting.getProtocol();
        }
        this.setProtocol(protocol);
    }

    @Override
    public void setAccountId(Id id) {
        this.setIdParam("accountId", id);
    }

    public Id getTemplateId() {
        return this.getIdParam("templateId");
    }

    @Override
    public void setTemplateId(Id templateId) {
        this.setIdParam("templateId", templateId);
    }

    @Override
    public void setProtocol(Desktop.Protocol protocol) {
        LoggerFactory.getLogger(UserSessionBean.class).info("set Protocol to {}", (Object)protocol);
        this.setParam((Object)"protocol", (Object)protocol);
    }

    public Desktop.Protocol getProtocol() {
        return (Desktop.Protocol)((Object)this.getParam("protocol"));
    }

    public ITemplateBean getTemplate() {
        return (ITemplateBean)Services.getTemplateService().findOne(this.getTemplateId());
    }

    public IInstanceBean getInstance() {
        return (IInstanceBean)Services.getInstanceService().findOne(this.getInstanceId());
    }

    @Override
    public boolean tryConnectTemplate() {
        try {
            if (limitLock.reqDeny()) {
                this.enterStatus(UserSessionStatus.NEW_WAITING);
                this.save();
                return false;
            }
            this.connectTemplate();
            return true;
        }
        finally {
            limitLock.reqDecrement();
        }
    }

    @Override
    public ApiResult<SessionEntity> apiGet() {
        ApiResult<SessionEntity> result = new ApiResult<SessionEntity>();
        result.setEntity(this.sessionEntityBinding.bindingForEntity(new SessionEntity(), this));
        return result;
    }

    @Override
    public String getInstanceName() {
        return (String)this.getParam("instanceName");
    }

    @Override
    public void setInstanceName(String instanceName) {
        this.setParam((Object)"instanceName", instanceName);
    }

    @Override
    public DpClientType getClientType() {
        return (DpClientType)((Object)this.getParam("clientType"));
    }

    @Override
    public void setClientType(DpClientType clientType) {
        this.setParam((Object)"clientType", (Object)clientType);
    }

    @Override
    public long getTimeOut() {
        return (Long)this.getParam("timeOut");
    }

    @Override
    public void setTimeOut(long timeOut) {
        this.setParam((Object)"timeOut", timeOut);
    }

    @Override
    public void setTcId(String tcId) {
        this.setParam((Object)"tcId", tcId);
    }

    @Override
    public String getTcId() {
        return (String)this.getParam("tcId");
    }

    private static class LimitLock {
        private AtomicInteger createNumLock = new AtomicInteger(0);
        private int max;

        public LimitLock() {
            AppProps props = AppProps.instance();
            this.max = props.get("usersession.connect.limit", 50);
        }

        public int getCurrentNum() {
            return this.createNumLock.get();
        }

        public boolean reqDeny() {
            return this.createNumLock.incrementAndGet() > this.max;
        }

        public void reqDecrement() {
            this.createNumLock.decrementAndGet();
        }
    }

    public static class TemplateResourceHolder
    extends ConcurrentHashMap<Id, UserSessionManager.TemplateSessionLock> {
        public UserSessionManager.TemplateSessionLock createIfAbsent(Id id) {
            UserSessionManager.TemplateSessionLock lock = this.putIfAbsent(id, new UserSessionManager.TemplateSessionLock());
            if (lock == null) {
                lock = this.get(id);
            }
            return lock;
        }

        @Override
        public UserSessionManager.TemplateSessionLock get(Object key) {
            return (UserSessionManager.TemplateSessionLock)super.get(key);
        }
    }
}
