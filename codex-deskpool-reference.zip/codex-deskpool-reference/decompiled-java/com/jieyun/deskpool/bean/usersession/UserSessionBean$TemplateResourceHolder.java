/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionManager;
import com.jieyun.deskpool.shared.Id;
import java.util.concurrent.ConcurrentHashMap;

public static class UserSessionBean.TemplateResourceHolder
extends ConcurrentHashMap<Id, UserSessionManager.TemplateSessionLock> {
    public UserSessionManager.TemplateSessionLock createIfAbsent(Id id) {
        UserSessionManager.TemplateSessionLock lock = this.putIfAbsent(id, new UserSessionManager.TemplateSessionLock());
        if (lock == null) {
            lock = this.get(id);
        }
        return lock;
    }

    @Override
    public UserSessionManager.TemplateSessionLock get(Object key) {
        return (UserSessionManager.TemplateSessionLock)super.get(key);
    }
}
