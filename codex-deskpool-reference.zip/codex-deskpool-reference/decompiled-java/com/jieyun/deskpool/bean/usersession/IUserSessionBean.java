/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.usersession;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.SessionEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.ConnectStatus;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DpClientType;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.shared.UserSessionToken;

public interface IUserSessionBean
extends Bean<UserSession> {
    public Id getInstanceId();

    public IInstanceBean getAssignedInstance();

    public void setInstanceId(Id var1);

    public Id getAccountId();

    public String getClientIP();

    public UserSessionStatus getStatus();

    public String getInstanceIP();

    public String getInstanceName();

    public void setInstanceIP(String var1);

    public void setInstanceName(String var1);

    public String getAccountName();

    public void setAccountId(Id var1);

    public void enterStatus(UserSessionStatus var1);

    public IPortMappingBean getPortMapping();

    public void setPortMappingId(Id var1);

    public void touch(boolean var1);

    public ConnectStatus readConnectStatus(String var1);

    public boolean testTheSameSource(String var1);

    public boolean testValid();

    public int lastUpdatePeriod();

    public String getTemplateName();

    public boolean isLocal();

    public JYServiceRuntimeException getException();

    public void setException(JYServiceRuntimeException var1);

    public ITemplateBean getConnectedTemplate();

    public void setConnectedTemplate(ITemplateBean var1);

    public IServerBean getServer();

    public Update getUpdate();

    public DpClientType getClientType();

    public void setClientType(DpClientType var1);

    public void destroy();

    public void connectTemplate(ITemplateBean var1, IAccountBean var2);

    public void connectTemplate(UserSessionToken var1);

    public boolean tryConnectTemplate();

    public void setTemplateId(Id var1);

    public void connectProcess(UserSessionToken var1);

    public ApiResult<SessionEntity> apiGet();

    public void setProtocol(Desktop.Protocol var1);

    public long getTimeOut();

    public void setTimeOut(long var1);

    public Id getServerId();

    public void setTcId(String var1);

    public String getTcId();

    public static interface Update
    extends IUserSessionBean,
    Bean.Update<UserSession> {
        public void active(Id var1, String var2, String var3, String var4, String var5);

        public void end();

        public void close();
    }
}
