/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.usersession;

import com.deskpool.constant.DeskpoolConfigConstant;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.IUserDiskBean;
import com.jieyun.deskpool.domain.VmAccount;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.PrepState;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.shared.UserdbContext;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserSessionUtils {
    private static final Logger logger = LoggerFactory.getLogger(UserSessionUtils.class);

    public static boolean suffixMatch(String str, String suffix) {
        if (StringUtils.isBlank((CharSequence)str) || StringUtils.isBlank((CharSequence)suffix)) {
            return false;
        }
        int suffixlen = suffix.length();
        int strlen = str.length();
        if (strlen < suffixlen) {
            return false;
        }
        return str.substring(strlen - suffixlen, strlen).equals(suffix);
    }

    public static IInstanceBean findIdleInstance(List<IInstanceBean> instanceList, boolean isSingDeskpool) {
        for (IInstanceBean item : instanceList) {
            if (item.isAssigned() || !item.getStatus().equals((Object)InstanceStatus.RUNNING) && (!item.getStatus().equals((Object)InstanceStatus.STANDING) || !isSingDeskpool || item.hasVmParam("phase")) || !item.inPrepState(PrepState.Completed)) continue;
            return item;
        }
        return null;
    }

    public static IInstanceBean findOnholdInstance(List<IInstanceBean> instanceList) {
        for (IInstanceBean item : instanceList) {
            if (!item.isAssigned() || item.isSessionActive()) continue;
            return item;
        }
        return null;
    }

    public static IInstanceBean findIdleInstanceWithSuffix(List<IInstanceBean> instanceList, String suffix, boolean forceSuffixMatch) {
        UserSessionLog.getLogger().info("findIdleInstanceWithSuffix :" + suffix);
        ArrayList<IInstanceBean> vmlist = new ArrayList<IInstanceBean>();
        for (IInstanceBean item : instanceList) {
            if (item.isAssigned() || !item.getStatus().equals((Object)InstanceStatus.RUNNING) && !forceSuffixMatch || !item.inPrepState(PrepState.Completed) || !UserSessionUtils.suffixMatch(item.getName(), suffix)) continue;
            UserSessionLog.getLogger().info("findIdleInstanceWithSuffix : found " + item.getName());
            vmlist.add(item);
        }
        IInstanceBean result = null;
        for (IInstanceBean item : vmlist) {
            if (item.getName().length() >= (result == null ? 100 : result.getName().length())) continue;
            result = item;
        }
        UserSessionLog.getLogger().info("findIdleInstanceWithSuffix : return " + (result == null ? "null" : result.getName()));
        return result;
    }

    public static IInstanceBean findNumMatchInstance(List<IInstanceBean> instanceList, String username, boolean forceSuffixMatch) {
        if (!StringUtils.isBlank((CharSequence)username)) {
            int len = username.length();
            String suffix1 = username.substring(len - 1, len);
            String suffix2 = null;
            String suffix3 = null;
            if (username.length() > 1) {
                suffix2 = username.substring(len - 2, len);
            }
            if (username.length() > 2) {
                suffix3 = username.substring(len - 3, len);
            }
            Pattern pattern = Pattern.compile("[0-9]*");
            if (suffix3 != null && pattern.matcher(suffix3).matches()) {
                return UserSessionUtils.findIdleInstanceWithSuffix(instanceList, suffix3, forceSuffixMatch);
            }
            if (suffix2 != null && pattern.matcher(suffix2).matches()) {
                return UserSessionUtils.findIdleInstanceWithSuffix(instanceList, suffix2, forceSuffixMatch);
            }
            if (pattern.matcher(suffix1).matches()) {
                return UserSessionUtils.findIdleInstanceWithSuffix(instanceList, suffix1, forceSuffixMatch);
            }
        }
        return null;
    }

    public static IInstanceBean allocateInstance(IAccountBean account, ITemplateBean template) {
        Stopwatch timer = new Stopwatch("[allocateInstance2(user = " + account.getName() + ")]");
        Bean instance = null;
        boolean firstAllocated = false;
        if (instance == null) {
            firstAllocated = true;
            List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(template.Id());
            int vmCount = 0;
            IServerBean serverBean = null;
            ArrayList<IInstanceBean> onLineList = new ArrayList<IInstanceBean>();
            for (IInstanceBean item : instanceList) {
                if (item.isSessionActive()) {
                    ++vmCount;
                }
                if (!NodeStatus.ONLINE.equals((Object)(serverBean = item.getServer()).getNodeStatus())) continue;
                onLineList.add(item);
            }
            instanceList = onLineList;
            if (vmCount >= template.getPolicy().getMaximum()) {
                UserSessionLog.getLogger().info(" No available instance. current instance count {} out of Template's maxInstance {}", (Object)vmCount, (Object)template.getPolicy().getMaximum());
            } else {
                instance = UserSessionUtils.findNumMatchInstance(instanceList, account.getName(), template.isForceSuffixMatch());
                if (instance != null) {
                    timer.record("allocateInstance for  " + account.getName() + " findNumMatchInstance return :" + instance.getName());
                }
                if (instance == null) {
                    if (template.isForceSuffixMatch()) {
                        UserSessionLog.getLogger().info(" allocate instance failed. There are no Instance with suffix matched for {}.", (Object)account.getName());
                    } else {
                        instance = UserSessionUtils.findIdleInstance(instanceList, template.isSingleImage());
                        if (instance != null) {
                            timer.record("allocateInstance for  " + account.getName() + "findIdleInstance return :" + instance.getName());
                        }
                        if (instance == null && template.isReassignOnhold() && (instance = UserSessionUtils.findOnholdInstance(instanceList)) != null) {
                            timer.record("allocateInstance for  " + account.getName() + "findOnholdInstance return :" + instance.getName());
                        }
                    }
                }
            }
            if (instance == null) {
                UserSessionLog.getLogger().info(" Template {} No available instance. Check the resource of server.", (Object)template.getName());
            }
        }
        if (instance != null) {
            try {
                Services.getInstanceService().connect((IInstanceBean)instance, account, null, template.isReassignOnhold());
                if (firstAllocated && UserdbContext.getInstance().userdbIs(UserDB.DB) && template.isAutoFillBinding()) {
                    VmAccount vmAccount = new VmAccount();
                    vmAccount.setEnable(true);
                    vmAccount.setInstanceId(instance.Id().getId());
                    vmAccount.setUsername(template.getPolicy().getUsername());
                    account.bindVmAccount(vmAccount, template.getPolicy().getPassword());
                }
            }
            catch (JYServiceException e) {
                e.printStackTrace();
            }
        }
        timer.stop();
        return instance;
    }

    public static IInstanceBean getAssignedInstance(IAccountBean user, ITemplateBean template, String connectInstanceName) {
        IServerBean serverBean;
        IInstanceBean assignedInstance = null;
        List<IInstanceBean> allocatedInstance = Services.getInstanceService().findByUser(user.getName());
        for (IInstanceBean instance : allocatedInstance) {
            if (InstanceStatus.DESTROYED.equals((Object)instance.getStatus()) || !instance.getTemplateId().equals(template.Id()) || !StringUtils.isEmpty((CharSequence)connectInstanceName) && !StringUtils.equals((CharSequence)instance.getName(), (CharSequence)connectInstanceName)) continue;
            assignedInstance = instance;
        }
        if (PoolType.POOLED.equals((Object)template.getPoolType()) && DeskpoolConfigConstant.HACLUSTER && assignedInstance != null && (serverBean = assignedInstance.getServer()) != null && NodeStatus.OFFLINE.equals((Object)serverBean.getNodeStatus())) {
            IUserDiskBean userdisk = Services.getUserDiskService().findByInstanceId(assignedInstance.Id());
            if (userdisk != null) {
                logger.info("the userdisk[{}] remove instance [{}]", (Object)userdisk.getName(), (Object)assignedInstance.getName());
                userdisk = userdisk.getUpdate().unmountFromVM();
                userdisk.save();
            }
            logger.info("The instance [{}] will remove user[]", (Object)assignedInstance.getName(), (Object)user.getName());
            IInstanceBean.Update update = assignedInstance.getUpdate();
            update.setUser(null);
            update.setWaitGegenerate(true);
            update.save();
            assignedInstance = (IInstanceBean)update.refresh();
            if (StringUtils.isEmpty((CharSequence)assignedInstance.getUsername())) {
                return null;
            }
        }
        return assignedInstance;
    }
}
