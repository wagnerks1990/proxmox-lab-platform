/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.usersession;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.shared.Id;

public static interface IUserSessionBean.Update
extends IUserSessionBean,
Bean.Update<UserSession> {
    public void active(Id var1, String var2, String var3, String var4, String var5);

    public void end();

    public void close();
}
