/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.usersession;

import com.jieyun.deskpool.utils.AppProps;
import java.util.concurrent.atomic.AtomicInteger;

private static class UserSessionBean.LimitLock {
    private AtomicInteger createNumLock = new AtomicInteger(0);
    private int max;

    public UserSessionBean.LimitLock() {
        AppProps props = AppProps.instance();
        this.max = props.get("usersession.connect.limit", 50);
    }

    public int getCurrentNum() {
        return this.createNumLock.get();
    }

    public boolean reqDeny() {
        return this.createNumLock.incrementAndGet() > this.max;
    }

    public void reqDecrement() {
        this.createNumLock.decrementAndGet();
    }
}
