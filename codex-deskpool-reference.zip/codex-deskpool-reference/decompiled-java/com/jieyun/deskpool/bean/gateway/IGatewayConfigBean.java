/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.gateway;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.GatewayConfig;

public interface IGatewayConfigBean
extends Bean<GatewayConfig> {
    public void reconfig();

    public void reset();

    public boolean validateConfig();

    public String getGateWay();
}
