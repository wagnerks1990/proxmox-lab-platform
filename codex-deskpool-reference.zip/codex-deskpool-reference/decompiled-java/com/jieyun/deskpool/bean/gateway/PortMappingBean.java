/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.gateway;

import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.domain.PortMapping;

public class PortMappingBean
extends DefaultBean<PortMapping>
implements IPortMappingBean {
    @Override
    public void allocate() {
        GatewayManager.instance().send(new GatewayManager.AllocateMessage(this));
    }

    @Override
    public void release() {
        GatewayManager.instance().send(new GatewayManager.ReleaseMessage(this));
    }

    @Override
    public String getServiceName() {
        return "";
    }
}
