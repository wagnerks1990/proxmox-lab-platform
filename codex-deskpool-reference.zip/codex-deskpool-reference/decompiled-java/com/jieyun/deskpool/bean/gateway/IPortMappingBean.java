/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean.gateway;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.PortMapping;

public interface IPortMappingBean
extends Bean<PortMapping> {
    public void allocate();

    public void release();
}
