/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis.client.Stub
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean.gateway;

import com.jieyun.deskpool.bean.gateway.IGatewayConfigBean;
import com.jieyun.deskpool.domain.GatewayConfig;
import com.jieyun.deskpool.gateway.JygwLocator;
import com.jieyun.deskpool.gateway.JygwPortType;
import com.jieyun.deskpool.service.GatewayService;
import com.jieyun.deskpool.utils.SpringUtils;
import java.net.URL;
import org.apache.axis.client.Stub;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GatewayUtils {
    private static final Logger logger = LoggerFactory.getLogger(GatewayUtils.class);

    public static JygwPortType lookupClient() throws Exception {
        JygwLocator locator = new JygwLocator();
        URL url = new URL("http://" + ((GatewayConfig)((GatewayService)SpringUtils.context.getBean(GatewayService.class)).getDefault().getDomain()).getInternalIP() + ":12345/jygw");
        JygwPortType jygwPortType = locator.getjygw(url);
        Stub stub = (Stub)jygwPortType;
        stub.setTimeout(30000);
        return jygwPortType;
    }

    public static JygwPortType lookupClient(IGatewayConfigBean config) throws Exception {
        JygwLocator locator = new JygwLocator();
        URL url = new URL("http://" + ((GatewayConfig)config.getDomain()).getInternalIP() + ":12345/jygw");
        JygwPortType jygwPortType = locator.getjygw(url);
        Stub stub = (Stub)jygwPortType;
        stub.setTimeout(30000);
        return jygwPortType;
    }

    public static boolean isConnected() {
        return true;
    }
}
