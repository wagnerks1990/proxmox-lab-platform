/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.bean.gateway;

import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.gateway.IGatewayConfigBean;
import com.jieyun.deskpool.domain.GatewayConfig;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import org.apache.commons.lang.StringUtils;

public class GatewayConfigBean
extends DefaultBean<GatewayConfig>
implements IGatewayConfigBean {
    @Override
    public Bean<GatewayConfig> save() {
        Bean<GatewayConfig> b = super.save();
        Services.getGatewayService().reload();
        return b;
    }

    @Override
    public boolean validateConfig() {
        return !StringUtils.isBlank((String)((GatewayConfig)this.getDomain()).getInternalIP());
    }

    @Override
    public void reset() {
        try {
            GatewayManager.instance().reset(this);
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException("gateway.reset.failure", "\u91cd\u7f6e\u7f51\u5173\u5931\u8d25\u3002", e);
        }
    }

    @Override
    public void reconfig() {
        try {
            String externalIP = ((GatewayConfig)this.getDomain()).getInternalIP();
            StringUtils.isNotEmpty((String)externalIP);
            ((GatewayConfig)this.getDomain()).setExternalIP(externalIP);
            this.save();
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException("gateway.reconfig.failure", "", e);
        }
    }

    @Override
    public String getServiceName() {
        return "";
    }

    @Override
    public String getGateWay() {
        if (this.getDomain() != null) {
            return ((GatewayConfig)this.getDomain()).getInternalIP();
        }
        return null;
    }
}
