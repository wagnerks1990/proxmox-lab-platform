/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.NodeSignature;
import com.jieyun.deskpool.shared.Id;

public interface INodeSignatureBean
extends Bean<NodeSignature> {
    public String getSignature();

    public Id getClusterId();

    public Id getServerId();

    public Update getUpdate();

    public static interface Update
    extends INodeSignatureBean,
    Bean.Update<NodeSignature> {
        public Update setSignature(String var1);

        public Update setServerId(Id var1);

        public Update setCluster(Id var1);

        public Update init(Id var1, String var2, String var3, String var4);
    }
}
