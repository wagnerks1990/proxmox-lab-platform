/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IMessageBean;
import com.jieyun.deskpool.domain.Tracker;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.TrackerCategory;
import com.jieyun.deskpool.shared.TrackerLevel;
import com.jieyun.deskpool.shared.TrackerOperation;
import java.util.Date;
import java.util.List;

public interface ITrackerBean
extends Bean<Tracker> {
    public int getProgress();

    public boolean isDone();

    public String getServer();

    public ITrackerBean keepSilent();

    public ITrackerBean setDone(boolean var1);

    public List<IMessageBean> getMessages();

    public List<Id> getMessageIDs();

    public IMessageBean getMessage();

    public ITrackerBean setProgress(int var1);

    public ITrackerBean setServer(String var1);

    public String getName();

    public String getText();

    public Id getTargetid();

    public String getTargetclass();

    public Date getStarted();

    public Integer getEct();

    public Date getUpdated();

    public TrackerCategory getCategory();

    public TrackerOperation getOperation();

    public void setName(String var1);

    public void setTargetid(Id var1);

    public void setTargetclass(String var1);

    public void setStarted(Date var1);

    public void setEct(Integer var1);

    public void setUpdated(Date var1);

    public void setCategory(TrackerCategory var1);

    public void setOperation(TrackerOperation var1);

    public void setMessages(List<IMessageBean> var1);

    public void setMessageIDs(List<Id> var1);

    public void addMessage(IMessageBean var1);

    public void removeMessage(IMessageBean var1);

    public void clearMessages();

    public TrackerLevel getLevel();

    public void setLevel(TrackerLevel var1);

    public Update getUpdate();

    public void startFaulted(int var1, int var2);

    public void destroy();

    public void removeOverMessage(int var1);

    public static interface Update
    extends ITrackerBean,
    Bean.Update<Tracker> {
    }
}
