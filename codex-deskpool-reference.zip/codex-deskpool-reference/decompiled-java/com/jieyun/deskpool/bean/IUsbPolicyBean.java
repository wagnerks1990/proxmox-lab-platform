/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.UsbPolicy;
import com.jieyun.deskpool.shared.RedirectionPolicy;
import com.jieyun.deskpool.shared.UsbRedirectNamelistPolicy;
import com.jieyun.deskpool.shared.UsbRedirectPolicy;
import java.util.List;

public interface IUsbPolicyBean
extends Bean<UsbPolicy> {
    public String getContent();

    public String formatContent();

    public void setContent(String var1);

    public void addUsbRedirectPolicy(UsbRedirectPolicy var1);

    public List<UsbRedirectPolicy> getUsbRedirectPolicy();

    public boolean replaceUsbRedirectPolicy(UsbRedirectPolicy var1, UsbRedirectPolicy var2);

    public boolean removeUsbRedirectPolicy(UsbRedirectPolicy var1);

    public String getDriveRedirect();

    public void setDriveRedirect(String var1);

    public UsbRedirectNamelistPolicy getNamelistPolicy();

    public void replaceNamelistData(String var1);

    public String formatRdpContent();

    public String formatRdpContent(RedirectionPolicy var1);
}
