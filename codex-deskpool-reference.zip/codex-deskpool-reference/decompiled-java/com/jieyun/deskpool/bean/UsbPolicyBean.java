/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IUsbPolicyBean;
import com.jieyun.deskpool.bean.utils.UsbPolicyUtils;
import com.jieyun.deskpool.domain.UsbPolicy;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.RedirectionPolicy;
import com.jieyun.deskpool.shared.UsbRedirectNamelistPolicy;
import com.jieyun.deskpool.shared.UsbRedirectPolicy;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

public class UsbPolicyBean
extends DefaultBean<UsbPolicy>
implements IUsbPolicyBean {
    public static final String DRIVE_REDIRECT_DEFAULT = "*";

    @Override
    public String formatContent() {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        String value = this.format(list);
        return value;
    }

    @Override
    public String formatRdpContent(RedirectionPolicy redirectPolicy) {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        String value = this.format(list);
        if (redirectPolicy != null && !redirectPolicy.allowAllUsbClass()) {
            value = String.valueOf(value) + String.format(";denyclassid\\%s", redirectPolicy.getUsbClassDeny());
        }
        return value;
    }

    @Override
    public String formatRdpContent() {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        String value = this.format(list);
        return value;
    }

    @Override
    public String getContent() {
        String value = (String)this.getParam("content");
        return value;
    }

    @Override
    public void setContent(String content) {
        this.setParam((Object)"content", content);
    }

    @Override
    public String getDriveRedirect() {
        String drive = (String)this.getParam("driveRedirect");
        if (StringUtils.isBlank((CharSequence)drive)) {
            drive = DRIVE_REDIRECT_DEFAULT;
        }
        return drive;
    }

    @Override
    public void setDriveRedirect(String driveRedirect) {
        this.setParam((Object)"driveRedirect", driveRedirect);
    }

    @Override
    public void addUsbRedirectPolicy(UsbRedirectPolicy policy) {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        int index = list.indexOf(policy);
        if (index < 0) {
            list.add(policy);
        }
        this.persistUsbRedirect(list);
    }

    private String format(List<UsbRedirectPolicy> list) {
        StringBuilder buf = new StringBuilder();
        buf.append(DRIVE_REDIRECT_DEFAULT);
        for (UsbRedirectPolicy policy : list) {
            if (!policy.validate()) {
                throw new JYServiceRuntimeException("Usb\u91cd\u5b9a\u5411\u7b56\u7565\u683c\u5f0f\u9519\u8bef");
            }
            if (UsbPolicyUtils.isDeny(policy)) {
                System.out.println("deny usb " + policy.getVid() + ":" + policy.getPid());
                buf.append(String.format(";-USB\\VID_%s&PID_%s", StringUtils.substring((String)policy.getVid(), (int)2), StringUtils.substring((String)policy.getPid(), (int)2)));
                continue;
            }
            System.out.println("allow usb " + policy.getVid() + ":" + policy.getPid());
            buf.append(String.format(";USB\\VID_%s&PID_%s", StringUtils.substring((String)policy.getVid(), (int)2), StringUtils.substring((String)policy.getPid(), (int)2)));
        }
        return buf.toString().trim();
    }

    private void persistUsbRedirect(List<UsbRedirectPolicy> list) {
        StringBuilder buf = new StringBuilder();
        for (UsbRedirectPolicy policy : list) {
            if (!policy.validate()) {
                throw new JYServiceRuntimeException("Usb\u91cd\u5b9a\u5411\u7b56\u7565\u683c\u5f0f\u9519\u8bef");
            }
            buf.append(policy.asString()).append("\r\n");
        }
        System.out.println("Persist usbpolicy " + ((UsbPolicy)this.getDomain()).getName() + ": \n" + buf);
        this.setContent(buf.toString());
        this.save();
    }

    @Override
    public boolean replaceUsbRedirectPolicy(UsbRedirectPolicy srcPolicy, UsbRedirectPolicy newPolicy) {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        int index = list.indexOf(srcPolicy);
        if (index < 0) {
            return false;
        }
        UsbRedirectPolicy getPolicy = list.get(index);
        if (getPolicy != null) {
            getPolicy.setPid(newPolicy.getPid());
            getPolicy.setVid(newPolicy.getVid());
            getPolicy.setType(newPolicy.getType());
            this.persistUsbRedirect(list);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeUsbRedirectPolicy(UsbRedirectPolicy policy) {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        boolean successed = list.remove(policy);
        this.persistUsbRedirect(list);
        return successed;
    }

    @Override
    public List<UsbRedirectPolicy> getUsbRedirectPolicy() {
        String content = this.getContent();
        if (StringUtils.isBlank((CharSequence)content)) {
            return new ArrayList<UsbRedirectPolicy>();
        }
        String[] contentList = content.split("\r\n");
        ArrayList<UsbRedirectPolicy> policyList = new ArrayList<UsbRedirectPolicy>();
        String[] stringArray = contentList;
        int n = contentList.length;
        int n2 = 0;
        while (n2 < n) {
            UsbRedirectPolicy policy = new UsbRedirectPolicy();
            String rowStr = stringArray[n2];
            if (policy.initFromStr(rowStr)) {
                policyList.add(policy);
            }
            ++n2;
        }
        return policyList;
    }

    private boolean isNameListSetting() {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        if (list.isEmpty()) {
            return false;
        }
        UsbRedirectPolicy policy = list.get(0);
        return UsbPolicyUtils.isAllowNamelistStyle(policy) || UsbPolicyUtils.isDenyNamelistStyle(policy);
    }

    @Override
    public UsbRedirectNamelistPolicy getNamelistPolicy() {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        UsbRedirectNamelistPolicy strategy = null;
        if (list.isEmpty()) {
            return null;
        }
        strategy = new UsbRedirectNamelistPolicy();
        UsbRedirectPolicy policy = list.get(0);
        if (UsbPolicyUtils.isAllowNamelistStyle(policy)) {
            strategy.setType("1");
        } else if (UsbPolicyUtils.isDenyNamelistStyle(policy)) {
            strategy.setType("0");
        }
        return strategy;
    }

    @Override
    public void replaceNamelistData(String namelistType) {
        List<UsbRedirectPolicy> list = this.getUsbRedirectPolicy();
        UsbRedirectPolicy policy = null;
        if (this.isNameListSetting()) {
            policy = list.get(0);
        } else {
            policy = new UsbRedirectPolicy();
            list.add(0, policy);
        }
        policy.setPid("0xffff");
        policy.setVid("0xffff");
        if ("0".equals(namelistType)) {
            policy.setType("Deny");
        } else if ("1".equals(namelistType)) {
            policy.setType("Allow");
        }
        this.persistUsbRedirect(list);
    }

    @Override
    public String getServiceName() {
        return "usbPolicyService";
    }
}
