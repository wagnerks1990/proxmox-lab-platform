/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IMessageBean;
import com.jieyun.deskpool.domain.Message;

public static interface IMessageBean.Update
extends IMessageBean,
Bean.Update<Message> {
}
