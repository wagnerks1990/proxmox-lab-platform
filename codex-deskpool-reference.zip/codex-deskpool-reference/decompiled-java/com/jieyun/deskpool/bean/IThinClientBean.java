/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.ITCGroupBean;
import com.jieyun.deskpool.bean.IThinClientPatchBean;
import com.jieyun.deskpool.domain.ThinClient;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ThinClientCerStatus;
import com.jieyun.deskpool.shared.ThinClientStatus;
import java.util.Date;

public interface IThinClientBean
extends Bean<ThinClient> {
    public String getSn();

    public String getHostName();

    public ThinClientStatus getStatus();

    public Id getGroupId();

    public ITCGroupBean getTCGroup();

    public Date getExcuteTime();

    public String getTcGroupName();

    public String getMacAddr();

    public String getVersion();

    public Date getUpdateTime();

    public Update getUpdate();

    public String getIpAddr();

    public String getVncUrl();

    public String getDeviceType();

    public String getType();

    public void start();

    public void restart();

    public void shutdown();

    public void reset();

    public void sysUpdate(IThinClientPatchBean var1);

    public void deleteTCMCertificate();

    public void encryptKey(String var1);

    public ThinClientCerStatus getCerStatus();

    public static interface Update
    extends IThinClientBean,
    Bean.Update<ThinClient> {
        public Update setSn(String var1);

        public Update setHostName(String var1);

        public Update setStatus(ThinClientStatus var1);

        public Update setTcGroupId(Id var1);

        public Update setExcuteTime(Date var1);

        public Update setMacAddr(String var1);

        public Update setVersion(String var1);

        public Update setUpdateTime(Date var1);

        public Update setIpAddr(String var1);

        public Update setDeviceType(String var1);

        public Update enterStatus(ThinClientStatus var1);

        public Update setType(String var1);

        public Update setTcGroup(ITCGroupBean var1);

        public Update setCerStatus(ThinClientCerStatus var1);
    }
}
