/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateAppBean;
import com.jieyun.deskpool.domain.TemplateApp;
import com.jieyun.deskpool.shared.TemplateAppStatus;
import com.jieyun.deskpool.shared.TemplateAppType;
import com.jieyun.deskpool.shared.VirtualSystemSubType;
import java.util.Date;

public static interface ITemplateAppBean.Update
extends ITemplateAppBean,
Bean.Update<TemplateApp> {
    public ITemplateAppBean.Update setName(String var1);

    public ITemplateAppBean.Update setVersions(String var1);

    public ITemplateAppBean.Update setFileSize(Long var1);

    public ITemplateAppBean.Update setDownloadUrl(String var1);

    public ITemplateAppBean.Update setImgSize(String var1);

    public ITemplateAppBean.Update setGuestos(String var1);

    public ITemplateAppBean.Update setCreatetime(Date var1);

    public ITemplateAppBean.Update setServer(IServerBean var1);

    public ITemplateAppBean.Update setTemplateAppStatus(TemplateAppStatus var1);

    public ITemplateAppBean.Update setDescription(String var1);

    public ITemplateAppBean.Update bindImage(IImageBean var1);

    public ITemplateAppBean.Update setTemplateAppType(TemplateAppType var1);

    public ITemplateAppBean.Update setAgentver(String var1);

    public ITemplateAppBean.Update setMd5(String var1);

    public ITemplateAppBean.Update setProtocol(String var1);

    public ITemplateAppBean.Update setFileName(String var1);

    public ITemplateAppBean.Update setUsername(String var1);

    public ITemplateAppBean.Update setPassword(String var1);

    public ITemplateAppBean.Update setSubType(VirtualSystemSubType var1);
}
