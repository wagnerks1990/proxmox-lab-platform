/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IQuartJobBean;
import com.jieyun.deskpool.domain.QuartJob;
import java.util.Date;

public static interface IQuartJobBean.Update
extends IQuartJobBean,
Bean.Update<QuartJob> {
    public IQuartJobBean.Update setQuartScheduleId(long var1);

    public IQuartJobBean.Update setQuartClass(String var1);

    public IQuartJobBean.Update setCron(String var1);

    public IQuartJobBean.Update setJobName(String var1);

    public IQuartJobBean.Update setStartDate(Date var1);
}
