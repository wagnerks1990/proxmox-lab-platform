/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

public static enum PatchBean.Status {
    TMP,
    PATCHFILE_READY,
    CHECKIN,
    PREAPPLY,
    APPLYED;

}
