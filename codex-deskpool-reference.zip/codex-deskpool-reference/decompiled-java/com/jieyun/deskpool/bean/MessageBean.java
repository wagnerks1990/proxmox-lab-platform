/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IMessageBean;
import com.jieyun.deskpool.domain.Message;
import com.jieyun.deskpool.shared.MessageColor;
import com.jieyun.deskpool.shared.MessagePriority;
import java.util.Date;

public class MessageBean
extends DefaultBean<Message>
implements IMessageBean,
IMessageBean.Update {
    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public void setName(String name) {
        this.setParam((Object)"name", name);
    }

    @Override
    public String getMsgid() {
        return (String)this.getParam("msgid");
    }

    @Override
    public void setMsgid(String msgid) {
        this.setParam((Object)"msgid", msgid);
    }

    @Override
    public MessagePriority getPriority() {
        return (MessagePriority)((Object)this.getParam("priority"));
    }

    @Override
    public void setPriority(MessagePriority priority) {
        this.setParam((Object)"priority", (Object)priority);
    }

    @Override
    public MessageColor getColor() {
        return (MessageColor)((Object)this.getParam("color"));
    }

    @Override
    public void setColor(MessageColor color) {
        this.setParam((Object)"color", (Object)color);
    }

    @Override
    public Date getCreatetime() {
        return (Date)this.getParam("createtime");
    }

    @Override
    public void setCreatetime(Date createtime) {
        this.setParam((Object)"createtime", createtime);
    }

    @Override
    public String getServiceName() {
        return "messageService";
    }
}
