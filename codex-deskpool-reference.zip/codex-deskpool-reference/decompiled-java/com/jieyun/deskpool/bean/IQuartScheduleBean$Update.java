/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IQuartScheduleBean;
import com.jieyun.deskpool.domain.QuartSchedule;
import com.jieyun.deskpool.shared.Id;
import java.util.List;
import java.util.Set;

public static interface IQuartScheduleBean.Update
extends IQuartScheduleBean,
Bean.Update<QuartSchedule> {
    public IQuartScheduleBean.Update setQuartName(String var1);

    public IQuartScheduleBean.Update setRemark(String var1);

    public IQuartScheduleBean.Update setCycle(Set<String> var1);

    public IQuartScheduleBean.Update setExcuteCount(int var1);

    public IQuartScheduleBean.Update setTemplates(List<Id> var1);
}
