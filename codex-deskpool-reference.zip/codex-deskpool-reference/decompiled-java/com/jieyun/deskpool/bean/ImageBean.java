/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.ImageEntity;
import com.jieyun.deskpool.api.data.ImageEntityBinding;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IParcelBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IDeskpoolServerRemote;
import com.jieyun.deskpool.distributed.topo.DeskpoolAddress;
import com.jieyun.deskpool.distributed.topo.ServerRegistry;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.domain.Image;
import com.jieyun.deskpool.service.ImageService;
import com.jieyun.deskpool.service.InstanceService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.ImageInfo;
import com.jieyun.deskpool.shared.ImageStatus;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.ParcelStatus;
import com.jieyun.deskpool.shared.Portion;
import com.jieyun.deskpool.shared.SetupPhase;
import com.jieyun.deskpool.shared.SetupStep;
import com.jieyun.deskpool.shared.VirtualSystemSubType;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.manager.ImageManager;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;
import javax.naming.NamingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class ImageBean
extends DefaultBean<Image>
implements IImageBean,
IImageBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(ImageBean.class);
    @Autowired
    InstanceService instanceService;
    @Autowired
    ImageService imageService;
    @Autowired
    ImageEntityBinding imageEntityBinding;

    @Override
    public SetupPhase getSetupPhase() {
        return new SetupPhase(SetupPhase.SetupPhaseId.image, SetupStep.SetupStepId.image_import);
    }

    @Override
    public IInstanceBean getInstance() {
        return null;
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public String getDescription() {
        return (String)this.getParam("description");
    }

    @Override
    public Desktop.ImageMode getMode() {
        return (Desktop.ImageMode)((Object)this.getParam("mode"));
    }

    @Override
    public boolean isAutoInstallAgent() {
        return this.booleanValue(this.getParam("autoInstallAgent"));
    }

    @Override
    public IImageBean.Update setAutoInstallAgent(boolean autoInstallAgent) {
        this.setParam((Object)"autoInstallAgent", autoInstallAgent);
        return this;
    }

    @Override
    public ImageStatus getStatus() {
        return (ImageStatus)((Object)this.getParam("status"));
    }

    @Override
    public String getSourcevm() {
        return (String)this.getParam("sourcevm");
    }

    @Override
    public String getDraftvm() {
        return (String)this.getParam("draftvm");
    }

    @Override
    public IInstanceBean getDraftInstance() {
        String vmname = this.getDraftvm();
        if (vmname == null || "".equals(vmname)) {
            return null;
        }
        return this.instanceService.findByName(vmname);
    }

    @Override
    public IImageBean.Update clearDraftVm() {
        this.setDraftvm("");
        return this;
    }

    @Override
    public String getTargetvm() {
        return (String)this.getParam("targetvm");
    }

    @Override
    public IImageBean.Update setName(String name) {
        this.setParam("name", name, name.getClass());
        return this;
    }

    @Override
    public IImageBean.Update setDescription(String description) {
        this.setParam("description", description, description.getClass());
        return this;
    }

    @Override
    public IImageBean.Update setMode(Desktop.ImageMode mode) {
        this.setParam("mode", (Object)mode, ((Object)((Object)mode)).getClass());
        return this;
    }

    @Override
    public IImageBean.Update setStatus(ImageStatus status) {
        this.setParam("status", (Object)status, ((Object)((Object)status)).getClass());
        return this;
    }

    @Override
    public IImageBean.Update setSourcevm(String sourcevm) {
        this.setParam("sourcevm", sourcevm, sourcevm.getClass());
        return this;
    }

    @Override
    public IImageBean.Update setDraftvm(String draftvm) {
        this.setParam("draftvm", draftvm, draftvm.getClass());
        return this;
    }

    @Override
    public IImageBean.Update setTargetvm(String targetvm) {
        this.setParam("targetvm", targetvm, targetvm.getClass());
        return this;
    }

    @Override
    List<ErrorMessage> validate() {
        List<ErrorMessage> errList = super.validate();
        int count = this.imageService.countByNameIgnoreCase(this.getName());
        if (count > 0 && (this.isNew() || this.imageService.existName(this.getName(), this.Id()))) {
            errList.add(new ErrorMessage("error.bean.image.name.duplicated"));
        }
        return errList;
    }

    public IImageBean.Update setVersions(List versions) {
        this.setParam("versions", versions);
        return this;
    }

    @Override
    public List<String> getVersions() {
        return this.getParamList("versions", String.class);
    }

    @Override
    public String getVersion() {
        List<String> list = this.getVersions();
        if (list.isEmpty()) {
            return this.getName();
        }
        return list.get(0);
    }

    @Override
    public IImageBean.Update setImageInfo(ImageInfo imageinfo) {
        this.setParam((Object)"imageinfo", imageinfo);
        return this;
    }

    @Override
    public ImageInfo getImageInfo() {
        ImageInfo imageinfo = (ImageInfo)this.getParam("imageinfo");
        if (imageinfo == null) {
            imageinfo = new ImageInfo();
            imageinfo.setAgentversion("");
            if (this.isLinux()) {
                imageinfo.setGuestos("linux");
            } else {
                imageinfo.setGuestos("");
            }
            imageinfo.setImgsize("");
            imageinfo.setOrgunit("");
            imageinfo.setPrepmode("");
            imageinfo.setWindomain("");
        }
        return imageinfo;
    }

    @Override
    public String getUsername() {
        return (String)this.getParam("username");
    }

    @Override
    public IImageBean.Update setUsername(String username) {
        this.setParam((Object)"username", username);
        return this;
    }

    @Override
    public String getPassword() {
        return (String)this.getParam("password");
    }

    @Override
    public IImageBean.Update setPassword(String password) {
        this.setParam((Object)"password", password);
        return this;
    }

    @Override
    public List<ITemplateBean> getTemplates() {
        return Services.getTemplateService().findByImage(this.Id());
    }

    @Override
    public String newVersion() {
        List<String> list = this.getVersions();
        long time = new Date().getTime() / 1000L / 60L;
        String ver = this.getName() + "v" + Long.toHexString(time);
        while (list.contains(ver)) {
            time = new Date().getTime() / 1000L / 60L;
            ver = this.getName() + "v" + Long.toHexString(time);
        }
        return ver;
    }

    @Override
    public IImageBean.Update addVersion(String imagename) {
        List<String> list = this.getVersions();
        list.add(0, imagename);
        this.setVersions((List)list);
        return this;
    }

    @Override
    public void destroy() {
        List<ITemplateBean> list = Services.getTemplateService().findByImage(this.Id());
        if (list.size() > 0) {
            List<ErrorMessage> errList = super.validate();
            errList.add(new ErrorMessage("error.bean.image.referenced"));
            throw new JYServiceRuntimeException(errList);
        }
        if (this.hasParcelOnOffLineServer()) {
            List<ErrorMessage> errList = super.validate();
            errList.add(new ErrorMessage("error.image.destroy.server.offline.has.parcel"));
            throw new JYServiceRuntimeException(errList);
        }
        IInstanceBean draftInstance = this.getDraftInstance();
        if (draftInstance != null) {
            draftInstance.destroy();
            this.setDraftvm("");
        }
        if (!this.getStatus().equals((Object)ImageStatus.VERIFYING)) {
            ServerRegistry registry = ServerRegistry.instance();
            for (IServerBean server : Services.getServerService().findAll()) {
                if ((server = (IServerBean)server.refresh()).isOnline() && NodeStatus.ONLINE.equals((Object)server.getNodeStatus())) {
                    DeskpoolAddress address = registry.findAddress(server.Id());
                    try {
                        IDeskpoolServerRemote remote = (IDeskpoolServerRemote)RMIUtils.getRemoteProxy(address.getAddress(), "DeskpoolServerRemote");
                        remote.destroyParcel(this.Id());
                    }
                    catch (RemoteException | NamingException e) {
                        e.printStackTrace();
                    }
                    continue;
                }
                for (IParcelBean parcel : Services.getParcelService().getParcel(server.Id(), this.Id())) {
                    parcel.remove();
                }
            }
        }
        this.remove();
    }

    @Override
    public IImageBean.Update getUpdate() {
        return (IImageBean.Update)this.refresh();
    }

    @Override
    public boolean canLinkedCopy() {
        return !Config.Store.get().vmIs(Config.VM.Type.hyperv);
    }

    @Override
    public ApiResult<ImageEntity> apiGet() {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        result.setEntity(this.imageEntityBinding.bindingForEntity(new ImageEntity(), this));
        return result;
    }

    @Override
    public ApiResult<ImageEntity> apiDelete() {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        try {
            this.destroy();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getErrorList());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<ImageEntity> apiPut(ImageEntity entity) {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        try {
            IImageBean bean = this.imageEntityBinding.bindingForBean(entity, this);
            bean.save();
        }
        catch (JYServiceRuntimeException ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        catch (Exception ex) {
            result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public void prepareImage() {
        IInstanceBean instance = this.getDraftInstance();
        instance.vmPrepare();
    }

    @Override
    public void unPrepareImage() {
        IInstanceBean instance = this.getDraftInstance();
        instance.vmUnPrepare();
    }

    @Override
    public void saveImage() {
        IInstanceBean instance = this.getDraftInstance();
        ImageInfo imginfo = this.getImageInfo();
        imginfo.setModifytime(new Date());
        String disksize = (String)instance.getVmParam("disksize");
        String guestos = this.isLinux() ? "Linux" : (String)instance.getVmParam("guestos");
        String agentver = instance.getVmParam("agentversion", "");
        String remotefx = instance.getVmParam("remotefx", "no");
        imginfo.setAgentversion(agentver);
        imginfo.setImgsize(disksize);
        imginfo.setGuestos(guestos);
        imginfo.setProtocol("RDP");
        imginfo.setRemotefx("yes".equals(remotefx));
        IImageBean.Update image = this.getUpdate().setImageInfo(imginfo);
        image.save();
        if (image.getStatus().equals((Object)ImageStatus.INITIAL) || image.getStatus().equals((Object)ImageStatus.EDIT)) {
            image = image.getUpdate().setStatus(ImageStatus.SAVING);
            image.save();
            instance.templatize(image.Id());
        } else if (image.getStatus().equals((Object)ImageStatus.VERIFYING)) {
            instance.destroy();
            image = image.getUpdate().setStatus(ImageStatus.RELEASED).clearDraftVm();
            image.save();
        }
    }

    @Override
    public String getServiceName() {
        return "imageService";
    }

    @Override
    public IParcelBean getLocalParcel() {
        List<IParcelBean> list = Services.getParcelService().getParcel(Services.getServerService().getCurrent().Id(), this.Id(), this.getVersion());
        for (IParcelBean parcelBean : list) {
            if (!parcelBean.ready()) continue;
            return parcelBean;
        }
        return null;
    }

    @Override
    public boolean allHaveCurrentParcel() {
        List<IParcelBean> parcelList = Services.getParcelService().getParcel(this, Portion.WHOLE);
        List serverList = Services.getServerService().findAll();
        for (IServerBean serverBean : serverList) {
            for (IParcelBean bean : Services.getParcelService().filterByServer(parcelList, serverBean.Id())) {
                if (bean.ready() || bean.broken()) continue;
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean hasParcelOnOffLineServer() {
        for (IServerBean server : Services.getServerService().findAll()) {
            if ((server = (IServerBean)server.refresh()).isOnline() && !NodeStatus.OFFLINE.equals((Object)server.getNodeStatus()) || Services.getParcelService().getParcel(server.Id(), this.Id(), ParcelStatus.READY).size() <= 0) continue;
            return true;
        }
        return false;
    }

    @Override
    public boolean parcelIsStable() {
        for (IParcelBean parcel : Services.getParcelService().getLocalParcel(this.Id())) {
            if (parcel.isStatus(ParcelStatus.NEW, ParcelStatus.NOTSHIPPABLE, ParcelStatus.BROKEN, ParcelStatus.NOTUNPACKABLE) || parcel.ready()) continue;
            return false;
        }
        return true;
    }

    @Override
    public IImageBean.Update setLinux(boolean isLinux) {
        this.setParam((Object)"linuxOS", isLinux);
        return this;
    }

    @Override
    public boolean isLinux() {
        return (Boolean)this.getParam("linuxOS");
    }

    @Override
    public boolean back() {
        ImageManager imageManager = VMControlFactory.get(Config.Store.get()).getImageManager();
        imageManager.back(this);
        return true;
    }

    @Override
    public VirtualSystemSubType getSubType() {
        ImageInfo imgInfo = this.getImageInfo();
        if (imgInfo != null) {
            return VirtualSystemSubType.tryParse(imgInfo.getSubType());
        }
        return VirtualSystemSubType.unknowType;
    }
}
