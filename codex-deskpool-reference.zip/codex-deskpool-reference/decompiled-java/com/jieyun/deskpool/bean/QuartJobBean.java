/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IQuartJobBean;
import com.jieyun.deskpool.bean.IQuartScheduleBean;
import com.jieyun.deskpool.domain.QuartJob;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

public class QuartJobBean
extends DefaultBean<QuartJob>
implements IQuartJobBean,
IQuartJobBean.Update {
    private static final String QUART_CRON = "0 %s %s ? * %s";

    @Override
    public String getServiceName() {
        return "quartJobService";
    }

    @Override
    public IQuartJobBean.Update setQuartScheduleId(long quartScheduleId) {
        this.setParam((Object)"quartScheduleId", quartScheduleId);
        return this;
    }

    @Override
    public IQuartJobBean.Update setQuartClass(String quartClass) {
        this.setParam((Object)"quartClass", quartClass);
        return this;
    }

    @Override
    public IQuartJobBean.Update setCron(String cron) {
        this.setParam((Object)"cron", cron);
        return this;
    }

    @Override
    public IQuartJobBean.Update setJobName(String jobName) {
        this.setParam((Object)"jobName", jobName);
        return null;
    }

    @Override
    public long getQuartScheduleId() {
        return (Long)this.getParam("quartScheduleId");
    }

    @Override
    public String getQuartClass() {
        return (String)this.getParam("quartClass");
    }

    @Override
    public String getCron() {
        return (String)this.getParam("cron");
    }

    @Override
    public String getJobName() {
        return this.Id().toString();
    }

    @Override
    public IQuartJobBean.Update getUpdate() {
        return (IQuartJobBean.Update)this.refresh();
    }

    @Override
    public IQuartJobBean.Update setStartDate(Date startDate) {
        this.setParam((Object)"startDate", startDate);
        return this;
    }

    @Override
    public Date getStartDate() {
        return (Date)this.getParam("startDate");
    }

    @Override
    public String getQuartCron() {
        return null;
    }

    @Override
    public String getQuartGroup() {
        return "" + this.getQuartScheduleId();
    }

    @Override
    public String getQuartCron(String weeks) {
        Date startDate = this.getStartDate();
        if (startDate == null || StringUtils.isEmpty((CharSequence)weeks)) {
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        return String.format(QUART_CRON, calendar.get(12), calendar.get(11), weeks);
    }

    @Override
    public String syncJob() {
        return null;
    }

    @Override
    public void excute() {
        System.out.print("===============excute===========");
        System.out.print("==============excute============");
        System.out.print("==============excute============");
        System.out.print("==============excute============" + this.getQuartClass());
    }

    @Override
    public IQuartScheduleBean getQuartSchedule() {
        return (IQuartScheduleBean)Services.getQuartScheduleService().findOne(Id.construct(this.getQuartScheduleId()));
    }

    @Override
    public List<IInstanceBean> findInstance() {
        IQuartScheduleBean scheduleBean = this.getQuartSchedule();
        if (scheduleBean != null) {
            return scheduleBean.findInstance();
        }
        return new ArrayList<IInstanceBean>();
    }

    @Override
    public int getExcuteCount() {
        IQuartScheduleBean schedule = this.getQuartSchedule();
        if (schedule != null) {
            return schedule.getExcuteCount();
        }
        return 0;
    }
}
