/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.AbstractEntityObject;

public interface EntityApi<T extends AbstractEntityObject> {
    public ApiResult<T> apiGet();

    public ApiResult<T> apiPut(T var1);

    public ApiResult<T> apiDelete();
}
