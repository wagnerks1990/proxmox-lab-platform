/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.data.PoolEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IResource;
import com.jieyun.deskpool.domain.Template;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DeviceMapping;
import com.jieyun.deskpool.shared.IPPolicy;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.RfxAdaptor;
import com.jieyun.deskpool.shared.StoragePolicy;
import com.jieyun.deskpool.shared.TemplatePolicy;
import com.jieyun.deskpool.shared.TemplateStatus;
import com.jieyun.deskpool.shared.VMNetworkConfig;
import com.jieyun.deskpool.shared.VgpuType;
import java.util.List;

public interface ITemplateBean
extends Bean<Template>,
IResource {
    public Template getData();

    public void enforceSchedule();

    @Override
    public void postConstruct();

    public String getName();

    public String getDescription();

    public IImageBean getImage();

    public Id getImageId();

    public String getPrefix();

    public String getSuffix();

    public boolean isDefault();

    public Integer getMemory();

    public Integer getCores();

    public Integer getSockets();

    public DeviceMapping getDevicmap();

    public TemplatePolicy getPolicy();

    public PoolInfo getPoolInfo();

    public String getGuestos();

    public Update getUpdate();

    public PoolType getPoolType();

    public String getNetwork();

    public boolean isEnableVlanTag();

    public Integer getVlanid();

    public Desktop.ColorDepth getColorDepth();

    public RfxAdaptor getRfxAdaptor();

    public boolean isDedicated();

    public boolean isPooled();

    public boolean isPersistent();

    public boolean isDynamic();

    public boolean isFreshOnboot();

    public boolean isSequenceName();

    public boolean isReserveForUser();

    public boolean isEnableSchedule();

    public void destroy();

    public boolean isReassignOnhold();

    public boolean isFastGenerate();

    public boolean isAutoFillBinding();

    public boolean inStatus(TemplateStatus var1);

    public TemplateStatus getStatus();

    public boolean shouldCheckpint();

    public StoragePolicy getStoragePolicy();

    public boolean hasSecondDisk();

    public Integer getSecondDiskSize();

    public long getSecondDiskSizeMB();

    public boolean hasUserDisk();

    public Integer getUserDiskSize();

    public long getUserDiskSizeMB();

    public String getUserDiskSet();

    public String getSecondDiskName(IInstanceBean var1);

    public String getUserDiskName(IAccountBean var1);

    public ApiResult<PoolEntity> apiGet();

    public ApiResult<PoolEntity> apiPut(PoolEntity var1);

    public ApiResult<PoolEntity> apiDelete();

    public boolean updateStatus(List<IGroupBean> var1);

    public boolean updateStatus();

    public boolean isForceSuffixMatch();

    public List<Desktop.Protocol> getProtocols();

    public boolean isEnableGfxH264();

    public Desktop.SchedulingModel getSchedulingModel();

    public boolean isEnableModifyBinding();

    public boolean isSingleImage();

    public boolean isSpecified();

    public String getOu();

    public IPPolicy getIpPolicy();

    public int getVmIndex(String var1);

    public VMNetworkConfig getVMNetWorkConfig(String var1);

    public List<IInstanceBean> getInstance();

    public boolean isLinux();

    public boolean isDrift();

    public boolean isEnableSgw();

    public VgpuType getVgpu();

    public String getGpuDevice();

    public static interface Update
    extends ITemplateBean,
    Bean.Update<Template> {
        public Update setName(String var1);

        public Update setDescription(String var1);

        public Update setImage(IImageBean var1);

        public Update setPrefix(String var1);

        public Update setSuffix(String var1);

        public Update setDefault(boolean var1);

        public Update setMemory(Integer var1);

        public Update setCores(Integer var1);

        public Update setSockets(Integer var1);

        public Update setDevicmap(DeviceMapping var1);

        public Update setPolicy(TemplatePolicy var1);

        public Update setStoragePolicy(StoragePolicy var1);

        public Update setPoolInfo(PoolInfo var1);

        public Update setPoolType(PoolType var1);

        public Update setNetwork(String var1);

        public Update setEnableVlanTag(boolean var1);

        public Update setVlanid(Integer var1);

        public Update setColorDepth(Desktop.ColorDepth var1);

        public Update rebuildRetiredInstances(Id var1);

        public Update regenerateInstances();

        public void setRfxAdaptor(RfxAdaptor var1);

        public Update save();

        public Update setImageId(Id var1);

        public Update setProtocols(List<Desktop.Protocol> var1);

        public Update setEnableGfxH264(Boolean var1);

        public Update setIPPolicy(IPPolicy var1);

        public Update setEnableSgw(boolean var1);

        public Update setVgpu(VgpuType var1);

        public Update setGpuDevice(String var1);
    }
}
