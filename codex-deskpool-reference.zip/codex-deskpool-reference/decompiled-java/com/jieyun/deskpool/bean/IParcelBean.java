/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Parcel;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.Lineage;
import com.jieyun.deskpool.shared.ParcelStatus;
import com.jieyun.deskpool.shared.Portion;
import com.jieyun.deskpool.shared.VirtualSystemSubType;

public interface IParcelBean
extends Bean<Parcel> {
    @Override
    public String getServiceName();

    public String getName();

    public String getVMName();

    public Id getImageId();

    public IImageBean getImage();

    public Id getServerId();

    public IServerBean getServer();

    public Id getSourceId();

    public IServerBean getSource();

    public Portion getPortion();

    public boolean isDelta();

    public ParcelStatus getStatus();

    public Lineage getLineage();

    public String getVersion();

    public void pack();

    public void unpack();

    public void depack();

    public void ship();

    public void checkHealth();

    public boolean canReceive();

    public boolean home();

    public boolean broken();

    public boolean shipping();

    public VirtualSystemSubType getSubType();

    public Update getUpdate();

    public IParcelBean save();

    public IParcelBean fulfillLocal();

    public IParcelBean fulfill();

    public IParcelBean fulfill(IServerBean var1);

    public IParcelBean fulfill(IParcelBean var1, IServerBean var2);

    public IParcelBean fulfillWhole();

    public boolean ready();

    public boolean hasSameImageAndVersion(IParcelBean var1);

    public boolean isStatus(ParcelStatus ... var1);

    public void destroy();

    public boolean isLocal();

    public String newVMName();

    public String newName();

    public boolean isFailed();

    public boolean existsOnServer();

    public String getDumpfile();

    public static interface Update
    extends IParcelBean,
    Bean.Update<Parcel> {
        public Update setName(String var1);

        public Update setImageId(Id var1);

        public Update setServer(Id var1);

        public Update setSource(Id var1);

        public Update setPortion(Portion var1);

        public Update setStatus(ParcelStatus var1);

        public Update setLineage(Lineage var1);

        public Update setVersion(String var1);

        public Update initialize(IImageBean var1, Lineage var2, Id var3, String var4);

        public Update initialize(IImageBean var1, Lineage var2, String var3);

        public Update initialize(IImageBean var1, Portion var2, Lineage var3, Id var4, String var5);

        public Update initialize(IImageBean var1, Portion var2, Lineage var3, Id var4, String var5, String var6);

        public Update setVMName(String var1);

        public Update enterStatus(ParcelStatus var1);

        public Update setDumpfile(String var1);

        public Update setSubType(VirtualSystemSubType var1);
    }
}
