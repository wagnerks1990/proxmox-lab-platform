/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.domain.Groups;

public static interface IGroupBean.Update
extends IGroupBean,
Bean.Update<Groups> {
}
