/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.domain.UserDisk;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.StoragePolicy;
import com.jieyun.deskpool.shared.UserDiskOperation;
import java.util.List;

public interface IUserDiskBean
extends Bean<UserDisk> {
    public Update getUpdate();

    public String getName();

    public Id getAccountId();

    public IAccountBean getAccount();

    public Id getInstanceId();

    public IInstanceBean getInstance();

    public Desktop.UserDiskStatus getStatus();

    public StoragePolicy getPolicy();

    public String getDatastore();

    public boolean isCreated();

    public long getDiskSizeMB();

    public boolean isMounted();

    @Override
    public String asString();

    public void offline();

    public boolean create();

    public void resize(long var1);

    public void destroy(boolean var1);

    public Long getFilesize();

    public String getPath();

    public void updateInfo();

    public boolean isExisted();

    public List<UserDiskOperation> getDiskOperation();

    public String getPrefix();

    public String getDiskName();

    public String getDiskPath();

    public String getStorageType();

    public static interface Update
    extends IUserDiskBean,
    Bean.Update<UserDisk> {
        public Update setName(String var1);

        public Update setAccount(IAccountBean var1);

        public Update setAccountId(Id var1);

        public Update mountToVM(IInstanceBean var1);

        public Update unmountFromVM(IInstanceBean var1);

        public Update unmountFromVM();

        public Update setPolicy(StoragePolicy var1);

        public Update enterStatus(Desktop.UserDiskStatus var1);

        public Update setDatastore(String var1);

        public Update setCreated(boolean var1);

        public Update setFilesize(Long var1);

        public Update setPath(String var1);

        public Update setPrefix(String var1);

        public Update setStorageType(String var1);

        public Update init(String var1, IAccountBean var2, StoragePolicy var3, String var4);
    }
}
