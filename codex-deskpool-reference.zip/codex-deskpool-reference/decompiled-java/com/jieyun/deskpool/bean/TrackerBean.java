/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IMessageBean;
import com.jieyun.deskpool.bean.ITrackerBean;
import com.jieyun.deskpool.domain.Tracker;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.TrackerCategory;
import com.jieyun.deskpool.shared.TrackerLevel;
import com.jieyun.deskpool.shared.TrackerOperation;
import com.jieyun.deskpool.utils.LocalException;
import com.jieyun.deskpool.utils.MessageTemplate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrackerBean
extends DefaultBean<Tracker>
implements ITrackerBean,
ITrackerBean.Update {
    public static int MAX_MSG_PER_TRACKER = 100;
    private static final Logger logger = LoggerFactory.getLogger(TrackerBean.class);
    private boolean updateDate = true;

    public int getDurationSeconds() {
        Date now = new Date();
        return (int)(now.getTime() - this.getStarted().getTime()) / 1000;
    }

    @Override
    public int getProgress() {
        int progress = (Integer)this.getParam("progress", -1);
        if (this.getParam("progress") == null && this.getEct() != null) {
            progress = (int)Math.floor(100.0 * (1.0 - Math.exp((double)this.getDurationSeconds() * 1.0 / (double)(-this.getEct().intValue()))));
        }
        return progress;
    }

    @Override
    public String getServer() {
        return (String)this.getParam("server");
    }

    @Override
    public boolean isDone() {
        return (Boolean)this.getParam("done");
    }

    @Override
    public ITrackerBean.Update getUpdate() {
        return (ITrackerBean.Update)this.refresh();
    }

    @Override
    public List<IMessageBean> getMessages() {
        ArrayList<IMessageBean> beanList = new ArrayList<IMessageBean>();
        List<Id> idList = this.getMessageIDs();
        for (Id beanId : idList) {
            IMessageBean oneBean = (IMessageBean)Services.getMessageService().findOne(beanId);
            if (oneBean == null) continue;
            beanList.add(oneBean);
        }
        return beanList;
    }

    @Override
    public List<Id> getMessageIDs() {
        return this.getParamList("messages", Id.class);
    }

    @Override
    public IMessageBean getMessage() {
        ArrayList beanList = new ArrayList();
        List<Id> idList = this.getMessageIDs();
        if (idList.size() == 0) {
            return null;
        }
        Id beanId = idList.get(idList.size() - 1);
        IMessageBean oneBean = (IMessageBean)Services.getMessageService().findOne(beanId);
        return oneBean;
    }

    @Override
    public TrackerLevel getLevel() {
        return (TrackerLevel)((Object)this.getParam("level"));
    }

    @Override
    public ITrackerBean keepSilent() {
        this.updateDate = false;
        return this;
    }

    @Override
    public ITrackerBean setDone(boolean isDone) {
        this.setParam((Object)"done", isDone);
        return this;
    }

    @Override
    public ITrackerBean setProgress(int paramInt) {
        this.setParam((Object)"progress", paramInt);
        return this;
    }

    @Override
    public ITrackerBean setServer(String servername) {
        this.setParam((Object)"server", servername);
        return this;
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    private long getFaultMinutes() {
        return (this.getUpdated().getTime() - this.getStarted().getTime()) / 1000L / 60L;
    }

    @Override
    public String getText() {
        String text = null;
        if (this.getFaultCount() != null) {
            String msgid = "tracker.fault.times";
            MessageTemplate mt = MessageTemplate.get(msgid);
            if (mt == null) {
                String s = "No predefined message '" + msgid + "'";
                new LocalException(s).printStackTrace();
            }
            if (mt != null) {
                text = mt.format(new String[]{"$faultCount", this.getFaultCount().toString(), "$faultMinutes", String.valueOf(this.getFaultMinutes())});
            }
        }
        if (!StringUtils.isBlank(text)) {
            return this.getName() + text;
        }
        return this.getName();
    }

    @Override
    public Id getTargetid() {
        return Id.construct((Long)this.getParam("targetid"));
    }

    @Override
    public String getTargetclass() {
        return (String)this.getParam("targetclass");
    }

    @Override
    public Date getStarted() {
        return (Date)this.getParam("started");
    }

    @Override
    public Integer getEct() {
        return (Integer)this.getParam("ect");
    }

    @Override
    public Date getUpdated() {
        return (Date)this.getParam("updated");
    }

    private Integer getFaultCount() {
        return (Integer)this.getParam("faultCount");
    }

    private int getRenewSeconds() {
        return (Integer)this.getParam("renewSeconds");
    }

    private int getWaitSeconds() {
        return (Integer)this.getParam("waitSeconds");
    }

    @Override
    public TrackerCategory getCategory() {
        return (TrackerCategory)((Object)this.getParam("category"));
    }

    @Override
    public TrackerOperation getOperation() {
        return (TrackerOperation)((Object)this.getParam("operation"));
    }

    @Override
    public void setName(String name) {
        this.setParam("name", name, name.getClass());
    }

    @Override
    public void setTargetid(Id targetid) {
        this.setParam("targetid", targetid.getId(), Long.class);
    }

    @Override
    public void setTargetclass(String targetclass) {
        this.setParam("targetclass", targetclass, targetclass.getClass());
    }

    @Override
    public void setStarted(Date started) {
        this.setParam("started", started, started.getClass());
    }

    @Override
    public void setEct(Integer ect) {
        this.setParam("ect", ect, ect.getClass());
    }

    @Override
    public void setUpdated(Date updated) {
        this.setParam("updated", updated, updated.getClass());
    }

    @Override
    public void setCategory(TrackerCategory category) {
        this.setParam("category", (Object)category, ((Object)((Object)category)).getClass());
    }

    @Override
    public void setOperation(TrackerOperation operation) {
        this.setParam("operation", (Object)operation, ((Object)((Object)operation)).getClass());
    }

    @Override
    public void setLevel(TrackerLevel level) {
        this.setParam((Object)"level", (Object)level);
    }

    @Override
    public void setMessageIDs(List<Id> ids) {
        this.setParam("messages", ids);
    }

    private void setFaultCount(Integer faultCount) {
        this.setParam((Object)"faultCount", faultCount);
    }

    private void setRenewSeconds(int renewSeconds) {
        this.setParam((Object)"renewSeconds", renewSeconds);
    }

    private void setWaitSeconds(int waitSeconds) {
        this.setParam((Object)"waitSeconds", waitSeconds);
    }

    @Override
    public void setMessages(List<IMessageBean> messages) {
        ArrayList<Id> list = new ArrayList<Id>();
        for (IMessageBean item : messages) {
            list.add(item.Id());
        }
        this.setMessageIDs(list);
    }

    @Override
    public String asString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Tracker:[").append(this.getName()).append("]");
        sb.append(" target:").append(this.getTargetid());
        sb.append(" category:").append((Object)this.getCategory());
        sb.append(" operation:").append((Object)this.getOperation());
        sb.append(" progress:").append(this.getProgress());
        sb.append("\n");
        List<IMessageBean> messageList = this.getMessages();
        if (messageList == null) {
            return "Message is empty !";
        }
        for (IMessageBean msg : messageList) {
            sb.append("Message:").append(msg.getName()).append("\n");
        }
        return sb.toString();
    }

    @Override
    public void startFaulted(int renewSeconds, int waitSeconds) {
        if (this.getFaultCount() == null) {
            this.setFaultCount(1);
            this.setRenewSeconds(renewSeconds);
            this.setWaitSeconds(waitSeconds);
        }
    }

    @Override
    public void addMessage(IMessageBean message) {
        IMessageBean lastMessage;
        if (this.getFaultCount() != null && (lastMessage = this.getMessage()) != null) {
            if (lastMessage.getCreatetime().getTime() + (long)(1000 * this.getWaitSeconds()) > message.getCreatetime().getTime()) {
                return;
            }
            if (lastMessage.getCreatetime().getTime() + (long)(1000 * this.getRenewSeconds()) < message.getCreatetime().getTime()) {
                ITrackerBean trackerBean = (ITrackerBean)Services.getTrackerService().createOne();
                trackerBean.setCategory(this.getCategory());
                trackerBean.setOperation(this.getOperation());
                trackerBean.setName(this.getName());
                trackerBean.setServer(this.getServer());
                trackerBean.setTargetid(this.getTargetid());
                trackerBean.setTargetclass(this.getTargetclass());
                trackerBean.startFaulted(this.getRenewSeconds(), this.getWaitSeconds());
                trackerBean.save();
                this.setDone(true);
                this.keepSilent();
                return;
            }
            this.removeMessage(lastMessage);
            this.setFaultCount(this.getFaultCount() + 1);
        }
        if (this.getMessageIDs().size() > MAX_MSG_PER_TRACKER) {
            this.clearMessages();
            logger.error(" Tracker's message number is exceed the max.  [{}] ", (Object)this.getName());
        }
        if (message != null) {
            if (message.isNew()) {
                message.persist();
            }
        } else {
            throw new RuntimeException("TrackerBean.addMessage : message is Null");
        }
        this.addCollParamBean("messages", message.Id());
    }

    @Override
    public void removeMessage(IMessageBean message) {
        if (message != null) {
            this.removeCollParamBean("messages", message.Id());
        }
        message.remove();
    }

    @Override
    public void clearMessages() {
        List<IMessageBean> msgList = this.getMessages();
        for (IMessageBean msg : msgList) {
            this.removeMessage(msg);
        }
    }

    @Override
    public void persist() {
        if (this.updateDate) {
            this.setUpdated(new Date());
        }
        super.persist();
    }

    @Override
    public void merge() {
        if (this.updateDate) {
            this.setUpdated(new Date());
        }
        super.merge();
    }

    @Override
    public void destroy() {
        this.clearMessages();
        this.remove();
    }

    @Override
    public String getServiceName() {
        return "trackerService";
    }

    @Override
    public void removeOverMessage(int limitMessage) {
        if (limitMessage <= 0) {
            return;
        }
        IMessageBean message = null;
        List<Id> idList = this.getMessageIDs();
        int i = 0;
        int size = idList.size();
        while (i <= size - limitMessage) {
            message = (IMessageBean)Services.getMessageService().findOne(idList.get(i));
            if (message != null) {
                this.removeMessage(message);
            }
            ++i;
        }
    }
}
