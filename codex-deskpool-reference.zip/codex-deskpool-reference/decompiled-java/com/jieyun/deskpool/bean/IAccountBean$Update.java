/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.domain.Account;
import com.jieyun.deskpool.shared.Id;

public static interface IAccountBean.Update
extends IAccountBean,
Bean.Update<Account> {
    public IAccountBean.Update setLastInstanceId(Id var1);
}
