/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.ImageDuplicate;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ImageStatus;
import java.util.List;

public interface IImageDuplicateBean
extends Bean<ImageDuplicate> {
    public String getName();

    public Id getImageId();

    public IImageBean getImage();

    public Id getServerId();

    public IServerBean getServerBean();

    public ImageStatus getStatus();

    public List<String> getVersions();

    public String getVersion();

    public static interface Update
    extends IImageDuplicateBean,
    Bean.Update<ImageDuplicate> {
        public Update setName(String var1);

        public Update addVersion(String var1);

        public Update enterStatus(ImageStatus var1);

        public void Init(IImageBean var1, IServerBean var2);
    }
}
