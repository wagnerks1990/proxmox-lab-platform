/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IThinClientCertificateBean;
import com.jieyun.deskpool.domain.ThinClientCertificate;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.utils.DpThinClientCertificateUtils;
import java.util.Date;

public class ThinClientCertificateBean
extends DefaultBean<ThinClientCertificate>
implements IThinClientCertificateBean,
IThinClientCertificateBean.update {
    @Override
    public String getServiceName() {
        return "thinClientCertificateService";
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public Date getCreateTime() {
        return (Date)this.getParam("createTime");
    }

    @Override
    public String getFileUuid() {
        return (String)this.getParam("fileUuid");
    }

    @Override
    public IThinClientCertificateBean.update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public IThinClientCertificateBean.update setCreateTime(Date createTime) {
        this.setParam((Object)"createTime", createTime);
        return this;
    }

    @Override
    public IThinClientCertificateBean.update setFileUuid(String fileUuid) {
        this.setParam((Object)"fileUuid", fileUuid);
        return this;
    }

    @Override
    public IThinClientCertificateBean.update getUpdate() {
        return (IThinClientCertificateBean.update)this.refresh();
    }

    @Override
    public void delete() {
        DpThinClientCertificateUtils.delete(this.getFileUuid());
        this.remove();
    }

    @Override
    public void create() {
        String fileUuid = Id.construct().toSerializeId();
        this.setFileUuid(fileUuid);
        DpThinClientCertificateUtils.createKeyPair(fileUuid);
        this.save();
    }

    @Override
    public IThinClientCertificateBean.update setRemark(String remark) {
        this.setParam((Object)"remark", remark);
        return this;
    }

    @Override
    public String getRemark() {
        return (String)this.getParam("remark");
    }

    @Override
    public String getFileDir() {
        return DpThinClientCertificateUtils.getPath(this.getFileUuid());
    }

    @Override
    public IThinClientCertificateBean.update setEnable(boolean enable) {
        this.setParam((Object)"enable", enable);
        return this;
    }

    @Override
    public boolean isEnable() {
        return (Boolean)this.getParam("enable");
    }
}
