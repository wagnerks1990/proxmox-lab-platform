/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;

public static interface Bean.Update<W>
extends Bean<W> {
}
