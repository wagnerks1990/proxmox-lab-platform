/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Cluster;
import com.jieyun.deskpool.domain.SgwServerConfig;
import com.jieyun.deskpool.domain.SystemConfig;
import com.jieyun.deskpool.shared.LicenseStatus;
import com.jieyun.deskpool.shared.UserDB;
import java.util.Date;
import java.util.List;
import java.util.Map;

public interface IClusterBean
extends Bean<Cluster> {
    public String getName();

    public UserDB getUserdb();

    public String getLdap_domain();

    public String getLdap_user();

    public String getLdap_password();

    public String getLdap_address();

    public String getLdap_netbios_domain();

    public void setLdap_netbios_domain(String var1);

    public void setName(String var1);

    public void setUserdb(UserDB var1);

    public void setLdap_domain(String var1);

    public void setLdap_user(String var1);

    public void setLdap_password(String var1);

    public void setLdap_address(String var1);

    public IClusterBean setCreateTime(Date var1);

    public LicenseStatus getLicenseStatus();

    public Update getUpdate();

    public Date getCreateTime();

    public String getFloatIp();

    public String getClusterLicense();

    public SystemConfig getSysConfig();

    public void setLdapIps(List<String> var1);

    public List<String> getLdapIps();

    public String getImageRepositoryAddr();

    public String getDefaultImageRepositoryAddr();

    public List<String> getImageRepositoryAddrList();

    public Map<String, String> getImageRepositoryMaps();

    public List<String> getImageRepositoryAddrFromAppProps();

    public String getDefaultImageRepositoryDr();

    public IServerBean getTemplateAPPServer();

    public SgwServerConfig getSgwServerConfig();

    public boolean isOpenSgws();

    public static interface Update
    extends IClusterBean,
    Bean.Update<Cluster> {
        public Update enterLicenseStatus(LicenseStatus var1);

        public Update updateFloatIp(String var1);

        public Update setClusterLicense(String var1);

        public Update setSysConfig(SystemConfig var1);

        public Update setImageResponsitoryAddr(String var1);

        public Update setImageResponsitoryAddrList(List<String> var1);

        public Update setTemplateAPPServerId(IServerBean var1);

        public Update setSgwsConfig(SgwServerConfig var1);

        public Update enableSgws();

        public Update disableSgws();
    }
}
