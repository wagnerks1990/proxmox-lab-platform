/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.utils.VmAccountPasswordUtils;
import com.jieyun.deskpool.distributed.agent.SystemStatusObject;
import com.jieyun.deskpool.service.AccountService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.SetupService;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.web.security.EncryptUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdminAccountBean {
    private static final Logger logger = LoggerFactory.getLogger(AdminAccountBean.class);
    private String username;
    private String password;

    public static boolean localAdminExisted() {
        Props props = Props.instance();
        String username = props.get("account.admin.username");
        return username != null && !"".equals(username);
    }

    public static AdminAccountBean settingLocalAdmin() {
        AdminAccountBean account = new AdminAccountBean();
        account.setUsername("admin");
        String defaultAdminPassword = AppProps.instance().get("admin.password", "deskpool");
        logger.info("settingLocalAdmin :" + defaultAdminPassword);
        account.updatePassword(defaultAdminPassword);
        account.save();
        return account;
    }

    public static void changePassword(String oldPassword, String newPassword) {
        if (SystemStatusObject.instance().isStoreActive()) {
            AccountService accountService = Services.getAccountService();
            IAccountBean accountBean = accountService.findByName("admin");
            if (accountBean != null) {
                if (!EncryptUtils.match(oldPassword, accountBean.getPassword())) {
                    throw new JYServiceRuntimeException("admin.oldpassword.invalid");
                }
                accountBean.setPassword(EncryptUtils.encrypt(newPassword));
                accountBean.save();
            }
        } else {
            AdminAccountBean bean = AdminAccountBean.get();
            if (bean != null) {
                bean.updatePassword(newPassword);
                bean.save();
            }
        }
    }

    public static void settingClusterAdmin() {
        SetupService setupService = Services.getSetupService();
        if (!setupService.isSetupAdmin()) {
            setupService.setupAdmin();
        }
    }

    public static AdminAccountBean get() {
        if (!AdminAccountBean.localAdminExisted()) {
            return null;
        }
        AdminAccountBean account = new AdminAccountBean();
        Props props = Props.instance();
        String username = props.get("account.admin.username");
        String password = props.get("account.admin.password");
        account.username = username;
        account.password = password;
        return account;
    }

    public boolean matchPassword(String password) {
        return this.getPassword().equals(VmAccountPasswordUtils.encode(password));
    }

    public void updatePassword(String rawPassword) {
        this.password = VmAccountPasswordUtils.encode(rawPassword);
    }

    public void save() {
        Props props = Props.instance();
        props.set("account.admin.username", this.username);
        props.set("account.admin.password", this.password);
        props.store();
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
