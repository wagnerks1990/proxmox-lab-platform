/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IParcelBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.distributed.rpc.DispatchPoint;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.domain.Parcel;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.Lineage;
import com.jieyun.deskpool.shared.ParcelStatus;
import com.jieyun.deskpool.shared.Portion;
import com.jieyun.deskpool.shared.VirtualSystemSubType;
import com.jieyun.deskpool.utils.DpStringUtils;
import com.jieyun.deskpool.vm.Stopwatch;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.manager.ImageManager;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

public class ParcelBean
extends DefaultBean<Parcel>
implements IParcelBean,
IParcelBean.Update {
    @Override
    public String getServiceName() {
        return "parcelService";
    }

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public IParcelBean.Update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public Id getImageId() {
        Long beanId = (Long)this.getParam("image");
        return Id.construct(beanId);
    }

    @Override
    public IImageBean getImage() {
        return this.getImageId() == null ? null : Services.getImageService().findOne(this.getImageId());
    }

    @Override
    public IParcelBean.Update setImageId(Id imageId) {
        this.setIdParam("image", imageId);
        return this;
    }

    @Override
    public Id getServerId() {
        Long beanId = (Long)this.getParam("server");
        return Id.construct(beanId);
    }

    @Override
    public IParcelBean.Update setServer(Id serverId) {
        this.setIdParam("server", serverId);
        return this;
    }

    @Override
    public Id getSourceId() {
        Long beanId = (Long)this.getParam("source");
        return Id.construct(beanId);
    }

    @Override
    public IParcelBean.Update setSource(Id sourceId) {
        this.setIdParam("source", sourceId);
        return this;
    }

    @Override
    public Portion getPortion() {
        return (Portion)((Object)this.getParam("portion"));
    }

    @Override
    public IParcelBean.Update setPortion(Portion portion) {
        this.setParam((Object)"portion", (Object)portion);
        return this;
    }

    @Override
    public ParcelStatus getStatus() {
        return (ParcelStatus)((Object)this.getParam("status"));
    }

    @Override
    public IParcelBean.Update setStatus(ParcelStatus status) {
        this.setParam((Object)"status", (Object)status);
        return this;
    }

    @Override
    public Lineage getLineage() {
        return (Lineage)this.getParam("lineage");
    }

    @Override
    public IParcelBean.Update setLineage(Lineage lineage) {
        this.setParam((Object)"lineage", lineage);
        return this;
    }

    @Override
    public String getVersion() {
        return (String)this.getParam("version");
    }

    @Override
    public IParcelBean.Update setVersion(String version) {
        this.setParam((Object)"version", version);
        return this;
    }

    @Override
    public void pack() {
        VMControlFactory.get().getController().pack(this);
    }

    @Override
    public void unpack() {
        VMControlFactory.get().getController().unpack(this);
    }

    @Override
    public void depack() {
        VMControlFactory.get().getController().depack(this);
        this.getUpdate().enterStatus(ParcelStatus.READY);
    }

    @Override
    public void ship() {
        if (this.canReceive()) {
            VMControlFactory.get().getController().ship(this, null);
        }
    }

    @Override
    public void checkHealth() {
        if (this.ready() || this.broken()) {
            VMControlFactory.get().getController().checkHealth(this);
        }
    }

    @Override
    public boolean canReceive() {
        return VMControlFactory.get().getController().canReceive(this);
    }

    @Override
    public boolean home() {
        return true;
    }

    @Override
    public boolean isDelta() {
        return Portion.DELTA.equals((Object)this.getPortion());
    }

    @Override
    public boolean broken() {
        return this.isStatus(ParcelStatus.BROKEN);
    }

    @Override
    public boolean shipping() {
        return this.isStatus(ParcelStatus.SHIPPING, ParcelStatus.SHIPPED, ParcelStatus.UNPACKING, ParcelStatus.UNPACKED);
    }

    @Override
    public IParcelBean.Update getUpdate() {
        this.lock();
        return (IParcelBean.Update)this.refresh();
    }

    @Override
    public IParcelBean.Update save() {
        super.save();
        return this;
    }

    @Override
    public IParcelBean fulfillLocal() {
        return this.fulfill(this, Services.getServerService().getCurrent());
    }

    @Override
    public IParcelBean fulfill() {
        return this.fulfill(this, Services.getServerService().getCurrent());
    }

    @Override
    public IParcelBean fulfillWhole() {
        Stopwatch timer = new Stopwatch("[Parcel.Handler.fulfillWhole(" + this + ")]");
        IParcelBean.Update parcel = null;
        if (this.isDelta()) {
            IParcelBean.Update update = ((IParcelBean)Services.getParcelService().createOne()).getUpdate();
            update.setImageId(this.getImageId());
            update.setImageId(this.getImageId());
            update.setServer(this.getServerId());
            update.setVersion(this.getVersion());
            update.setVMName(this.newVMName());
            update.setName(this.newName());
            update.setPortion(Portion.WHOLE);
            update.setStatus(ParcelStatus.READY);
            parcel = this.save();
        }
        timer.stop("" + parcel);
        return parcel;
    }

    @Override
    public boolean ready() {
        return this.isStatus(ParcelStatus.READY, ParcelStatus.PACKING, ParcelStatus.PACKED, ParcelStatus.NOTPACKABLE);
    }

    @Override
    public IParcelBean fulfill(IParcelBean parcel, IServerBean server) {
        Stopwatch timer = new Stopwatch("ParcelBean.fulfill(" + parcel + "," + server + ")]");
        try {
            List<IParcelBean> portioned;
            List<IParcelBean> parcelList = Services.getParcelService().getParcel(server.Id(), parcel.getImageId(), parcel.getVersion());
            IParcelBean parcelBean = null;
            StringBuilder sb = new StringBuilder();
            sb.append("find parcelList=[" + parcelList.size() + "] by serverId\uff1a");
            sb.append(server.Id() + ",ImageId:" + parcel.getImageId());
            sb.append("version:" + parcel.getVersion());
            timer.record(sb.toString());
            if (parcelList.size() > 1 && !(portioned = Services.getParcelService().filterParcelList(parcelList, parcel.getPortion())).isEmpty()) {
                parcelList = portioned;
            }
            if (!parcelList.isEmpty()) {
                parcelBean = parcelList.get(0);
                timer.record("fulfill found existing [ParcelBean={" + parcel + "}]");
            }
            if (parcelBean == null) {
                timer.record("fulfill not found,the parcale [ParcelBean={" + parcel + "}] will create!");
                IParcelBean.Update update = Services.getParcelService().create(server, parcel.getImageId(), parcel.getVersion());
                update.setImageId(parcel.getImageId());
                update.setServer(server.Id());
                update.setVersion(parcel.getVersion());
                update.setVMName(this.newVMName());
                update.setName(this.newName());
                update.setStatus(ParcelStatus.NEW);
                if (update.isDelta()) {
                    IParcelBean parentParcel;
                    if (parcel.getLineage() != null && (parentParcel = Services.getParcelService().getAny(server.Id(), Id.construct(parcel.getLineage().getParent()), parcel.getLineage().getParentVersion())) != null && parentParcel.ready()) {
                        update.setPortion(Portion.DELTA);
                        update.setLineage(parcel.getLineage());
                    }
                } else {
                    update.setPortion(Portion.WHOLE);
                }
                update.save();
                parcelBean = update;
            }
            timer.stop("parcelBean=[" + parcelBean + "]");
            IParcelBean iParcelBean = parcelBean;
            return iParcelBean;
        }
        finally {
            timer.stop();
        }
    }

    @Override
    public boolean hasSameImageAndVersion(IParcelBean parcelBean) {
        return parcelBean.getImage() != null && this.getImageId().equals(parcelBean.getImageId()) && this.getVersion() != null && parcelBean.getVersion().equals(this.getVersion());
    }

    @Override
    public IServerBean getServer() {
        return this.getServerId() == null ? null : Services.getServerService().findOne(this.getServerId());
    }

    @Override
    public boolean isStatus(ParcelStatus ... pStatus) {
        if (pStatus == null) {
            return false;
        }
        ParcelStatus[] parcelStatusArray = pStatus;
        int n = pStatus.length;
        int n2 = 0;
        while (n2 < n) {
            ParcelStatus status = parcelStatusArray[n2];
            if (status.equals((Object)this.getStatus())) {
                return true;
            }
            ++n2;
        }
        return false;
    }

    @Override
    public IParcelBean fulfill(IServerBean server) {
        return this.fulfill(this, server);
    }

    @Override
    public IServerBean getSource() {
        return this.getSourceId() == null ? null : Services.getServerService().findOne(this.getSourceId());
    }

    @Override
    @DispatchPoint
    public void destroy() {
        ImageManager imageManager = VMControlFactory.get(Config.Store.get()).getImageManager();
        imageManager.destroyParcel(this);
        this.remove();
    }

    @Override
    public IParcelBean.Update initialize(IImageBean image, Lineage lineage, String vname) {
        return this.initialize(image, Portion.WHOLE, null, null, vname);
    }

    @Override
    public IParcelBean.Update initialize(IImageBean image, Lineage lineage, Id serverId, String vname) {
        return this.initialize(image, Portion.WHOLE, null, serverId, vname);
    }

    @Override
    public IParcelBean.Update initialize(IImageBean image, Portion portion, Lineage lineage, Id serverId, String vname) {
        return this.initialize(image, portion, lineage, serverId, null, vname);
    }

    @Override
    public IParcelBean.Update enterStatus(ParcelStatus status) {
        this.setStatus(status);
        this.save();
        return this;
    }

    @Override
    public boolean isLocal() {
        return this.getServerId().equals(Services.getServerService().getCurrent().Id());
    }

    @Override
    public IParcelBean.Update setVMName(String vmName) {
        this.setParam((Object)"vmname", vmName);
        return this;
    }

    @Override
    public String getVMName() {
        return (String)this.getParam("vmname");
    }

    @Override
    public String newVMName() {
        Config.VM vm = Config.Store.get().vm();
        if (StringUtils.equals((CharSequence)vm.type().name(), (CharSequence)"vmware")) {
            int parcelCount = Services.getParcelService().getParcel(this.getImageId(), this.getVersion()).size();
            String newVmName = String.format("%sc%s", this.getVersion(), DpStringUtils.getRandomStr(3).toLowerCase(), parcelCount);
            IServerBean serverBean = Services.getServerService().getCurrent();
            while (Services.getParcelService().coutParcelByVMName(newVmName) > 0 || serverBean.vmExists(newVmName)) {
                parcelCount = Services.getParcelService().getParcel(this.getImageId(), this.getVersion()).size();
                newVmName = String.format("%sc%s", this.getVersion(), DpStringUtils.getRandomStr(3).toLowerCase(), parcelCount);
            }
            return newVmName;
        }
        return this.getVersion();
    }

    @Override
    public String newName() {
        IServerBean serverBean = Services.getServerService().findOne(this.getServerId());
        return String.format("%s_on_%s", this.getVersion(), serverBean == null ? "" : serverBean.getName());
    }

    @Override
    public String toString() {
        IServerBean server = this.getServer();
        StringBuffer sb = new StringBuffer();
        sb.append(String.valueOf(this.getClass().getSimpleName()) + " [");
        sb.append(this.Id()).append("] name :").append(this.getName()).append(",server:").append(server != null ? server.getName() : "NULL");
        sb.append(this.getSubType() == null ? "SubType None" : this.getSubType().toString());
        return sb.toString();
    }

    @Override
    public IParcelBean.Update initialize(IImageBean image, Portion portion, Lineage lineage, Id serverId, String version, String vname) {
        Stopwatch timer = new Stopwatch("[ParcelBean.initialize(" + image + "," + (Object)((Object)portion) + "," + lineage + ")]");
        try {
            IParcelBean.Update update = this.getUpdate();
            IServerBean serverBean = null;
            if (serverId != null) {
                serverBean = Services.getServerService().findOne(serverId);
            }
            if (serverBean == null) {
                serverBean = Services.getServerService().getCurrent();
            }
            update.setImageId(image.Id());
            update.setServer(serverBean.Id());
            update.setVersion(version != null ? version : image.getVersion());
            update.setPortion(portion);
            update.setStatus(ParcelStatus.READY);
            update.setLineage(lineage);
            update.setVMName(vname != null ? vname : this.newVMName());
            update.setName(this.newName());
            update.setSubType(image.getSubType());
            update.save();
            IParcelBean.Update update2 = update;
            return update2;
        }
        finally {
            timer.stop();
        }
    }

    @Override
    public boolean isFailed() {
        return this.isStatus(ParcelStatus.NOTSHIPPABLE, ParcelStatus.BROKEN, ParcelStatus.NOTUNPACKABLE);
    }

    @Override
    @DispatchPoint
    public boolean existsOnServer() {
        IServerBean current = Services.getServerService().getCurrent();
        return current.vmExistsOnLocal(this.getVMName());
    }

    @Override
    public String getDumpfile() {
        return (String)this.getParam("dumpfile");
    }

    @Override
    public IParcelBean.Update setDumpfile(String dumpfile) {
        this.setParam((Object)"dumpfile", dumpfile);
        return this;
    }

    @Override
    public IParcelBean.Update setSubType(VirtualSystemSubType subType) {
        this.setParam("subType", (Object)subType, ((Object)((Object)subType)).getClass());
        return this;
    }

    @Override
    public VirtualSystemSubType getSubType() {
        return (VirtualSystemSubType)((Object)this.getParam("subType"));
    }
}
