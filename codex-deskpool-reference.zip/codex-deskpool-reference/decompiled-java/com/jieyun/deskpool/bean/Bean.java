/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.StoreObject;

public interface Bean<T> {
    public void managedById(Id var1);

    public void setStoreObject(StoreObject var1);

    public void postConstruct();

    public void postStoreObjectSet();

    public void persist();

    public void remove();

    public Id Id();

    public void createId();

    public <W> W refresh();

    public String getServiceName();

    public boolean isDeattach();

    public T getDomain();

    public Bean<T> save();

    public String asString();

    public boolean isNew();

    public void lock();

    public void unlock();

    public boolean persistOnOnly(Id var1);

    public static interface Update<W>
    extends Bean<W> {
    }
}
