/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.aspectj.runtime.internal.AroundClosure
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.DefaultBean;
import org.aspectj.runtime.internal.AroundClosure;

public class DefaultBean$AjcClosure1
extends AroundClosure {
    public DefaultBean$AjcClosure1(Object[] objectArray) {
        super(objectArray);
    }

    public Object run(Object[] objectArray) {
        Object[] objectArray2 = this.state;
        DefaultBean.persist_aroundBody0((DefaultBean)objectArray[0]);
        return null;
    }
}
