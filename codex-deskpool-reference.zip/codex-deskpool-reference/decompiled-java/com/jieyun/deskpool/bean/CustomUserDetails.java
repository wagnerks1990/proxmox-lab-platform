/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.springframework.security.core.GrantedAuthority
 *  org.springframework.security.core.userdetails.User
 */
package com.jieyun.deskpool.bean;

import com.deskpool.constant.DeskpoolConfigConstant;
import java.util.Collection;
import org.apache.commons.lang.StringUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class CustomUserDetails
extends User {
    private static final long serialVersionUID = 320L;
    private boolean checkTotp;
    private int checkTimes;

    public CustomUserDetails(String username, String password, Collection<? extends GrantedAuthority> authorities, String totpSecret) {
        this(username, password, true, true, true, true, authorities, totpSecret);
    }

    public CustomUserDetails(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities, String totpSecret) {
        super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
        Boolean enableTotpSet = DeskpoolConfigConstant.isEnableTotp();
        this.setCheckTotp(StringUtils.isNotEmpty((String)totpSecret) && enableTotpSet != false);
    }

    public boolean isCheckTotp() {
        return this.checkTotp;
    }

    public void setCheckTotp(boolean checkTotp) {
        this.checkTotp = checkTotp;
    }

    public int getCheckTimes() {
        return this.checkTimes;
    }

    public void setCheckTimes(int checkTimes) {
        this.checkTimes = checkTimes;
    }

    public void setCheckTimesAdd() {
        ++this.checkTimes;
    }
}
