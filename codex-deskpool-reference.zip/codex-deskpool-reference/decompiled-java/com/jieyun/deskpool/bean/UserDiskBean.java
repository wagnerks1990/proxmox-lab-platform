/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.bean;

import com.deskpool.constant.DeskpoolConfigConstant;
import com.jieyun.deskpool.bean.DefaultBean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.IUserDiskBean;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.domain.UserDisk;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DiskAttribute;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.StoragePolicy;
import com.jieyun.deskpool.shared.UserDiskOperation;
import com.jieyun.deskpool.utils.Props;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserDiskBean
extends DefaultBean<UserDisk>
implements IUserDiskBean,
IUserDiskBean.Update {
    private static final Logger logger = LoggerFactory.getLogger(UserDiskBean.class);

    @Override
    public String getName() {
        return (String)this.getParam("name");
    }

    @Override
    public IUserDiskBean.Update setName(String name) {
        this.setParam((Object)"name", name);
        return this;
    }

    @Override
    public Id getAccountId() {
        return this.getIdParam("account");
    }

    @Override
    public IAccountBean getAccount() {
        Id id = this.getAccountId();
        if (id == null) {
            return null;
        }
        return (IAccountBean)Services.getAccountService().findOne(id);
    }

    @Override
    public IUserDiskBean.Update setAccount(IAccountBean account) {
        if (account != null) {
            this.setAccountId(account.Id());
        } else {
            this.setAccountId(null);
        }
        return this;
    }

    @Override
    public Id getInstanceId() {
        return this.getIdParam("instance");
    }

    @Override
    public IInstanceBean getInstance() {
        return (IInstanceBean)Services.getInstanceService().findOne(this.getInstanceId());
    }

    private IUserDiskBean.Update setInstance(IInstanceBean instance) {
        if (instance != null) {
            this.setIdParam("instance", instance.Id());
        } else {
            this.setIdParam("instance", null);
        }
        return this;
    }

    @Override
    public IUserDiskBean.Update getUpdate() {
        return (IUserDiskBean.Update)this.refresh();
    }

    @Override
    public Desktop.UserDiskStatus getStatus() {
        return (Desktop.UserDiskStatus)((Object)this.getParam("status"));
    }

    private IUserDiskBean.Update setStatus(Desktop.UserDiskStatus status) {
        this.setParam((Object)"status", (Object)status);
        return this;
    }

    @Override
    public IUserDiskBean.Update enterStatus(Desktop.UserDiskStatus status) {
        this.setStatus(status);
        this.save();
        return this;
    }

    @Override
    public StoragePolicy getPolicy() {
        return (StoragePolicy)this.getParam("policy");
    }

    @Override
    public IUserDiskBean.Update setPolicy(StoragePolicy policy) {
        this.setParam((Object)"policy", policy);
        return this;
    }

    @Override
    public IUserDiskBean.Update setAccountId(Id accountid) {
        this.setIdParam("account", accountid);
        return this;
    }

    @Override
    public String getDatastore() {
        return (String)this.getParam("datastore");
    }

    @Override
    public IUserDiskBean.Update setDatastore(String datastore) {
        this.setParam((Object)"datastore", datastore);
        return this;
    }

    @Override
    public boolean isCreated() {
        return this.booleanValue(this.getParam("created"));
    }

    @Override
    public IUserDiskBean.Update setCreated(boolean created) {
        this.setParam((Object)"created", created);
        return this;
    }

    private IUserDiskBean.Update setMounted(boolean mounted) {
        this.setParam((Object)"mounted", mounted);
        return this;
    }

    @Override
    public boolean isMounted() {
        return this.booleanValue(this.getParam("mounted"));
    }

    @Override
    public IUserDiskBean.Update init(String diskname, IAccountBean account, StoragePolicy storagePolicy, String datastore) {
        this.setName(diskname);
        this.setAccount(account);
        this.setPolicy(storagePolicy);
        this.setDatastore(datastore);
        this.setCreated(false);
        Props props = Props.instance();
        if (StringUtils.equals((String)props.get("config.vm.server.type"), (String)Config.VM.Type.pve.name())) {
            this.setPrefix(props.get("server.create.disk.vmid", "100"));
            IServerBean server = Services.getServerService().getCurrent();
            if (server != null) {
                this.setStorageType(server.getDiskType());
            }
        }
        this.enterStatus(Desktop.UserDiskStatus.INITIAL);
        this.setFilesize(0L);
        return this;
    }

    @Override
    public long getDiskSizeMB() {
        return (long)this.getPolicy().getUserDiskSize().intValue() * 1024L;
    }

    @Override
    public String asString() {
        StringBuilder sb = new StringBuilder();
        sb.append("UserDisk:[").append(this.getName()).append("]");
        sb.append(" isCreated:").append(this.isCreated());
        sb.append(" isMounted:").append(this.isMounted());
        return sb.toString();
    }

    @Override
    public IUserDiskBean.Update mountToVM(IInstanceBean instance) {
        this.setInstance(instance);
        this.setMounted(true);
        this.enterStatus(Desktop.UserDiskStatus.ONLINE);
        return this;
    }

    @Override
    public IUserDiskBean.Update unmountFromVM() {
        return this.unmountFromVM(null);
    }

    @Override
    public IUserDiskBean.Update unmountFromVM(IInstanceBean instance) {
        this.setInstance(null);
        this.setMounted(false);
        this.enterStatus(Desktop.UserDiskStatus.OFFLINE);
        return this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void offline() {
        if (!this.getStatus().equals((Object)Desktop.UserDiskStatus.ONLINE)) return;
        IInstanceBean instance = this.getInstance();
        if (instance != null) {
            if (!instance.getStatus().equals((Object)InstanceStatus.SHUTDOWN)) throw new JYServiceRuntimeException("error.userdisk.offline.error", "\u7528\u6237\u6570\u636e\u76d8\u6302\u8f7d\u7684\u684c\u9762\u6b63\u5728\u8fd0\u884c\uff0c\u65e0\u6cd5\u8fdb\u884c\u5378\u8f7d\u3002\u8bf7\u5173\u673a\u540e\u5378\u8f7d\u7528\u6237\u6570\u636e\u76d8\u3002");
            instance.detachUserDisk(this);
            return;
        } else {
            this.unmountFromVM();
        }
    }

    @Override
    public Long getFilesize() {
        Long size = (Long)this.getParam("filesize");
        return size != null ? size : 0L;
    }

    @Override
    public IUserDiskBean.Update setFilesize(Long filesize) {
        this.setParam((Object)"filesize", filesize);
        return this;
    }

    @Override
    public String getPath() {
        return (String)this.getParam("path", "");
    }

    @Override
    public IUserDiskBean.Update setPath(String path) {
        this.setParam((Object)"path", path);
        return this;
    }

    @Override
    public void resize(long mb) {
        IInstanceBean instance = this.getInstance();
        if (instance != null && !instance.getStatus().equals((Object)InstanceStatus.SHUTDOWN)) {
            throw new JYServiceRuntimeException("error.userdisk.modify.offline.error");
        }
        DiskAttribute di = new DiskAttribute();
        di.setSizeMB(mb);
        Services.getUserDiskService().modifyDisk(this, di);
    }

    @Override
    public void destroy(boolean filing) {
        logger.info("UserDiskBean[{}].destroy({})", (Object)this.getName(), (Object)filing);
        if (this.getStatus().equals((Object)Desktop.UserDiskStatus.ONLINE)) {
            throw new JYServiceRuntimeException("error.userdisk.destroy.error");
        }
        try {
            new TrackerService.Writer.UserDisk().destroy(this).message("userdisk.destroy.start", new String[0]);
            if (this.getStatus().equals((Object)Desktop.UserDiskStatus.OFFLINE)) {
                Services.getUserDiskService().destroyDisk(this, filing);
            } else if (this.getStatus().equals((Object)Desktop.UserDiskStatus.DESTROYED)) {
                Services.getUserDiskService().destroyDisk(this, filing);
            } else if (this.getStatus().equals((Object)Desktop.UserDiskStatus.INITIAL)) {
                logger.info("UserDiskBean[{}].destroy({})", (Object)this.getName(), (Object)filing);
                Services.getUserDiskService().destroyDisk(this, filing);
            }
        }
        catch (Exception ex) {
            new TrackerService.Writer.UserDisk().destroy(this).failure("userdisk.destroy.failed", new String[]{"$error", ex.getMessage()});
        }
    }

    public IUserDiskBean.Update save() {
        if (this.isNew()) {
            this.persist();
        } else {
            this.merge();
        }
        return this;
    }

    @Override
    public boolean create() {
        if (!this.isCreated()) {
            Services.getUserDiskService().createDisk(this);
        }
        return this.isCreated();
    }

    @Override
    public void updateInfo() {
        IUserDiskBean.Update userdisk = this.getUpdate();
        Services.getUserDiskService().queryDisk(userdisk);
    }

    @Override
    public List<UserDiskOperation> getDiskOperation() {
        ArrayList<UserDiskOperation> list = new ArrayList<UserDiskOperation>();
        list.add(UserDiskOperation.DiskArchive);
        list.add(UserDiskOperation.DiskDelete);
        list.add(UserDiskOperation.DiskDetach);
        list.add(UserDiskOperation.DiskResize);
        return list;
    }

    @Override
    public boolean isExisted() {
        return this.isCreated() && StringUtils.isNotBlank((String)this.getPath());
    }

    @Override
    public String getServiceName() {
        return "userDiskService";
    }

    @Override
    public IUserDiskBean.Update setPrefix(String prefix) {
        this.setParam((Object)"prefix", prefix);
        return this;
    }

    @Override
    public String getPrefix() {
        return (String)this.getParam("prefix");
    }

    @Override
    public String getDiskName() {
        if (StringUtils.isEmpty((String)this.getPrefix())) {
            return this.getName();
        }
        return String.format("vm-%s-%s.raw", this.getPrefix(), this.getName());
    }

    @Override
    public String getDiskPath() {
        if (StringUtils.isEmpty((String)this.getPrefix())) {
            return this.getName();
        }
        String storageType = this.getStorageType();
        if (StringUtils.isEmpty((String)storageType) || DeskpoolConfigConstant.NOT_VMID_STORAGE.contains(storageType)) {
            return String.format("vm-%s-%s.raw", this.getPrefix(), this.getName());
        }
        return String.format("%s/vm-%s-%s.raw", this.getPrefix(), this.getPrefix(), this.getName());
    }

    @Override
    public IUserDiskBean.Update setStorageType(String storageType) {
        this.setParam((Object)"storageType", storageType);
        return this;
    }

    @Override
    public String getStorageType() {
        return (String)this.getParam("storageType");
    }
}
