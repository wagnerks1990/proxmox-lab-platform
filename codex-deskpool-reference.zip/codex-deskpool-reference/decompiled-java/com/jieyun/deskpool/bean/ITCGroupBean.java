/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.domain.TCGroup;
import com.jieyun.deskpool.shared.TCBaseConfig;
import com.jieyun.deskpool.shared.TCConnectConfig;
import com.jieyun.deskpool.tcapi.domain.BaseConnConfig;
import java.util.List;

public interface ITCGroupBean
extends Bean<TCGroup> {
    public List<String> getAllIp();

    public String getStartIp();

    public String getEndIp();

    public BaseConnConfig getConnection();

    public Update getUpdate();

    public boolean isEnable();

    public String getName();

    public String getRemark();

    public String getGroupName();

    public TCBaseConfig getTCBaseConfig();

    public TCConnectConfig getTCConnectConfig();

    public boolean getEnableLocalIP();

    public boolean isAddConnection();

    public boolean updateTCConfig();

    public boolean isMonitorNoUpdateConfig();

    public List<String> getAllOnLineIp();

    public List<String> getAllOffLineIp(List<String> var1);

    public void sysncStatus(List<String> var1, List<String> var2);

    public void sysncStatus();

    public void sysncStatus(List<String> var1);

    public boolean enableMonitoring();

    public static interface Update
    extends ITCGroupBean,
    Bean.Update<TCGroup> {
        public void setStartIp(String var1);

        public void setEndIp(String var1);

        public void setEnable(boolean var1);

        public void setName(String var1);

        public void setRemark(String var1);

        public void setTCBaseConfig(TCBaseConfig var1);

        public void setTCConnectConfig(TCConnectConfig var1);

        public void setEnableLocalIP(boolean var1);

        public void setMonitorNoUpdateConfig(boolean var1);
    }
}
