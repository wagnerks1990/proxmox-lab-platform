/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.api.data.ImageEntity;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.EntityApi;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IParcelBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Image;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.ImageInfo;
import com.jieyun.deskpool.shared.ImageStatus;
import com.jieyun.deskpool.shared.SetupPhase;
import com.jieyun.deskpool.shared.VirtualSystemSubType;
import java.util.List;

public interface IImageBean
extends Bean<Image>,
EntityApi<ImageEntity> {
    public SetupPhase getSetupPhase();

    public String getName();

    public String getDescription();

    public Desktop.ImageMode getMode();

    public ImageStatus getStatus();

    public String getSourcevm();

    public String getDraftvm();

    public IInstanceBean getDraftInstance();

    public String getTargetvm();

    public IInstanceBean getInstance();

    public boolean isAutoInstallAgent();

    public List<String> getVersions();

    public String getVersion();

    public String newVersion();

    public void destroy();

    public Update getUpdate();

    public ImageInfo getImageInfo();

    public List<ITemplateBean> getTemplates();

    public boolean canLinkedCopy();

    public String getUsername();

    public String getPassword();

    public void prepareImage();

    public void unPrepareImage();

    public void saveImage();

    public IParcelBean getLocalParcel();

    public boolean allHaveCurrentParcel();

    public boolean hasParcelOnOffLineServer();

    public boolean parcelIsStable();

    public boolean isLinux();

    public boolean back();

    public VirtualSystemSubType getSubType();

    public static interface Update
    extends IImageBean,
    Bean.Update<Image> {
        public Update setName(String var1);

        public Update setDescription(String var1);

        public Update setMode(Desktop.ImageMode var1);

        public Update setStatus(ImageStatus var1);

        public Update setSourcevm(String var1);

        public Update setDraftvm(String var1);

        public Update setTargetvm(String var1);

        public Update setImageInfo(ImageInfo var1);

        public Update setAutoInstallAgent(boolean var1);

        public Update setVersions(List<String> var1);

        public Update clearDraftVm();

        public Update addVersion(String var1);

        public Update setUsername(String var1);

        public Update setPassword(String var1);

        public Update setLinux(boolean var1);
    }
}
