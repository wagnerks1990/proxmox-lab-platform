/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.bean;

import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Cluster;
import com.jieyun.deskpool.domain.SgwServerConfig;
import com.jieyun.deskpool.domain.SystemConfig;
import com.jieyun.deskpool.shared.LicenseStatus;
import java.util.List;

public static interface IClusterBean.Update
extends IClusterBean,
Bean.Update<Cluster> {
    public IClusterBean.Update enterLicenseStatus(LicenseStatus var1);

    public IClusterBean.Update updateFloatIp(String var1);

    public IClusterBean.Update setClusterLicense(String var1);

    public IClusterBean.Update setSysConfig(SystemConfig var1);

    public IClusterBean.Update setImageResponsitoryAddr(String var1);

    public IClusterBean.Update setImageResponsitoryAddrList(List<String> var1);

    public IClusterBean.Update setTemplateAPPServerId(IServerBean var1);

    public IClusterBean.Update setSgwsConfig(SgwServerConfig var1);

    public IClusterBean.Update enableSgws();

    public IClusterBean.Update disableSgws();
}
