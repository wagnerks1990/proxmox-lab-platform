/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.InstanceWatcher;
import com.jieyun.deskpool.vm.Event;

class InstanceWatcher.1
extends Event.TimedEngine {
    InstanceWatcher.1(String $anonymous0, long $anonymous1) {
        super($anonymous0, $anonymous1);
    }

    @Override
    protected Event defaultEvent() {
        return new InstanceWatcher.Message();
    }
}
