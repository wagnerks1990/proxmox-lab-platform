/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYEngine;
import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.agent.utils.JYWorker;
import com.jieyun.deskpool.agent.utils.MessageCreator;
import com.jieyun.deskpool.agent.utils.StaticEngineLookupStrategy;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Script;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServerCommandEngine
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(ServerCommandEngine.class);
    private static final String FLOAT_FILE_NAME = "eth0:float";
    private static final String FLOAT_IP_FILE = "/etc/sysconfig/network-scripts/eth0:float";
    private static ServerCommandEngine instance = new ServerCommandEngine();

    public void init() {
    }

    public static ServerCommandEngine instance() {
        return instance;
    }

    @Override
    public void onStart() {
    }

    @Override
    public void onShutdown() {
    }

    public void stopService() {
        MessageFactory.instance().create(Worker.StopServiceMessage.class).send(5);
    }

    public void restartService() {
        MessageFactory.instance().create(Worker.RestartServiceMessage.class).send(5);
    }

    public void shutdownServer() {
        MessageFactory.instance().create(Worker.ShutdownServerMessage.class).send(5);
    }

    public void restartServer() {
        MessageFactory.instance().create(Worker.RestartServerMessage.class).send(5);
    }

    public void startFloatIp() {
        MessageFactory.instance().create(Worker.StartFloagIpMessage.class).send(5);
    }

    public void stopFloatIp() {
        MessageFactory.instance().create(Worker.StopFloagIpMessage.class).send(5);
    }

    public static class MessageFactory
    extends MessageCreator {
        private static MessageFactory instance = new MessageFactory();

        static {
            JYEngine engine = new JYEngine("ServerCommandEngine"){

                @Override
                public boolean isRejectWorking() {
                    return false;
                }
            };
            new Worker(Worker.CreateClusterMessage.class, engine);
            new Worker(Worker.JoinClusterMessage.class, engine);
            new Worker(Worker.UpdateNetworkConfigMessage.class, engine);
            new Worker(Worker.LeaveClusterMessage.class, engine);
            new Worker(Worker.EnterMaintanceMessage.class, engine);
            new Worker(Worker.ExitMaintanceMessage.class, engine);
            new Worker(Worker.RefreshMasterMessage.class, engine);
            new Worker(Worker.StopServiceMessage.class, engine);
            new Worker(Worker.RestartServiceMessage.class, engine);
            new Worker(Worker.RestartServerMessage.class, engine);
            new Worker(Worker.ShutdownServerMessage.class, engine);
            new Worker(Worker.RestoreFactorySettingMessage.class, engine);
            new Worker(Worker.StartFloagIpMessage.class, engine);
            new Worker(Worker.StopFloagIpMessage.class, engine);
            StaticEngineLookupStrategy lookupStrategy = new StaticEngineLookupStrategy();
            lookupStrategy.setEngine(engine);
            instance.setEngineLookupStrategy(lookupStrategy);
            engine.start();
        }

        public static MessageFactory instance() {
            return instance;
        }
    }

    public static class Worker
    extends JYWorker {
        public Worker(Class<? extends JYMessage> msgClass, Event.Engine engine) {
            super(msgClass, engine);
            this.engine = engine;
        }

        public static class CreateClusterMessage
        extends JYMessage {
            @Override
            public void onReceive() {
                List<ErrorMessage> result = null;
                try {
                    if (this.getEventHandler() != null) {
                        try {
                            this.getEventHandler().handle();
                        }
                        catch (JYServiceRuntimeException e) {
                            result = e.getErrorList();
                            logger.error(e.toString());
                        }
                    }
                }
                catch (Throwable throwable) {
                    if (this.isSync() && this.getResponse() == null) {
                        this.respond(new Response(result){});
                    }
                    throw throwable;
                }
                if (this.isSync() && this.getResponse() == null) {
                    this.respond(new /* invalid duplicate definition of identical inner class */);
                }
            }

            public Response awaitResponse() {
                Stopwatch timer = new Stopwatch("[ServerCommandEngine.Worker.CreateClusterMessage.Response()]");
                try {
                    Response response = (Response)this.response(120);
                    return response;
                }
                finally {
                    timer.stop();
                }
            }

            public static class Response
            implements Event.Response {
                private List<ErrorMessage> result;

                Response(List<ErrorMessage> result) {
                    Stopwatch timer = new Stopwatch("[[ServerCommandEngine.Worker.CreateClusterMessage.Response.Response(" + result + ")]");
                    try {
                        this.result = result;
                    }
                    finally {
                        timer.stop();
                    }
                }

                public List<ErrorMessage> getResult() {
                    return this.result;
                }
            }
        }

        public static class EnterMaintanceMessage
        extends JYMessage {
        }

        public static class ExitMaintanceMessage
        extends JYMessage {
        }

        public static class JoinClusterMessage
        extends JYMessage {
        }

        public static class LeaveClusterMessage
        extends JYMessage {
        }

        public static class RefreshMasterMessage
        extends JYMessage {
            @Override
            public void onReceive() {
                MasterCoordinator masterCoordinator = MasterCoordinator.instance();
                if (masterCoordinator.isMasterLocal()) {
                    IServerBean currentServer = Services.getServerService().getCurrent();
                    if (!currentServer.isMaster()) {
                        logger.info("masterAddress:{}", masterCoordinator.getMasterIpAddress());
                        currentServer.setMaster(true);
                        currentServer.save();
                    }
                    List servers = Services.getServerService().findAll();
                    for (IServerBean server : servers) {
                        if (server.Id().equals(currentServer.Id()) || !server.isMaster()) continue;
                        server.setMaster(false);
                        server.save();
                    }
                }
            }
        }

        public static class RestartServerMessage
        extends JYMessage {
            @Override
            public void onReceive() {
                logger.info("restartServer");
                String killcmd2 = "reboot";
                Script.runSimpleBashRemoteScript(killcmd2, 1200);
            }
        }

        public static class RestartServiceMessage
        extends JYMessage {
            @Override
            public void onReceive() {
                logger.info("restartService");
                try {
                    Runtime.getRuntime().exec("nohup service tomcat restart &");
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public static class RestoreFactorySettingMessage
        extends JYMessage {
        }

        public static class ShutdownServerMessage
        extends JYMessage {
            @Override
            public void onReceive() {
                logger.info("shutdownServer");
                String killcmd2 = "shutdown -h now";
                Script.runSimpleBashRemoteScript(killcmd2, 1200);
            }
        }

        public static class StartFloagIpMessage
        extends JYMessage {
            private static final long serialVersionUID = 1L;

            @Override
            public void onReceive() {
                String floatIp = ClusterNodeBean.getFloatIp();
                if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
                    NetworkConfig networkConfig;
                    String secondaryIp = null;
                    try {
                        secondaryIp = NetUtils.getSecondaryIp();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (StringUtils.equals((CharSequence)secondaryIp, (CharSequence)floatIp)) {
                        return;
                    }
                    if (StringUtils.isNotBlank((CharSequence)secondaryIp)) {
                        logger.info("StartFloagIpMessage stop old FloatIP {}", (Object)secondaryIp);
                        networkConfig = NetworkConfigFactory.createNetworkConfig();
                        networkConfig.stopFloatIp();
                    }
                    if (StringUtils.isNotBlank((CharSequence)floatIp)) {
                        logger.info("StartFloagIpMessage startFloatIp {} ", (Object)floatIp);
                        networkConfig = NetworkConfigFactory.createNetworkConfig();
                        networkConfig.startFloatIp(floatIp);
                    }
                } else {
                    if (StringUtils.isEmpty((CharSequence)floatIp) || !ClusterNodeBean.isStartFloatIp()) {
                        if (DpFileUtils.exists(ServerCommandEngine.FLOAT_IP_FILE)) {
                            String ifdown = "ifdown eth0:float";
                            Script.runSimpleBashRemoteScript(ifdown, 1200);
                        }
                        return;
                    }
                    NetworkConfig config = NetworkConfigFactory.createNetworkConfig();
                    config.createOrUpdateFloatIp(floatIp, ServerCommandEngine.FLOAT_FILE_NAME);
                    String ifup = "ifup eth0:float";
                    String string = Script.runSimpleBashRemoteScript(ifup, 1200);
                }
            }
        }

        public static class StopFloagIpMessage
        extends JYMessage {
            private static final long serialVersionUID = 1L;

            @Override
            public void onReceive() {
                if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
                    String secondaryIp = null;
                    try {
                        secondaryIp = NetUtils.getSecondaryIp();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (StringUtils.isNotBlank((CharSequence)secondaryIp)) {
                        logger.info("StopFloagIpMessage networkConfig.stopFloatIp");
                        NetworkConfig networkConfig = NetworkConfigFactory.createNetworkConfig();
                        networkConfig.stopFloatIp();
                    }
                } else {
                    String floatIpFile = ServerCommandEngine.FLOAT_IP_FILE;
                    if (!DpFileUtils.exists(floatIpFile)) {
                        return;
                    }
                    String ifdown = "ifdown eth0:float";
                    String result = Script.runSimpleBashRemoteScript(ifdown, 1200);
                    String removefile = "rm -rf eth0:float";
                    String string = Script.runSimpleBashRemoteScript(removefile, 1200);
                }
            }
        }

        public static class StopServiceMessage
        extends JYMessage {
            @Override
            public void onReceive() {
                logger.info("stopService");
                String killcmd2 = "service tomcat stop";
                Script.runSimpleBashRemoteScript(killcmd2, 1200);
            }
        }

        public static class UpdateNetworkConfigMessage
        extends JYMessage {
            private NetworkConfigVO params;
            private IServerBean serverBean;

            public UpdateNetworkConfigMessage() {
            }

            public UpdateNetworkConfigMessage(NetworkConfigVO params, IServerBean serverBean) {
                this.params = params;
                this.serverBean = serverBean;
            }

            public NetworkConfigVO getParams() {
                return this.params;
            }

            public void setParams(NetworkConfigVO params) {
                this.params = params;
            }

            public IServerBean getServerBean() {
                return this.serverBean;
            }

            public void setServerBean(IServerBean serverBean) {
                this.serverBean = serverBean;
            }

            @Override
            public void onReceive() {
                this.serverBean.getNetworkConfig().reconfig(this.params.getType(), this.params.getIp(), this.params.isReboot());
            }
        }
    }
}
