/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.vm.Context;
import com.jieyun.deskpool.vm.Event;

public interface Agent
extends Event.Recipient {

    public static abstract class Impl
    implements Agent {
        protected Event.Engine engine;

        protected Impl(Event.Engine engine) {
            this.engine = engine;
        }

        public Event.Engine engine() {
            return this.engine;
        }

        protected void subscribe(Class eventClass) {
            boolean bypass = true;
            this.engine().subscribe(eventClass, this, bypass);
        }

        @Override
        public abstract boolean receive(Event var1);

        public String toString() {
            return String.valueOf(this.getClass().getName()) + "<" + this.engine + ">";
        }
    }

    public static abstract class Message
    extends Event.Impl {
    }

    public static abstract class MessageWithContext
    extends Event.Impl {
        private Context context;

        public MessageWithContext(Context context) {
            this.context = context;
        }

        public Context context() {
            return this.context;
        }
    }
}
