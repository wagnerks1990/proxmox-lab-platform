/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;

public static class CommandStub.RedirectUsbResponse.Factory {
    public static CommandStub.RedirectUsbResponse parse(XMLStreamReader reader) throws Exception {
        CommandStub.RedirectUsbResponse object = new CommandStub.RedirectUsbResponse();
        Object nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            String fullTypeName;
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null && (fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type")) != null) {
                String nsPrefix = null;
                if (fullTypeName.indexOf(":") > -1) {
                    nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                }
                nsPrefix = nsPrefix == null ? "" : nsPrefix;
                String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);
                if (!"RedirectUsbResponse".equals(type)) {
                    String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                    return (CommandStub.RedirectUsbResponse)CommandStub.ExtensionMapper.getTypeObject(nsUri, type, reader);
                }
            }
            Vector handledAttributes = new Vector();
            reader.next();
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement() && new QName("http://tempuri.org/", "RedirectUsbResult").equals(reader.getName())) {
                object.setRedirectUsbResult(CommandStub.CommandResult.Factory.parse(reader));
                reader.next();
            }
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement()) {
                throw new ADBException("Unexpected subelement " + reader.getName());
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
