/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.ConverterUtil
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.ConverterUtil;

public static class CommandStub.PvdAction.Factory {
    public static CommandStub.PvdAction fromValue(String value) throws IllegalArgumentException {
        CommandStub.PvdAction enumeration = (CommandStub.PvdAction)_table_.get(value);
        if (enumeration == null && value != null && !value.equals("")) {
            throw new IllegalArgumentException();
        }
        return enumeration;
    }

    public static CommandStub.PvdAction fromString(String value, String namespaceURI) throws IllegalArgumentException {
        try {
            return CommandStub.PvdAction.Factory.fromValue(ConverterUtil.convertToString((String)value));
        }
        catch (Exception e) {
            throw new IllegalArgumentException();
        }
    }

    public static CommandStub.PvdAction fromString(XMLStreamReader xmlStreamReader, String content) {
        if (content.indexOf(":") > -1) {
            String prefix = content.substring(0, content.indexOf(":"));
            String namespaceUri = xmlStreamReader.getNamespaceContext().getNamespaceURI(prefix);
            return CommandStub.PvdAction.Factory.fromString(content, namespaceUri);
        }
        return CommandStub.PvdAction.Factory.fromString(content, "");
    }

    public static CommandStub.PvdAction parse(XMLStreamReader reader) throws Exception {
        CommandStub.PvdAction object = null;
        HashMap attributeMap = new HashMap();
        ArrayList extraAttributeList = new ArrayList();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            Vector handledAttributes = new Vector();
            while (!reader.isEndElement()) {
                if (reader.isStartElement() || reader.hasText()) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                        throw new ADBException("The element: PvdAction  cannot be null");
                    }
                    String content = reader.getElementText();
                    if (content.indexOf(":") > 0) {
                        prefix = content.substring(0, content.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object = CommandStub.PvdAction.Factory.fromString(content, namespaceuri);
                        continue;
                    }
                    object = CommandStub.PvdAction.Factory.fromString(content, "");
                    continue;
                }
                reader.next();
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
