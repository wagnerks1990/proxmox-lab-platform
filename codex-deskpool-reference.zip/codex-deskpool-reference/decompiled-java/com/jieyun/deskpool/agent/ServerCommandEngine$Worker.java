/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.ServerCommandEngine;
import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.agent.utils.JYWorker;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Script;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

public static class ServerCommandEngine.Worker
extends JYWorker {
    public ServerCommandEngine.Worker(Class<? extends JYMessage> msgClass, Event.Engine engine) {
        super(msgClass, engine);
        this.engine = engine;
    }

    public static class CreateClusterMessage
    extends JYMessage {
        @Override
        public void onReceive() {
            List<ErrorMessage> result = null;
            try {
                if (this.getEventHandler() != null) {
                    try {
                        this.getEventHandler().handle();
                    }
                    catch (JYServiceRuntimeException e) {
                        result = e.getErrorList();
                        logger.error(e.toString());
                    }
                }
            }
            catch (Throwable throwable) {
                if (this.isSync() && this.getResponse() == null) {
                    this.respond(new Response(result){});
                }
                throw throwable;
            }
            if (this.isSync() && this.getResponse() == null) {
                this.respond(new /* invalid duplicate definition of identical inner class */);
            }
        }

        public Response awaitResponse() {
            Stopwatch timer = new Stopwatch("[ServerCommandEngine.Worker.CreateClusterMessage.Response()]");
            try {
                Response response = (Response)this.response(120);
                return response;
            }
            finally {
                timer.stop();
            }
        }

        public static class Response
        implements Event.Response {
            private List<ErrorMessage> result;

            Response(List<ErrorMessage> result) {
                Stopwatch timer = new Stopwatch("[[ServerCommandEngine.Worker.CreateClusterMessage.Response.Response(" + result + ")]");
                try {
                    this.result = result;
                }
                finally {
                    timer.stop();
                }
            }

            public List<ErrorMessage> getResult() {
                return this.result;
            }
        }
    }

    public static class EnterMaintanceMessage
    extends JYMessage {
    }

    public static class ExitMaintanceMessage
    extends JYMessage {
    }

    public static class JoinClusterMessage
    extends JYMessage {
    }

    public static class LeaveClusterMessage
    extends JYMessage {
    }

    public static class RefreshMasterMessage
    extends JYMessage {
        @Override
        public void onReceive() {
            MasterCoordinator masterCoordinator = MasterCoordinator.instance();
            if (masterCoordinator.isMasterLocal()) {
                IServerBean currentServer = Services.getServerService().getCurrent();
                if (!currentServer.isMaster()) {
                    logger.info("masterAddress:{}", masterCoordinator.getMasterIpAddress());
                    currentServer.setMaster(true);
                    currentServer.save();
                }
                List servers = Services.getServerService().findAll();
                for (IServerBean server : servers) {
                    if (server.Id().equals(currentServer.Id()) || !server.isMaster()) continue;
                    server.setMaster(false);
                    server.save();
                }
            }
        }
    }

    public static class RestartServerMessage
    extends JYMessage {
        @Override
        public void onReceive() {
            logger.info("restartServer");
            String killcmd2 = "reboot";
            Script.runSimpleBashRemoteScript(killcmd2, 1200);
        }
    }

    public static class RestartServiceMessage
    extends JYMessage {
        @Override
        public void onReceive() {
            logger.info("restartService");
            try {
                Runtime.getRuntime().exec("nohup service tomcat restart &");
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static class RestoreFactorySettingMessage
    extends JYMessage {
    }

    public static class ShutdownServerMessage
    extends JYMessage {
        @Override
        public void onReceive() {
            logger.info("shutdownServer");
            String killcmd2 = "shutdown -h now";
            Script.runSimpleBashRemoteScript(killcmd2, 1200);
        }
    }

    public static class StartFloagIpMessage
    extends JYMessage {
        private static final long serialVersionUID = 1L;

        @Override
        public void onReceive() {
            String floatIp = ClusterNodeBean.getFloatIp();
            if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
                NetworkConfig networkConfig;
                String secondaryIp = null;
                try {
                    secondaryIp = NetUtils.getSecondaryIp();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                if (StringUtils.equals((CharSequence)secondaryIp, (CharSequence)floatIp)) {
                    return;
                }
                if (StringUtils.isNotBlank((CharSequence)secondaryIp)) {
                    logger.info("StartFloagIpMessage stop old FloatIP {}", (Object)secondaryIp);
                    networkConfig = NetworkConfigFactory.createNetworkConfig();
                    networkConfig.stopFloatIp();
                }
                if (StringUtils.isNotBlank((CharSequence)floatIp)) {
                    logger.info("StartFloagIpMessage startFloatIp {} ", (Object)floatIp);
                    networkConfig = NetworkConfigFactory.createNetworkConfig();
                    networkConfig.startFloatIp(floatIp);
                }
            } else {
                if (StringUtils.isEmpty((CharSequence)floatIp) || !ClusterNodeBean.isStartFloatIp()) {
                    if (DpFileUtils.exists(ServerCommandEngine.FLOAT_IP_FILE)) {
                        String ifdown = "ifdown eth0:float";
                        Script.runSimpleBashRemoteScript(ifdown, 1200);
                    }
                    return;
                }
                NetworkConfig config = NetworkConfigFactory.createNetworkConfig();
                config.createOrUpdateFloatIp(floatIp, ServerCommandEngine.FLOAT_FILE_NAME);
                String ifup = "ifup eth0:float";
                String string = Script.runSimpleBashRemoteScript(ifup, 1200);
            }
        }
    }

    public static class StopFloagIpMessage
    extends JYMessage {
        private static final long serialVersionUID = 1L;

        @Override
        public void onReceive() {
            if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
                String secondaryIp = null;
                try {
                    secondaryIp = NetUtils.getSecondaryIp();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                if (StringUtils.isNotBlank((CharSequence)secondaryIp)) {
                    logger.info("StopFloagIpMessage networkConfig.stopFloatIp");
                    NetworkConfig networkConfig = NetworkConfigFactory.createNetworkConfig();
                    networkConfig.stopFloatIp();
                }
            } else {
                String floatIpFile = ServerCommandEngine.FLOAT_IP_FILE;
                if (!DpFileUtils.exists(floatIpFile)) {
                    return;
                }
                String ifdown = "ifdown eth0:float";
                String result = Script.runSimpleBashRemoteScript(ifdown, 1200);
                String removefile = "rm -rf eth0:float";
                String string = Script.runSimpleBashRemoteScript(removefile, 1200);
            }
        }
    }

    public static class StopServiceMessage
    extends JYMessage {
        @Override
        public void onReceive() {
            logger.info("stopService");
            String killcmd2 = "service tomcat stop";
            Script.runSimpleBashRemoteScript(killcmd2, 1200);
        }
    }

    public static class UpdateNetworkConfigMessage
    extends JYMessage {
        private NetworkConfigVO params;
        private IServerBean serverBean;

        public UpdateNetworkConfigMessage() {
        }

        public UpdateNetworkConfigMessage(NetworkConfigVO params, IServerBean serverBean) {
            this.params = params;
            this.serverBean = serverBean;
        }

        public NetworkConfigVO getParams() {
            return this.params;
        }

        public void setParams(NetworkConfigVO params) {
            this.params = params;
        }

        public IServerBean getServerBean() {
            return this.serverBean;
        }

        public void setServerBean(IServerBean serverBean) {
            this.serverBean = serverBean;
        }

        @Override
        public void onReceive() {
            this.serverBean.getNetworkConfig().reconfig(this.params.getType(), this.params.getIp(), this.params.isReboot());
        }
    }
}
