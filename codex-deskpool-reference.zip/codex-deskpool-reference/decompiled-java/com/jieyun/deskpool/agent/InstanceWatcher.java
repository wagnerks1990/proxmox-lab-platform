/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.PoolManager;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.cache.DeskPoolCacheManager;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.AgentStatus;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.PrepState;
import com.jieyun.deskpool.shared.ServerStatus;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.DiskInfo;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.HostInfo;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.VMResource;
import com.jieyun.deskpool.vm.common.NodeConfig;
import com.jieyun.deskpool.windows.agentclient.PrepareManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InstanceWatcher
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(InstanceWatcher.class);
    private static String engineName = "instancewatcher";
    private static int REPEAT_SHORT = 5;
    private static int STATUS_LIST_SIZE = 0;
    private static int STATUS_PRINT_COUNTS = 0;
    VMControlFactory factory = null;
    int resetConnectionCount = 0;
    int oneMinuteCount = 0;
    int fiveMinuteCount = 0;
    private Map<String, NodeConfig> vmAndServerHost = new HashMap<String, NodeConfig>();
    private static long lastFiveMinutesTick = 0L;

    public InstanceWatcher() {
        this(new Event.TimedEngine(engineName, REPEAT_SHORT){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    @Override
    public void onStart() {
        this.engine().start();
    }

    @Override
    public void onShutdown() {
        this.engine().quit();
    }

    public InstanceWatcher(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    public synchronized void reset() {
        Config config;
        if (this.factory != null) {
            this.factory.release();
            this.factory = null;
        }
        if (!(config = Config.Store.get()).vmIs(Config.VM.Type.none)) {
            this.factory = VMControlFactory.get(config);
            this.factory.connect();
            this.resetConnectionCount = 12;
        }
    }

    protected VMControlFactory getFactory() {
        return this.factory;
    }

    void process() {
        IServerBean server;
        if (--this.resetConnectionCount < 0 || this.getFactory() == null) {
            try {
                this.reset();
                DeskPoolCacheManager.clearValidata();
            }
            catch (Exception ex) {
                logger.warn(ex.getMessage());
                return;
            }
        }
        DeskPoolCacheManager.setServerIp(NetUtils.getHostIP());
        long startTime = System.currentTimeMillis();
        this.oneMinuteCount = (this.oneMinuteCount + 1) % 12;
        this.fiveMinuteCount = (this.fiveMinuteCount + 1) % 60;
        if (this.fiveMinuteCount == 0) {
            long currentMillis = System.currentTimeMillis();
            if (lastFiveMinutesTick != 0L) {
                logger.info(" InstanceWatcher has run 60 times in " + (currentMillis - lastFiveMinutesTick) / 1000L + " seconds");
            }
            lastFiveMinutesTick = currentMillis;
        }
        try {
            server = Services.getServerService().getCurrent();
        }
        catch (Exception e) {
            e.printStackTrace();
            server = null;
        }
        if (server == null || this.getFactory() == null) {
            logger.debug("There is no server config.  Don't execute freshen() ");
            return;
        }
        List<IInstanceBean> list = Services.getInstanceService().findByServer(server);
        if (list.size() > 0) {
            if (this.oneMinuteCount == 0) {
                logger.debug(" Execute task per minutes.");
                this.taskPerMinute(list);
            }
            VMResource vmResource = this.getFactory().getVMOperations();
            if (server.getStatus().equals((Object)ServerStatus.STATUS_ACTIVATED)) {
                HostInfo hostInfo = this.getFactory().getHostInfo(null);
                this.vmAndServerHost = this.getFactory().getVMOperations().getServerHostMap();
                Map<String, String> statuslist = hostInfo.getAllStatus();
                int statuslistSize = statuslist.size();
                STATUS_PRINT_COUNTS = (STATUS_PRINT_COUNTS + 1) % 120;
                if (STATUS_LIST_SIZE != statuslistSize || STATUS_PRINT_COUNTS == 2) {
                    logger.info("InstanceWatcher getAllStatus , vm number :" + statuslistSize);
                }
                STATUS_LIST_SIZE = statuslistSize;
                if (statuslist != null && statuslistSize > 0) {
                    for (IInstanceBean instance : list) {
                        instance.lock();
                        try {
                            try {
                                if (!instance.hasVmParam("phase")) {
                                    this.freshen(vmResource, server, instance, statuslist);
                                }
                            }
                            catch (Exception ex) {
                                try {
                                    logger.error("InstanceWatcher Exception refreshing instance " + instance + ":  " + ex.getMessage() + " StackTrace :" + ex.getStackTrace());
                                }
                                catch (Exception exception) {
                                    // empty catch block
                                }
                                ex.printStackTrace();
                                instance.unlock();
                                continue;
                            }
                        }
                        catch (Throwable throwable) {
                            instance.unlock();
                            throw throwable;
                        }
                        instance.unlock();
                    }
                }
            } else {
                logger.error("InstanceWatcher server is fault. notify PoolManager to freshen server status");
                new PoolManager.Message(true).send();
            }
        }
        this.checkRefreshTime(startTime, server);
    }

    private void taskPerMinute(List<IInstanceBean> list) {
        int max_create_minutes = Props.instance().get("max.create.minutes", 10);
        try {
            for (IInstanceBean instance : list) {
                instance.lock();
                try {
                    InstanceStatus status = instance.getStatus();
                    if (instance.isAssigned() || instance.isImageInstance().booleanValue() || InstanceStatus.DESTROYED.equals((Object)status) || InstanceStatus.RUNNING.equals((Object)status) || instance.isSleeped() || instance.hasVmParam("phase") && "regenerate".equals(instance.getVmParam("phase"))) {
                        if (!instance.hasVmParam("create_minutes")) continue;
                        instance = instance.getUpdate().clearVmParam("create_minutes");
                        instance.save();
                        continue;
                    }
                    int minutes = instance.getVmParam("create_minutes", 1);
                    logger.info(" VM {} has creating {} minutes", (Object)instance.getName(), (Object)minutes);
                    if (minutes > max_create_minutes) {
                        logger.info(" Creating time out, Detroy the virtualMachine {}", (Object)instance.getName());
                        instance.destroyImplicitly();
                    }
                    instance = instance.getUpdate().setVmParam("create_minutes", minutes + 1);
                    instance.save();
                }
                finally {
                    instance.unlock();
                }
            }
        }
        catch (Exception ex) {
            logger.error(" taskPerMinute Exception: {}", (Object)ex.getMessage());
        }
    }

    public static int abs(int a) {
        return a < 0 ? -a : a;
    }

    void freshen(VMResource vmResource, IServerBean server, IInstanceBean instance, Map<String, String> statuslist) {
        String ipaddr;
        int n;
        int n2;
        String[] stringArray;
        String vmname;
        IInstanceBean instanceUpdate = (IInstanceBean)Services.getInstanceService().findOne(instance.Id());
        if (instanceUpdate == null) {
            logger.warn("instance {} has been deleted!", (Object)instance);
            return;
        }
        instance = instanceUpdate;
        InstanceStatus current = instance.getStatus();
        if (current == null) {
            logger.error(" WARNING: instance {} status is null! ", (Object)instance.toString());
        }
        if (StringUtils.isEmpty((CharSequence)(vmname = instance.getVmname()))) {
            if (current != InstanceStatus.PRESTARTUP) {
                logger.warn("instance {} {} has no VM yet!", (Object)instance, (Object)current);
            }
            return;
        }
        if (statuslist.get(vmname) == null) {
            if (instance.getStatus().isVmCreated()) {
                logger.warn("instance {} with vmid {} has lost in hypervisor!", (Object)instance.getName(), (Object)vmname);
            }
            return;
        }
        String vmstatus = statuslist.get(vmname);
        boolean vmRunning = "running".equals(vmstatus);
        InstanceStatus status = current;
        String newipaddress = null;
        if ("NONE".equals(vmstatus)) {
            logger.info("InstanceWatcher freshen unkown status for instance {} ", (Object)instance);
        } else if (vmRunning) {
            switch (current) {
                case RUNNING: {
                    if (InstanceWatcher.abs(vmname.hashCode()) % 60 == this.fiveMinuteCount || StringUtils.isEmpty((CharSequence)instance.getIpaddress()) || instance.getIpaddress().startsWith("169.")) {
                        logger.info(" running status get ipaddress of " + vmname);
                        newipaddress = vmResource.ipaddress(vmname);
                        logger.info(" vm " + vmname + " ip :" + newipaddress);
                        if (instance.getStatus() == InstanceStatus.RUNNING && instance.getTemplate() != null && instance.getTemplate().isDrift() && StringUtils.isNotBlank((CharSequence)instance.getClientLocation()) && StringUtils.isBlank((CharSequence)newipaddress)) {
                            instance.regenerate();
                            logger.info("the vm[{}] ip[{}]   is Empty,the vm will regenerate", (Object)vmname, (Object)newipaddress);
                        }
                    }
                }
                case RESTARTING: 
                case PRESHUTDOWN: 
                case BROKEN: 
                case DESTROYED: {
                    status = current;
                    break;
                }
                case UNKNOWN: 
                case PRESTARTUP: 
                case STARTUP: 
                case STARTINGIP: 
                case STARTINGCONN: 
                case STANDING: 
                case SHUTDOWN: {
                    newipaddress = vmResource.ipaddress(vmname);
                    if (StringUtils.isNotEmpty((CharSequence)newipaddress)) {
                        boolean vmReady = false;
                        stringArray = newipaddress.split(";");
                        n2 = stringArray.length;
                        n = 0;
                        while (n < n2) {
                            ipaddr = stringArray[n];
                            Pattern pattern = Pattern.compile("\\b((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\b");
                            if (instance.isLinux()) {
                                if (instance.inPrepState(PrepState.Preparing) || !instance.isImageInstance().booleanValue()) {
                                    instance = instance.getUpdate().fakePrepFinished().save();
                                    logger.info("VM {} support linux. fake PrepFinished.", (Object)vmname);
                                }
                                vmReady = true;
                                break;
                            }
                            logger.info("VM {} :ipaddr:{} {},isReadyToRun:{}", new Object[]{vmname, ipaddr, pattern.matcher(ipaddr).find(), instance.isReadyToRun()});
                            if (pattern.matcher(ipaddr).find() && instance.isReadyToRun() && vmResource.isIPAvailable(ipaddr)) {
                                vmReady = true;
                                newipaddress = ipaddr;
                                logger.info("VM {} Ready to run , ip {} available", (Object)vmname, (Object)ipaddr);
                                break;
                            }
                            ++n;
                        }
                        if (!vmReady) {
                            status = InstanceStatus.STARTINGCONN;
                            break;
                        }
                        if (!instance.isCheckpointed() && instance.shouldCheckpint()) {
                            boolean snapShotLive = Props.instance().get("policy.vm.snapshotlive", false);
                            instance.checkpoint(snapShotLive);
                            break;
                        }
                        status = InstanceStatus.RUNNING;
                        break;
                    }
                    if (current == InstanceStatus.STARTINGIP && !instance.hasPrepTask()) {
                        instance.configuringNetwork();
                    }
                    status = InstanceStatus.STARTINGIP;
                    break;
                }
                default: {
                    logger.info("Instance {} status {} can't be freshen. ", (Object)instance, (Object)current);
                    break;
                }
            }
        } else {
            switch (current) {
                case PRESTARTUP: 
                case CREATING: 
                case STARTUP: 
                case STARTINGCONN: 
                case STANDING: 
                case RESTARTING: 
                case BROKEN: 
                case DESTROYED: {
                    status = current;
                    break;
                }
                case UNKNOWN: 
                case STARTINGIP: 
                case RUNNING: 
                case PRESHUTDOWN: 
                case SHUTDOWN: {
                    status = InstanceStatus.SHUTDOWN;
                    break;
                }
                default: {
                    logger.info("Instance {} status {} can't be freshen. ", (Object)instance, (Object)current);
                }
            }
        }
        String ipaddress = null;
        ipaddress = instance.getIpaddress();
        if (!vmRunning && !StringUtils.isBlank((CharSequence)ipaddress)) {
            instance = instance.getUpdate().setIpaddress("").save();
            logger.info("clear vm {} ipaddress {} to empty", (Object)vmname, (Object)newipaddress);
        } else if (!instance.getStatus().equals((Object)InstanceStatus.CREATING)) {
            String subType;
            String newguestos;
            String guestos;
            String disksize;
            if (newipaddress != null) {
                if (newipaddress.contains(";")) {
                    if (StringUtils.isBlank((CharSequence)ipaddress) || !newipaddress.contains(ipaddress)) {
                        stringArray = newipaddress.split(";");
                        n2 = stringArray.length;
                        n = 0;
                        while (n < n2) {
                            ipaddr = stringArray[n];
                            if (vmResource.isIPAvailable(ipaddr)) {
                                newipaddress = ipaddr;
                                logger.info("VM {} Ready to run , ip {} available", (Object)vmname, (Object)ipaddr);
                                break;
                            }
                            ++n;
                        }
                    }
                    if (newipaddress.contains(ipaddress) && StringUtils.isNotBlank((CharSequence)ipaddress)) {
                        newipaddress = ipaddress;
                    }
                }
                if (StringUtils.isBlank((CharSequence)ipaddress) || !StringUtils.equals((CharSequence)newipaddress, (CharSequence)ipaddress)) {
                    instance = instance.getUpdate().setIpaddress(newipaddress);
                    instance.save();
                    if (instance.getStatus() == InstanceStatus.RUNNING && !instance.isImageInstance().booleanValue() && instance.getTemplate().isDrift() && !vmResource.isIPAvailable(newipaddress)) {
                        instance.regenerate();
                        logger.info("the vm[] ip[{}]   is not available,the vm will regenerate", (Object)vmname, (Object)newipaddress);
                    }
                    logger.info("update vm {}  from {} to {}", new Object[]{vmname, ipaddress, newipaddress});
                }
            }
            if (StringUtils.isEmpty((CharSequence)(disksize = (String)instance.getVmParam("disksize"))) && (ipaddress != null || newipaddress != null)) {
                String newdisksize = null;
                try {
                    DiskInfo[] diskinfo = this.getFactory().getVMInfo(vmname).getGuestDiskInfo();
                    if (diskinfo != null && diskinfo.length > 0 && diskinfo[0] != null) {
                        newdisksize = "" + diskinfo[0].getCapacity();
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                if (StringUtils.isNotEmpty(newdisksize)) {
                    if (newdisksize.indexOf(".") != -1) {
                        newdisksize = newdisksize.substring(0, newdisksize.indexOf("."));
                    }
                    instance.getUpdate().setVmParam("disksize", newdisksize).save();
                    logger.info("freshen {} disksize {}", (Object)instance.toString(), (Object)newdisksize);
                }
            }
            if (StringUtils.isEmpty((CharSequence)(guestos = (String)instance.getVmParam("guestos"))) && StringUtils.isNotEmpty((CharSequence)(newguestos = this.getFactory().getVMInfo(vmname).getGuestOSName()))) {
                instance.getUpdate().setVmParam("guestos", newguestos).save();
                logger.info("freshen {} newguestos {}", (Object)instance.toString(), (Object)newguestos);
            }
            if (StringUtils.isBlank((CharSequence)(subType = (String)instance.getVmParam("subType"))) && StringUtils.isNotBlank((CharSequence)(subType = this.getFactory().getVMInfo(vmname).getSubType()))) {
                instance.getUpdate().setVmParam("subType", subType).save();
                logger.info("freshen {} subType {}", (Object)instance.toString(), (Object)subType);
            }
        }
        if (!status.equals((Object)current)) {
            if (current.equals((Object)InstanceStatus.RUNNING) && status.equals((Object)InstanceStatus.SHUTDOWN) && instance.hasPrepTask() && instance.inPrepState(PrepState.Preparing)) {
                new PrepareManager(instance).onEvent(new PrepareManager.VmShutdownEvent());
            }
            if (!(instance = instance.getUpdate()).hasVmParam("phase")) {
                instance.enterStatus(status);
            } else {
                logger.info("instance {} is in phase {}, status change to {} is canceled ", new Object[]{vmname, instance.getVmParam("phase"), status});
            }
        }
        status = instance.getStatus();
        if (instance.isImporting() && status == InstanceStatus.RUNNING) {
            if (instance.isLinux()) {
                if (instance.isLinux() && instance.getAgentStatus() != AgentStatus.YES) {
                    logger.info("instance {} support liux , skip agent install ", (Object)instance.getName());
                    instance = instance.getUpdate().setAgentStatus(AgentStatus.YES).setVmParam("agentversion", "2.0.0").save();
                }
            } else if (instance.isAutoInstallAgent() && instance.getAgentStatus().equals((Object)AgentStatus.INITIAL)) {
                logger.info(" ip address :{} isAutoInstallAgent", (Object)instance.getIpaddress());
                instance.agentInstall();
            }
        }
        if ((instance = instance.getUpdate()).isSpice() && instance.isLocal() && vmRunning) {
            if (instance.isSaveVMNetworkConfig()) {
                String serverIP = DeskPoolCacheManager.getServerIp();
                if (!instance.isLinux() && !StringUtils.equals((CharSequence)instance.getVmParam("server_ip", "NULL"), (CharSequence)serverIP) && StringUtils.isNotEmpty((CharSequence)serverIP)) {
                    logger.info("{}[ip={}] setVmDataByAgent", (Object)instance, (Object)instance.getIpaddress());
                    instance.setVmDataByAgent();
                }
            } else if (StringUtils.isNotEmpty((CharSequence)ipaddress) || StringUtils.isNotEmpty((CharSequence)newipaddress)) {
                logger.info("configuringNetwork \uff1athe vm{}", (Object)instance.getVmname());
                instance.configuringNetwork();
            }
        }
        if (this.vmAndServerHost.containsKey(vmname)) {
            instance.refreshServerHost(this.vmAndServerHost.get(vmname));
        }
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable()) {
            return true;
        }
        this.process();
        return true;
    }

    private void checkRefreshTime(long startTime, IServerBean server) {
        long slowTime = Props.instance().get("server.refresh.slow", 100);
        long longTime = Props.instance().get("server.refresh.long", 150);
        long hostTime = (System.currentTimeMillis() - startTime) / 1000L;
        if (hostTime > longTime) {
            new TrackerService.Writer.Server().refreshLong(server).message("tracker.server.instance.refresh.host", 10, new String[]{"$time", "" + hostTime});
        } else if (hostTime > slowTime) {
            new TrackerService.Writer.Server().refreshSlow(server).message("tracker.server.instance.refresh.host", 10, new String[]{"$time", "" + hostTime});
        }
    }

    public static class Message
    extends Agent.Message {
        private static final long serialVersionUID = 1L;
        private static String engineName = null;

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
