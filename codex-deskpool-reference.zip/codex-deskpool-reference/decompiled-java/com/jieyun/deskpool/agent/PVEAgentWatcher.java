/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.HostInfo;
import com.jieyun.deskpool.vm.VMControlFactory;
import com.jieyun.deskpool.vm.VMResource;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

@Deprecated
public class PVEAgentWatcher
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final String ENGINE_NAME = "PVEAgentWatcher";
    private static final int HEARTBEAT_TIME = 120;
    private static String SERVER_IP = null;
    VMControlFactory factory = null;

    public synchronized void reset() {
        Config config;
        if (this.factory != null) {
            this.factory.release();
            this.factory = null;
        }
        if (!(config = Config.Store.get()).vmIs(Config.VM.Type.none)) {
            this.factory = VMControlFactory.get(config);
            this.factory.connect();
        }
    }

    protected VMControlFactory getFactory() {
        return this.factory;
    }

    public PVEAgentWatcher() {
        this(new Event.TimedEngine(ENGINE_NAME, 120L){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    protected PVEAgentWatcher(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        IServerBean server = Services.getServerService().getCurrent();
        if (server != null && server.isOnline() && "pve".equals(server.getHost_type())) {
            this.checkAgentData();
        }
        return false;
    }

    private void checkAgentData() {
        this.reset();
        SERVER_IP = NetUtils.getHostIP();
        if (StringUtils.isEmpty((CharSequence)SERVER_IP)) {
            return;
        }
        HostInfo hostInfo = this.getFactory().getHostInfo(null);
        VMResource vmResource = this.getFactory().getVMOperations();
        Map<String, String> statuslist = hostInfo.getAllStatus();
        String vmName = null;
        for (IInstanceBean instance : Services.getInstanceService().findAll()) {
            vmName = instance.getVmname();
            if (!StringUtils.equals((CharSequence)"running", (CharSequence)statuslist.get(vmName)) || !StringUtils.equals((CharSequence)instance.getVmParam("server_ip", "NULL"), (CharSequence)SERVER_IP)) continue;
            vmResource.setDeskPoolData(vmName, instance.Id().toSerializeId(), SERVER_IP);
        }
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
