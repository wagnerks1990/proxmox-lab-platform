/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;

public static class CommandStub.CommandResultE.Factory {
    public static CommandStub.CommandResultE parse(XMLStreamReader reader) throws Exception {
        CommandStub.CommandResultE object = new CommandStub.CommandResultE();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
            if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                while (!reader.isEndElement()) {
                    reader.next();
                }
                return object;
            }
            Vector handledAttributes = new Vector();
            while (!reader.isEndElement()) {
                if (reader.isStartElement()) {
                    if (reader.isStartElement() && new QName("http://schemas.datacontract.org/2004/07/Citrix.VDI.Inside.Support", "CommandResult").equals(reader.getName())) {
                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                            object.setCommandResult(null);
                            reader.next();
                            continue;
                        }
                        object.setCommandResult(CommandStub.CommandResult.Factory.parse(reader));
                        continue;
                    }
                    throw new ADBException("Unexpected subelement " + reader.getName());
                }
                reader.next();
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
