/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.utils.JYTimedEngine;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.vm.Event;
import java.io.File;

public class Axis2TempFileWatcher
extends JYTimedEngine
implements ApplicationLifecycle.LifecycleListener {
    public Axis2TempFileWatcher(String name, long seconds) {
        super(name, seconds);
        this.subscribe(Message.class, new EventHandler());
    }

    @Override
    public boolean isRejectWorking() {
        return false;
    }

    @Override
    protected Event defaultEvent() {
        return new Message();
    }

    @Override
    public void onStart() {
        this.start();
    }

    @Override
    public void onShutdown() {
        this.quit();
    }

    public class EventHandler
    implements Event.Recipient {
        @Override
        public boolean receive(Event paramEvent) {
            File file = new File(System.getProperty("java.io.tmpdir"));
            if (file.exists()) {
                File[] subfiles;
                File[] fileArray = subfiles = file.listFiles();
                int n = subfiles.length;
                int n2 = 0;
                while (n2 < n) {
                    File axisFile = fileArray[n2];
                    if (axisFile.getName().contains("axis") && axisFile.isDirectory()) {
                        this.deleteInvalidateFile(axisFile);
                    }
                    ++n2;
                }
            }
            return true;
        }

        private void deleteInvalidateFile(File dir) {
            File[] files = dir.listFiles();
            if (files != null) {
                File[] fileArray = files;
                int n = files.length;
                int n2 = 0;
                while (n2 < n) {
                    File file = fileArray[n2];
                    file.delete();
                    ++n2;
                }
            }
            dir.delete();
        }
    }

    public class Message
    extends Agent.Message {
    }
}
