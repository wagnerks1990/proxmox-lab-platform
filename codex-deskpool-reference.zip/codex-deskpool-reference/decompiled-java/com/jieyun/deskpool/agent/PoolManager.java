/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.deskpool.constant.DeskpoolConfigConstant;
import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.AwakeningWatcher;
import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.front.ServerFront;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.JieyunLicense;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.NetworkConfigVO;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.Resource;
import com.jieyun.deskpool.shared.ServerStatus;
import com.jieyun.deskpool.shared.SystemStatus;
import com.jieyun.deskpool.shared.TemplatePolicy;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.text.NumberFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PoolManager
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(PoolManager.class);
    private static String engineName = "poolmanager";
    private static int REPEAT_SHORT = 30;
    private static boolean hasrecovered = false;
    private static int serverLoadCount = 0;
    private static int diskFreshCount = 0;
    private static long startTime = System.nanoTime();
    private static Map<String, String> lastCountInfo = new HashMap<String, String>();
    private static AwakeningWatcher awakeningWatcher = new AwakeningWatcher();
    private static long LEAVEN_CLUSTER_TIME = -1L;

    private boolean isServiceStarting() {
        double startingPeriod;
        long period = (System.nanoTime() - startTime) / 1000000L;
        return (double)period < 1000.0 * (startingPeriod = (double)Props.instance().get("server.starting.duration", 60));
    }

    private boolean isWaitMergeCluster() {
        double startingPeriod;
        if (LEAVEN_CLUSTER_TIME == -1L || Services.getServerService().findAll().size() <= 1) {
            return false;
        }
        long period = (System.nanoTime() - LEAVEN_CLUSTER_TIME) / 1000000L;
        return (double)period < 1000.0 * (startingPeriod = (double)Props.instance().get("server.merge.duration", 120));
    }

    public PoolManager() {
        this(new Event.TimedEngine(engineName, REPEAT_SHORT){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    public PoolManager(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    private int reuseVm(ITemplateBean template, IServerBean server, int allocate) {
        int reused = 0;
        if (allocate <= 0) {
            return reused;
        }
        List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(template.Id());
        for (IInstanceBean item : instanceList) {
            item = item.getUpdate();
            item.lock();
            try {
                if (!item.getServerId().equals(server.Id())) continue;
                if (item.isReadyToRun() && item.getStatus().equals((Object)InstanceStatus.SHUTDOWN) && !item.isAssigned() && !item.hasVmParam("phase")) {
                    logger.info("poolManager reuse {} ", (Object)item);
                    item.start();
                    ++reused;
                    --allocate;
                }
                if (allocate != 0) continue;
                break;
            }
            finally {
                item.unlock();
            }
        }
        return reused;
    }

    private int clearShutdownVm(ITemplateBean template, IServerBean server) {
        int count = 0;
        List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(template.Id());
        for (IInstanceBean item : instanceList) {
            if (!item.getServerId().equals(server.Id())) continue;
            if (item.getStatus().equals((Object)InstanceStatus.SHUTDOWN) && !item.isAssigned() && !item.hasVmParam("phase") && !item.isSleeped()) {
                logger.info("poolManager destroy unused shutdown   VM {} ", (Object)item);
                item.destroyImplicitly();
            }
            ++count;
        }
        return count;
    }

    private int evaluateLoading(IServerBean server, ITemplateBean template) {
        int countByStarting;
        int result;
        double power = 0.0;
        int startingCount = 0;
        Props props = Props.instance();
        double maxServerLoad = props.get("server.load.max", 0.95);
        int maxServerStart = props.get("server.starting.max", 10);
        List<IInstanceBean> allInstances = Services.getInstanceService().findByServer(server.Id());
        for (IInstanceBean instance : allInstances) {
            InstanceStatus status = instance.getStatus();
            if (!status.equals((Object)InstanceStatus.STANDING) || instance.hasVmParam("phase")) {
                power += instance.getPower().ratio(server.getPower());
            }
            if (!status.isStarting() || !instance.hasVmParam("prepvm")) continue;
            ++startingCount;
        }
        NumberFormat nf = NumberFormat.getPercentInstance();
        logger.info("evaluateLoading  scan status : startingCount {} power {}", (Object)startingCount, (Object)nf.format(power));
        int countByLoading = (int)Math.floor((maxServerLoad - power) / template.getPower().ratio(server.getPower()));
        if (countByLoading <= 0) {
            double powerAfterAlloc = power + template.getPower().ratio(server.getPower());
            if (power > maxServerLoad) {
                new TrackerService.Writer.Server().allocate(server).message("error.server.overload", new String[]{"$template", template.getName(), "$maxload", nf.format(maxServerLoad), "$load", nf.format(power), "$server", server.getName()});
            } else if (powerAfterAlloc > maxServerLoad) {
                new TrackerService.Writer.Server().allocate(server).message("warning.server.overload", new String[]{"$template", template.getName(), "$maxload", nf.format(maxServerLoad), "$load", nf.format(powerAfterAlloc), "$server", server.getName()});
            }
        }
        result = (result = Math.min(countByLoading, countByStarting = maxServerStart - startingCount)) < 0 ? 0 : result;
        logger.info("evaluateLoading : byLoading {}  byStarting {}, return {}", new Object[]{countByLoading, countByStarting, result});
        return result;
    }

    private void countServerLoad(IServerBean server) {
        double power = 0.0;
        List<IInstanceBean> allInstances = Services.getInstanceService().findByServer(server.Id());
        for (IInstanceBean instance : allInstances) {
            InstanceStatus status = instance.getStatus();
            if (status.equals((Object)InstanceStatus.STANDING)) continue;
            power += instance.getPower().ratio(server.getPower());
        }
        server.setCapacity(new Resource.Capacity(1.0, power));
        server.save();
    }

    /*
     * Unable to fully structure code
     */
    private void manage(boolean refreshHostInfo) {
        templateList = Services.getTemplateService().findAll();
        server = Services.getServerService().getCurrent();
        if (server == null) {
            return;
        }
        if (server.isWitness()) {
            this.refreshWitness(server);
            return;
        }
        this.regenerateWait();
        if (PoolManager.diskFreshCount % 100 == 2) {
            Services.getUserDiskService().freshAllDisk();
        }
        PoolManager.diskFreshCount = (PoolManager.diskFreshCount + 1) % 100;
        if (refreshHostInfo || PoolManager.serverLoadCount % 6 == 0) {
            PoolManager.logger.info("call server.freshen");
            server = server.freshen();
            PoolManager.logger.info("server.freshen Status:{}", (Object)server.getStatus());
            serverCfg = server.getUpdate();
            if (!server.getHost_address().equals(serverCfg.getHost_address())) {
                PoolManager.logger.warn("SERVERCFG error {} {}", (Object)serverCfg.getHost_address(), (Object)server.getHost_address());
            }
            server.setHost_address(serverCfg.getHost_address());
            server.setHost_user(serverCfg.getHost_user());
            server.setHost_password(serverCfg.getHost_password());
            server.setDatastore(serverCfg.getDatastore());
            server.setNetwork(serverCfg.getNetwork());
            list = server.getMACAddr();
            if (list != null && list.size() > 0) {
                server.setHost_macAddr(server.getMACAddress(list));
            }
            server = server.save();
            this.saveNetworkAndNodeInfo(server.getUpdate());
            server = (IServerBean)server.refresh();
        }
        PoolManager.serverLoadCount = (PoolManager.serverLoadCount + 1) % 6;
        this.countServerLoad(server);
        if (JieyunLicense.get().getIndate().strike()) {
            PoolManager.logger.info("PoolManager License strike !");
            for (IInstanceBean instance : Services.getInstanceService().findByServer(server.Id())) {
                if (instance.getStatus() != InstanceStatus.RUNNING) continue;
                instance.shutdown();
            }
            return;
        }
        if (!JieyunLicense.get().getIndate().valid()) {
            PoolManager.logger.info("PoolManager License error !");
            return;
        }
        PoolManager.logger.debug("check ClusterNodeBean isActive");
        if (!ClusterNodeBean.isActive()) {
            PoolManager.logger.info("The number of survival in the cluster is not more than half");
            PoolManager.LEAVEN_CLUSTER_TIME = System.nanoTime();
            return;
        }
        if (!server.isOnline()) {
            PoolManager.logger.info("the server[{}] is Off-line", (Object)server.getName());
            return;
        }
        if (this.isWaitMergeCluster()) {
            PoolManager.logger.info("the cluster is Merge ! wait .....");
            return;
        }
        if (Services.getSystemService().getServiceStatus() == SystemStatus.MAINTENANCE) {
            PoolManager.logger.info("System is in Maintenance mode ! Pool Manage is stoped.");
            return;
        }
        block3: for (ITemplateBean template : templateList) {
            if (PoolType.DEDICATED == template.getPoolType() && !JieyunLicense.get().getFeature().dedicatedDesktop()) {
                PoolManager.logger.error("No dedicate desktop License! dedicate desktop is not processed.");
                continue;
            }
            if (PoolType.POOLED == template.getPoolType() && !JieyunLicense.get().getFeature().pulicDesktop()) {
                PoolManager.logger.error("No public desktop License! public desktop is not processed.");
                continue;
            }
            templateUpdate = template.getUpdate();
            if (templateUpdate.updateStatus()) {
                templateUpdate.save();
                template = templateUpdate;
            }
            template.enforceSchedule();
            instanceList = Services.getInstanceService().findByTemplate(template.Id());
            alloc = this.allocate(template, instanceList);
            if (alloc.allocate > 0) {
                loadingCount = this.evaluateLoading(server, template);
                reuseCount = this.reuseVm(template, server, Math.min(alloc.allocate, loadingCount));
                if (reuseCount != 0) continue;
                if (this.isLicenseCreateDeny()) {
                    return;
                }
                PoolManager.logger.error("Gateway is {}", (Object)GatewayManager.instance().isServiceNormal());
                if (template.getImage().getLocalParcel() == null || !GatewayManager.instance().isServiceNormal()) continue;
                index = 0;
                while (index < Math.min(alloc.allocate, loadingCount)) {
                    block26: {
                        try {
                            Services.getInstanceService().createInstance(template, server);
                            break block26;
                        }
                        catch (JYServiceException e) {
                            e.printStackTrace();
                            ** for (item : e.getErrorList())
                        }
lbl-1000:
                        // 1 sources

                        {
                            PoolManager.logger.error("[" + item.getErrorId() + "]");
                            continue;
                        }
                    }
                    ++index;
                }
                continue;
            }
            if (alloc.allocate < 0) {
                props = Props.instance();
                startingmax = props.get("server.starting.max", 10);
                maxDestroying = props.get("server.destroying.max", startingmax);
                index = 0;
                while (index < maxDestroying) {
                    if (!this.decreaseDeskpool(template, instanceList)) continue block3;
                    ++alloc.allocate;
                    if (alloc.allocate == 0) continue block3;
                    ++index;
                }
                continue;
            }
            if (alloc.reuse > 0) {
                loadingCount = this.evaluateLoading(server, template);
                reuseCount = this.reuseVm(template, server, Math.min(alloc.reuse, loadingCount));
                PoolManager.logger.info(" {} instances has been reused! ", (Object)reuseCount);
                continue;
            }
            this.clearShutdownVm(template, server);
        }
    }

    private boolean decreaseDeskpool(ITemplateBean template, List<IInstanceBean> instanceList) {
        boolean deallocated = false;
        if (!instanceList.isEmpty()) {
            Collections.sort(instanceList, new Comparator<IInstanceBean>(){

                @Override
                public int compare(IInstanceBean o1, IInstanceBean o2) {
                    String o1Value = o1.getName();
                    String o2Value = o2.getName();
                    if (o1Value == null && o2Value == null) {
                        return 0;
                    }
                    if (o1Value == null && o2Value != null) {
                        return -1;
                    }
                    if (o1Value != null && o2Value == null) {
                        return 1;
                    }
                    return -o1Value.compareTo(o2Value);
                }
            });
        }
        for (IInstanceBean instance : instanceList) {
            if (!instance.isLocal() || !instance.getStatus().equals((Object)InstanceStatus.SHUTDOWN) || instance.isAssigned()) continue;
            instance.destroyImplicitly();
            instanceList.remove(instance);
            deallocated = true;
            break;
        }
        if (!deallocated) {
            IInstanceBean startingInstance = null;
            for (IInstanceBean instance : instanceList) {
                if (!instance.isLocal() || !instance.getStatus().isStarting() || instance.isAssigned() || startingInstance != null && startingInstance.getStatus().compareTo(instance.getStatus()) <= 0) continue;
                startingInstance = instance;
            }
            if (startingInstance != null) {
                startingInstance.destroyImplicitly();
                instanceList.remove(startingInstance);
                deallocated = true;
            }
        }
        if (!deallocated) {
            for (IInstanceBean instance : instanceList) {
                if (!instance.isLocal() || !instance.getStatus().equals((Object)InstanceStatus.RUNNING) || instance.isAssigned()) continue;
                instance.destroyImplicitly();
                instanceList.remove(instance);
                deallocated = true;
                break;
            }
        }
        if (!deallocated && template.isPooled()) {
            for (IInstanceBean instance : instanceList) {
                if (!instance.isLocal() || !instance.isAssigned() || instance.isSessionActive()) continue;
                instance.destroyImplicitly();
                deallocated = true;
                break;
            }
        }
        return deallocated;
    }

    private boolean isLicenseCreateDeny() {
        boolean deny;
        Integer maxDesktops = JieyunLicense.get().getCount().desktops();
        if (maxDesktops == null) {
            return false;
        }
        int runtimeCount = 0;
        try {
            IServerBean serverBean = Services.getServerService().getCurrent();
            List<ITemplateBean> tpls = Services.getTemplateService().findAll();
            for (ITemplateBean tplBean : tpls) {
                runtimeCount += serverBean.countInstancebyStatus(tplBean).getTotal().intValue();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        boolean bl = deny = runtimeCount + 1 > maxDesktops;
        if (deny) {
            try {
                new TrackerService.Writer.Server().desktopOverload(Services.getServerService().getCurrent()).message("warning.license.desktop.overload", new String[]{"$allow", "" + maxDesktops, "$used", String.valueOf(runtimeCount)});
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return deny;
    }

    public static PoolInfo countByStatus(List<IInstanceBean> instances, ITemplateBean template) {
        int countIdle = 0;
        int countInuse = 0;
        int countOnhold = 0;
        int countBroken = 0;
        int countSleeping = 0;
        int countStarting = 0;
        int countOther = 0;
        int countAll = 0;
        int countRunning = 0;
        IServerBean server = null;
        for (IInstanceBean instance : instances) {
            if (template != null && !instance.inTemplate(template) || (server = instance.getServer()) != null && ServerStatus.STATUS_MISSING.equals((Object)server.getStatus()) && DeskpoolConfigConstant.HACLUSTER && DeskpoolConfigConstant.MISS_CREATE) continue;
            InstanceStatus status = instance.getStatus();
            ++countAll;
            if (status.equals((Object)InstanceStatus.RUNNING)) {
                ++countRunning;
            }
            if (instance.isAssigned()) {
                if (instance.isSessionActive()) {
                    ++countInuse;
                    continue;
                }
                ++countOnhold;
                continue;
            }
            if (status.equals((Object)InstanceStatus.RUNNING)) {
                ++countIdle;
                continue;
            }
            if (instance.isSleeped()) {
                ++countSleeping;
                continue;
            }
            if (status.equals((Object)InstanceStatus.CREATING) || status.equals((Object)InstanceStatus.STARTUP) || status.equals((Object)InstanceStatus.PRESTARTUP) || status.equals((Object)InstanceStatus.STARTINGIP) || status.equals((Object)InstanceStatus.STARTINGCONN) || status.equals((Object)InstanceStatus.RESTARTING) || status.equals((Object)InstanceStatus.STANDING)) {
                ++countStarting;
                continue;
            }
            ++countOther;
            if (!status.equals((Object)InstanceStatus.BROKEN)) continue;
            ++countBroken;
        }
        PoolInfo poolInfo = new PoolInfo();
        poolInfo.setTotal(countAll);
        poolInfo.setInuse(countInuse);
        poolInfo.setOther(countOther);
        poolInfo.setOnhold(countOnhold);
        poolInfo.setIdle(countIdle);
        poolInfo.setStarting(countStarting);
        poolInfo.setBroken(countBroken);
        poolInfo.setSleeping(countSleeping);
        poolInfo.setRunning(countRunning);
        return poolInfo;
    }

    AllocInfo allocate(ITemplateBean template, List<IInstanceBean> instances) {
        int imagePacelCount;
        AllocInfo alloc = new AllocInfo(0, 0);
        TemplatePolicy policy = template.getPolicy();
        if (policy == null) {
            return alloc;
        }
        PoolInfo poolInfo = PoolManager.countByStatus(instances, null);
        template = template.getUpdate().setPoolInfo(poolInfo).save();
        if (poolInfo.getIdle() + poolInfo.getSleeping() > policy.getPrestart()) {
            alloc.allocate = policy.getPrestart() - poolInfo.getIdle() - poolInfo.getSleeping();
        } else if (poolInfo.getIdle() + poolInfo.getSleeping() + poolInfo.getStarting() > policy.getPrestart()) {
            alloc.allocate = policy.getPrestart() - poolInfo.getIdle() - poolInfo.getStarting() - poolInfo.getSleeping();
        } else if (poolInfo.getIdle() + poolInfo.getSleeping() + poolInfo.getUsed() > policy.getMaximum()) {
            alloc.allocate = policy.getMaximum() - poolInfo.getIdle() - poolInfo.getUsed() - poolInfo.getSleeping();
            if (alloc.allocate + poolInfo.getIdle() + poolInfo.getSleeping() < 0) {
                alloc.allocate = 0 - poolInfo.getIdle() - poolInfo.getSleeping();
            }
        } else if (poolInfo.getIdle() + poolInfo.getSleeping() + poolInfo.getStarting() < policy.getPrestart() && poolInfo.getTotal() < policy.getMaximum()) {
            alloc.allocate = Math.min(policy.getPrestart() - poolInfo.getIdle() - poolInfo.getStarting() - poolInfo.getSleeping(), policy.getMaximum() - poolInfo.getTotal());
        } else if (poolInfo.getTotal() > policy.getMaximum()) {
            alloc.allocate = policy.getMaximum() - poolInfo.getTotal();
        } else if (poolInfo.getTotal() == policy.getMaximum() && poolInfo.getIdle() + poolInfo.getSleeping() + poolInfo.getStarting() < policy.getPrestart() && poolInfo.getOther() > 0) {
            alloc.reuse = Math.min(policy.getPrestart() - poolInfo.getIdle() - poolInfo.getSleeping() - poolInfo.getStarting(), poolInfo.getOther());
        }
        String currentCountInfo = String.format("Pool[%s] Allocate = %d reuse %d  [inuse %d, onhold %d  idle %d, sleeping %d, starting %d, other %d all %d]", template.getName(), alloc.allocate, alloc.reuse, poolInfo.getInuse(), poolInfo.getOnhold(), poolInfo.getIdle(), poolInfo.getSleeping(), poolInfo.getStarting(), poolInfo.getOther(), poolInfo.getTotal());
        if (!StringUtils.equals((CharSequence)lastCountInfo.get(template.getName()), (CharSequence)currentCountInfo)) {
            logger.info(currentCountInfo);
            lastCountInfo.put(template.getName(), currentCountInfo);
        }
        if ((imagePacelCount = Services.getParcelService().getReadyParcel(template.getImage()).size()) > 1) {
            IServerBean server = Services.getServerService().getCurrent();
            PoolInfo poolInfoLocal = server.countInstancebyStatus(template);
            int target = poolInfo.getTotal() + alloc.allocate;
            if (alloc.allocate > 0) {
                int avg_alloc_min = alloc.allocate / imagePacelCount;
                int avg_alloc_max = (alloc.allocate + imagePacelCount - 1) / imagePacelCount;
                int allocate2 = (target + imagePacelCount - 1) / imagePacelCount - poolInfoLocal.getTotal();
                logger.info(" target {}  local total {} allocate {} avg_alloc_max = {}  allocate2(full alloc) = {} ", new Object[]{target, poolInfoLocal.getTotal(), alloc.allocate, avg_alloc_max, allocate2});
                if (allocate2 > 0) {
                    alloc.allocate = Math.max(allocate2 - (1 + avg_alloc_max) / 2, 1);
                } else {
                    int result = (int)(Math.random() * (double)imagePacelCount) == 0 ? 1 : 0;
                    alloc.allocate = Math.max(avg_alloc_max / 2, result);
                }
                logger.info(" allocate {}", (Object)alloc.allocate);
            } else if (alloc.allocate < 0) {
                int allocate1 = (alloc.allocate - imagePacelCount + 1) / imagePacelCount;
                int allocate2 = (target + imagePacelCount - 1) / imagePacelCount - poolInfoLocal.getTotal();
                logger.info(" target {}  local total {} allocate {} allocate1(average alloc) = {}  allocate2(full alloc) = {} ", new Object[]{target, poolInfoLocal.getTotal(), alloc.allocate, allocate1, allocate2});
                if (allocate2 < 0) {
                    alloc.allocate = Math.min(allocate2 - (allocate1 - 1) / 2, -1);
                } else {
                    int result = (int)(Math.random() * (double)imagePacelCount) == 0 ? -1 : 0;
                    alloc.allocate = Math.min(allocate1 / 2, result);
                }
                logger.info(" allocate {}", (Object)alloc.allocate);
            }
        }
        return alloc;
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable()) {
            return true;
        }
        IServerBean server = Services.getServerService().getCurrent();
        if (this.isServiceStarting()) {
            logger.info("system recovering...");
            try {
                logger.info(" HostIP {}  ServerIP {}  getDefaultIp {}", new Object[]{NetUtils.getHostIP(), NetUtils.getServerIp(), NetUtils.getDefaultIp()});
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            if (server != null) {
                new TrackerService.Writer.Server().booting(server).complete("server.booting.finished", new String[0]);
            }
            this.systemRecover();
        } else if (awakeningWatcher.isAwakening()) {
            if (server != null) {
                boolean oldOnline = server.isOnline();
                logger.info("system is awakening ...  old status is " + (Object)((Object)server.getStatus()));
                this.manage(true);
                server = (IServerBean)server.refresh();
                if (server.isOnline()) {
                    awakeningWatcher.awaken();
                    if (!oldOnline) {
                        logger.info("system awaken from server reboot, call executeRebootFreshPolicy");
                        Services.getTemplateService().executeRebootFreshPolicy();
                    } else {
                        logger.info("system awaken for deskpool vm save, or time changed. nothing to do.");
                    }
                } else {
                    logger.info("server is offline. continue in awakening ");
                }
            } else {
                awakeningWatcher.awaken();
            }
        } else {
            Message message = (Message)paramEvent;
            this.manage(message.isRefreshHost());
        }
        return true;
    }

    public void checkManagerIp() {
        NetworkConfig config = NetworkConfigFactory.createNetworkConfig();
        if (StringUtils.isEmpty((CharSequence)config.address())) {
            config.fixNetworkEth0();
        }
    }

    public void systemRecover() {
        IServerBean server;
        if (hasrecovered) {
            return;
        }
        this.checkManagerIp();
        logger.info("systemRecover call clearInvalidMessage");
        Services.getMessageService().clearInvalidMessage();
        logger.info("systemRecover call clearInvalidVmAccount");
        Services.getAccountService().clearInvalidVmAccount();
        logger.info("systemRecover load thinclient license");
        Services.getTcCertificateService().loadLicense();
        hasrecovered = true;
        try {
            server = Services.getServerService().getCurrent();
        }
        catch (Exception e) {
            e.printStackTrace();
            server = null;
        }
        if (server == null) {
            logger.info("There is no server config.  Don't execute systemRecover() ");
            return;
        }
        server.freshen().save();
        if ("YES".equalsIgnoreCase(Props.instance().get("resetadmin", "NO"))) {
            logger.info("reset admin password ");
            String defaultAdminPassword = AppProps.instance().get("admin.password", "deskpool");
            logger.info("defaultAdminPassword {}", (Object)defaultAdminPassword);
            IAccountBean user = Services.getAccountService().findByName("admin");
            if (user != null) {
                logger.info(" Secured password : {}", (Object)user.getPassword());
                user.updatePassword(defaultAdminPassword);
                user.save();
                user = Services.getAccountService().findByName("admin");
                logger.info(" Secured password reseted :{}", (Object)user.getPassword());
            } else {
                logger.info(" setupAdmin() ");
                Services.getSetupService().setupAdmin();
                logger.info(" Secured password : {}", (Object)user.getPassword());
            }
        }
        List<IInstanceBean> list = Services.getInstanceService().findByServer(server);
        for (IInstanceBean instance : list) {
            instance.recover();
        }
    }

    private void saveNetworkAndNodeInfo(IServerBean.Update update) {
        Stopwatch timer = new Stopwatch("PoolManager.saveNetworkAndNodeInfo()");
        try {
            try {
                NetworkConfigVO vo = update.readNetworkConfig();
                List<ServerFront.NodeInfoFront> nodeList = update.getNodeInfoList();
                if (!nodeList.isEmpty()) {
                    update.setNetworkStr(vo);
                    update.setNodeInfoListStr(nodeList);
                    update.save();
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                timer.stop();
            }
        }
        finally {
            timer.stop();
        }
    }

    private void refreshWitness(IServerBean server) {
        block7: {
            Stopwatch timer = new Stopwatch("PoolManager.refreshWitness()");
            try {
                try {
                    IServerBean.Update update = server.getUpdate();
                    NetworkConfigVO vo = update.readNetworkConfig();
                    update.setName(vo.getAddress());
                    update.setNetworkStr(vo);
                    update.save();
                }
                catch (Exception e) {
                    e.printStackTrace();
                    timer.stop();
                    break block7;
                }
            }
            catch (Throwable throwable) {
                timer.stop();
                throw throwable;
            }
            timer.stop();
        }
        long sleepTimes = Props.instance().get("server.refreshWitness.duration", 10);
        try {
            Thread.sleep(sleepTimes * 60L * 1000L);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void regenerateWait() {
        ITemplateBean tem = null;
        for (IInstanceBean instance : Services.getInstanceService().findAll()) {
            if (!instance.isLocal() || !instance.isWaitGegenerate()) continue;
            logger.info("instance[{}] user has been transferred, desktop will be regenerate.", (Object)instance.getName());
            instance = instance.getUpdate().setWaitGegenerate(false).save();
            tem = instance.getTemplate();
            if (tem != null && PoolType.POOLED.equals((Object)instance.getTemplate().getPoolType())) {
                instance.regenerate();
            }
            logger.info("the instance [] regenerate end!", (Object)instance.getName());
        }
    }

    static class AllocInfo {
        int allocate;
        int reuse;

        public AllocInfo(int alloc, int reuse) {
            this.allocate = alloc;
            this.reuse = reuse;
        }
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
