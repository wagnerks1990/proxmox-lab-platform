/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;

public static class CommandStub.DisconnectAllUsersResponse.Factory {
    public static CommandStub.DisconnectAllUsersResponse parse(XMLStreamReader reader) throws Exception {
        CommandStub.DisconnectAllUsersResponse object = new CommandStub.DisconnectAllUsersResponse();
        Object nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            String fullTypeName;
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null && (fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type")) != null) {
                String nsPrefix = null;
                if (fullTypeName.indexOf(":") > -1) {
                    nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                }
                nsPrefix = nsPrefix == null ? "" : nsPrefix;
                String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);
                if (!"DisconnectAllUsersResponse".equals(type)) {
                    String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                    return (CommandStub.DisconnectAllUsersResponse)CommandStub.ExtensionMapper.getTypeObject(nsUri, type, reader);
                }
            }
            Vector handledAttributes = new Vector();
            reader.next();
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement() && new QName("http://tempuri.org/", "DisconnectAllUsersResult").equals(reader.getName())) {
                object.setDisconnectAllUsersResult(CommandStub.CommandResult.Factory.parse(reader));
                reader.next();
            }
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement()) {
                throw new ADBException("Unexpected subelement " + reader.getName());
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
