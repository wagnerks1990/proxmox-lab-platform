/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.domain.SgwServerConfig;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.SgwClientService;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.IPv4Util;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.vm.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SgwWatch
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(SgwWatch.class);
    private static final String sgw_WATCH_NAME = "sgwWatch";
    private static final int sgw_WATCH_TIME = 60;
    private static boolean isBusy = false;

    public SgwWatch() {
        this(new Event.TimedEngine(sgw_WATCH_NAME, 60L){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    public SgwWatch(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    protected SgwWatch(Event.Engine engine) {
        super(engine);
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable() || isBusy || !NetUtils.isLiux()) {
            return true;
        }
        isBusy = true;
        try {
            this.tick();
        }
        finally {
            isBusy = false;
        }
        return false;
    }

    private void tick() {
        this.refresh();
    }

    public void refresh() {
        SgwServerConfig sgwsConfig = Services.getClusterService().getCluster().getSgwServerConfig();
        if (!sgwsConfig.isEnableSgws()) {
            return;
        }
        if (!IPv4Util.pingIPPort(sgwsConfig.getDomain(), sgwsConfig.getVmPort(), 2000)) {
            logger.info("the sgws is stop! please check sgws!");
            return;
        }
        SgwClientService sgwcServcice = Services.getSgwClientService();
        switch (sgwcServcice.getStatus()) {
            case NONE: {
                sgwcServcice.install();
                logger.info("the sgwc is install!");
            }
            case PREREADY: {
                sgwcServcice.updateCommon();
                logger.info("the sgwc common is change!");
            }
            case SHUTDOWN: {
                sgwcServcice.start();
                logger.info("the sgwc  is start!");
            }
        }
        Services.getSgwClientService().syncVMConfig();
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
