/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.PVEAgentWatcher;
import com.jieyun.deskpool.vm.Event;

class PVEAgentWatcher.1
extends Event.TimedEngine {
    PVEAgentWatcher.1(String $anonymous0, long $anonymous1) {
        super($anonymous0, $anonymous1);
    }

    @Override
    protected Event defaultEvent() {
        return new PVEAgentWatcher.Message();
    }
}
