/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.SessionLockManager;
import java.util.Collection;

public static class SessionLockManager.TemplateSessionLock
extends SessionLockManager.OrderCheckReentrantLock {
    private static final long serialVersionUID = 1L;

    @Override
    protected void checkAndSet() {
        Collection localSeqList = (Collection)seqLockLocal.get();
        if (localSeqList.contains("gatewayLock")) {
            throw new RuntimeException("Lock reject , gateway is locking , can not acquire other lock .");
        }
        localSeqList.add("templateLock");
    }

    @Override
    protected void removeOrder() {
        ((Collection)seqLockLocal.get()).remove("templateLock");
    }
}
