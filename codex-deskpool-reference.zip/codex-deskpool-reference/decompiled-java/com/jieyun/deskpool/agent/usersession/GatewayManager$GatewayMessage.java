/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.Agent;

public static class GatewayManager.GatewayMessage
extends Agent.Message {
}
