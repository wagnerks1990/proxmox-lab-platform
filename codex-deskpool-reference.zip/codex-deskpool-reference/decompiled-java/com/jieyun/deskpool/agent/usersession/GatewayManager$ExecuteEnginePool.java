/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.vm.Event;

public static class GatewayManager.ExecuteEnginePool
extends Event.EnginePool {
    @Override
    public void init(Event.Engine engine) {
        engine.subscribe(GatewayManager.AllocateMessage.class, new GatewayManager.AllocateMessage.ResponseHandler());
        engine.subscribe(GatewayManager.ReleaseMessage.class, new GatewayManager.ReleaseMessage.ResponseHandler());
    }
}
