/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.SessionLockManager;
import java.util.concurrent.ConcurrentHashMap;

public static class SessionLockManager.AccountResourceHolder
extends ConcurrentHashMap<String, SessionLockManager.AccountSessionLock> {
    private String hashKey(String key) {
        String ikey = String.valueOf(key.hashCode() % 50);
        return ikey;
    }

    public SessionLockManager.AccountSessionLock createIfAbsent(String key) {
        SessionLockManager.AccountSessionLock newLock;
        String internalKey = this.hashKey(key);
        SessionLockManager.AccountSessionLock sessionLock = (SessionLockManager.AccountSessionLock)this.get(internalKey);
        if (sessionLock == null && (sessionLock = this.putIfAbsent(internalKey, newLock = new SessionLockManager.AccountSessionLock(internalKey, this))) == null) {
            sessionLock = newLock;
        }
        return sessionLock;
    }
}
