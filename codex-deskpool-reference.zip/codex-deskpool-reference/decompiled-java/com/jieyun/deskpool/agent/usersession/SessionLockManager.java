/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.UserSessionToken;
import java.util.Collection;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class SessionLockManager {
    private static SessionLockManager instance = new SessionLockManager();
    private AccountResourceHolder accountLockHolder = new AccountResourceHolder();
    private TemplateResourceHolder templateLockHolder = new TemplateResourceHolder();
    private static ThreadLocal<Collection<String>> seqLockLocal = new ThreadLocal<Collection<String>>(){

        @Override
        protected Collection<String> initialValue() {
            return new HashSet<String>();
        }
    };

    public static SessionLockManager instance() {
        return instance;
    }

    public AccountSessionLock acquireAccountLock(UserSessionToken token) {
        return this.acquireAccountLock(token.getDpUsername());
    }

    public AccountSessionLock acquireAccountLock(String username) {
        return this.accountLockHolder.createIfAbsent(username);
    }

    public TemplateSessionLock acquireTemplateLock(Id id) {
        return this.templateLockHolder.createIfAbsent(id);
    }

    public static class AccountResourceHolder
    extends ConcurrentHashMap<String, AccountSessionLock> {
        private String hashKey(String key) {
            String ikey = String.valueOf(key.hashCode() % 50);
            return ikey;
        }

        public AccountSessionLock createIfAbsent(String key) {
            AccountSessionLock newLock;
            String internalKey = this.hashKey(key);
            AccountSessionLock sessionLock = (AccountSessionLock)this.get(internalKey);
            if (sessionLock == null && (sessionLock = this.putIfAbsent(internalKey, newLock = new AccountSessionLock(internalKey, this))) == null) {
                sessionLock = newLock;
            }
            return sessionLock;
        }
    }

    public static class AccountSessionLock
    extends OrderCheckReentrantLock {
        private static final long serialVersionUID = 1L;
        private String key;
        private AccountResourceHolder holder;

        public AccountSessionLock(String key, AccountResourceHolder holder) {
            this.key = key;
            this.holder = holder;
        }

        @Override
        protected void checkAndSet() {
            Collection localSeqList = (Collection)seqLockLocal.get();
            if (localSeqList.contains("templateLock")) {
                throw new RuntimeException("Invalid lock order , templateLock -> accountLock .");
            }
            if (localSeqList.contains("gatewayLock")) {
                throw new RuntimeException("Lock reject , gateway is locking , can not acquire other lock .");
            }
            localSeqList.add("accountLock");
        }

        @Override
        protected void removeOrder() {
            Collection localSeqList = (Collection)seqLockLocal.get();
            localSeqList.remove("accountLock");
        }

        @Override
        public void unlock() {
            super.unlock();
        }
    }

    public static abstract class OrderCheckReentrantLock
    extends ReentrantLock {
        protected abstract void checkAndSet();

        protected abstract void removeOrder();

        @Override
        public void lock() {
            this.checkAndSet();
            super.lock();
        }

        @Override
        public boolean tryLock() {
            this.checkAndSet();
            boolean result = super.tryLock();
            if (!result) {
                this.removeOrder();
            }
            return result;
        }

        @Override
        public boolean tryLock(long timeout, TimeUnit unit) throws InterruptedException {
            this.checkAndSet();
            boolean result = super.tryLock(timeout, unit);
            if (!result) {
                this.removeOrder();
            }
            return result;
        }

        @Override
        public void lockInterruptibly() throws InterruptedException {
            this.checkAndSet();
            try {
                super.lockInterruptibly();
            }
            catch (InterruptedException e) {
                this.removeOrder();
                throw e;
            }
        }

        @Override
        public void unlock() {
            try {
                this.removeOrder();
            }
            finally {
                super.unlock();
            }
        }
    }

    public static class TemplateResourceHolder
    extends ConcurrentHashMap<Id, TemplateSessionLock> {
        public TemplateSessionLock createIfAbsent(Id id) {
            TemplateSessionLock lock = this.putIfAbsent(id, new TemplateSessionLock());
            if (lock == null) {
                lock = this.get(id);
            }
            return lock;
        }

        @Override
        public TemplateSessionLock get(Object key) {
            return (TemplateSessionLock)super.get(key);
        }
    }

    public static class TemplateSessionLock
    extends OrderCheckReentrantLock {
        private static final long serialVersionUID = 1L;

        @Override
        protected void checkAndSet() {
            Collection localSeqList = (Collection)seqLockLocal.get();
            if (localSeqList.contains("gatewayLock")) {
                throw new RuntimeException("Lock reject , gateway is locking , can not acquire other lock .");
            }
            localSeqList.add("templateLock");
        }

        @Override
        protected void removeOrder() {
            ((Collection)seqLockLocal.get()).remove("templateLock");
        }
    }
}
