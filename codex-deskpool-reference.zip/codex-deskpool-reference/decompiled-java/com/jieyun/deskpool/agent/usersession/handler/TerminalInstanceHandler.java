/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.PoolManager;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.vm.Stopwatch;

public class TerminalInstanceHandler {
    public void handle(IUserSessionBean userSessionBean) {
        UserSessionLog.getLogger().info("{} , terminal instance .", (Object)userSessionBean);
        IInstanceBean instance = (IInstanceBean)Services.getInstanceService().findOne(userSessionBean.getInstanceId());
        Stopwatch timer = new Stopwatch("[UserSession.end.terminateInstance(" + instance + ")]");
        try {
            if (instance == null) {
                UserSessionLog.getLogger().error("{} - UserSession.end given null instance", (Object)userSessionBean);
                return;
            }
            try {
                if (!InstanceStatus.DESTROYED.equals((Object)instance.getStatus()) && !InstanceStatus.STANDING.equals((Object)instance.getStatus())) {
                    instance.terminate();
                }
                new PoolManager.Message().send();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        finally {
            timer.stop();
        }
    }
}
