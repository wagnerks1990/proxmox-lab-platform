/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;

public class SessionActivedHandler {
    private IUserSessionBean userSessionBean;

    public SessionActivedHandler(IUserSessionBean userSessionBean) {
        this.userSessionBean = userSessionBean;
    }

    public boolean handle(IInstanceBean agentConnectInstance, String computerIp, String computerUsername, String computerName, String clientIP) {
        UserSessionLog.getLogger().debug("{} - active usersession instance:{} ip:{} user:{} computername:{}", new Object[]{this.userSessionBean, agentConnectInstance, computerIp, computerUsername, computerName});
        IInstanceBean connectedInstance = null;
        if (this.userSessionBean.getInstanceId() != null) {
            connectedInstance = (IInstanceBean)Services.getInstanceService().findOne(this.userSessionBean.getInstanceId());
        }
        if (connectedInstance == null || StringUtils.isBlank((CharSequence)computerIp) || StringUtils.isBlank((CharSequence)computerName)) {
            UserSessionLog.getLogger().error("{} - failed to record instance:{} ip:{} user:{} computername:{}", new Object[]{this.userSessionBean, connectedInstance, computerIp, computerUsername, computerName});
            return false;
        }
        String accountName = ((UserSession)this.userSessionBean.getDomain()).getAccountName();
        String ipaddress = computerIp;
        IAccountBean user = connectedInstance.getUser();
        if (user == null) {
            UserSessionLog.getLogger().info("{} , binding user is null , breach instance .", (Object)this.userSessionBean);
            this.breach(connectedInstance);
            new TrackerService.Writer.Instance().login(connectedInstance, user).failure("error.desktop.connect.unassigned", new String[]{"$username", accountName, "$clientIP", clientIP});
            return false;
        }
        Props props = Props.instance();
        String userverify = props.get("policy.login.userverify", "false");
        if (this.userSessionBean.getStatus() == UserSessionStatus.ACTIVED) {
            this.userSessionBean.touch(true);
            return true;
        }
        if (this.userSessionBean.getStatus() != UserSessionStatus.RESOURCE_ALL_READY) {
            UserSessionLog.getLogger().info("UserSession is not RESOURCE_ALL_READY status, ignore.");
            return false;
        }
        connectedInstance = connectedInstance.getUpdate().setSessionActive(true).setVmParam("computername", computerName).setLoginTime(new Date()).setIpaddress(ipaddress).setClientLocation(clientIP).save();
        this.userSessionBean.enterStatus(UserSessionStatus.ACTIVED);
        this.userSessionBean.touch(false);
        this.userSessionBean.save();
        TrackerService.Writer tracker = new TrackerService.Writer.connInfo().connect(this.userSessionBean);
        if (!tracker.getTracker().isNew()) {
            tracker.complete("session.connect.VM", new String[0]);
        }
        return true;
    }

    private void breach(IInstanceBean instance) {
        Stopwatch timer = new Stopwatch("[UserSession.breach(" + instance.toString() + ")]");
        try {
            instance.logoff();
        }
        finally {
            timer.stop();
        }
    }

    private boolean isInvalidateClientIP(String clientIP) {
        return StringUtils.isEmpty((CharSequence)clientIP) || clientIP.equalsIgnoreCase("none");
    }
}
