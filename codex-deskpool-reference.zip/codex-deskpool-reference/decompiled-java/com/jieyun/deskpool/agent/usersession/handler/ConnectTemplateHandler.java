/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.usersession.handler.AllocateInstanceHandler;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.UserSessionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Deprecated
public class ConnectTemplateHandler {
    private static final Logger logger = LoggerFactory.getLogger(ConnectTemplateHandler.class);
    private IUserSessionBean userSession;
    private String password;
    private AllocateInstanceHandler allocateInstanceHandler;

    public ConnectTemplateHandler(IUserSessionBean userSession) {
        this.userSession = userSession;
    }

    public void handle() throws Exception {
        if (this.userSession.isDeattach()) {
            throw new JYServiceRuntimeException("usersession.destroyed", "session\u5df2\u9500\u6bc1\u3002");
        }
        if (UserSessionStatus.INVALIDATE == this.userSession.getStatus()) {
            throw new JYServiceRuntimeException("usersession.invalidate", "\u8fde\u63a5\u5df2\u5931\u6548\u3002");
        }
        if (UserSessionStatus.GATEWAY_ALLOCATE_FAILED == this.userSession.getStatus()) {
            throw new JYServiceRuntimeException("usersession.gateway.allocateFailure", "\u7f51\u5173\u7533\u8bf7\u5931\u8d25\u3002");
        }
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
