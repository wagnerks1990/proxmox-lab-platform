/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IUserSessionManagerRemote;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.UserSessionService;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.shared.UserSessionToken;

public class DispatchProxy {
    private static DispatchProxy instance = new DispatchProxy();

    public static DispatchProxy instance() {
        return instance;
    }

    public DispatchResult createNew(UserSessionToken token) {
        MasterCoordinator masterCoordinator = MasterCoordinator.instance();
        DispatchResult result = new DispatchResult();
        if (masterCoordinator.isMasterLocal()) {
            result.status = DispatchResult.Status.LOOP;
            return result;
        }
        try {
            IUserSessionManagerRemote userSessionManagerRemote = (IUserSessionManagerRemote)RMIUtils.getRemoteProxy(masterCoordinator.masterAddress().getAddress(), "UserSessionManagerRemote");
            userSessionManagerRemote.createNew(token);
            UserSessionService userSessionService = Services.getUserSessionService();
            IUserSessionBean session = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
            if (session == null) {
                session = (IUserSessionBean)userSessionService.createOne();
                session.enterStatus(UserSessionStatus.NEW_ACCEPTED);
                result.status = DispatchResult.Status.REMOTE;
            }
            result.userSessionBean = session;
            result.status = DispatchResult.Status.REMOTE;
            return result;
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public DispatchResult connect(UserSessionToken token) {
        MasterCoordinator masterCoordinator = MasterCoordinator.instance();
        DispatchResult result = new DispatchResult();
        if (masterCoordinator.isMasterLocal()) {
            result.status = DispatchResult.Status.LOOP;
            return result;
        }
        try {
            IUserSessionManagerRemote userSessionManagerRemote = (IUserSessionManagerRemote)RMIUtils.getRemoteProxy(masterCoordinator.masterAddress().getAddress(), "UserSessionManagerRemote");
            userSessionManagerRemote.connect(token);
            UserSessionService userSessionService = Services.getUserSessionService();
            IUserSessionBean session = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
            if (session == null) {
                session = (IUserSessionBean)userSessionService.createOne();
                session.enterStatus(UserSessionStatus.NEW_ACCEPTED);
            }
            result.userSessionBean = session;
            result.status = DispatchResult.Status.REMOTE;
            return result;
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public DispatchResult allocateInstance(UserSessionToken token) {
        MasterCoordinator masterCoordinator = MasterCoordinator.instance();
        DispatchResult result = new DispatchResult();
        if (masterCoordinator.isMasterLocal()) {
            result.status = DispatchResult.Status.LOOP;
            return result;
        }
        try {
            IUserSessionManagerRemote userSessionManagerRemote = (IUserSessionManagerRemote)RMIUtils.getRemoteProxy(masterCoordinator.masterAddress().getAddress(), "UserSessionManagerRemote");
            userSessionManagerRemote.connect(token);
            result.status = DispatchResult.Status.REMOTE;
            return result;
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    public void activedSession(IUserSessionBean userSessionBean, IInstanceBean instance, String username, String computerIP, String computerName, String clientIP) {
    }

    public void closeSession() {
    }

    public void endSession() {
    }

    public DispatchResult connectInstance() {
        return null;
    }

    public static class DispatchResult {
        public IUserSessionBean userSessionBean;
        public Status status;

        public boolean isRemoted() {
            return Status.REMOTE == this.status;
        }

        public static enum Status {
            LOOP,
            REMOTE;

        }
    }
}
