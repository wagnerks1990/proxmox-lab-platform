/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.accessnetwork.AccessMatchResult;
import com.jieyun.deskpool.bean.accessnetwork.IAccessNetworkBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.PortMappingService;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.GatewayRule;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.shared.ServiceACL;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.utils.SpringUtils;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class AllocateGatewayStatusHandler {
    private IUserSessionBean userSession;

    public AllocateGatewayStatusHandler(IUserSessionBean userSession, IInstanceBean instanceBean) {
        this.userSession = userSession;
    }

    public void handle() throws Exception {
        UserSession session = (UserSession)this.userSession.getDomain();
        if (!"true".equals(Props.instance().get("gateway.enable", "true"))) {
            this.userSession.enterStatus(UserSessionStatus.GATEWAY_PASSING);
            return;
        }
        IPortMappingBean portMappingBean = this.userSession.getPortMapping();
        this.byPassGateway(portMappingBean);
    }

    private void byPassGateway(IPortMappingBean portMappingBean) {
        this.userSession.enterStatus(UserSessionStatus.GATEWAY_PASSING);
    }

    private boolean isAllocatorRunning(IPortMappingBean portMappingBean) {
        if (portMappingBean == null) {
            return false;
        }
        if (PortMappingStatus.ALLOCATE_WAITING == ((PortMapping)portMappingBean.getDomain()).getStatus()) {
            return true;
        }
        if (PortMappingStatus.ALLOCATE_SUCCESS == ((PortMapping)portMappingBean.getDomain()).getStatus()) {
            if (this.userSession.getStatus() == UserSessionStatus.GATEWAY_WAITING) {
                this.userSession.enterStatus(UserSessionStatus.GATEWAY_ALLOCATED);
            }
            return true;
        }
        if (PortMappingStatus.ALLOCATE_FAILURE == ((PortMapping)portMappingBean.getDomain()).getStatus()) {
            this.userSession.enterStatus(UserSessionStatus.GATEWAY_ALLOCATE_FAILED);
            return true;
        }
        return false;
    }

    private void doAllocate(AccessMatchResult matchResult) {
        List<GatewayRule> gatewayRules = this.caculateTargetRuleList(matchResult, this.userSession.getInstanceIP());
        IPortMappingBean portMappingBean = (IPortMappingBean)((PortMappingService)SpringUtils.context.getBean(PortMappingService.class)).createOne();
        PortMapping portResource = (PortMapping)portMappingBean.getDomain();
        portResource.setList(gatewayRules);
        portResource.setStatus(PortMappingStatus.ALLOCATE_WAITING);
        portMappingBean.save();
        this.userSession.setPortMappingId(portMappingBean.Id());
        this.userSession.enterStatus(UserSessionStatus.GATEWAY_WAITING);
        this.userSession.save();
        portMappingBean.allocate();
    }

    public List<GatewayRule> caculateTargetRuleList(AccessMatchResult matchResult, String instIP) {
        ServiceACL serviceACL = matchResult.getServiceACL();
        Boolean rdp = serviceACL.getRdp();
        ArrayList<GatewayRule> portList = new ArrayList<GatewayRule>();
        if (Boolean.TRUE.equals(rdp)) {
            GatewayRule rdpResult = new GatewayRule();
            rdpResult.setServiceName("rdp");
            rdpResult.setTargetPort(ClusterNodeBean.getRdpPort());
            rdpResult.setTargetIP(instIP);
            portList.add(rdpResult);
        }
        return portList;
    }

    public AccessMatchResult matchAccessResult() {
        List accessNetworkBeans = Services.getAccessNetworkService().findAll();
        AccessMatchResult matchResult = null;
        for (IAccessNetworkBean accessNetworkBean : accessNetworkBeans) {
            AccessMatchResult tmpResult = accessNetworkBean.matchACL(this.ip(this.userSession.getClientIP()));
            if (tmpResult == null) continue;
            return tmpResult;
        }
        return matchResult;
    }

    private String ip(String inetAddress) {
        if (StringUtils.isNotBlank((String)inetAddress)) {
            int idx = inetAddress.indexOf(":");
            if (idx > 0) {
                return inetAddress.substring(0, idx);
            }
            return inetAddress;
        }
        return null;
    }
}
