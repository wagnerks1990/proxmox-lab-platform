/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.gateway.GatewayUtils;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.gateway.JygwPortType;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.GatewayRule;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.store.ServicePortCache;
import com.jieyun.deskpool.vm.Event;
import java.util.Iterator;
import java.util.List;

public static class GatewayManager.ReleaseMessage.ResponseHandler
extends GatewayManager.GatewayResponse {
    @Override
    public boolean responseHandle(Event paramEvent) {
        GatewayManager.ReleaseMessage msg = (GatewayManager.ReleaseMessage)paramEvent;
        IPortMappingBean portMappingBean = null;
        try {
            portMappingBean = (IPortMappingBean)msg.getPortMappingBean().refresh();
        }
        catch (Exception e) {
            portMappingBean = msg.getPortMappingBean();
            e.printStackTrace();
        }
        List<GatewayRule> ruleList = ((PortMapping)portMappingBean.getDomain()).getList();
        if (ruleList != null && !ruleList.isEmpty()) {
            Iterator<GatewayRule> it = ruleList.iterator();
            try {
                GatewayManager.instance().avaliableCheck();
                JygwPortType client = GatewayUtils.lookupClient();
                while (it.hasNext()) {
                    GatewayRule rule = it.next();
                    if (rule.getSourcePort() == null) continue;
                    int result = client.deleterule("", rule.getSourcePort(), rule.getTargetIP(), rule.getTargetPort(), "tcp");
                    if (result == 0) {
                        ServicePortCache.destroyServicePort(rule.getSourcePort());
                    }
                    UserSessionLog.getLogger().info("Destroy gateway rule : {}", (Object)rule);
                }
            }
            catch (Exception e) {
                ((PortMapping)portMappingBean.getDomain()).setStatus(PortMappingStatus.RELEASE_EXCEPTION);
                portMappingBean.save();
                throw new JYServiceRuntimeException("gateway.port.release.exception", "gateway.port.release.exception", e);
            }
            if (portMappingBean != null) {
                portMappingBean.remove();
                UserSessionLog.getLogger().info("Remove portMapping {}", (Object)portMappingBean);
            }
            return true;
        }
        return true;
    }
}
