/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.SessionLockManager;
import java.util.Collection;

public static class SessionLockManager.AccountSessionLock
extends SessionLockManager.OrderCheckReentrantLock {
    private static final long serialVersionUID = 1L;
    private String key;
    private SessionLockManager.AccountResourceHolder holder;

    public SessionLockManager.AccountSessionLock(String key, SessionLockManager.AccountResourceHolder holder) {
        this.key = key;
        this.holder = holder;
    }

    @Override
    protected void checkAndSet() {
        Collection localSeqList = (Collection)seqLockLocal.get();
        if (localSeqList.contains("templateLock")) {
            throw new RuntimeException("Invalid lock order , templateLock -> accountLock .");
        }
        if (localSeqList.contains("gatewayLock")) {
            throw new RuntimeException("Lock reject , gateway is locking , can not acquire other lock .");
        }
        localSeqList.add("accountLock");
    }

    @Override
    protected void removeOrder() {
        Collection localSeqList = (Collection)seqLockLocal.get();
        localSeqList.remove("accountLock");
    }

    @Override
    public void unlock() {
        super.unlock();
    }
}
