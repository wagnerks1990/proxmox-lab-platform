/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import java.util.Stack;

public class TxManager {
    private ThreadLocal<Tx> txLocal = new ThreadLocal();
    private static TxManager instance = new TxManager();

    public static TxManager instance() {
        return instance;
    }

    public Tx getTx() {
        return this.txLocal.get();
    }

    public void begin() {
        Tx tx = this.getTx();
        if (tx == null) {
            this.txLocal.set(new Tx());
        } else {
            tx.push(new Tx());
        }
    }

    public void commit() {
        Tx tx = this.getTx();
        if (tx == null) {
            return;
        }
        tx.commit();
    }

    static class Tx {
        private Stack<Tx> txStack = new Stack();

        Tx() {
        }

        public void push(Tx tx) {
            this.txStack.push(tx);
        }

        public void commit() {
        }
    }
}
