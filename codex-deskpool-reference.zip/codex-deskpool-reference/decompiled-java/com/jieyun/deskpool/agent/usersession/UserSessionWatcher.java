/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.usersession.UserSessionManager;
import com.jieyun.deskpool.agent.utils.JYEngine;
import com.jieyun.deskpool.agent.utils.JYTimedEngine;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.vm.Event;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class UserSessionWatcher
implements ApplicationLifecycle.LifecycleListener {
    private TimedEngine timedEngine;
    private Event.Engine quickEngine;
    private String timedEngineName = "UserSessionWatcher-Timed";
    private String quickEngineName = "UserSessionWatcher-Quick";
    private AtomicInteger quickQueneLen = new AtomicInteger(0);
    private static UserSessionWatcher instance = new UserSessionWatcher();

    public static UserSessionWatcher instance() {
        return instance;
    }

    @Override
    public void onStart() {
        this.timedEngine.start();
        this.quickEngine.start();
    }

    @Override
    public void onShutdown() {
        this.timedEngine.quit();
        this.quickEngine.quit();
    }

    public UserSessionWatcher() {
        this.timedEngine = new TimedEngine(this.timedEngineName, 60L);
        this.timedEngine.subscribe(Message.class, new EventHandler());
        this.quickEngine = new JYEngine(this.quickEngineName);
        this.quickEngine.subscribe(Message.class, new EventHandler());
    }

    public void quickSendWatch() {
        if (this.quickQueneLen.compareAndSet(20, 0)) {
            return;
        }
        this.quickQueneLen.incrementAndGet();
        new Message().send(this.quickEngine);
    }

    public class EventHandler
    implements Event.Recipient {
        @Override
        public boolean receive(Event paramEvent) {
            List userSessionBeanList = Services.getUserSessionService().findAll();
            for (IUserSessionBean userSessionBean : userSessionBeanList) {
                UserSessionManager.instance().destroyInvalidateSession(userSessionBean);
            }
            return true;
        }
    }

    public class Message
    extends Agent.Message {
    }

    public class TimedEngine
    extends JYTimedEngine {
        public TimedEngine(String name, long seconds) {
            super(name, seconds);
        }

        @Override
        protected Event defaultEvent() {
            return new Message();
        }
    }
}
