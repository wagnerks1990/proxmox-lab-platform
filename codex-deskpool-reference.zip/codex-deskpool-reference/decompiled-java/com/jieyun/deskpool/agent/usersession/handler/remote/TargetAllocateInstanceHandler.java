/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession.handler.remote;

import com.jieyun.deskpool.agent.usersession.handler.AllocateInstanceHandler;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.distributed.transfer.data.AllocateInstanceParams;

public class TargetAllocateInstanceHandler {
    private AllocateInstanceParams params;

    public void setParams(AllocateInstanceParams params) {
        this.params = params;
    }

    public IUserSessionBean handle() {
        AllocateInstanceHandler delegate = new AllocateInstanceHandler();
        IInstanceBean instanceBean = delegate.allocate();
        return null;
    }
}
