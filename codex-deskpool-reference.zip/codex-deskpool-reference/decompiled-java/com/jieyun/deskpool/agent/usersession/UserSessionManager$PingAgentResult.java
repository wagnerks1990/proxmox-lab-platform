/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

public static enum UserSessionManager.PingAgentResult {
    SUCCESS,
    FAILURE,
    AGENT_OFFLINE;

}
