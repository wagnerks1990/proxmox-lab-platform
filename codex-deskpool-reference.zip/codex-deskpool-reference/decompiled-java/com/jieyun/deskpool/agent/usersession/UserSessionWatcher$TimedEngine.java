/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionWatcher;
import com.jieyun.deskpool.agent.utils.JYTimedEngine;
import com.jieyun.deskpool.vm.Event;

public class UserSessionWatcher.TimedEngine
extends JYTimedEngine {
    public UserSessionWatcher.TimedEngine(String name, long seconds) {
        super(name, seconds);
    }

    @Override
    protected Event defaultEvent() {
        return new UserSessionWatcher.Message(UserSessionWatcher.this);
    }
}
