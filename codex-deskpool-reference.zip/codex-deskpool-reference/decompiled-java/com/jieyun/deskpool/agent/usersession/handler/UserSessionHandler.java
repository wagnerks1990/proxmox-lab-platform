/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.shared.UserSessionToken;

public interface UserSessionHandler {
    public IUserSessionBean handle(UserSessionToken var1);
}
