/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.gateway.GatewayUtils;
import com.jieyun.deskpool.bean.gateway.IGatewayConfigBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.domain.GatewayConfig;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.gateway.JygwPortType;
import com.jieyun.deskpool.service.GatewayService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.GatewayRule;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.store.ServicePortCache;
import com.jieyun.deskpool.utils.SpringUtils;
import com.jieyun.deskpool.vm.Event;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public static class GatewayManager.AllocateMessage
extends GatewayManager.GatewayMessage {
    private IPortMappingBean portMappingBean;

    public GatewayManager.AllocateMessage(IPortMappingBean portResource) {
        this.portMappingBean = portResource;
    }

    public IPortMappingBean getPortResource() {
        return this.portMappingBean;
    }

    public static class ResponseHandler
    extends GatewayManager.GatewayResponse {
        private IPortMappingBean portMappingBean;

        @Override
        public boolean responseHandle(Event paramEvent) {
            GatewayManager.AllocateMessage allocateMsg = (GatewayManager.AllocateMessage)paramEvent;
            this.portMappingBean = allocateMsg.getPortResource();
            JygwPortType client = null;
            try {
                GatewayManager.instance().avaliableCheck();
                try {
                    client = GatewayUtils.lookupClient();
                    String version = client.getversion();
                    if (StringUtils.isBlank((String)version)) {
                        throw new RuntimeException("Gateway get version failure.");
                    }
                }
                catch (Throwable t) {
                    this.throwAllocateFailure(t, "gateway.connectFailure", "\u7f51\u5173\u8fde\u63a5\u5931\u8d25");
                }
                try {
                    this.addGatewayRule(client, ((PortMapping)this.portMappingBean.getDomain()).getList());
                }
                catch (Throwable t) {
                    this.throwAllocateFailure(t, "gateway.allocateFailure", "\u7f51\u5173\u5206\u914d\u5931\u8d25");
                }
                ((PortMapping)this.portMappingBean.getDomain()).setStatus(PortMappingStatus.ALLOCATE_SUCCESS);
            }
            finally {
                this.portMappingBean.save();
            }
            return true;
        }

        private void throwAllocateFailure(Throwable cause, String errorId, String defaultError) {
            ((PortMapping)this.portMappingBean.getDomain()).setRemark(errorId);
            ((PortMapping)this.portMappingBean.getDomain()).setStatus(PortMappingStatus.ALLOCATE_FAILURE);
            if (cause != null) {
                throw new JYServiceRuntimeException(errorId, defaultError, cause);
            }
            throw new JYServiceRuntimeException(errorId, defaultError);
        }

        private void addGatewayRule(JygwPortType client, List<GatewayRule> targetPortArr) throws Exception {
            List<GatewayRule> gatewayRules = ((PortMapping)this.portMappingBean.getDomain()).getList();
            if (gatewayRules == null) {
                gatewayRules = new ArrayList<GatewayRule>();
            }
            int i = 0;
            while (i < gatewayRules.size()) {
                int end;
                IGatewayConfigBean configBean = ((GatewayService)SpringUtils.context.getBean(GatewayService.class)).getDefault();
                int start = ((GatewayConfig)configBean.getDomain()).getStartPort();
                int serviceport = ServicePortCache.allocateServicePort(start, end = ((GatewayConfig)configBean.getDomain()).getEndPort().intValue());
                if (serviceport == -1) {
                    throw new JYServiceRuntimeException("gateway.serviceport.overload", "\u7cfb\u7edf\u8fc7\u8f7d\uff0c\u8bf7\u91cd\u8bd5\u6216\u8054\u7cfb\u7ba1\u7406\u5458");
                }
                GatewayRule rule = targetPortArr.get(0);
                String targetIP = rule.getTargetIP();
                int targetPort = rule.getTargetPort();
                int result = -1;
                try {
                    result = client.audit("", serviceport, targetIP, targetPort, "tcp") == 0 ? 0 : client.createrule("", serviceport, targetIP, targetPort, "tcp");
                    rule.setSourceIP("");
                    rule.setSourcePort(serviceport);
                }
                catch (Exception e) {
                    throw new JYServiceRuntimeException("gateway.addRuleFailure", "\u6dfb\u52a0\u7f51\u5173\u8bb0\u5f55\u5931\u8d25", e);
                }
                UserSessionLog.getLogger().info("Allocate gateway : {}", (Object)rule);
                ++i;
            }
        }
    }
}
