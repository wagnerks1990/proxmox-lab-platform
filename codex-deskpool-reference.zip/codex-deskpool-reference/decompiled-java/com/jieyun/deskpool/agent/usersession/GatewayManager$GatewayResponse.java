/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.vm.Event;

public static abstract class GatewayManager.GatewayResponse
implements Event.Recipient {
    @Override
    public boolean receive(Event paramEvent) {
        return this.responseHandle(paramEvent);
    }

    public abstract boolean responseHandle(Event var1);
}
