/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.gateway.GatewayUtils;
import com.jieyun.deskpool.bean.gateway.IGatewayConfigBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.domain.GatewayConfig;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.gateway.JygwPortType;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.GatewayService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.GatewayRule;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.store.ServicePortCache;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.SpringUtils;
import com.jieyun.deskpool.vm.Event;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.commons.lang.StringUtils;

public class GatewayManager
implements ApplicationLifecycle.LifecycleListener {
    private static GatewayManager instance = new GatewayManager();
    private ReentrantLock resetLock = new ReentrantLock();
    private int i = 0;
    private ExecuteEnginePool enginePool = new ExecuteEnginePool();
    private String engineName = "GatewayEngine-0";
    private volatile GatewayServerStatus gatewayServerStatus = GatewayServerStatus.NORMAL;

    public void setServerStatus(GatewayServerStatus status) {
        if (status == null) {
            return;
        }
        this.gatewayServerStatus = GatewayServerStatus.NORMAL;
    }

    @Override
    public void onShutdown() {
        this.enginePool.drop(this.engineName);
    }

    @Override
    public void onStart() {
    }

    public static GatewayManager instance() {
        return instance;
    }

    public void reset(IGatewayConfigBean config) throws Exception {
        this.resetLock.lock();
        try {
            JygwPortType client = GatewayUtils.lookupClient();
            int start = ((GatewayConfig)config.getDomain()).getStartPort();
            int end = ((GatewayConfig)config.getDomain()).getEndPort();
            client.initgateway(start, end - start);
            this.waitingGWReady();
            String externalIP = client.getwlanip();
            ((GatewayConfig)config.getDomain()).setExternalIP(externalIP);
            config.save();
            if (client.audit("", 80, NetUtils.getHostIP(), 80, "tcp") == 0) {
                client.deleterule("", 80, NetUtils.getHostIP(), 80, "tcp");
            }
            if (client.audit("", 443, NetUtils.getHostIP(), 443, "tcp") == 0) {
                client.deleterule("", 443, NetUtils.getHostIP(), 443, "tcp");
            }
            client.createrule("", 80, NetUtils.getHostIP(), 80, "tcp");
            client.createrule("", 443, NetUtils.getHostIP(), 443, "tcp");
            ServicePortCache.reset();
        }
        finally {
            this.resetLock.unlock();
        }
    }

    public void send(GatewayMessage message) {
        this.avaliableCheck();
        message.send(this.enginePool.get(this.engineName));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void waitingGWReady() throws Exception {
        client = null;
        try {
            version = "";
            while ("".equals(version) || this.i < 10 || client == null) {
                try {
                    client = GatewayUtils.lookupClient();
                    version = client.getversion();
                    ++this.i;
                    ** if (this.i <= 20) goto lbl16
                }
                catch (Throwable e) {
                    try {
                        System.out.println(e.getMessage());
                        continue;
                    }
                    catch (Throwable var4_9) {
                        throw var4_9;
                    }
                    finally {
                        try {
                            Thread.sleep(1000L);
                        }
                        catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
lbl30:
                    // 1 sources

                    try {
                        Thread.sleep(1000L);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    continue;
                    return;
                }
lbl-1000:
                // 1 sources

                {
                    try {
                        Thread.sleep(1000L);
                        return;
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                        return;
                    }
                }
lbl16:
                // 1 sources

                ** GOTO lbl30
            }
        }
        finally {
            this.i = 0;
        }
    }

    public void avaliableCheck() {
        if (this.isReset()) {
            throw new JYServiceRuntimeException("gateway.reset.waiting", "\u7ba1\u7406\u5458\u6b63\u5728\u91cd\u7f6e\u7f51\u5173\u3002");
        }
        if (GatewayServerStatus.UNREACHABLE == this.gatewayServerStatus) {
            throw new JYServiceRuntimeException("gateway.server.unreachable", "\u7f51\u5173\u8fde\u63a5\u5931\u8d25\u3002");
        }
    }

    public boolean isServiceNormal() {
        return GatewayServerStatus.NORMAL == this.gatewayServerStatus;
    }

    public boolean isReset() {
        return this.resetLock.isLocked();
    }

    public boolean isBusy() {
        return this.resetLock.isLocked();
    }

    public static class AllocateMessage
    extends GatewayMessage {
        private IPortMappingBean portMappingBean;

        public AllocateMessage(IPortMappingBean portResource) {
            this.portMappingBean = portResource;
        }

        public IPortMappingBean getPortResource() {
            return this.portMappingBean;
        }

        public static class ResponseHandler
        extends GatewayResponse {
            private IPortMappingBean portMappingBean;

            @Override
            public boolean responseHandle(Event paramEvent) {
                AllocateMessage allocateMsg = (AllocateMessage)paramEvent;
                this.portMappingBean = allocateMsg.getPortResource();
                JygwPortType client = null;
                try {
                    GatewayManager.instance().avaliableCheck();
                    try {
                        client = GatewayUtils.lookupClient();
                        String version = client.getversion();
                        if (StringUtils.isBlank((String)version)) {
                            throw new RuntimeException("Gateway get version failure.");
                        }
                    }
                    catch (Throwable t) {
                        this.throwAllocateFailure(t, "gateway.connectFailure", "\u7f51\u5173\u8fde\u63a5\u5931\u8d25");
                    }
                    try {
                        this.addGatewayRule(client, ((PortMapping)this.portMappingBean.getDomain()).getList());
                    }
                    catch (Throwable t) {
                        this.throwAllocateFailure(t, "gateway.allocateFailure", "\u7f51\u5173\u5206\u914d\u5931\u8d25");
                    }
                    ((PortMapping)this.portMappingBean.getDomain()).setStatus(PortMappingStatus.ALLOCATE_SUCCESS);
                }
                finally {
                    this.portMappingBean.save();
                }
                return true;
            }

            private void throwAllocateFailure(Throwable cause, String errorId, String defaultError) {
                ((PortMapping)this.portMappingBean.getDomain()).setRemark(errorId);
                ((PortMapping)this.portMappingBean.getDomain()).setStatus(PortMappingStatus.ALLOCATE_FAILURE);
                if (cause != null) {
                    throw new JYServiceRuntimeException(errorId, defaultError, cause);
                }
                throw new JYServiceRuntimeException(errorId, defaultError);
            }

            private void addGatewayRule(JygwPortType client, List<GatewayRule> targetPortArr) throws Exception {
                List<GatewayRule> gatewayRules = ((PortMapping)this.portMappingBean.getDomain()).getList();
                if (gatewayRules == null) {
                    gatewayRules = new ArrayList<GatewayRule>();
                }
                int i = 0;
                while (i < gatewayRules.size()) {
                    int end;
                    IGatewayConfigBean configBean = ((GatewayService)SpringUtils.context.getBean(GatewayService.class)).getDefault();
                    int start = ((GatewayConfig)configBean.getDomain()).getStartPort();
                    int serviceport = ServicePortCache.allocateServicePort(start, end = ((GatewayConfig)configBean.getDomain()).getEndPort().intValue());
                    if (serviceport == -1) {
                        throw new JYServiceRuntimeException("gateway.serviceport.overload", "\u7cfb\u7edf\u8fc7\u8f7d\uff0c\u8bf7\u91cd\u8bd5\u6216\u8054\u7cfb\u7ba1\u7406\u5458");
                    }
                    GatewayRule rule = targetPortArr.get(0);
                    String targetIP = rule.getTargetIP();
                    int targetPort = rule.getTargetPort();
                    int result = -1;
                    try {
                        result = client.audit("", serviceport, targetIP, targetPort, "tcp") == 0 ? 0 : client.createrule("", serviceport, targetIP, targetPort, "tcp");
                        rule.setSourceIP("");
                        rule.setSourcePort(serviceport);
                    }
                    catch (Exception e) {
                        throw new JYServiceRuntimeException("gateway.addRuleFailure", "\u6dfb\u52a0\u7f51\u5173\u8bb0\u5f55\u5931\u8d25", e);
                    }
                    UserSessionLog.getLogger().info("Allocate gateway : {}", (Object)rule);
                    ++i;
                }
            }
        }
    }

    public static class ExecuteEnginePool
    extends Event.EnginePool {
        @Override
        public void init(Event.Engine engine) {
            engine.subscribe(AllocateMessage.class, new AllocateMessage.ResponseHandler());
            engine.subscribe(ReleaseMessage.class, new ReleaseMessage.ResponseHandler());
        }
    }

    public static class GatewayMessage
    extends Agent.Message {
    }

    public static abstract class GatewayResponse
    implements Event.Recipient {
        @Override
        public boolean receive(Event paramEvent) {
            return this.responseHandle(paramEvent);
        }

        public abstract boolean responseHandle(Event var1);
    }

    public static enum GatewayServerStatus {
        NORMAL,
        UNREACHABLE,
        BUSY;

    }

    public static class ReleaseMessage
    extends GatewayMessage {
        private IPortMappingBean portMappingBean;

        public ReleaseMessage(IPortMappingBean portMappingBean) {
            this.portMappingBean = portMappingBean;
        }

        public IPortMappingBean getPortMappingBean() {
            return this.portMappingBean;
        }

        public static class ResponseHandler
        extends GatewayResponse {
            @Override
            public boolean responseHandle(Event paramEvent) {
                ReleaseMessage msg = (ReleaseMessage)paramEvent;
                IPortMappingBean portMappingBean = null;
                try {
                    portMappingBean = (IPortMappingBean)msg.getPortMappingBean().refresh();
                }
                catch (Exception e) {
                    portMappingBean = msg.getPortMappingBean();
                    e.printStackTrace();
                }
                List<GatewayRule> ruleList = ((PortMapping)portMappingBean.getDomain()).getList();
                if (ruleList != null && !ruleList.isEmpty()) {
                    Iterator<GatewayRule> it = ruleList.iterator();
                    try {
                        GatewayManager.instance().avaliableCheck();
                        JygwPortType client = GatewayUtils.lookupClient();
                        while (it.hasNext()) {
                            GatewayRule rule = it.next();
                            if (rule.getSourcePort() == null) continue;
                            int result = client.deleterule("", rule.getSourcePort(), rule.getTargetIP(), rule.getTargetPort(), "tcp");
                            if (result == 0) {
                                ServicePortCache.destroyServicePort(rule.getSourcePort());
                            }
                            UserSessionLog.getLogger().info("Destroy gateway rule : {}", (Object)rule);
                        }
                    }
                    catch (Exception e) {
                        ((PortMapping)portMappingBean.getDomain()).setStatus(PortMappingStatus.RELEASE_EXCEPTION);
                        portMappingBean.save();
                        throw new JYServiceRuntimeException("gateway.port.release.exception", "gateway.port.release.exception", e);
                    }
                    if (portMappingBean != null) {
                        portMappingBean.remove();
                        UserSessionLog.getLogger().info("Remove portMapping {}", (Object)portMappingBean);
                    }
                    return true;
                }
                return true;
            }
        }
    }
}
