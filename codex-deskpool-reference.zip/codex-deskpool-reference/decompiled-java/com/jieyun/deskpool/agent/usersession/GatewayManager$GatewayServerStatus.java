/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

public static enum GatewayManager.GatewayServerStatus {
    NORMAL,
    UNREACHABLE,
    BUSY;

}
