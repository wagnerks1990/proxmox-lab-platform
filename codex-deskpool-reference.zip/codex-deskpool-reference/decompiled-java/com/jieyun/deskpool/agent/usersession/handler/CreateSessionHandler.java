/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.usersession.handler.UserSessionHandler;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.shared.UserSessionToken;

public class CreateSessionHandler
implements UserSessionHandler {
    @Override
    public IUserSessionBean handle(UserSessionToken token) {
        return null;
    }
}
