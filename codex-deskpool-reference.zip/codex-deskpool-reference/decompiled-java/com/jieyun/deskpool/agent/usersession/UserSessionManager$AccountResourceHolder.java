/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionManager;
import java.util.concurrent.ConcurrentHashMap;

public static class UserSessionManager.AccountResourceHolder
extends ConcurrentHashMap<String, UserSessionManager.AccountSessionLock> {
    private String hashKey(String key) {
        String ikey = String.valueOf(key.hashCode() % 50);
        return ikey;
    }

    public UserSessionManager.AccountSessionLock createIfAbsent(String key) {
        UserSessionManager.AccountSessionLock newLock;
        String internalKey = this.hashKey(key);
        UserSessionManager.AccountSessionLock sessionLock = (UserSessionManager.AccountSessionLock)this.get(internalKey);
        if (sessionLock == null && (sessionLock = this.putIfAbsent(internalKey, newLock = new UserSessionManager.AccountSessionLock(internalKey, this))) == null) {
            sessionLock = newLock;
        }
        return sessionLock;
    }
}
