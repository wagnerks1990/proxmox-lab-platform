/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.bean.usersession.IUserSessionBean;

public static class DispatchProxy.DispatchResult {
    public IUserSessionBean userSessionBean;
    public Status status;

    public boolean isRemoted() {
        return Status.REMOTE == this.status;
    }

    public static enum Status {
        LOOP,
        REMOTE;

    }
}
