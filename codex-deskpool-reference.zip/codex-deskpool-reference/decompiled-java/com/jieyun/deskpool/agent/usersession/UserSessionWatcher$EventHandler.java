/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionManager;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.vm.Event;
import java.util.List;

public class UserSessionWatcher.EventHandler
implements Event.Recipient {
    @Override
    public boolean receive(Event paramEvent) {
        List userSessionBeanList = Services.getUserSessionService().findAll();
        for (IUserSessionBean userSessionBean : userSessionBeanList) {
            UserSessionManager.instance().destroyInvalidateSession(userSessionBean);
        }
        return true;
    }
}
