/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import java.io.Serializable;

public class SessionId
implements Serializable {
}
