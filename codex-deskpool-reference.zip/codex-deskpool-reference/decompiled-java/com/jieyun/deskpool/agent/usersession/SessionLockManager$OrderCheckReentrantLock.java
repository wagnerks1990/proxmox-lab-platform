/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public static abstract class SessionLockManager.OrderCheckReentrantLock
extends ReentrantLock {
    protected abstract void checkAndSet();

    protected abstract void removeOrder();

    @Override
    public void lock() {
        this.checkAndSet();
        super.lock();
    }

    @Override
    public boolean tryLock() {
        this.checkAndSet();
        boolean result = super.tryLock();
        if (!result) {
            this.removeOrder();
        }
        return result;
    }

    @Override
    public boolean tryLock(long timeout, TimeUnit unit) throws InterruptedException {
        this.checkAndSet();
        boolean result = super.tryLock(timeout, unit);
        if (!result) {
            this.removeOrder();
        }
        return result;
    }

    @Override
    public void lockInterruptibly() throws InterruptedException {
        this.checkAndSet();
        try {
            super.lockInterruptibly();
        }
        catch (InterruptedException e) {
            this.removeOrder();
            throw e;
        }
    }

    @Override
    public void unlock() {
        try {
            this.removeOrder();
        }
        finally {
            super.unlock();
        }
    }
}
