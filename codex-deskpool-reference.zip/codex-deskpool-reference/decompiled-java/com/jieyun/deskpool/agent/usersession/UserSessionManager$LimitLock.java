/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.Props;
import java.util.concurrent.atomic.AtomicInteger;

private static class UserSessionManager.LimitLock {
    private AtomicInteger createNumLock = new AtomicInteger(0);
    private int max;

    public UserSessionManager.LimitLock() {
        AppProps props = AppProps.instance();
        this.max = props.get("usersession.connect.limit", 50);
        if (Props.instance().has("usersession.connect.limit")) {
            this.max = Props.instance().get("usersession.connect.limit", this.max);
        }
    }

    public int getCurrentNum() {
        return this.createNumLock.get();
    }

    public boolean reqDeny() {
        boolean result = this.createNumLock.incrementAndGet() > this.max;
        UserSessionLog.getLogger().info("Connect Speed Limit {} session/sec,  current {} session/sec  --- reqDeny return {}  ", new Object[]{this.max, this.getCurrentNum(), result});
        return result;
    }

    public void reqDecrement() {
        this.createNumLock.decrementAndGet();
    }
}
