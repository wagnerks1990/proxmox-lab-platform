/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent.usersession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserSessionLog {
    private static final Logger logger = LoggerFactory.getLogger(UserSessionLog.class);

    public static Logger getLogger() {
        return logger;
    }
}
