/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.usersession.SessionLockManager;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.agent.usersession.handler.AllocateGatewayStatusHandler;
import com.jieyun.deskpool.agent.usersession.handler.AllocateInstanceHandler;
import com.jieyun.deskpool.agent.usersession.handler.UserSessionHandler;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IUserSessionManagerRemote;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.JieyunLicense;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.service.UserSessionService;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.shared.UserSessionToken;
import com.jieyun.deskpool.store.spec.DpSpec;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.List;
import org.apache.commons.lang.StringUtils;

@Deprecated
public class AllocateResourceHandler
implements UserSessionHandler {
    private UserSessionHandler delegate;

    @Deprecated
    public AllocateResourceHandler(UserSessionHandler delegate) {
        this.delegate = delegate;
    }

    @Override
    @Deprecated
    public IUserSessionBean handle(UserSessionToken token) {
        return this.delegate.handle(token);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated
    private IUserSessionBean connectTemplate(UserSessionToken token, IUserSessionBean userSession, ITemplateBean template, IAccountBean account, AllocateInstanceHandler allocateInstanceHandler) {
        IInstanceBean instanceBean;
        Stopwatch timer;
        block32: {
            SessionLockManager.TemplateSessionLock lock;
            timer = new Stopwatch("[connectTemplate(user = " + token.getDpUsername() + ")]");
            MasterCoordinator masterCoordinator = MasterCoordinator.instance();
            if (!masterCoordinator.isMasterLocal()) {
                return this.masterCreateConnect(token, masterCoordinator);
            }
            try {
                block31: {
                    String curClientIP;
                    String tokenClientIP;
                    if (userSession == null) {
                        this.licenseCreateControl();
                        UserSessionService userSessionService = Services.getUserSessionService();
                        userSession = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
                        if (userSession == null) {
                            UserSessionLog.getLogger().info(" UserSession not found . ");
                            throw new JYServiceRuntimeException("usersession.invalidate", "\u8fde\u63a5\u5f02\u5e38");
                        }
                    }
                    if (!(tokenClientIP = token.getClientIP()).equals(curClientIP = userSession.getClientIP())) {
                        throw new JYServiceRuntimeException("usersession.clientIP.notmatch", "\u5e10\u6237\u5728\u5176\u5b83\u5730\u70b9\u767b\u5f55");
                    }
                    if (UserSessionStatus.INVALIDATE == userSession.getStatus()) {
                        throw new JYServiceRuntimeException("usersession.invalidate", "\u8fde\u63a5\u5df2\u5931\u6548\u3002");
                    }
                    if (UserSessionStatus.GATEWAY_ALLOCATE_FAILED == userSession.getStatus()) {
                        throw new JYServiceRuntimeException("usersession.gateway.allocateFailure", "\u7f51\u5173\u7533\u8bf7\u5931\u8d25\u3002");
                    }
                    if (UserSessionStatus.INSTANCE_ASSIGN_FAILURE == userSession.getStatus()) {
                        IUserSessionBean iUserSessionBean = userSession;
                        return iUserSessionBean;
                    }
                    userSession.touch(false);
                    if (UserSessionStatus.NEW == userSession.getStatus()) {
                        account = Services.getAccountService().findByName(userSession.getAccountName());
                        if (account == null) {
                            throw new JYServiceRuntimeException("usersession.accountNotFound", "\u7528\u6237\u4e0d\u5b58\u5728\u3002");
                        }
                        userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_WAITING);
                    }
                    instanceBean = null;
                    if (((UserSession)userSession.getDomain()).getStatus() == UserSessionStatus.INSTANCE_ASSIGN_WAITING) {
                        if (template == null) {
                            template = Services.getTemplateService().findByName(userSession.getTemplateName());
                        }
                        if (account == null) {
                            account = Services.getAccountService().findByName(userSession.getAccountName());
                        }
                        if (template != null) {
                            userSession.setConnectedTemplate(template);
                            lock = null;
                            lock = SessionLockManager.instance().acquireTemplateLock(template.Id());
                            lock.lock();
                            instanceBean = allocateInstanceHandler == null ? this.getDefaultAllocateInstanceHandler(template, account, userSession).allocate() : allocateInstanceHandler.allocate();
                            if (instanceBean != null) {
                                timer.record("connecting  instance " + instanceBean.getName() + " to " + token.getDpUsername());
                                userSession.setInstanceId(instanceBean.Id());
                                userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGNED);
                                ((UserSession)userSession.getDomain()).setInstanceIP(instanceBean.getIpaddress());
                                break block31;
                            }
                            userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_FAILURE);
                            IUserSessionBean iUserSessionBean = userSession;
                            return iUserSessionBean;
                        }
                    }
                }
                if (instanceBean != null) break block32;
            }
            catch (Throwable t) {
                block33: {
                    block34: {
                        t.printStackTrace();
                        if (userSession == null) break block33;
                        break block34;
                        finally {
                            lock.unlock();
                        }
                    }
                    userSession.setException(new JYServiceRuntimeException(t));
                }
                IUserSessionBean iUserSessionBean = userSession;
                return iUserSessionBean;
            }
            instanceBean = (IInstanceBean)Services.getInstanceService().findOne(userSession.getInstanceId());
        }
        if (instanceBean == null) {
            userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_FAILURE);
            return userSession;
        }
        if (instanceBean.getStatus() == InstanceStatus.SHUTDOWN) {
            instanceBean.start();
        }
        if (instanceBean != null && userSession.getStatus() == UserSessionStatus.INSTANCE_ASSIGNED && instanceBean.getStatus() == InstanceStatus.RUNNING && StringUtils.isNotBlank((String)instanceBean.getIpaddress()) && instanceBean.alive()) {
            ((UserSession)userSession.getDomain()).setInstanceIP(instanceBean.getIpaddress());
            new AllocateGatewayStatusHandler(userSession, instanceBean).handle();
            if (userSession.getStatus() == UserSessionStatus.GATEWAY_ALLOCATED || userSession.getStatus() == UserSessionStatus.GATEWAY_PASSING) {
                userSession.enterStatus(UserSessionStatus.RESOURCE_ALL_READY);
            }
        }
        if (UserSessionStatus.RESOURCE_ALL_READY != userSession.getStatus()) return userSession;
        if (account == null) {
            account = Services.getAccountService().findByName(userSession.getAccountName());
        }
        ((UserSession)userSession.getDomain()).setProtocol(account.getSetting().getProtocol());
        if (((UserSession)userSession.getDomain()).getVmAccount() != null) return userSession;
        ((UserSession)userSession.getDomain()).setVmAccount(account.getVmAccount(instanceBean.Id()));
        return userSession;
        finally {
            timer.stop();
            if (userSession != null) {
                userSession.save();
            }
        }
    }

    @Deprecated
    private void licenseCreateControl() {
        Integer licCount = JieyunLicense.get().getCount().sessions();
        if (licCount == null) {
            return;
        }
        DpSpec root = new DpSpec().byClass(UserSession.class);
        DpSpec sub = new DpSpec().orEquals("status", (Object)UserSessionStatus.ACTIVED);
        root.andSub(sub);
        List beans = Services.getUserSessionService().find(root);
        int runtimeCount = beans.size();
        if (runtimeCount + 1 > licCount) {
            new TrackerService.Writer.Server().sessionOverload(Services.getServerService().getCurrent()).message("warning.license.usersession.overload", new String[]{"$allow", "" + licCount, "$used", String.valueOf(runtimeCount)});
            throw new JYServiceRuntimeException("license.usersession.overload", "\u6ca1\u6709\u7a7a\u95f2\u7684\u684c\u9762\u4f1a\u8bdd\u8bb8\u53ef\u8bc1\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458\u6216\u7a0d\u540e\u767b\u5f55\uff01");
        }
    }

    @Deprecated
    private AllocateInstanceHandler getDefaultAllocateInstanceHandler(ITemplateBean template, IAccountBean account, IUserSessionBean userSession) {
        AllocateInstanceHandler handler = new AllocateInstanceHandler();
        handler.setAccount(account);
        handler.setTemplate(template);
        handler.setUserSessionBean(userSession);
        return handler;
    }

    @Deprecated
    private IUserSessionBean masterCreateConnect(UserSessionToken token, MasterCoordinator masterCoordinator) {
        try {
            IUserSessionManagerRemote userSessionManagerRemote = (IUserSessionManagerRemote)RMIUtils.getRemoteProxy(masterCoordinator.masterAddress().getAddress(), "UserSessionManagerRemote");
            userSessionManagerRemote.connect(token);
            UserSessionService userSessionService = Services.getUserSessionService();
            IUserSessionBean session = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
            if (session == null) {
                session = (IUserSessionBean)userSessionService.createOne();
                session.enterStatus(UserSessionStatus.NEW_ACCEPTED);
                return session;
            }
            return session;
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }
}
