/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.JieyunLicense;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;

public class LicenseControl {
    private static LicenseControl instance = new LicenseControl();

    public static LicenseControl instance() {
        return instance;
    }

    public void createControl() {
        Integer licCount = JieyunLicense.get().getCount().sessions();
        if (licCount == null) {
            return;
        }
        DpSpec root = new DpSpec().byClass(UserSession.class);
        DpSpec sub = new DpSpec().orEquals("status", (Object)UserSessionStatus.ACTIVED);
        root.andSub(sub);
        List beans = Services.getUserSessionService().find(root);
        int runtimeCount = beans.size();
        if (runtimeCount + 1 > licCount) {
            new TrackerService.Writer.Server().sessionOverload(Services.getServerService().getCurrent()).message("warning.license.usersession.overload", new String[]{"$allow", "" + licCount, "$used", String.valueOf(runtimeCount)});
            throw new JYServiceRuntimeException("license.usersession.overload", "\u6ca1\u6709\u7a7a\u95f2\u7684\u684c\u9762\u4f1a\u8bdd\u8bb8\u53ef\u8bc1\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458\u6216\u7a0d\u540e\u767b\u5f55\uff01");
        }
    }
}
