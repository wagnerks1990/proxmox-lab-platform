/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.shared.UserSessionToken;

public class UserSessionActiveObject {
    private UserSessionToken token;

    public void active() {
    }

    public UserSessionToken getToken() {
        return this.token;
    }

    public void setToken(UserSessionToken token) {
        this.token = token;
    }
}
