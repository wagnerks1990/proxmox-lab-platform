/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.SessionLockManager;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.agent.usersession.handler.SessionActivedHandler;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.UserSessionStatus;

public class UserSessionServant {
    private static UserSessionServant instance = new UserSessionServant();

    public static UserSessionServant instance() {
        return instance;
    }

    public boolean activedSession(IUserSessionBean userSessionBean, Id instanceId, String username, String computerIP, String computerName, String clientIP) {
        SessionLockManager.AccountSessionLock accountLock = SessionLockManager.instance().acquireAccountLock(userSessionBean.getAccountName());
        accountLock.lock();
        try {
            IInstanceBean instance = (IInstanceBean)Services.getInstanceService().findOne(instanceId);
            boolean bl = new SessionActivedHandler(userSessionBean).handle(instance, computerIP, username, computerName, clientIP);
            return bl;
        }
        finally {
            accountLock.unlock();
        }
    }

    public void endSession(IUserSessionBean userSessionBean) {
        String username = userSessionBean.getAccountName();
        SessionLockManager.AccountSessionLock sessionLock = SessionLockManager.instance().acquireAccountLock(username);
        sessionLock.lock();
        try {
            if (UserSessionStatus.ACTIVED != userSessionBean.getStatus()) {
                UserSessionLog.getLogger().info("UserSession is not ACTIVED, ignore .");
                return;
            }
            try {
                userSessionBean.enterStatus(UserSessionStatus.ENDING);
                userSessionBean.save();
                userSessionBean.destroy();
            }
            catch (Throwable t) {
                t.printStackTrace();
                userSessionBean.enterStatus(UserSessionStatus.INVALIDATE);
                userSessionBean.save();
            }
        }
        finally {
            sessionLock.unlock();
        }
    }

    public void closeSession(IUserSessionBean userSessionBean) {
        SessionLockManager.AccountSessionLock sessionLock = SessionLockManager.instance().acquireAccountLock(userSessionBean.getAccountName());
        try {
            if (userSessionBean.getStatus() == UserSessionStatus.ENDING) {
                return;
            }
            try {
                userSessionBean.destroy();
            }
            catch (Throwable t) {
                t.printStackTrace();
                userSessionBean.enterStatus(UserSessionStatus.INVALIDATE);
                userSessionBean.save();
            }
        }
        finally {
            sessionLock.unlock();
        }
    }
}
