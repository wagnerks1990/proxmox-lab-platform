/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.domain.VmAccount;
import com.jieyun.deskpool.service.JYServiceException;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.PrepState;
import com.jieyun.deskpool.shared.UserDB;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

public class AllocateInstanceHandler {
    private ITemplateBean template;
    private IAccountBean account;
    private IUserSessionBean userSessionBean;
    private IInstanceBean allocatedInstanceBean;

    public IInstanceBean allocate() {
        return this.allocateInstance();
    }

    private IInstanceBean findIdleInstance(List<IInstanceBean> instanceList, boolean isSingDeskpool) {
        for (IInstanceBean item : instanceList) {
            if (item.isAssigned() || !item.getStatus().equals((Object)InstanceStatus.RUNNING) && (!item.getStatus().equals((Object)InstanceStatus.STANDING) || !isSingDeskpool) || !item.inPrepState(PrepState.Completed)) continue;
            return item;
        }
        return null;
    }

    private IInstanceBean findOnholdInstance(List<IInstanceBean> instanceList) {
        for (IInstanceBean item : instanceList) {
            if (!item.isAssigned() || item.isSessionActive()) continue;
            return item;
        }
        return null;
    }

    private boolean suffixMatch(String str, String suffix) {
        if (StringUtils.isBlank((CharSequence)str) || StringUtils.isBlank((CharSequence)suffix)) {
            return false;
        }
        int suffixlen = suffix.length();
        int strlen = str.length();
        if (strlen < suffixlen) {
            return false;
        }
        return str.substring(strlen - suffixlen, strlen).equals(suffix);
    }

    public IInstanceBean findIdleInstanceWithSuffix(List<IInstanceBean> instanceList, String suffix, boolean forceSuffixMatch) {
        UserSessionLog.getLogger().info("findIdleInstanceWithSuffix :" + suffix);
        ArrayList<IInstanceBean> vmlist = new ArrayList<IInstanceBean>();
        for (IInstanceBean item : instanceList) {
            if (item.isAssigned() || !item.getStatus().equals((Object)InstanceStatus.RUNNING) && !forceSuffixMatch || !item.inPrepState(PrepState.Completed) || !this.suffixMatch(item.getName(), suffix)) continue;
            UserSessionLog.getLogger().info("findIdleInstanceWithSuffix : found " + item.getName());
            vmlist.add(item);
        }
        IInstanceBean result = null;
        for (IInstanceBean item : vmlist) {
            if (item.getName().length() >= (result == null ? 100 : result.getName().length())) continue;
            result = item;
        }
        UserSessionLog.getLogger().info("findIdleInstanceWithSuffix : return " + (result == null ? "null" : result.getName()));
        return result;
    }

    public IInstanceBean findNumMatchInstance(List<IInstanceBean> instanceList, String username, boolean forceSuffixMatch) {
        if (!StringUtils.isBlank((CharSequence)username)) {
            int len = username.length();
            String suffix1 = username.substring(len - 1, len);
            String suffix2 = username.substring(len - 2, len);
            String suffix3 = username.substring(len - 3, len);
            Pattern pattern = Pattern.compile("[0-9]*");
            if (pattern.matcher(suffix3).matches()) {
                return this.findIdleInstanceWithSuffix(instanceList, suffix3, forceSuffixMatch);
            }
            if (pattern.matcher(suffix2).matches()) {
                return this.findIdleInstanceWithSuffix(instanceList, suffix2, forceSuffixMatch);
            }
            if (pattern.matcher(suffix1).matches()) {
                return this.findIdleInstanceWithSuffix(instanceList, suffix1, forceSuffixMatch);
            }
        }
        return null;
    }

    private IInstanceBean allocateInstance() {
        Stopwatch timer = new Stopwatch("[allocateInstance1(user = " + this.account.getName() + ")]");
        IInstanceBean instance = null;
        boolean firstAllocated = false;
        instance = this.getAssignedInstance(this.account, this.template);
        if (instance == null) {
            firstAllocated = true;
            List<IInstanceBean> instanceList = Services.getInstanceService().findByTemplate(this.template.Id());
            int vmCount = 0;
            IServerBean server = null;
            ArrayList<IInstanceBean> onLineList = new ArrayList<IInstanceBean>();
            for (IInstanceBean item : instanceList) {
                if (item.isSessionActive()) {
                    ++vmCount;
                }
                if (!NodeStatus.ONLINE.equals((Object)(server = item.getServer()).getNodeStatus()) || item.isWaitGegenerate()) continue;
                onLineList.add(item);
            }
            instanceList = onLineList;
            if (vmCount >= this.template.getPolicy().getMaximum()) {
                UserSessionLog.getLogger().info("{} - No available instance. current instance count {} out of Template's maxInstance {}", new Object[]{this.userSessionBean, vmCount, this.template.getPolicy().getMaximum()});
            } else {
                instance = this.findNumMatchInstance(instanceList, this.account.getName(), this.template.isForceSuffixMatch());
                if (instance != null) {
                    timer.record("allocateInstance for  " + this.account.getName() + " findNumMatchInstance return :" + instance.getName());
                }
                if (instance == null) {
                    if (this.template.isForceSuffixMatch()) {
                        UserSessionLog.getLogger().info("{} - allocate instance failed. There are no Instance with suffix matched for {}.", (Object)this, (Object)this.account.getName());
                    } else {
                        instance = this.findIdleInstance(instanceList, this.template.isForceSuffixMatch());
                        if (instance != null) {
                            timer.record("allocateInstance for  " + this.account.getName() + "findIdleInstance return :" + instance.getName());
                        }
                        if (instance == null && this.template.isReassignOnhold() && (instance = this.findOnholdInstance(instanceList)) != null) {
                            timer.record("allocateInstance for  " + this.account.getName() + "findOnholdInstance return :" + instance.getName());
                        }
                    }
                }
            }
            if (instance == null) {
                UserSessionLog.getLogger().info("{} - Template {} No available instance. Check the resource of server.", (Object)this.userSessionBean, (Object)this.template.getName());
            }
        }
        String clientIP = ((UserSession)this.userSessionBean.getDomain()).getClientIP();
        if (instance != null) {
            try {
                Services.getInstanceService().connect(instance, this.account, clientIP, this.template.isReassignOnhold());
                if (firstAllocated && UserDB.DB == Services.getClusterService().getCluster().getUserdb() && this.template.isAutoFillBinding()) {
                    VmAccount vmAccount = new VmAccount();
                    vmAccount.setEnable(true);
                    vmAccount.setInstanceId(instance.Id().getId());
                    vmAccount.setUsername(this.template.getPolicy().getUsername());
                    this.account.bindVmAccount(vmAccount, this.template.getPolicy().getPassword());
                }
            }
            catch (JYServiceException e) {
                e.printStackTrace();
            }
        }
        timer.stop();
        return instance;
    }

    private IInstanceBean getAssignedInstance(IAccountBean user, ITemplateBean template) {
        IInstanceBean assignedInstance = null;
        List<IInstanceBean> allocatedInstance = Services.getInstanceService().findByUser(user.getName());
        for (IInstanceBean instance : allocatedInstance) {
            if (InstanceStatus.DESTROYED.equals((Object)instance.getStatus()) || !instance.getTemplateId().equals(template.Id())) continue;
            assignedInstance = instance;
        }
        return assignedInstance;
    }

    public ITemplateBean getTemplate() {
        return this.template;
    }

    public void setTemplate(ITemplateBean template) {
        this.template = template;
    }

    public IAccountBean getAccount() {
        return this.account;
    }

    public void setAccount(IAccountBean account) {
        this.account = account;
    }

    public IUserSessionBean getUserSessionBean() {
        return this.userSessionBean;
    }

    public void setUserSessionBean(IUserSessionBean userSessionBean) {
        this.userSessionBean = userSessionBean;
    }

    public IInstanceBean getAllocatedInstanceBean() {
        return this.allocatedInstanceBean;
    }

    public void setAllocatedInstanceBean(IInstanceBean allocatedInstanceBean) {
        this.allocatedInstanceBean = allocatedInstanceBean;
    }
}
