/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession.handler;

import com.jieyun.deskpool.agent.PoolManager;
import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.vm.Stopwatch;

public class EndSessionHandler {
    private IUserSessionBean userSessionBean;

    public EndSessionHandler(IUserSessionBean userSessionBean) {
        this.userSessionBean = userSessionBean;
    }

    public void handle() {
        IInstanceBean instance = (IInstanceBean)Services.getInstanceService().findOne(this.userSessionBean.getInstanceId());
        Stopwatch timer = new Stopwatch("[UserSession.end(" + instance + ")]");
        try {
            if (instance == null) {
                UserSessionLog.getLogger().error("{} - UserSession.end given null instance", (Object)this.userSessionBean);
                return;
            }
            try {
                instance.terminate();
                new PoolManager.Message().send();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        finally {
            timer.stop();
        }
    }
}
