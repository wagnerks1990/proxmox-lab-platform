/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import java.util.Collection;
import java.util.HashSet;

class UserSessionManager.1
extends ThreadLocal<Collection<String>> {
    UserSessionManager.1() {
    }

    @Override
    protected Collection<String> initialValue() {
        return new HashSet<String>();
    }
}
