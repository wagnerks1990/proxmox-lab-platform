/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import java.util.Stack;

static class TxManager.Tx {
    private Stack<TxManager.Tx> txStack = new Stack();

    TxManager.Tx() {
    }

    public void push(TxManager.Tx tx) {
        this.txStack.push(tx);
    }

    public void commit() {
    }
}
