/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.UserSessionLog;
import com.jieyun.deskpool.agent.usersession.handler.AllocateGatewayStatusHandler;
import com.jieyun.deskpool.agent.usersession.handler.AllocateInstanceHandler;
import com.jieyun.deskpool.agent.usersession.handler.SessionActivedHandler;
import com.jieyun.deskpool.agent.usersession.handler.TerminalInstanceHandler;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.distributed.rpc.RMIUtils;
import com.jieyun.deskpool.distributed.rpc.bean.rpcinterface.IUserSessionManagerRemote;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.AccountService;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.service.JieyunLicense;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TemplateService;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.service.UserSessionService;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.InstanceStatus;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.shared.UserSessionStatus;
import com.jieyun.deskpool.shared.UserSessionToken;
import com.jieyun.deskpool.store.spec.DpSpec;
import com.jieyun.deskpool.usersession.logs.UserOnlineCouter;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.DpDateUtils;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.utils.SpringUtils;
import com.jieyun.deskpool.utils.Util;
import com.jieyun.deskpool.vm.Stopwatch;
import com.jieyun.deskpool.windows.agentclient.AgentInfo;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.commons.lang.StringUtils;

public class UserSessionManager {
    private static UserSessionManager instance = new UserSessionManager();
    private AccountResourceHolder accountLockHolder = new AccountResourceHolder();
    private TemplateResourceHolder templateLockHolder = new TemplateResourceHolder();
    private static ThreadLocal<Collection<String>> seqLockLocal = new ThreadLocal<Collection<String>>(){

        @Override
        protected Collection<String> initialValue() {
            return new HashSet<String>();
        }
    };
    private LimitLock limitLock = new LimitLock();
    private static long licenseCheckTime = System.currentTimeMillis();

    public static UserSessionManager instance() {
        return instance;
    }

    public void init() {
    }

    public IUserSessionBean createSessionNew(UserSessionToken token) {
        try {
            if (this.limitLock.reqDeny()) {
                UserSessionLog.getLogger().info("reqDeny true, NEW_WAITING");
                IUserSessionBean userSessionBean = (IUserSessionBean)Services.getUserSessionService().createOne();
                userSessionBean.enterStatus(UserSessionStatus.NEW_WAITING);
                IUserSessionBean iUserSessionBean = userSessionBean;
                return iUserSessionBean;
            }
            UserSessionLog.getLogger().info("reqDeny false, createSession");
            try {
                Thread.sleep(500L);
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
            IUserSessionBean iUserSessionBean = this.createSession(token);
            return iUserSessionBean;
        }
        finally {
            this.limitLock.reqDecrement();
        }
    }

    public IUserSessionBean connectTemplateNew(UserSessionToken token, AllocateInstanceHandler allocateInstanceHandler) {
        try {
            if (this.limitLock.reqDeny()) {
                IUserSessionBean iUserSessionBean = Services.getUserSessionService().findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
                return iUserSessionBean;
            }
            IUserSessionBean iUserSessionBean = this.connectTemplate(token, allocateInstanceHandler);
            return iUserSessionBean;
        }
        finally {
            this.limitLock.reqDecrement();
        }
    }

    public IUserSessionBean createSession(UserSessionToken token) {
        MasterCoordinator masterCoordinator;
        Bean userSessionBean = null;
        if (StringUtils.isBlank((String)token.getDpUsername())) {
            throw new JYServiceRuntimeException("usersession.create.username.isNull", "\u7528\u6237\u540d\u4e3a\u7a7a");
        }
        if (StringUtils.isBlank((String)token.getTemplateName())) {
            throw new JYServiceRuntimeException("usersession.create.templateName.isNull", "templateName\u4e3a\u7a7a");
        }
        if (StringUtils.isBlank((String)token.getClientIP())) {
            throw new JYServiceRuntimeException("usersession.create.clientIP.isNull", "ClientIP\u4e3a\u7a7a");
        }
        if (StringUtils.isBlank((String)token.getContextPath())) {
            throw new JYServiceRuntimeException("usersession.create.contextPath.isNull");
        }
        if (StringUtils.isBlank((String)token.getJsessionId())) {
            throw new RuntimeException("usersession.create.jsession.isNull");
        }
        if (token.getProtocol() == null) {
            token.setProtocol(Desktop.Protocol.RDP);
        }
        if (!(masterCoordinator = MasterCoordinator.instance()).isMasterLocal()) {
            return this.masterCreateNew(token, masterCoordinator);
        }
        AccountService accountService = Services.getAccountService();
        IAccountBean accountBean = accountService.findByName(token.getDpUsername());
        if (accountBean == null) {
            throw new JYServiceRuntimeException("usersession.create.accountNotFound", "\u7528\u6237\u4e0d\u5b58\u5728");
        }
        AccountSessionLock sessionLock = this.accountLockHolder.createIfAbsent(token.getDpUsername());
        UserSessionLog.getLogger().info("CreateNewSession -- {}", (Object)token);
        sessionLock.lock();
        try {
            UserSessionService userSessionService = (UserSessionService)SpringUtils.context.getBean(UserSessionService.class);
            TemplateService templateService = Services.getTemplateService();
            ITemplateBean templateBean = templateService.findByName(token.getTemplateName());
            if (templateBean == null) {
                throw new JYServiceRuntimeException("usersession.create.template.isNull", "\u6a21\u7248\u4e3a\u7a7a");
            }
            List<IUserSessionBean> beans = userSessionService.findByUserAndTemplate(token.getDpUsername(), token.getTemplateName());
            for (IUserSessionBean bean : beans) {
                try {
                    bean.destroy();
                }
                catch (Exception e) {
                    e.printStackTrace();
                    bean.remove();
                }
            }
            if (userSessionBean == null) {
                userSessionBean = (IUserSessionBean)userSessionService.createOne();
            }
            UserSession domain = (UserSession)userSessionBean.getDomain();
            domain.setStatus(UserSessionStatus.NEW);
            domain.setAccountName(token.getDpUsername());
            domain.setAccountId(accountBean.Id().getId());
            domain.setClientIP(token.getClientIP());
            domain.setDateCreated(new Date());
            domain.setDateUpdated(new Date());
            domain.setTemplateName(token.getTemplateName());
            domain.setProtocol(token.getProtocol());
            domain.setServerId(Services.getServerService().getCurrent().Id().getId());
            domain.setInstanceId(null);
            domain.setContextPath(token.getContextPath());
            domain.setJsessionId(token.getJsessionId());
            domain.setPortMappingId(null);
            domain.setPingAgentCount(0);
            domain.setVmAccount(null);
            domain.setTcId(token.getTcId());
            domain.setSgw(token.getSgw());
            userSessionBean.setConnectedTemplate(templateBean);
            userSessionBean.setAccountId(accountBean.Id());
            userSessionBean.setTemplateId(templateBean.Id());
            domain.setAccountName(token.getDpUsername());
            domain.setConnectInstanceName(token.getConnectInstanceName());
            UserSessionLog.getLogger().info("call licenseCreateControl.. ");
            this.licenseSessionControl((IUserSessionBean)userSessionBean);
            Bean bean = userSessionBean;
            return bean;
        }
        finally {
            try {
                userSessionBean.save();
            }
            finally {
                sessionLock.unlock();
            }
        }
    }

    private IUserSessionBean newWaitingStatus() {
        IUserSessionBean userSessionBean = (IUserSessionBean)Services.getUserSessionService().createOne();
        userSessionBean.enterStatus(UserSessionStatus.NEW_WAITING);
        return userSessionBean;
    }

    private IUserSessionBean masterCreateNew(UserSessionToken token, MasterCoordinator masterCoordinator) {
        try {
            IUserSessionManagerRemote userSessionManagerRemote = (IUserSessionManagerRemote)RMIUtils.getRemoteProxy(masterCoordinator.masterAddress().getAddress(), "UserSessionManagerRemote");
            userSessionManagerRemote.createNew(token);
            UserSessionService userSessionService = Services.getUserSessionService();
            IUserSessionBean session = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
            if (session == null) {
                session = (IUserSessionBean)userSessionService.createOne();
                session.enterStatus(UserSessionStatus.NEW_ACCEPTED);
                return session;
            }
            return session;
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    private IUserSessionBean masterCreateConnect(UserSessionToken token, MasterCoordinator masterCoordinator) {
        try {
            IUserSessionManagerRemote userSessionManagerRemote = (IUserSessionManagerRemote)RMIUtils.getRemoteProxy(masterCoordinator.masterAddress().getAddress(), "UserSessionManagerRemote");
            userSessionManagerRemote.connect(token);
            UserSessionService userSessionService = Services.getUserSessionService();
            IUserSessionBean session = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
            if (session == null) {
                session = (IUserSessionBean)userSessionService.createOne();
                session.enterStatus(UserSessionStatus.NEW_ACCEPTED);
                return session;
            }
            return session;
        }
        catch (Exception e) {
            throw new JYServiceRuntimeException(e);
        }
    }

    private boolean needCheckLicense() {
        if (!JieyunLicense.get().getIndate().valid()) {
            return true;
        }
        long current = System.currentTimeMillis();
        return current - licenseCheckTime > 60000L;
    }

    private void freshLicenseCheckTime() {
        licenseCheckTime = System.currentTimeMillis();
    }

    private void licenseSessionControl(IUserSessionBean session) {
        if (!this.needCheckLicense()) {
            return;
        }
        boolean passed = true;
        try {
            if (JieyunLicense.get().getIndate().strike()) {
                passed = false;
                new TrackerService.Writer.License().licenseError().message("warning.license.strike", new String[]{"$username", session.getAccountName(), "$template", session.getTemplateName()});
                throw new JYServiceRuntimeException("license.strike", "\u7531\u4e8e\u8f6f\u4ef6\u8bb8\u53ef\u8fc7\u671f\uff0c\u7cfb\u7edf\u65e0\u6cd5\u63d0\u4f9b\u670d\u52a1\uff01");
            }
            Integer licCount = JieyunLicense.get().getCount().sessions();
            if (licCount != null) {
                DpSpec root = new DpSpec().byClass(UserSession.class);
                DpSpec sub = new DpSpec().orEquals("status", (Object)UserSessionStatus.ACTIVED);
                root.andSub(sub);
                List beans = Services.getUserSessionService().find(root);
                int runtimeCount = beans.size();
                if (runtimeCount + 1 > licCount) {
                    passed = false;
                    new TrackerService.Writer.License().sessionOverload().message("warning.license.usersession.overload", new String[]{"$allow", "" + licCount, "$used", String.valueOf(runtimeCount)});
                    throw new JYServiceRuntimeException("license.usersession.overload", "\u6ca1\u6709\u7a7a\u95f2\u7684\u684c\u9762\u4f1a\u8bdd\u8bb8\u53ef\u8bc1\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458\u6216\u7a0d\u540e\u767b\u5f55\uff01");
                }
            }
        }
        finally {
            if (passed) {
                this.freshLicenseCheckTime();
            }
        }
    }

    private IUserSessionBean connectTemplate(UserSessionToken token, AllocateInstanceHandler allocateInstanceHandler) {
        return this.connectTemplate(token, null, null, null, allocateInstanceHandler);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private IUserSessionBean connectTemplate(UserSessionToken token, IUserSessionBean userSession, ITemplateBean template, IAccountBean account, AllocateInstanceHandler allocateInstanceHandler) {
        IInstanceBean instanceBean;
        Stopwatch timer;
        block32: {
            TemplateSessionLock lock;
            timer = new Stopwatch("[connectTemplate(user = " + token.getDpUsername() + ")]");
            MasterCoordinator masterCoordinator = MasterCoordinator.instance();
            if (!masterCoordinator.isMasterLocal()) {
                return this.masterCreateConnect(token, masterCoordinator);
            }
            try {
                block31: {
                    String curClientIP;
                    String tokenClientIP;
                    if (userSession == null) {
                        this.licenseSessionControl(userSession);
                        UserSessionService userSessionService = Services.getUserSessionService();
                        userSession = userSessionService.findLastCreated(token.getDpUsername(), token.getTemplateName(), token.getClientIP());
                        if (userSession == null) {
                            UserSessionLog.getLogger().info(" UserSession not found . ");
                            throw new JYServiceRuntimeException("usersession.invalidate", "\u8fde\u63a5\u5f02\u5e38");
                        }
                    }
                    if (!(tokenClientIP = token.getClientIP()).equals(curClientIP = userSession.getClientIP())) {
                        throw new JYServiceRuntimeException("usersession.clientIP.notmatch", "\u5e10\u6237\u5728\u5176\u5b83\u5730\u70b9\u767b\u5f55");
                    }
                    if (UserSessionStatus.INVALIDATE == userSession.getStatus()) {
                        throw new JYServiceRuntimeException("usersession.invalidate", "\u8fde\u63a5\u5df2\u5931\u6548\u3002");
                    }
                    if (UserSessionStatus.GATEWAY_ALLOCATE_FAILED == userSession.getStatus()) {
                        throw new JYServiceRuntimeException("usersession.gateway.allocateFailure", "\u7f51\u5173\u7533\u8bf7\u5931\u8d25\u3002");
                    }
                    if (UserSessionStatus.INSTANCE_ASSIGN_FAILURE == userSession.getStatus()) {
                        IUserSessionBean iUserSessionBean = userSession;
                        return iUserSessionBean;
                    }
                    userSession.touch(false);
                    if (UserSessionStatus.NEW == userSession.getStatus()) {
                        account = Services.getAccountService().findByName(userSession.getAccountName());
                        if (account == null) {
                            throw new JYServiceRuntimeException("usersession.accountNotFound", "\u7528\u6237\u4e0d\u5b58\u5728\u3002");
                        }
                        userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_WAITING);
                    }
                    instanceBean = null;
                    if (((UserSession)userSession.getDomain()).getStatus() == UserSessionStatus.INSTANCE_ASSIGN_WAITING) {
                        if (template == null) {
                            template = Services.getTemplateService().findByName(userSession.getTemplateName());
                        }
                        if (account == null) {
                            account = Services.getAccountService().findByName(userSession.getAccountName());
                        }
                        if (template != null) {
                            userSession.setConnectedTemplate(template);
                            lock = null;
                            lock = this.templateLockHolder.createIfAbsent(template.Id());
                            lock.lock();
                            instanceBean = allocateInstanceHandler == null ? this.getDefaultAllocateInstanceHandler(template, account, userSession).allocate() : allocateInstanceHandler.allocate();
                            if (instanceBean != null) {
                                timer.record("connecting  instance " + instanceBean.getName() + " to " + token.getDpUsername());
                                userSession.setInstanceId(instanceBean.Id());
                                userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGNED);
                                ((UserSession)userSession.getDomain()).setInstanceIP(instanceBean.getIpaddress());
                                break block31;
                            }
                            userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_FAILURE);
                            IUserSessionBean iUserSessionBean = userSession;
                            return iUserSessionBean;
                        }
                    }
                }
                if (instanceBean != null) break block32;
            }
            catch (Throwable t) {
                block33: {
                    block34: {
                        t.printStackTrace();
                        if (userSession == null) break block33;
                        break block34;
                        finally {
                            lock.unlock();
                        }
                    }
                    userSession.setException(new JYServiceRuntimeException(t));
                }
                IUserSessionBean iUserSessionBean = userSession;
                return iUserSessionBean;
            }
            instanceBean = (IInstanceBean)Services.getInstanceService().findOne(userSession.getInstanceId());
        }
        if (instanceBean == null) {
            userSession.enterStatus(UserSessionStatus.INSTANCE_ASSIGN_FAILURE);
            return userSession;
        }
        if (instanceBean.getStatus() == InstanceStatus.SHUTDOWN) {
            instanceBean.start();
        }
        if (instanceBean != null && userSession.getStatus() == UserSessionStatus.INSTANCE_ASSIGNED && instanceBean.getStatus() == InstanceStatus.RUNNING && StringUtils.isNotBlank((String)instanceBean.getIpaddress()) && instanceBean.alive()) {
            ((UserSession)userSession.getDomain()).setInstanceIP(instanceBean.getIpaddress());
            new AllocateGatewayStatusHandler(userSession, instanceBean).handle();
            if (userSession.getStatus() == UserSessionStatus.GATEWAY_ALLOCATED || userSession.getStatus() == UserSessionStatus.GATEWAY_PASSING) {
                userSession.enterStatus(UserSessionStatus.RESOURCE_ALL_READY);
            }
        }
        if (UserSessionStatus.RESOURCE_ALL_READY != userSession.getStatus()) return userSession;
        if (account == null) {
            account = Services.getAccountService().findByName(userSession.getAccountName());
        }
        ((UserSession)userSession.getDomain()).setProtocol(account.getSetting().getProtocol());
        if (((UserSession)userSession.getDomain()).getVmAccount() != null) return userSession;
        ((UserSession)userSession.getDomain()).setVmAccount(account.getVmAccount(instanceBean.Id()));
        return userSession;
        finally {
            timer.stop();
            if (userSession != null) {
                userSession.save();
            }
        }
    }

    public PingAgentResult pingAgent(IUserSessionBean sessionBean, IInstanceBean inst) {
        AccountSessionLock accountLock = this.accountLockHolder.createIfAbsent(sessionBean.getAccountName());
        accountLock.lock();
        try {
            sessionBean = (IUserSessionBean)sessionBean.refresh();
            UserSession userSession = (UserSession)sessionBean.getDomain();
            int count = userSession.getPingAgentCount();
            userSession.setPingAgentCount(++count);
            if (count > 6) {
                PingAgentResult pingAgentResult = PingAgentResult.AGENT_OFFLINE;
                return pingAgentResult;
            }
            sessionBean.save();
            PingAgentResult pingAgentResult = inst.agentAlive() ? PingAgentResult.SUCCESS : PingAgentResult.FAILURE;
            return pingAgentResult;
        }
        finally {
            accountLock.unlock();
        }
    }

    public boolean activedSession(IInstanceBean instance, String username, String computerIP, String computerName, String clientIP) {
        UserSessionService userSessionService = (UserSessionService)SpringUtils.context.getBean(UserSessionService.class);
        List<IUserSessionBean> userSessionBeans = userSessionService.findValidate(instance.Id());
        String displayip = "";
        if (!StringUtils.isEmpty((String)clientIP) && !clientIP.equalsIgnoreCase("none")) {
            displayip = clientIP;
        }
        if (!displayip.equalsIgnoreCase(instance.getClientLocation())) {
            UserSessionLog.getLogger().info(" record user login ");
            instance.getUpdate().setClientLocation(displayip).save();
            Date curTime = new Date();
            if (StringUtils.isBlank((String)displayip)) {
                long stayMinutes = 0L;
                long staySeconds = 0L;
                if (instance.getLoginTime() != null) {
                    staySeconds = (curTime.getTime() - instance.getLoginTime().getTime()) / 1000L;
                    stayMinutes = staySeconds / 60L;
                    staySeconds -= 60L * stayMinutes;
                }
                UserOnlineCouter.getLogger().info(",{},{},{},{},{},{},{}", new Object[]{instance.getUsername(), DpDateUtils.getDateDayString(curTime), DpDateUtils.getDateString(instance.getLoginTime()), DpDateUtils.getDateString(curTime), "offline", stayMinutes, staySeconds});
            } else {
                UserOnlineCouter.getLogger().info(",{},{},{},{},{}", new Object[]{instance.getUsername(), DpDateUtils.getDateDayString(curTime), DpDateUtils.getDateString(curTime), "", "online"});
            }
        }
        boolean disableBrowserLogin = ClusterNodeBean.isDisableNonPlatformLogin();
        if (userSessionBeans.isEmpty()) {
            if (disableBrowserLogin && !instance.isImageInstance().booleanValue()) {
                this.breachInstance(instance);
                new TrackerService.Writer.Instance().login(instance).failure("error.desktop.connect.unassigned", new String[]{"$username", username, "$clientIP", clientIP});
                return false;
            }
            String adminName = instance.getVmParam("adminname", "Administrator");
            if (adminName.equalsIgnoreCase(username)) {
                if (instance.hasVmParam("adminlogin")) {
                    UserSessionLog.getLogger().info("Notify has user login - user is Administrator , return false . ");
                    return false;
                }
                instance.getUpdate().setVmParam("adminlogin", Util.secondsDateFormat.format(new Date())).setVmParam("computername", computerName).setLoginTime(new Date()).setIpaddress(computerIP).save();
                UserSessionLog.getLogger().info("Notify has user login - user is Administrator , return true . ");
                return true;
            }
            UserSessionLog.getLogger().info("No usersession attach to instance:{} ip:{} user:{} computername:{}", new Object[]{instance, computerIP, username, computerName});
            return false;
        }
        if (disableBrowserLogin && !this.haveClientIp(userSessionBeans, clientIP) && !instance.isImageInstance().booleanValue()) {
            UserSessionLog.getLogger().info("breach session on clientIP {}", (Object)clientIP);
            this.breachInstance(instance);
            new TrackerService.Writer.Instance().login(instance).failure("error.desktop.connect.unassigned", new String[]{"$username", username, "$clientIP", clientIP});
            return false;
        }
        for (IUserSessionBean userSessionBean : userSessionBeans) {
            this.activedSession(userSessionBean, instance, username, computerIP, computerName, clientIP);
        }
        return true;
    }

    private boolean haveClientIp(List<IUserSessionBean> userSessionBeans, String clientIp) {
        if (StringUtils.isEmpty((String)clientIp)) {
            return true;
        }
        for (IUserSessionBean userSessionBean : userSessionBeans) {
            if (!clientIp.equals(userSessionBean.getClientIP())) continue;
            return true;
        }
        return false;
    }

    private void breachInstance(IInstanceBean instance) {
        Stopwatch timer = new Stopwatch("[UserSession.breach(" + instance.toString() + ")]");
        try {
            instance.logoff();
        }
        finally {
            timer.stop();
        }
    }

    public boolean endSession(IInstanceBean instance, AgentInfo agentInfo) {
        if (instance == null) {
            throw new JYServiceRuntimeException("usersession.end.instance.null", "instance\u4e3a\u7a7a");
        }
        UserSessionService userSessionService = Services.getUserSessionService();
        List<IUserSessionBean> userSessionBeanList = userSessionService.findValidate(instance.Id());
        if (userSessionBeanList.isEmpty()) {
            instance.getUpdate().clearLoginTime().clearClientLocation().clearVmParam("adminlogin").save();
            return false;
        }
        for (IUserSessionBean userSessionBean : userSessionBeanList) {
            this.endSession(userSessionBean);
        }
        return true;
    }

    public void closeSession(IInstanceBean instanceBean) {
        if (instanceBean == null) {
            throw new JYServiceRuntimeException("usersession.end.instance.null", "instance\u4e3a\u7a7a");
        }
        instanceBean.clearLoginTime();
        instanceBean.clearClientLocation();
        UserSessionService userSessionService = (UserSessionService)SpringUtils.context.getBean(UserSessionService.class);
        List<IUserSessionBean> userSessionBeanList = userSessionService.findByInstance(instanceBean.Id());
        for (IUserSessionBean userSessionBean : userSessionBeanList) {
            this.closeSession(userSessionBean);
        }
    }

    public void destroyInvalidateSession(IUserSessionBean userSessionBean) {
        block11: {
            if (StringUtils.isBlank((String)userSessionBean.getAccountName())) {
                this.destroySession(userSessionBean);
                UserSessionLog.getLogger().debug("Destroy session without name {}", (Object)userSessionBean);
                return;
            }
            AccountSessionLock accountLock = this.accountLockHolder.createIfAbsent(userSessionBean.getAccountName());
            accountLock.lock();
            try {
                userSessionBean = (IUserSessionBean)userSessionBean.refresh();
                int lastUpdatePerio = userSessionBean.lastUpdatePeriod();
                if ((userSessionBean.getStatus() == UserSessionStatus.INVALIDATE || userSessionBean.getStatus() == UserSessionStatus.INSTANCE_ASSIGN_FAILURE || userSessionBean.getStatus() == UserSessionStatus.GATEWAY_ALLOCATE_FAILED) && lastUpdatePerio > 30) {
                    this.destroySession(userSessionBean);
                    return;
                }
                if (userSessionBean.getStatus() == UserSessionStatus.RESOURCE_ALL_READY && lastUpdatePerio > 600) {
                    this.destroySession(userSessionBean);
                    return;
                }
                if (userSessionBean.getStatus() == UserSessionStatus.ACTIVED && lastUpdatePerio > 600) {
                    this.destroySession(userSessionBean);
                    return;
                }
                if (lastUpdatePerio >= 3600) {
                    this.destroySession(userSessionBean);
                    break block11;
                }
                UserSessionLog.getLogger().debug("Destroy invalidate session ignore - {}", (Object)userSessionBean);
                return;
            }
            finally {
                accountLock.unlock();
            }
        }
    }

    private void releasePortMapping(IUserSessionBean userSessionBean) {
        IPortMappingBean portMappingBean = userSessionBean.getPortMapping();
        if (portMappingBean != null) {
            userSessionBean.setPortMappingId(null);
            ((PortMapping)portMappingBean.getDomain()).setStatus(PortMappingStatus.MARK_RELEASE);
            portMappingBean.save();
            portMappingBean.release();
        }
    }

    private void destroySession(IUserSessionBean userSessionBean) {
        try {
            if (StringUtils.isBlank((String)userSessionBean.getAccountName())) {
                userSessionBean.remove();
                return;
            }
            AccountSessionLock accountLock = this.accountLockHolder.createIfAbsent(userSessionBean.getAccountName());
            accountLock.lock();
            try {
                try {
                    UserSessionLog.getLogger().info("Destroy session -- {}", (Object)userSessionBean);
                    userSessionBean.remove();
                }
                catch (Throwable t) {
                    t.printStackTrace();
                    userSessionBean.save();
                    accountLock.unlock();
                }
            }
            finally {
                accountLock.unlock();
            }
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private AllocateInstanceHandler getDefaultAllocateInstanceHandler(ITemplateBean template, IAccountBean account, IUserSessionBean userSession) {
        AllocateInstanceHandler handler = new AllocateInstanceHandler();
        handler.setAccount(account);
        handler.setTemplate(template);
        handler.setUserSessionBean(userSession);
        return handler;
    }

    private boolean activedSession(IUserSessionBean userSessionBean, IInstanceBean instance, String username, String computerIP, String computerName, String clientIP) {
        AccountSessionLock accountLock = this.accountLockHolder.createIfAbsent(((UserSession)userSessionBean.getDomain()).getAccountName());
        accountLock.lock();
        try {
            userSessionBean = (IUserSessionBean)userSessionBean.refresh();
            boolean bl = new SessionActivedHandler(userSessionBean).handle(instance, computerIP, username, computerName, clientIP);
            return bl;
        }
        finally {
            accountLock.unlock();
        }
    }

    private void endSession(IUserSessionBean userSessionBean) {
        String username = userSessionBean.getAccountName();
        AccountSessionLock sessionLock = this.accountLockHolder.createIfAbsent(username);
        sessionLock.lock();
        try {
            userSessionBean = (IUserSessionBean)userSessionBean.refresh();
            if (UserSessionStatus.ACTIVED != userSessionBean.getStatus()) {
                UserSessionLog.getLogger().info("UserSession is not ACTIVED, ignore .");
                return;
            }
            try {
                userSessionBean.enterStatus(UserSessionStatus.ENDING);
                userSessionBean.save();
                new TerminalInstanceHandler().handle(userSessionBean);
                this.destroySession(userSessionBean);
                IPortMappingBean portMappingBean = userSessionBean.getPortMapping();
                if (portMappingBean != null) {
                    portMappingBean.release();
                }
            }
            catch (Throwable t) {
                t.printStackTrace();
                userSessionBean.enterStatus(UserSessionStatus.INVALIDATE);
                userSessionBean.save();
            }
        }
        finally {
            sessionLock.unlock();
            this.accountLockHolder.remove(username);
        }
    }

    private void closeSession(IUserSessionBean userSessionBean) {
        String username = userSessionBean.getAccountName();
        AccountSessionLock sessionLock = this.accountLockHolder.createIfAbsent(username);
        sessionLock.lock();
        try {
            userSessionBean = (IUserSessionBean)userSessionBean.refresh();
            if (userSessionBean.getStatus() == UserSessionStatus.ENDING) {
                return;
            }
            try {
                new TerminalInstanceHandler().handle(userSessionBean);
                this.destroySession(userSessionBean);
                IPortMappingBean portMappingBean = userSessionBean.getPortMapping();
                if (portMappingBean != null) {
                    portMappingBean.release();
                }
            }
            catch (Throwable t) {
                t.printStackTrace();
                userSessionBean.enterStatus(UserSessionStatus.INVALIDATE);
                userSessionBean.save();
            }
        }
        finally {
            sessionLock.unlock();
            this.accountLockHolder.remove(username);
        }
    }

    public static class AccountResourceHolder
    extends ConcurrentHashMap<String, AccountSessionLock> {
        private String hashKey(String key) {
            String ikey = String.valueOf(key.hashCode() % 50);
            return ikey;
        }

        public AccountSessionLock createIfAbsent(String key) {
            AccountSessionLock newLock;
            String internalKey = this.hashKey(key);
            AccountSessionLock sessionLock = (AccountSessionLock)this.get(internalKey);
            if (sessionLock == null && (sessionLock = this.putIfAbsent(internalKey, newLock = new AccountSessionLock(internalKey, this))) == null) {
                sessionLock = newLock;
            }
            return sessionLock;
        }
    }

    public static class AccountSessionLock
    extends OrderCheckReentrantLock {
        private static final long serialVersionUID = 1L;
        private String key;
        private AccountResourceHolder holder;

        public AccountSessionLock(String key, AccountResourceHolder holder) {
            this.key = key;
            this.holder = holder;
        }

        @Override
        protected void checkAndSet() {
            Collection localSeqList = (Collection)seqLockLocal.get();
            if (localSeqList.contains("templateLock")) {
                throw new RuntimeException("Invalid lock order , templateLock -> accountLock .");
            }
            if (localSeqList.contains("gatewayLock")) {
                throw new RuntimeException("Lock reject , gateway is locking , can not acquire other lock .");
            }
            localSeqList.add("accountLock");
        }

        @Override
        protected void removeOrder() {
            Collection localSeqList = (Collection)seqLockLocal.get();
            localSeqList.remove("accountLock");
        }

        @Override
        public void unlock() {
            super.unlock();
        }
    }

    private static class LimitLock {
        private AtomicInteger createNumLock = new AtomicInteger(0);
        private int max;

        public LimitLock() {
            AppProps props = AppProps.instance();
            this.max = props.get("usersession.connect.limit", 50);
            if (Props.instance().has("usersession.connect.limit")) {
                this.max = Props.instance().get("usersession.connect.limit", this.max);
            }
        }

        public int getCurrentNum() {
            return this.createNumLock.get();
        }

        public boolean reqDeny() {
            boolean result = this.createNumLock.incrementAndGet() > this.max;
            UserSessionLog.getLogger().info("Connect Speed Limit {} session/sec,  current {} session/sec  --- reqDeny return {}  ", new Object[]{this.max, this.getCurrentNum(), result});
            return result;
        }

        public void reqDecrement() {
            this.createNumLock.decrementAndGet();
        }
    }

    public static abstract class OrderCheckReentrantLock
    extends ReentrantLock {
        protected abstract void checkAndSet();

        protected abstract void removeOrder();

        @Override
        public void lock() {
            this.checkAndSet();
            super.lock();
        }

        @Override
        public boolean tryLock() {
            this.checkAndSet();
            boolean result = super.tryLock();
            if (!result) {
                this.removeOrder();
            }
            return result;
        }

        @Override
        public boolean tryLock(long timeout, TimeUnit unit) throws InterruptedException {
            this.checkAndSet();
            boolean result = super.tryLock(timeout, unit);
            if (!result) {
                this.removeOrder();
            }
            return result;
        }

        @Override
        public void lockInterruptibly() throws InterruptedException {
            this.checkAndSet();
            try {
                super.lockInterruptibly();
            }
            catch (InterruptedException e) {
                this.removeOrder();
                throw e;
            }
        }

        @Override
        public void unlock() {
            try {
                this.removeOrder();
            }
            finally {
                super.unlock();
            }
        }
    }

    public static enum PingAgentResult {
        SUCCESS,
        FAILURE,
        AGENT_OFFLINE;

    }

    public static class TemplateResourceHolder
    extends ConcurrentHashMap<Id, TemplateSessionLock> {
        public TemplateSessionLock createIfAbsent(Id id) {
            TemplateSessionLock lock = this.putIfAbsent(id, new TemplateSessionLock());
            if (lock == null) {
                lock = this.get(id);
            }
            return lock;
        }

        @Override
        public TemplateSessionLock get(Object key) {
            return (TemplateSessionLock)super.get(key);
        }
    }

    public static class TemplateSessionLock
    extends OrderCheckReentrantLock {
        private static final long serialVersionUID = 1L;

        @Override
        protected void checkAndSet() {
            Collection localSeqList = (Collection)seqLockLocal.get();
            if (localSeqList.contains("gatewayLock")) {
                throw new RuntimeException("Lock reject , gateway is locking , can not acquire other lock .");
            }
            localSeqList.add("templateLock");
        }

        @Override
        protected void removeOrder() {
            ((Collection)seqLockLocal.get()).remove("templateLock");
        }
    }
}
