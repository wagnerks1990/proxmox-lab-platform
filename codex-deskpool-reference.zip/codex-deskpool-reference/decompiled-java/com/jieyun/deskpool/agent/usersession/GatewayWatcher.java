/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.joda.time.DateTime
 *  org.joda.time.Minutes
 *  org.joda.time.ReadableInstant
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.GatewayManager;
import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.agent.utils.JYTimedEngine;
import com.jieyun.deskpool.bean.gateway.IGatewayConfigBean;
import com.jieyun.deskpool.bean.gateway.IPortMappingBean;
import com.jieyun.deskpool.domain.GatewayConfig;
import com.jieyun.deskpool.domain.PortMapping;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.PortMappingStatus;
import com.jieyun.deskpool.vm.Event;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Minutes;
import org.joda.time.ReadableInstant;

public class GatewayWatcher
extends JYTimedEngine
implements ApplicationLifecycle.LifecycleListener {
    private static GatewayWatcher instance = new GatewayWatcher("GatewayWatcher", 5L);

    public static GatewayWatcher instance() {
        return instance;
    }

    public GatewayWatcher(String name, long seconds) {
        super(name, seconds);
        this.subscribe(JYMessage.class, new EventHandler());
    }

    @Override
    protected Event defaultEvent() {
        return new JYMessage();
    }

    @Override
    public void onStart() {
        this.start();
    }

    @Override
    public void onShutdown() {
        this.quit();
    }

    public class EventHandler
    implements Event.Recipient {
        @Override
        public boolean receive(Event paramEvent) {
            this.gatewayHeartbeat();
            this.handleDirtyPort();
            return true;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private boolean gatewayHeartbeat() {
            try {
                Throwable throwable = null;
                Object var2_4 = null;
                try {
                    Socket socket = new Socket();
                    try {
                        IGatewayConfigBean config = Services.getGatewayService().getDefault();
                        if (StringUtils.isBlank((String)((GatewayConfig)config.getDomain()).getInternalIP())) {
                            return false;
                        }
                        socket.setSoTimeout(10000);
                        socket.connect(new InetSocketAddress(((GatewayConfig)config.getDomain()).getInternalIP(), 12345));
                        if (socket.isConnected()) {
                            GatewayManager.instance().setServerStatus(GatewayManager.GatewayServerStatus.NORMAL);
                            return true;
                        }
                        GatewayManager.instance().setServerStatus(GatewayManager.GatewayServerStatus.UNREACHABLE);
                        return true;
                    }
                    finally {
                        if (socket == null) return false;
                        socket.close();
                    }
                }
                catch (Throwable throwable2) {
                    if (throwable == null) {
                        throwable = throwable2;
                        throw throwable;
                    }
                    if (throwable == throwable2) throw throwable;
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
            }
            catch (Exception e) {
                GatewayManager.instance().setServerStatus(GatewayManager.GatewayServerStatus.UNREACHABLE);
                e.printStackTrace();
            }
            return true;
        }

        private boolean handleDirtyPort() {
            if (GatewayManager.instance().isServiceNormal()) {
                List portMappingBeans = Services.getPortMappingService().findAll();
                for (IPortMappingBean portMappingBean : portMappingBeans) {
                    Minutes mins;
                    Date dateCreated;
                    if (PortMappingStatus.RELEASE_EXCEPTION == ((PortMapping)portMappingBean.getDomain()).getStatus()) {
                        GatewayManager.instance().send(new GatewayManager.ReleaseMessage(portMappingBean));
                    }
                    if (PortMappingStatus.MARK_RELEASE != ((PortMapping)portMappingBean.getDomain()).getStatus() || (dateCreated = ((PortMapping)portMappingBean.getDomain()).getDateCreated()) == null || (mins = Minutes.minutesBetween((ReadableInstant)new DateTime((Object)dateCreated), (ReadableInstant)new DateTime())).getMinutes() <= 20) continue;
                    GatewayManager.instance().send(new GatewayManager.ReleaseMessage(portMappingBean));
                }
            }
            return true;
        }
    }
}
