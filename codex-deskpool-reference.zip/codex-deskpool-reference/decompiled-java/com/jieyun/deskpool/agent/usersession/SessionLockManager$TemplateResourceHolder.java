/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.usersession;

import com.jieyun.deskpool.agent.usersession.SessionLockManager;
import com.jieyun.deskpool.shared.Id;
import java.util.concurrent.ConcurrentHashMap;

public static class SessionLockManager.TemplateResourceHolder
extends ConcurrentHashMap<Id, SessionLockManager.TemplateSessionLock> {
    public SessionLockManager.TemplateSessionLock createIfAbsent(Id id) {
        SessionLockManager.TemplateSessionLock lock = this.putIfAbsent(id, new SessionLockManager.TemplateSessionLock());
        if (lock == null) {
            lock = this.get(id);
        }
        return lock;
    }

    @Override
    public SessionLockManager.TemplateSessionLock get(Object key) {
        return (SessionLockManager.TemplateSessionLock)super.get(key);
    }
}
