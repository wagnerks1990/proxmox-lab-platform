/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.Script;
import com.jieyun.deskpool.vm.Event;
import java.util.regex.Matcher;
import org.apache.commons.lang.StringUtils;

public class DeskpoolDiskWatcher.EventHandler
implements Event.Recipient {
    @Override
    public boolean receive(Event paramEvent) {
        Matcher matcher;
        if (System.getProperty("os.name").contains("Windows")) {
            return true;
        }
        String cmd = "df";
        String result = Script.runSimpleBashRemoteScript(cmd, 1200);
        if (result != null && (matcher = pattern.matcher(result)).find()) {
            String usedCapStr = matcher.group(1);
            Double usedCap = Double.parseDouble(usedCapStr);
            String thresholdStr = AppProps.instance().get("deskpool.disk.capacity.warning.threshold");
            Double threshold = StringUtils.isBlank((String)thresholdStr) ? 60.0 : Double.parseDouble(thresholdStr);
            if (usedCap >= threshold) {
                new TrackerService.Writer.Server().deskpoolDiskCapacityLow(ClusterNodeBean.instance().getLocalServer()).message("tracker.deskpool.disk.capacity.low.msg", new String[]{"$used", usedCapStr});
            }
        }
        return true;
    }
}
