/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;

public class Axis2TempFileWatcher.Message
extends Agent.Message {
}
