/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.agent.utils.JYEngine;
import com.jieyun.deskpool.agent.utils.JYMessage;

public class EngineLookupStrategy {
    public JYEngine lookup(JYMessage message) {
        return null;
    }
}
