/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.agent.utils.EngineLookupStrategy;
import com.jieyun.deskpool.agent.utils.JYEventHandler;
import com.jieyun.deskpool.agent.utils.JYMessage;

public class MessageCreator {
    private EngineLookupStrategy engineLookupStrategy;

    public JYMessage create(Class<? extends JYMessage> msgClass) {
        return (JYMessage)this.create(msgClass, null);
    }

    public <T> T create(Class<? extends JYMessage> msgClass, JYEventHandler eventHandler) {
        try {
            JYMessage message = msgClass.newInstance();
            message.setEngineLookupStrategy(this.engineLookupStrategy);
            message.setEventHandler(eventHandler);
            return (T)message;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setEngineLookupStrategy(EngineLookupStrategy engineLookupStrategy) {
        this.engineLookupStrategy = engineLookupStrategy;
    }
}
