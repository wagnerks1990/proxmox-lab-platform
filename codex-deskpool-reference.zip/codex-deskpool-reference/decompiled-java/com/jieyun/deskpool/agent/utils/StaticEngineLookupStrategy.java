/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.agent.utils.EngineLookupStrategy;
import com.jieyun.deskpool.agent.utils.JYEngine;
import com.jieyun.deskpool.agent.utils.JYMessage;

public class StaticEngineLookupStrategy
extends EngineLookupStrategy {
    private JYEngine engine;

    public void setEngine(JYEngine engine) {
        this.engine = engine;
    }

    @Override
    public JYEngine lookup(JYMessage message) {
        return this.engine;
    }
}
