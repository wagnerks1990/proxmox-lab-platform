/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

public abstract class JYEventHandler {
    public abstract void handle();
}
