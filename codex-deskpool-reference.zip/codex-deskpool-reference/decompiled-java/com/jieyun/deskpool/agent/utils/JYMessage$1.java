/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.vm.Event;

class JYMessage.1
implements Event.Response {
    JYMessage.1() {
    }
}
