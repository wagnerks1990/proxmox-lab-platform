/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.distributed.agent.SystemStatusObject;
import com.jieyun.deskpool.vm.Event;

public class JYEngine
extends Event.Engine {
    public JYEngine(String name) {
        super(name);
    }

    @Override
    public boolean isRejectWorking() {
        return !SystemStatusObject.instance().storeStatusIs(SystemStatusObject.StoreStatus.RUNNING);
    }

    @Override
    public void quit() {
        this.interrupt();
        super.quit();
    }
}
