/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.agent.utils.EngineLookupStrategy;

public class EnginePoolLookupStrategy
extends EngineLookupStrategy {
}
