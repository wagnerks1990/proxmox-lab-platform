/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.utils.EngineLookupStrategy;
import com.jieyun.deskpool.agent.utils.JYEventHandler;
import com.jieyun.deskpool.vm.Event;

public class JYMessage
extends Agent.Message {
    private Event.Engine engine;
    private JYEventHandler eventHandler;
    private EngineLookupStrategy engineLookupStrategy;

    public JYEventHandler getEventHandler() {
        return this.eventHandler;
    }

    public void setEngine(Event.Engine engine) {
        this.engine = engine;
    }

    public void setEngineLookupStrategy(EngineLookupStrategy engineLookupStrategy) {
        this.engineLookupStrategy = engineLookupStrategy;
    }

    public void setEventHandler(JYEventHandler eventHandler) {
        this.eventHandler = eventHandler;
    }

    public void send(int seconds) {
        this.preSend();
        super.send(this.engine, seconds);
    }

    public void send() {
        this.preSend();
        this.send(this.engine, 0, 0);
    }

    private void preSend() {
        if (this.engineLookupStrategy != null) {
            this.engine = this.engineLookupStrategy.lookup(this);
        }
    }

    @Override
    public void send(Event.Engine engine, int seconds, int priority) {
        if (engine.isRejectWorking()) {
            return;
        }
        super.send(engine, seconds, priority);
    }

    public void onReceive() {
        try {
            if (this.eventHandler != null) {
                this.eventHandler.handle();
            }
        }
        catch (Throwable throwable) {
            if (this.isSync() && this.getResponse() == null) {
                this.respond(new Event.Response(){});
            }
            throw throwable;
        }
        if (this.isSync() && this.getResponse() == null) {
            this.respond(new /* invalid duplicate definition of identical inner class */);
        }
    }
}
