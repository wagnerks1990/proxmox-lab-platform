/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent.utils;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.vm.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JYWorker
extends Agent.Impl {
    private static final Logger logger = LoggerFactory.getLogger(JYWorker.class);

    public JYWorker(Class<? extends JYMessage> msgClass, Event.Engine engine) {
        super(engine);
        this.subscribe(msgClass);
    }

    @Override
    public boolean receive(Event paramEvent) {
        try {
            JYMessage message = (JYMessage)paramEvent;
            message.onReceive();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}
