/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.List;

public static class ServerCommandEngine.Worker.CreateClusterMessage.Response
implements Event.Response {
    private List<ErrorMessage> result;

    ServerCommandEngine.Worker.CreateClusterMessage.Response(List<ErrorMessage> result) {
        Stopwatch timer = new Stopwatch("[[ServerCommandEngine.Worker.CreateClusterMessage.Response.Response(" + result + ")]");
        try {
            this.result = result;
        }
        finally {
            timer.stop();
        }
    }

    public List<ErrorMessage> getResult() {
        return this.result;
    }
}
