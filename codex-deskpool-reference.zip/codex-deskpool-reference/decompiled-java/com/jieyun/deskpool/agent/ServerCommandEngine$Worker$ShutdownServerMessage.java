/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.utils.Script;

public static class ServerCommandEngine.Worker.ShutdownServerMessage
extends JYMessage {
    @Override
    public void onReceive() {
        logger.info("shutdownServer");
        String killcmd2 = "shutdown -h now";
        Script.runSimpleBashRemoteScript(killcmd2, 1200);
    }
}
