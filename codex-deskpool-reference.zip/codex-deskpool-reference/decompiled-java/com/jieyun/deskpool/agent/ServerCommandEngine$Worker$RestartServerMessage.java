/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.utils.Script;

public static class ServerCommandEngine.Worker.RestartServerMessage
extends JYMessage {
    @Override
    public void onReceive() {
        logger.info("restartServer");
        String killcmd2 = "reboot";
        Script.runSimpleBashRemoteScript(killcmd2, 1200);
    }
}
