/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYEngine;

class ServerCommandEngine.MessageFactory.1
extends JYEngine {
    ServerCommandEngine.MessageFactory.1(String $anonymous0) {
        super($anonymous0);
    }

    @Override
    public boolean isRejectWorking() {
        return false;
    }
}
