/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.ServerCommandEngine;
import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Script;
import org.apache.commons.lang3.StringUtils;

public static class ServerCommandEngine.Worker.StartFloagIpMessage
extends JYMessage {
    private static final long serialVersionUID = 1L;

    @Override
    public void onReceive() {
        String floatIp = ClusterNodeBean.getFloatIp();
        if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
            NetworkConfig networkConfig;
            String secondaryIp = null;
            try {
                secondaryIp = NetUtils.getSecondaryIp();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            if (StringUtils.equals((CharSequence)secondaryIp, (CharSequence)floatIp)) {
                return;
            }
            if (StringUtils.isNotBlank((CharSequence)secondaryIp)) {
                logger.info("StartFloagIpMessage stop old FloatIP {}", (Object)secondaryIp);
                networkConfig = NetworkConfigFactory.createNetworkConfig();
                networkConfig.stopFloatIp();
            }
            if (StringUtils.isNotBlank((CharSequence)floatIp)) {
                logger.info("StartFloagIpMessage startFloatIp {} ", (Object)floatIp);
                networkConfig = NetworkConfigFactory.createNetworkConfig();
                networkConfig.startFloatIp(floatIp);
            }
        } else {
            if (StringUtils.isEmpty((CharSequence)floatIp) || !ClusterNodeBean.isStartFloatIp()) {
                if (DpFileUtils.exists(ServerCommandEngine.FLOAT_IP_FILE)) {
                    String ifdown = "ifdown eth0:float";
                    Script.runSimpleBashRemoteScript(ifdown, 1200);
                }
                return;
            }
            NetworkConfig config = NetworkConfigFactory.createNetworkConfig();
            config.createOrUpdateFloatIp(floatIp, ServerCommandEngine.FLOAT_FILE_NAME);
            String ifup = "ifup eth0:float";
            String string = Script.runSimpleBashRemoteScript(ifup, 1200);
        }
    }
}
