/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.tracker;

import com.jieyun.deskpool.utils.AppProps;

public class TrackerWatcherConfig {
    private int expriedMax;
    private int scheduledPeriod;

    public TrackerWatcherConfig() {
        AppProps props = AppProps.instance();
        try {
            this.expriedMax = Integer.parseInt(props.get("tracker.watcher.expriedMax"));
            this.scheduledPeriod = Integer.parseInt(props.get("tracker.watcher.scheduledPerios"));
        }
        catch (Exception e) {
            e.printStackTrace();
            this.expriedMax = 10000;
            this.scheduledPeriod = 600;
        }
    }

    public int getExpriedMax() {
        return this.expriedMax;
    }

    public void setExpriedMax(int expriedMax) {
        this.expriedMax = expriedMax;
    }

    public int getScheduledPeriod() {
        return this.scheduledPeriod;
    }

    public void setScheduledPeriod(int scheduledPeriod) {
        this.scheduledPeriod = scheduledPeriod;
    }
}
