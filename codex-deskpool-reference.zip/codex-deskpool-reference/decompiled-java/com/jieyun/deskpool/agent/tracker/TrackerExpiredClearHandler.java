/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.tracker;

import com.jieyun.deskpool.agent.tracker.TrackerWatcherConfig;
import com.jieyun.deskpool.bean.ITrackerBean;
import com.jieyun.deskpool.domain.Tracker;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;

public class TrackerExpiredClearHandler {
    public void handle(TrackerWatcherConfig config) {
        List list = Services.getTrackerService().find(new DpSpec().byClass(Tracker.class.getName()).sortBy("updated", "ASC"));
        int max = config.getExpriedMax();
        int offset = list.size() - max;
        if ((double)offset / (double)max > 0.1) {
            int i = 0;
            while (i < offset) {
                ITrackerBean tracker = (ITrackerBean)list.get(i);
                if (tracker != null) {
                    tracker.destroy();
                }
                ++i;
            }
        }
    }
}
