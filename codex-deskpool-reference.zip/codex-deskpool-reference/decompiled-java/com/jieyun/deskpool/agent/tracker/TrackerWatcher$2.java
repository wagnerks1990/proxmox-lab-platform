/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.tracker;

import com.jieyun.deskpool.agent.tracker.TrackerExpiredClearHandler;
import com.jieyun.deskpool.distributed.agent.SystemStatusObject;

class TrackerWatcher.2
implements Runnable {
    private TrackerExpiredClearHandler handler = new TrackerExpiredClearHandler();

    TrackerWatcher.2() {
    }

    @Override
    public void run() {
        try {
            if (!SystemStatusObject.instance().storeStatusIs(SystemStatusObject.StoreStatus.RUNNING)) {
                return;
            }
            this.handler.handle(TrackerWatcher.this.config);
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
