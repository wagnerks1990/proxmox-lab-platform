/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent.tracker;

import java.util.concurrent.ThreadFactory;

class TrackerWatcher.1
implements ThreadFactory {
    TrackerWatcher.1() {
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r);
        t.setName("TrackerWatcher");
        return t;
    }
}
