/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent.tracker;

import com.jieyun.deskpool.agent.tracker.TrackerExpiredClearHandler;
import com.jieyun.deskpool.agent.tracker.TrackerWatcherConfig;
import com.jieyun.deskpool.distributed.agent.SystemStatusObject;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrackerWatcher
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(TrackerWatcher.class);
    private ScheduledExecutorService pool;
    private volatile boolean started = false;
    private TrackerWatcherConfig config = new TrackerWatcherConfig();
    private static TrackerWatcher trackerWatcher = new TrackerWatcher();

    public TrackerWatcherConfig getConfig() {
        return this.config;
    }

    public void setConfig(TrackerWatcherConfig config) {
        this.config = config;
    }

    public static TrackerWatcher instance() {
        return trackerWatcher;
    }

    public synchronized void start() {
    }

    @Override
    public void onStart() {
        if (this.started) {
            return;
        }
        this.pool = Executors.newScheduledThreadPool(1, new ThreadFactory(){

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("TrackerWatcher");
                return t;
            }
        });
        this.pool.scheduleAtFixedRate(new Runnable(){
            private TrackerExpiredClearHandler handler = new TrackerExpiredClearHandler();

            @Override
            public void run() {
                try {
                    if (!SystemStatusObject.instance().storeStatusIs(SystemStatusObject.StoreStatus.RUNNING)) {
                        return;
                    }
                    this.handler.handle(TrackerWatcher.this.config);
                }
                catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        }, 0L, this.config.getScheduledPeriod(), TimeUnit.SECONDS);
        this.started = true;
        logger.info("TrackerWatcher started , expiredMax is {} , scheduledPeriod is {}", (Object)this.config.getExpriedMax(), (Object)this.config.getScheduledPeriod());
    }

    @Override
    public void onShutdown() {
        if (this.pool != null) {
            this.pool.shutdownNow();
        }
    }
}
