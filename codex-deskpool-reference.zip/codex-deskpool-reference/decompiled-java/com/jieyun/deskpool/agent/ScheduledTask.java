/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.store.VirtualOutput;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.Event;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScheduledTask
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(ScheduledTask.class);
    private static final String ENGINE_NAME = "ScheduledTask";
    private static final int SCHEDULETASK_TIME = 60;
    private static final boolean IS_BACK_DATA = Props.instance().get("server.back.data", true);
    private static final int BACK_NUMBER_MAX = Props.instance().get("server.back.max", 10);
    private static int backDataDay = 0;

    public ScheduledTask() {
        this(new Event.TimedEngine(ENGINE_NAME, 60L){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    public ScheduledTask(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable()) {
            return true;
        }
        this.backData();
        return false;
    }

    private void backData() {
        Calendar calendar;
        int day;
        if (IS_BACK_DATA && (day = (calendar = Calendar.getInstance()).get(5)) != backDataDay) {
            logger.info(" start backData==========================");
            this.delOverBackFile(this.getBackDir());
            this.delOverBackFile(this.getRestartBack());
            this.dataBackup();
            backDataDay = day;
            logger.info(" end backData==========================");
        }
    }

    private void dataBackup() {
        block9: {
            File dataFile = null;
            File storeFile = null;
            File licenseFile = null;
            try {
                long t = System.currentTimeMillis();
                dataFile = File.createTempFile("deskpool-data-$$$-" + t, ".xml");
                storeFile = File.createTempFile("deskpool-store-$$$-" + t, ".properties");
                licenseFile = File.createTempFile("license", ".lic");
                DpFileUtils.copyFile(new File(String.valueOf(System.getProperty("jy.configHome")) + File.separator + "store.properties"), storeFile, true);
                DpFileUtils.copyFile(new File(String.valueOf(System.getProperty("jy.configHome")) + File.separator + "license.lic"), licenseFile, true);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            if (dataFile == null || storeFile == null) {
                return;
            }
            try {
                try {
                    VirtualOutput virtualOutput = new VirtualOutput();
                    virtualOutput.setTarget(dataFile);
                    StoreContext.getPersister().exportBasicData(virtualOutput, new Object[0]);
                    SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
                    String backFile = "jy_bak_" + format.format(new Date()) + ".zip";
                    File zipTempFile = new File(String.valueOf(this.getBackDir()) + backFile);
                    if (zipTempFile.exists()) {
                        zipTempFile.createNewFile();
                    }
                    DpFileUtils.genZipFile(zipTempFile, dataFile, storeFile, licenseFile);
                    logger.info("the ScheduledTask generate backFile[{}]", (Object)backFile);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    DpFileUtils.batchDelFile(dataFile, storeFile, licenseFile);
                    break block9;
                }
            }
            catch (Throwable throwable) {
                DpFileUtils.batchDelFile(dataFile, storeFile, licenseFile);
                throw throwable;
            }
            DpFileUtils.batchDelFile(dataFile, storeFile, licenseFile);
        }
    }

    private String getBackDir() {
        StringBuilder backDir = new StringBuilder(System.getProperty("user.home"));
        backDir.append(File.separator);
        backDir.append("backup");
        backDir.append(File.separator);
        return backDir.toString();
    }

    private String getRestartBack() {
        StringBuilder backFileName = new StringBuilder(System.getProperty("user.home"));
        backFileName.append(File.separator);
        backFileName.append("restart");
        backFileName.append(File.separator);
        return backFileName.toString();
    }

    private void delOverBackFile(String fileBacke) {
        File backDir = new File(fileBacke);
        if (!backDir.exists()) {
            backDir.mkdir();
            return;
        }
        int i = 10;
        while (--i > 0) {
            String[] fileList = backDir.list();
            if (fileList == null || fileList.length < BACK_NUMBER_MAX) {
                return;
            }
            String delFile = null;
            String[] stringArray = fileList;
            int n = fileList.length;
            int n2 = 0;
            while (n2 < n) {
                String file = stringArray[n2];
                if (delFile == null) {
                    delFile = file;
                } else if (delFile.compareTo(file) > 0) {
                    delFile = file;
                }
                ++n2;
            }
            logger.info("the ScheduledTask del backFile[{}]", delFile);
            DpFileUtils.delete(String.valueOf(fileBacke) + delFile);
        }
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
