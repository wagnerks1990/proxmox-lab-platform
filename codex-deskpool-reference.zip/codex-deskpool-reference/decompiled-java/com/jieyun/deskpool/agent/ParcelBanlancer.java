/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.bean.IParcelBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.comparator.ParcelComparator;
import com.jieyun.deskpool.domain.ParcelOrderFilter;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.shared.ImageStatus;
import com.jieyun.deskpool.shared.Lineage;
import com.jieyun.deskpool.shared.NodeStatus;
import com.jieyun.deskpool.shared.ParcelStatus;
import com.jieyun.deskpool.shared.Portion;
import com.jieyun.deskpool.shared.SystemStatus;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParcelBanlancer
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger log = LoggerFactory.getLogger(ParcelBanlancer.class);
    private static String engineName = "parcelBanlancer";
    private static int REPEAT_SHORT = 30;
    private static ParcelOrderFilter[] parcelRequestOrder = new ParcelOrderFilter[]{new ParcelOrderFilter(ParcelStatus.PACKED, Portion.DELTA), new ParcelOrderFilter(ParcelStatus.PACKING, Portion.DELTA), new ParcelOrderFilter(ParcelStatus.READY, Portion.DELTA), new ParcelOrderFilter(ParcelStatus.PACKED, null), new ParcelOrderFilter(ParcelStatus.PACKING, null), new ParcelOrderFilter(ParcelStatus.READY, null)};

    public ParcelBanlancer() {
        this(new Event.TimedEngine(engineName, REPEAT_SHORT){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    public ParcelBanlancer(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        if (StoreContext.enable()) {
            this.clear();
        }
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable()) {
            return true;
        }
        if (Services.getSystemService().getServiceStatus() == SystemStatus.MAINTENANCE) {
            return true;
        }
        this.check();
        return true;
    }

    private void check() {
        boolean bypass = true;
        Stopwatch timer = new Stopwatch("[ParcelBanlaner.check]", bypass);
        try {
            IServerBean current = Services.getServerService().getCurrent();
            if (current != null && current.isOnline() && !current.isWitness()) {
                this.checkSourcedParcels(current);
                this.checkOwnParcels(current);
            } else {
                timer.record("the server is offline:current=" + current);
            }
        }
        finally {
            timer.stop();
        }
    }

    private void checkSourcedParcels(IServerBean source) {
        List<IImageBean> imageList = Services.getImageService().findAll();
        for (IImageBean image : imageList) {
            List<IParcelBean> parcelList = Services.getParcelService().getParcelBySource(source.Id(), image.Id());
            Collections.sort(parcelList, new ParcelComparator());
            for (IParcelBean parcel : parcelList) {
                if (parcel.getServer() == null) {
                    log.error("The Parcel[{0}] cannot find server[serverId={1}]", (Object)parcel, (Object)parcel.getServerId());
                    continue;
                }
                switch (parcel.getStatus()) {
                    case ORDERED: {
                        this.handleOrder(parcel);
                        break;
                    }
                }
            }
        }
    }

    private void handleOrder(IParcelBean parcel) {
        block14: {
            Stopwatch timer = new Stopwatch("[ParcelBanlancer.handleOrder(" + parcel + ")]");
            try {
                try {
                    parcel = (IParcelBean)parcel.refresh();
                    if (parcel == null) {
                        timer.record("not shipping...  null refresh of " + parcel);
                        break block14;
                    }
                    if (parcel.isStatus(ParcelStatus.NEW, ParcelStatus.ORDERED)) {
                        IParcelBean myParcel = parcel.fulfillLocal();
                        switch (myParcel.getStatus()) {
                            case READY: {
                                if (this.countPackedParcels(myParcel) > 0) {
                                    this.forwardOrder(parcel, myParcel);
                                    break;
                                }
                                timer.record("packing " + myParcel);
                                new TrackerService.Writer.Parcel().create(parcel, parcel.getServer()).message("tracker.parcel.packing", new String[]{"$source", myParcel.getServer().getResourceAddress()});
                                IParcelBean.Update update = myParcel.getUpdate();
                                update.enterStatus(ParcelStatus.PACKING);
                                update.pack();
                                update = (IParcelBean.Update)update.refresh();
                                if (update.getStatus().equals((Object)ParcelStatus.PACKED)) {
                                    new TrackerService.Writer.Parcel().create(parcel, parcel.getServer()).message("tracker.parcel.packed", new String[]{"$source", myParcel.getServer().getHost_address()});
                                    break;
                                }
                                update.enterStatus(ParcelStatus.BROKEN);
                                new TrackerService.Writer.Parcel().create(parcel, parcel.getServer()).failure("tracker.parcel.pack.err", new String[]{"$source", myParcel.getServer().getHost_address()});
                                break;
                            }
                            case PACKING: {
                                timer.record("packing " + parcel + " version:" + parcel.getVersion());
                                break;
                            }
                            case PACKED: {
                                timer.record("shipping " + parcel + " version:" + parcel.getVersion());
                                parcel.ship();
                                break;
                            }
                            default: {
                                timer.record("WARNING:  order for unshippable " + myParcel);
                                log.warn("WARNING:  order for unshippable " + myParcel);
                                break;
                            }
                        }
                        break block14;
                    }
                    timer.record("not shipping...  not needed for " + parcel);
                }
                catch (Exception ex) {
                    log.error("Exception in handleOrder,ex: {0}", (Object)ex.toString());
                    timer.stop();
                }
            }
            finally {
                timer.stop();
            }
        }
    }

    private int countPackedParcels(IParcelBean parcel) {
        int othersPacked = 0;
        List<IParcelBean> parcelList = Services.getParcelService().getParcel(parcel.getServerId(), parcel.getImageId());
        for (IParcelBean parcelBean : parcelList) {
            if ((parcelBean = (IParcelBean)parcelBean.refresh()).hasSameImageAndVersion(parcel) || !parcelBean.isStatus(ParcelStatus.PACKED, ParcelStatus.PACKING)) continue;
            ++othersPacked;
        }
        return othersPacked;
    }

    private void accelerateOrder(IParcelBean parcel, IParcelBean sParcel) {
        this.forwardOrder(parcel, sParcel, false);
    }

    private void forwardOrder(IParcelBean parcel, IParcelBean sourceParcel) {
        this.forwardOrder(parcel, sourceParcel, true);
    }

    private void forwardOrder(IParcelBean parcel, IParcelBean sourceParcel, boolean singleSource) {
        Stopwatch timer = new Stopwatch("[ParcelBanlancer.forwardOrder(" + parcel + "," + sourceParcel + "," + singleSource + ")]");
        List<IParcelBean> list = Services.getParcelService().getParcel(parcel.getImageId(), parcel.getVersion());
        IParcelBean best = null;
        IServerBean beanServer = null;
        ParcelOrderFilter[] parcelOrderFilterArray = parcelRequestOrder;
        int n = parcelRequestOrder.length;
        int n2 = 0;
        while (n2 < n) {
            ParcelOrderFilter filter = parcelOrderFilterArray[n2];
            for (IParcelBean bean : Services.getParcelService().filterParcelList(list, filter)) {
                beanServer = bean.getServer();
                if (beanServer == null || sourceParcel.getServerId().equals(bean.getServerId()) || parcel.getServerId().equals(bean.getServerId()) || !beanServer.isOnline() || !NodeStatus.ONLINE.equals((Object)beanServer.getNodeStatus()) || this.countPackedParcels(bean) != 0 || !singleSource && this.countOrderedParcels(bean) != 0) continue;
                best = bean;
                break;
            }
            if (best != null) break;
            ++n2;
        }
        if (best != null) {
            timer.record("Forwarding to " + best.getServer());
            this.order(parcel, best.getServer());
        }
        timer.stop();
    }

    private int countOrderedParcels(IParcelBean pracel) {
        List<IParcelBean> list = Services.getParcelService().getParcelBySource(pracel.getServerId(), pracel.getImageId(), pracel.getVersion());
        int others = 0;
        for (IParcelBean bean : list) {
            if (!bean.isStatus(ParcelStatus.ORDERED, ParcelStatus.SHIPPING)) continue;
            ++others;
        }
        return others;
    }

    private IParcelBean order(IParcelBean parcel, IServerBean source) {
        new TrackerService.Writer.Parcel().create(parcel, Services.getServerService().getCurrent()).message("tracker.parcel.ship.waitting", new String[]{"$source", source.getResourceAddress()});
        IParcelBean.Update update = parcel.getUpdate();
        update.setSource(source.Id());
        update.setStatus(ParcelStatus.ORDERED);
        update.save();
        return update;
    }

    private void checkOwnParcels(IServerBean current) {
        List<IImageBean> imageList = Services.getImageService().findAll();
        List<IParcelBean> parcelList = null;
        for (IImageBean image : imageList) {
            if (image.getStatus() != ImageStatus.RELEASED) continue;
            parcelList = Services.getParcelService().getParcel(current.Id(), image.Id());
            try {
                if (image.parcelIsStable() && Services.getParcelService().filterByVersion(parcelList, image.getVersion()).isEmpty()) {
                    if (current.vmExistsOnLocal(image.getVersion())) {
                        IParcelBean.Update newParcelBean = null;
                        for (String version : image.getVersions()) {
                            if (!current.vmExistsOnLocal(version)) continue;
                            newParcelBean = Services.getParcelService().create(current, image.Id(), version);
                            newParcelBean = newParcelBean.getUpdate().initialize(image, Portion.WHOLE, null, current.Id(), version, version);
                            log.info("the server exists Vm =" + version, (Object)"the parcel create finshed");
                        }
                        continue;
                    }
                    this.order(current, image);
                    continue;
                }
                block10: for (IParcelBean bean : parcelList) {
                    switch (bean.getStatus()) {
                        case ORDERED: {
                            this.reviewOrder(bean);
                            break;
                        }
                        case PACKED: {
                            this.checkParcelDepack(current, image, bean);
                            break;
                        }
                        case SHIPPED: {
                            bean.unpack();
                            if (!bean.isDelta()) break;
                            bean.destroy();
                            break;
                        }
                        case READY: 
                        case NOTPACKABLE: 
                        case BROKEN: {
                            if (!bean.isDelta() || !image.allHaveCurrentParcel()) continue block10;
                            bean.destroy();
                            break;
                        }
                    }
                }
            }
            catch (Exception ex) {
                log.error("Exception in checkOwnParcels image :{}", (Object)image);
                ex.printStackTrace();
            }
        }
    }

    private void order(IServerBean server, IImageBean image) {
        Stopwatch timer = new Stopwatch("[ParcelBanlancer.order(" + server + "," + image + ")]");
        try {
            IParcelBean best = null;
            List<String> lostVersion = Services.getParcelService().getLocalLostVersion(image.getVersions(), image.Id());
            if (lostVersion.size() > 0) {
                String version = lostVersion.get(0);
                best = this.getBestParcel(server, image.Id(), version);
                if (best != null) {
                    this.oderLostOldVersion(best.getServerId(), image, version);
                }
                timer.record("lost version[" + lostVersion.get(0) + "],order lostVersion start");
                return;
            }
            IParcelBean localParcel = Services.getParcelService().getAny(server.Id(), image.Id(), image.getVersion());
            if (localParcel != null && !ParcelStatus.NEW.equals((Object)localParcel.getStatus())) {
                timer.record("already have parcel");
                return;
            }
            best = this.getBestParcel(server, image.Id(), image.getVersion());
            if (best != null) {
                timer.record("best=[" + best + "]");
                localParcel = best.fulfillLocal();
                timer.record("localParcel=[" + localParcel + "]");
                if (localParcel.isStatus(ParcelStatus.NEW)) {
                    localParcel = this.order(localParcel, best.getServer());
                }
            }
        }
        finally {
            timer.stop();
        }
    }

    private IParcelBean getBestParcel(IServerBean server, Id imageId, String version) {
        List<IParcelBean> parcelList = Services.getParcelService().getParcel(imageId, version);
        IServerBean beanServer = null;
        ParcelOrderFilter[] parcelOrderFilterArray = parcelRequestOrder;
        int n = parcelRequestOrder.length;
        int n2 = 0;
        while (n2 < n) {
            ParcelOrderFilter filter = parcelOrderFilterArray[n2];
            for (IParcelBean bean : Services.getParcelService().filterParcelList(parcelList, filter)) {
                boolean perfer;
                boolean bl = perfer = !bean.isDelta();
                if (!perfer) {
                    Lineage lineage = bean.getLineage();
                    perfer = lineage != null && Services.getImageService().findOne(Id.construct(lineage.getParent())) != null && Services.getParcelService().getAny(server.Id(), Id.construct(lineage.getParent()), lineage.getParentVersion()) != null;
                }
                beanServer = bean.getServer();
                if (!perfer || beanServer == null || !beanServer.isOnline() || !NodeStatus.ONLINE.equals((Object)beanServer.getNodeStatus())) continue;
                return bean;
            }
            ++n2;
        }
        return null;
    }

    private void reviewOrder(IParcelBean parcel) {
        block13: {
            Stopwatch timer = new Stopwatch("[ParcelBanlance.reviewOrder(" + parcel + ")]");
            try {
                parcel = (IParcelBean)parcel.refresh();
                if (parcel == null) {
                    timer.record("null refresh of " + parcel);
                    break block13;
                }
                if (!parcel.isStatus(ParcelStatus.NEW, ParcelStatus.ORDERED)) break block13;
                IServerBean source = parcel.getSource();
                if (source != null) {
                    IParcelBean sParcel = parcel.fulfill(source);
                    if (NodeStatus.OFFLINE.equals((Object)source.getNodeStatus())) {
                        timer.record(String.valueOf(source.getResourceAddress()) + "is offline,the order will forward!");
                        this.forwardOrder(parcel, sParcel);
                        break block13;
                    }
                    switch (sParcel.getStatus()) {
                        case READY: {
                            if (this.countPackedParcels(sParcel) > 0) {
                                this.forwardOrder(parcel, sParcel);
                                break;
                            }
                            if (this.accelerate(parcel, sParcel) > 0) {
                                this.accelerateOrder(parcel, sParcel);
                                break;
                            }
                            break block13;
                        }
                        case PACKED: 
                        case PACKING: {
                            if (this.accelerate(parcel, sParcel) > 0) {
                                this.accelerateOrder(parcel, sParcel);
                                break;
                            }
                            break block13;
                        }
                    }
                    break block13;
                }
                timer.record("the source is null !" + parcel);
            }
            finally {
                timer.stop();
            }
        }
    }

    private int accelerate(IParcelBean parcel, IParcelBean sParcel) {
        Stopwatch timer = new Stopwatch("[ParcelBanlaner.accelerate(" + parcel + "," + sParcel + ")]");
        List<IParcelBean> census = ParcelBanlancer.census(parcel);
        if (census.size() < 4) {
            timer.stop("returning 0 in small grid " + census.size());
            return 0;
        }
        if (Services.getParcelService().filterBySource(census, sParcel.getServerId()).size() < 2) {
            timer.stop("returning 0 because order not multiply sourced");
            return 0;
        }
        int ready = 0;
        int packing = 0;
        int packed = 0;
        int shipping = 0;
        int ordered = 0;
        for (IParcelBean bean : census) {
            switch (bean.getStatus()) {
                case READY: {
                    ++ready;
                    break;
                }
                case PACKING: {
                    ++packing;
                    break;
                }
                case PACKED: {
                    ++packed;
                    break;
                }
                case SHIPPED: 
                case SHIPPING: 
                case UNPACKED: 
                case UNPACKING: {
                    ++shipping;
                    break;
                }
                case ORDERED: {
                    ++ordered;
                    break;
                }
            }
        }
        int acceleration = ordered - shipping - packing;
        timer.record("ready=" + ready + " packing=" + packing + " packed=" + packed + " shipping=" + shipping + " ordered=" + ordered);
        timer.stop("" + acceleration);
        return acceleration;
    }

    private static List<IParcelBean> census(IParcelBean parcel) {
        TreeMap<Long, IParcelBean> census = new TreeMap<Long, IParcelBean>();
        List<IParcelBean> list = Services.getParcelService().getParcel(parcel.getImage());
        for (IParcelBean bean : Services.getParcelService().filterParcelList(list, Portion.WHOLE)) {
            census.put(bean.getServerId().getId(), bean);
        }
        for (IParcelBean bean : Services.getParcelService().filterParcelList(list, Portion.DELTA)) {
            census.put(bean.getServerId().getId(), bean);
        }
        return new ArrayList<IParcelBean>(census.values());
    }

    private void checkParcelDepack(IServerBean current, IImageBean image, IParcelBean parcel) {
        Stopwatch timer = new Stopwatch("[ParcelBanlaner.checkParcelDepack(" + parcel + ")]");
        try {
            List<IServerBean> serverList = Services.getServerService().findAll();
            List<IParcelBean> parcelList = Services.getParcelService().getParcel(image.Id(), parcel.getVersion());
            timer.record("parcelList:" + parcelList);
            for (IParcelBean bean : parcelList) {
                timer.record(String.valueOf(bean.asString()) + " status=" + (Object)((Object)bean.getStatus()));
                if (bean.ready() || bean.broken() || bean.isStatus(ParcelStatus.NOTSHIPPABLE)) {
                    if (bean.getServer() != null) {
                        timer.record("remove Server:" + bean.getServer().getResourceAddress());
                    }
                    serverList.remove(bean.getServer());
                    this.removeServer(serverList, bean.getServerId());
                    timer.record("serverList:" + serverList);
                    continue;
                }
                if (bean.getServer() != null) break;
                try {
                    timer.record("Destroying parcel found without resource:[" + parcel + "]  ");
                    bean.destroy();
                }
                catch (Exception ex) {
                    timer.record("Exception destroying resourceless parcel '{" + parcel + "}'.  Will unstore.");
                    log.warn(ex.toString());
                }
            }
            if (serverList.isEmpty()) {
                timer.record("depack:[" + parcel + "]");
                parcel.depack();
                if (parcel.isDelta()) {
                    parcel.destroy();
                }
            }
        }
        finally {
            timer.stop();
        }
    }

    private void removeServer(List<IServerBean> serverList, Id serverId) {
        for (IServerBean server : serverList) {
            if (!server.Id().equals(serverId)) continue;
            serverList.remove(server);
            break;
        }
    }

    private void oderLostOldVersion(Id source, IImageBean image, String oldVersion) {
        IParcelBean.Update update = null;
        Id serverId = Services.getServerService().getCurrent().Id();
        Id imageId = image.Id();
        update = ((IParcelBean)Services.getParcelService().createOne()).getUpdate();
        update.setImageId(imageId);
        update.setServer(serverId);
        update.setSource(source);
        update.setVersion(oldVersion);
        update.setVMName(update.newVMName());
        update.setName(update.newName());
        update.setStatus(ParcelStatus.NEW);
        update.save();
        this.order(update, Services.getServerService().findOne(source));
    }

    private void clear() {
        Stopwatch stop = new Stopwatch("[ParcelBanlaner.clear()");
        try {
            IServerBean server = Services.getServerService().getCurrent();
            if (server == null) {
                log.error("the current is null");
                return;
            }
            List<IParcelBean> list = Services.getParcelService().getParcel(server.Id());
            stop.record("clear local parcel");
            for (IParcelBean parcel : list) {
                if (parcel.isStatus(ParcelStatus.UNPACKING)) {
                    parcel.getUpdate().enterStatus(ParcelStatus.ORDERED);
                    continue;
                }
                if (parcel.isStatus(ParcelStatus.SHIPPING)) {
                    parcel.getUpdate().enterStatus(ParcelStatus.ORDERED);
                    this.changeStatus(false, parcel, ParcelStatus.READY, ParcelStatus.PACKING, ParcelStatus.PACKED);
                    continue;
                }
                if (!parcel.isStatus(ParcelStatus.PACKING, ParcelStatus.PACKED)) continue;
                parcel.getUpdate().enterStatus(ParcelStatus.READY);
                this.changeStatus(true, parcel, ParcelStatus.ORDERED, ParcelStatus.SHIPPING);
            }
            stop.record("clear source ");
        }
        finally {
            stop.stop();
        }
    }

    private void changeStatus(boolean isSource, IParcelBean parcel, ParcelStatus status, ParcelStatus ... curentStatus) {
        List<IParcelBean> list = null;
        list = isSource ? Services.getParcelService().getParcelBySource(parcel.getServerId(), parcel.getImageId(), parcel.getVersion()) : Services.getParcelService().getParcel(parcel.getSourceId(), parcel.getImageId(), parcel.getVersion());
        for (IParcelBean bean : list) {
            if (!bean.isStatus(curentStatus)) continue;
            bean.getUpdate().enterStatus(status);
        }
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
