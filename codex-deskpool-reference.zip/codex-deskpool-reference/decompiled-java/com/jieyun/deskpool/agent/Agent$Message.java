/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.vm.Event;

public static abstract class Agent.Message
extends Event.Impl {
}
