/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.ServerCommandEngine;
import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.utils.DpFileUtils;
import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.NetworkConfig;
import com.jieyun.deskpool.utils.NetworkConfigFactory;
import com.jieyun.deskpool.utils.Script;
import org.apache.commons.lang3.StringUtils;

public static class ServerCommandEngine.Worker.StopFloagIpMessage
extends JYMessage {
    private static final long serialVersionUID = 1L;

    @Override
    public void onReceive() {
        if (NetUtils.checkIsRockyLinux("/etc/os-release")) {
            String secondaryIp = null;
            try {
                secondaryIp = NetUtils.getSecondaryIp();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            if (StringUtils.isNotBlank((CharSequence)secondaryIp)) {
                logger.info("StopFloagIpMessage networkConfig.stopFloatIp");
                NetworkConfig networkConfig = NetworkConfigFactory.createNetworkConfig();
                networkConfig.stopFloatIp();
            }
        } else {
            String floatIpFile = ServerCommandEngine.FLOAT_IP_FILE;
            if (!DpFileUtils.exists(floatIpFile)) {
                return;
            }
            String ifdown = "ifdown eth0:float";
            String result = Script.runSimpleBashRemoteScript(ifdown, 1200);
            String removefile = "rm -rf eth0:float";
            String string = Script.runSimpleBashRemoteScript(removefile, 1200);
        }
    }
}
