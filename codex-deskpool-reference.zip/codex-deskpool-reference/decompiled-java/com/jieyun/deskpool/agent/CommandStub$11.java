/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axiom.om.OMElement
 *  org.apache.axiom.soap.SOAPEnvelope
 *  org.apache.axis2.AxisFault
 *  org.apache.axis2.client.FaultMapKey
 *  org.apache.axis2.client.async.AxisCallback
 *  org.apache.axis2.context.MessageContext
 *  org.apache.axis2.util.Utils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandCallbackHandler;
import com.jieyun.deskpool.agent.CommandStub;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axis2.AxisFault;
import org.apache.axis2.client.FaultMapKey;
import org.apache.axis2.client.async.AxisCallback;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.util.Utils;

class CommandStub.11
implements AxisCallback {
    private final /* synthetic */ CommandCallbackHandler val$callback;
    private final /* synthetic */ MessageContext val$_messageContext;

    CommandStub.11(CommandCallbackHandler commandCallbackHandler, MessageContext messageContext) {
        this.val$callback = commandCallbackHandler;
        this.val$_messageContext = messageContext;
    }

    public void onMessage(MessageContext resultContext) {
        try {
            SOAPEnvelope resultEnv = resultContext.getEnvelope();
            Object object = CommandStub.this.fromOM(resultEnv.getBody().getFirstElement(), CommandStub.LogOffAllUsersResponse.class, CommandStub.this.getEnvelopeNamespaces(resultEnv));
            this.val$callback.receiveResultlogOffAllUsers((CommandStub.LogOffAllUsersResponse)object);
        }
        catch (AxisFault e) {
            this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)e));
        }
    }

    public void onError(Exception error) {
        if (error instanceof AxisFault) {
            AxisFault f = (AxisFault)((Object)error);
            OMElement faultElt = f.getDetail();
            if (faultElt != null) {
                if (CommandStub.this.faultExceptionNameMap.containsKey(new FaultMapKey(faultElt.getQName(), "LogOffAllUsers"))) {
                    try {
                        String exceptionClassName = (String)CommandStub.this.faultExceptionClassNameMap.get(new FaultMapKey(faultElt.getQName(), "LogOffAllUsers"));
                        Class<?> exceptionClass = Class.forName(exceptionClassName);
                        Constructor<?> constructor = exceptionClass.getConstructor(CommandStub.String.class);
                        Exception ex = (Exception)constructor.newInstance(f.getMessage());
                        String messageClassName = (String)CommandStub.this.faultMessageMap.get(new FaultMapKey(faultElt.getQName(), "LogOffAllUsers"));
                        Class<?> messageClass = Class.forName(messageClassName);
                        Object messageObject = CommandStub.this.fromOM(faultElt, messageClass, null);
                        Method m = exceptionClass.getMethod("setFaultMessage", messageClass);
                        m.invoke(ex, messageObject);
                        this.val$callback.receiveErrorlogOffAllUsers(new RemoteException(ex.getMessage(), ex));
                    }
                    catch (ClassCastException e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                    catch (ClassNotFoundException e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                    catch (NoSuchMethodException e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                    catch (InvocationTargetException e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                    catch (IllegalAccessException e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                    catch (InstantiationException e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                    catch (AxisFault e) {
                        this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                    }
                } else {
                    this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
                }
            } else {
                this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)f));
            }
        } else {
            this.val$callback.receiveErrorlogOffAllUsers(error);
        }
    }

    public void onFault(MessageContext faultContext) {
        AxisFault fault = Utils.getInboundFaultFromMessageContext((MessageContext)faultContext);
        this.onError((Exception)((Object)fault));
    }

    public void onComplete() {
        try {
            this.val$_messageContext.getTransportOut().getSender().cleanup(this.val$_messageContext);
        }
        catch (AxisFault axisFault) {
            this.val$callback.receiveErrorlogOffAllUsers((Exception)((Object)axisFault));
        }
    }
}
