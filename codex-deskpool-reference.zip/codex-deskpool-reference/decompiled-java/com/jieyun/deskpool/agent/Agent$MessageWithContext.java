/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.vm.Context;
import com.jieyun.deskpool.vm.Event;

public static abstract class Agent.MessageWithContext
extends Event.Impl {
    private Context context;

    public Agent.MessageWithContext(Context context) {
        this.context = context;
    }

    public Context context() {
        return this.context;
    }
}
