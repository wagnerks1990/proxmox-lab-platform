/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axiom.om.OMDataSource
 *  org.apache.axiom.om.OMElement
 *  org.apache.axiom.om.OMFactory
 *  org.apache.axis2.databinding.ADBBean
 *  org.apache.axis2.databinding.ADBDataSource
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.BeanUtil
 *  org.apache.axis2.databinding.utils.ConverterUtil
 *  org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl
 */
package com.jieyun.deskpool.agent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import org.apache.axiom.om.OMDataSource;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axis2.databinding.ADBBean;
import org.apache.axis2.databinding.ADBDataSource;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.BeanUtil;
import org.apache.axis2.databinding.utils.ConverterUtil;
import org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl;

public static class CommandStub.PvdAction
implements ADBBean {
    public static final QName MY_QNAME = new QName("http://schemas.datacontract.org/2004/07/Citrix.VDI.Agent.Executer", "PvdAction", "ns2");
    protected String localPvdAction;
    private static HashMap _table_ = new HashMap();
    public static final String _Unknown = ConverterUtil.convertToString((String)"Unknown");
    public static final String _Enable = ConverterUtil.convertToString((String)"Enable");
    public static final String _Disable = ConverterUtil.convertToString((String)"Disable");
    public static final String _TakeInventory = ConverterUtil.convertToString((String)"TakeInventory");
    public static final String _UpdateInventory = ConverterUtil.convertToString((String)"UpdateInventory");
    public static final CommandStub.PvdAction Unknown = new CommandStub.PvdAction(_Unknown, true);
    public static final CommandStub.PvdAction Enable = new CommandStub.PvdAction(_Enable, true);
    public static final CommandStub.PvdAction Disable = new CommandStub.PvdAction(_Disable, true);
    public static final CommandStub.PvdAction TakeInventory = new CommandStub.PvdAction(_TakeInventory, true);
    public static final CommandStub.PvdAction UpdateInventory = new CommandStub.PvdAction(_UpdateInventory, true);

    protected CommandStub.PvdAction(String value, boolean isRegisterValue) {
        this.localPvdAction = value;
        if (isRegisterValue) {
            _table_.put(this.localPvdAction, this);
        }
    }

    public String getValue() {
        return this.localPvdAction;
    }

    public boolean equals(Object obj) {
        return obj == this;
    }

    public int hashCode() {
        return this.toString().hashCode();
    }

    public String toString() {
        return this.localPvdAction.toString();
    }

    public OMElement getOMElement(QName parentQName, OMFactory factory) throws ADBException {
        ADBDataSource dataSource = new ADBDataSource((ADBBean)this, MY_QNAME);
        return factory.createOMElement((OMDataSource)dataSource, MY_QNAME);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter) throws XMLStreamException, ADBException {
        this.serialize(parentQName, xmlWriter, false);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter, boolean serializeType) throws XMLStreamException, ADBException {
        String namespace = parentQName.getNamespaceURI();
        String _localName = parentQName.getLocalPart();
        this.writeStartElement(null, namespace, _localName, xmlWriter);
        if (serializeType) {
            String namespacePrefix = this.registerPrefix(xmlWriter, "http://schemas.datacontract.org/2004/07/Citrix.VDI.Agent.Executer");
            if (namespacePrefix != null && namespacePrefix.trim().length() > 0) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", String.valueOf(namespacePrefix) + ":PvdAction", xmlWriter);
            } else {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", "PvdAction", xmlWriter);
            }
        }
        if (this.localPvdAction == null) {
            throw new ADBException("PvdAction cannot be null !!");
        }
        xmlWriter.writeCharacters(this.localPvdAction);
        xmlWriter.writeEndElement();
    }

    private static String generatePrefix(String namespace) {
        if (namespace.equals("http://schemas.datacontract.org/2004/07/Citrix.VDI.Agent.Executer")) {
            return "ns2";
        }
        return BeanUtil.getUniquePrefix();
    }

    private void writeStartElement(String prefix, String namespace, String localPart, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String writerPrefix = xmlWriter.getPrefix(namespace);
        if (writerPrefix != null) {
            xmlWriter.writeStartElement(namespace, localPart);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = CommandStub.PvdAction.generatePrefix(namespace);
            }
            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    private void writeAttribute(String prefix, String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    private void writeAttribute(String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    private void writeQNameAttribute(String namespace, String attName, QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String attributeNamespace = qname.getNamespaceURI();
        String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
        if (attributePrefix == null) {
            attributePrefix = this.registerPrefix(xmlWriter, attributeNamespace);
        }
        String attributeValue = attributePrefix.trim().length() > 0 ? String.valueOf(attributePrefix) + ":" + qname.getLocalPart() : qname.getLocalPart();
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    private void writeQName(QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String namespaceURI = qname.getNamespaceURI();
        if (namespaceURI != null) {
            String prefix = xmlWriter.getPrefix(namespaceURI);
            if (prefix == null) {
                prefix = CommandStub.PvdAction.generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }
            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(String.valueOf(prefix) + ":" + ConverterUtil.convertToString((QName)qname));
            } else {
                xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
            }
        } else {
            xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
        }
    }

    private void writeQNames(QName[] qnames, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (qnames != null) {
            StringBuffer stringToWrite = new StringBuffer();
            String namespaceURI = null;
            String prefix = null;
            int i = 0;
            while (i < qnames.length) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }
                if ((namespaceURI = qnames[i].getNamespaceURI()) != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);
                    if (prefix == null || prefix.length() == 0) {
                        prefix = CommandStub.PvdAction.generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }
                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":").append(ConverterUtil.convertToString((QName)qnames[i]));
                    } else {
                        stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                    }
                } else {
                    stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                }
                ++i;
            }
            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    private String registerPrefix(XMLStreamWriter xmlWriter, String namespace) throws XMLStreamException {
        String prefix = xmlWriter.getPrefix(namespace);
        if (prefix == null) {
            String uri;
            prefix = CommandStub.PvdAction.generatePrefix(namespace);
            NamespaceContext nsContext = xmlWriter.getNamespaceContext();
            while ((uri = nsContext.getNamespaceURI(prefix)) != null && uri.length() != 0) {
                prefix = BeanUtil.getUniquePrefix();
            }
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        return prefix;
    }

    public XMLStreamReader getPullParser(QName qName) throws ADBException {
        return new ADBXMLStreamReaderImpl(MY_QNAME, new Object[]{"Element Text", ConverterUtil.convertToString((String)this.localPvdAction)}, null);
    }

    public static class Factory {
        public static CommandStub.PvdAction fromValue(String value) throws IllegalArgumentException {
            CommandStub.PvdAction enumeration = (CommandStub.PvdAction)_table_.get(value);
            if (enumeration == null && value != null && !value.equals("")) {
                throw new IllegalArgumentException();
            }
            return enumeration;
        }

        public static CommandStub.PvdAction fromString(String value, String namespaceURI) throws IllegalArgumentException {
            try {
                return Factory.fromValue(ConverterUtil.convertToString((String)value));
            }
            catch (Exception e) {
                throw new IllegalArgumentException();
            }
        }

        public static CommandStub.PvdAction fromString(XMLStreamReader xmlStreamReader, String content) {
            if (content.indexOf(":") > -1) {
                String prefix = content.substring(0, content.indexOf(":"));
                String namespaceUri = xmlStreamReader.getNamespaceContext().getNamespaceURI(prefix);
                return Factory.fromString(content, namespaceUri);
            }
            return Factory.fromString(content, "");
        }

        public static CommandStub.PvdAction parse(XMLStreamReader reader) throws Exception {
            CommandStub.PvdAction object = null;
            HashMap attributeMap = new HashMap();
            ArrayList extraAttributeList = new ArrayList();
            String nillableValue = null;
            String prefix = "";
            String namespaceuri = "";
            try {
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                Vector handledAttributes = new Vector();
                while (!reader.isEndElement()) {
                    if (reader.isStartElement() || reader.hasText()) {
                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                            throw new ADBException("The element: PvdAction  cannot be null");
                        }
                        String content = reader.getElementText();
                        if (content.indexOf(":") > 0) {
                            prefix = content.substring(0, content.indexOf(":"));
                            namespaceuri = reader.getNamespaceURI(prefix);
                            object = Factory.fromString(content, namespaceuri);
                            continue;
                        }
                        object = Factory.fromString(content, "");
                        continue;
                    }
                    reader.next();
                }
            }
            catch (XMLStreamException e) {
                throw new Exception(e);
            }
            return object;
        }
    }
}
