/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.vm.Event;

public static class TCGroupWatch.Message
extends Agent.Message {
    private static String engineName = null;
    private boolean refreshHost;

    public TCGroupWatch.Message() {
        this.refreshHost = false;
    }

    public boolean isRefreshHost() {
        return this.refreshHost;
    }

    public void setRefreshHost(boolean refreshHost) {
        this.refreshHost = refreshHost;
    }

    public TCGroupWatch.Message(boolean refreshHost) {
        this.refreshHost = refreshHost;
    }

    public void send() {
        this.send(Event.Router.lookup(engineName));
    }

    static /* synthetic */ String access$0() {
        return engineName;
    }

    static /* synthetic */ void access$1(String string) {
        engineName = string;
    }
}
