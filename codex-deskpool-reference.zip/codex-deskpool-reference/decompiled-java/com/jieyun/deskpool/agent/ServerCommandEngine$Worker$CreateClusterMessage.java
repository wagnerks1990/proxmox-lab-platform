/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.service.JYServiceRuntimeException;
import com.jieyun.deskpool.shared.ErrorMessage;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.List;

public static class ServerCommandEngine.Worker.CreateClusterMessage
extends JYMessage {
    @Override
    public void onReceive() {
        List<ErrorMessage> result = null;
        try {
            if (this.getEventHandler() != null) {
                try {
                    this.getEventHandler().handle();
                }
                catch (JYServiceRuntimeException e) {
                    result = e.getErrorList();
                    logger.error(e.toString());
                }
            }
        }
        catch (Throwable throwable) {
            if (this.isSync() && this.getResponse() == null) {
                this.respond(new Response(result){});
            }
            throw throwable;
        }
        if (this.isSync() && this.getResponse() == null) {
            this.respond(new /* invalid duplicate definition of identical inner class */);
        }
    }

    public Response awaitResponse() {
        Stopwatch timer = new Stopwatch("[ServerCommandEngine.Worker.CreateClusterMessage.Response()]");
        try {
            Response response = (Response)this.response(120);
            return response;
        }
        finally {
            timer.stop();
        }
    }

    public static class Response
    implements Event.Response {
        private List<ErrorMessage> result;

        Response(List<ErrorMessage> result) {
            Stopwatch timer = new Stopwatch("[[ServerCommandEngine.Worker.CreateClusterMessage.Response.Response(" + result + ")]");
            try {
                this.result = result;
            }
            finally {
                timer.stop();
            }
        }

        public List<ErrorMessage> getResult() {
            return this.result;
        }
    }
}
