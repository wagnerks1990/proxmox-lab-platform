/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.ConverterUtil
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.ConverterUtil;

public static class CommandStub.QName.Factory {
    public static CommandStub.QName parse(XMLStreamReader reader) throws Exception {
        CommandStub.QName object = new CommandStub.QName();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
            if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                while (!reader.isEndElement()) {
                    reader.next();
                }
                return object;
            }
            Vector handledAttributes = new Vector();
            while (!reader.isEndElement()) {
                if (reader.isStartElement()) {
                    if (reader.isStartElement() && new QName("http://schemas.microsoft.com/2003/10/Serialization/", "QName").equals(reader.getName())) {
                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                            String content = reader.getElementText();
                            int index = content.indexOf(":");
                            prefix = index > 0 ? content.substring(0, index) : "";
                            namespaceuri = reader.getNamespaceURI(prefix);
                            object.setQName(ConverterUtil.convertToQName((String)content, (String)namespaceuri));
                            continue;
                        }
                        reader.getElementText();
                        continue;
                    }
                    throw new ADBException("Unexpected subelement " + reader.getName());
                }
                reader.next();
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
