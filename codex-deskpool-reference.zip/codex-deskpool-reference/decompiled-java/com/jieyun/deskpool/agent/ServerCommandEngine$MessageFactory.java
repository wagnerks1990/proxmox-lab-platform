/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.ServerCommandEngine;
import com.jieyun.deskpool.agent.utils.JYEngine;
import com.jieyun.deskpool.agent.utils.MessageCreator;
import com.jieyun.deskpool.agent.utils.StaticEngineLookupStrategy;

public static class ServerCommandEngine.MessageFactory
extends MessageCreator {
    private static ServerCommandEngine.MessageFactory instance = new ServerCommandEngine.MessageFactory();

    static {
        JYEngine engine = new JYEngine("ServerCommandEngine"){

            @Override
            public boolean isRejectWorking() {
                return false;
            }
        };
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.CreateClusterMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.JoinClusterMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.UpdateNetworkConfigMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.LeaveClusterMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.EnterMaintanceMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.ExitMaintanceMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.RefreshMasterMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.StopServiceMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.RestartServiceMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.RestartServerMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.ShutdownServerMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.RestoreFactorySettingMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.StartFloagIpMessage.class, engine);
        new ServerCommandEngine.Worker(ServerCommandEngine.Worker.StopFloagIpMessage.class, engine);
        StaticEngineLookupStrategy lookupStrategy = new StaticEngineLookupStrategy();
        lookupStrategy.setEngine(engine);
        instance.setEngineLookupStrategy(lookupStrategy);
        engine.start();
    }

    public static ServerCommandEngine.MessageFactory instance() {
        return instance;
    }
}
