/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.ConverterUtil
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.ConverterUtil;

public static class CommandStub.CommandResult.Factory {
    public static CommandStub.CommandResult fromValue(String value) throws IllegalArgumentException {
        CommandStub.CommandResult enumeration = (CommandStub.CommandResult)_table_.get(value);
        if (enumeration == null && value != null && !value.equals("")) {
            throw new IllegalArgumentException();
        }
        return enumeration;
    }

    public static CommandStub.CommandResult fromString(String value, String namespaceURI) throws IllegalArgumentException {
        try {
            return CommandStub.CommandResult.Factory.fromValue(ConverterUtil.convertToString((String)value));
        }
        catch (Exception e) {
            throw new IllegalArgumentException();
        }
    }

    public static CommandStub.CommandResult fromString(XMLStreamReader xmlStreamReader, String content) {
        if (content.indexOf(":") > -1) {
            String prefix = content.substring(0, content.indexOf(":"));
            String namespaceUri = xmlStreamReader.getNamespaceContext().getNamespaceURI(prefix);
            return CommandStub.CommandResult.Factory.fromString(content, namespaceUri);
        }
        return CommandStub.CommandResult.Factory.fromString(content, "");
    }

    public static CommandStub.CommandResult parse(XMLStreamReader reader) throws Exception {
        CommandStub.CommandResult object = null;
        HashMap attributeMap = new HashMap();
        ArrayList extraAttributeList = new ArrayList();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            Vector handledAttributes = new Vector();
            while (!reader.isEndElement()) {
                if (reader.isStartElement() || reader.hasText()) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                        throw new ADBException("The element: CommandResult  cannot be null");
                    }
                    String content = reader.getElementText();
                    if (content.indexOf(":") > 0) {
                        prefix = content.substring(0, content.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object = CommandStub.CommandResult.Factory.fromString(content, namespaceuri);
                        continue;
                    }
                    object = CommandStub.CommandResult.Factory.fromString(content, "");
                    continue;
                }
                reader.next();
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
