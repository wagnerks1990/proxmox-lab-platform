/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;

public abstract class CommandCallbackHandler {
    protected Object clientData;

    public CommandCallbackHandler(Object clientData) {
        this.clientData = clientData;
    }

    public CommandCallbackHandler() {
        this.clientData = null;
    }

    public Object getClientData() {
        return this.clientData;
    }

    public void receiveResultpvd(CommandStub.PvdResponse result) {
    }

    public void receiveErrorpvd(Exception e) {
    }

    public void receiveResultputFile(CommandStub.PutFileResponse result) {
    }

    public void receiveErrorputFile(Exception e) {
    }

    public void receiveResultdestroy(CommandStub.DestroyResponse result) {
    }

    public void receiveErrordestroy(Exception e) {
    }

    public void receiveResultputTextFile(CommandStub.PutTextFileResponse result) {
    }

    public void receiveErrorputTextFile(Exception e) {
    }

    public void receiveResultsysPrep(CommandStub.SysPrepResponse result) {
    }

    public void receiveErrorsysPrep(Exception e) {
    }

    public void receiveResultrestartSelf(CommandStub.RestartSelfResponse result) {
    }

    public void receiveErrorrestartSelf(Exception e) {
    }

    public void receiveResultdisconnectAllUsers(CommandStub.DisconnectAllUsersResponse result) {
    }

    public void receiveErrordisconnectAllUsers(Exception e) {
    }

    public void receiveResultjoinWorkgroup(CommandStub.JoinWorkgroupResponse result) {
    }

    public void receiveErrorjoinWorkgroup(Exception e) {
    }

    public void receiveResultsetComputerName(CommandStub.SetComputerNameResponse result) {
    }

    public void receiveErrorsetComputerName(Exception e) {
    }

    public void receiveResultexecuteAndWait(CommandStub.ExecuteAndWaitResponse result) {
    }

    public void receiveErrorexecuteAndWait(Exception e) {
    }

    public void receiveResultlogOffAllUsers(CommandStub.LogOffAllUsersResponse result) {
    }

    public void receiveErrorlogOffAllUsers(Exception e) {
    }

    public void receiveResultredirectPrinter(CommandStub.RedirectPrinterResponse result) {
    }

    public void receiveErrorredirectPrinter(Exception e) {
    }

    public void receiveResultping(CommandStub.PingResponse result) {
    }

    public void receiveErrorping(Exception e) {
    }

    public void receiveResultgetFile(CommandStub.GetFileResponse result) {
    }

    public void receiveErrorgetFile(Exception e) {
    }

    public void receiveResultversion(CommandStub.VersionResponse result) {
    }

    public void receiveErrorversion(Exception e) {
    }

    public void receiveResultrestartService(CommandStub.RestartServiceResponse result) {
    }

    public void receiveErrorrestartService(Exception e) {
    }

    public void receiveResultgetState(CommandStub.GetStateResponse result) {
    }

    public void receiveErrorgetState(Exception e) {
    }

    public void receiveResultexecute(CommandStub.ExecuteResponse result) {
    }

    public void receiveErrorexecute(Exception e) {
    }

    public void receiveResultstopService(CommandStub.StopServiceResponse result) {
    }

    public void receiveErrorstopService(Exception e) {
    }

    public void receiveResultdisablePasswordChange(CommandStub.DisablePasswordChangeResponse result) {
    }

    public void receiveErrordisablePasswordChange(Exception e) {
    }

    public void receiveResultredirectUsb(CommandStub.RedirectUsbResponse result) {
    }

    public void receiveErrorredirectUsb(Exception e) {
    }

    public void receiveResultvdiPrep(CommandStub.VdiPrepResponse result) {
    }

    public void receiveErrorvdiPrep(Exception e) {
    }

    public void receiveResultjoinDomain(CommandStub.JoinDomainResponse result) {
    }

    public void receiveErrorjoinDomain(Exception e) {
    }
}
