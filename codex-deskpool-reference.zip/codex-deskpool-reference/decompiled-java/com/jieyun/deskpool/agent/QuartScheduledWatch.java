/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.Event;

public class QuartScheduledWatch
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final String ENGINE_NAME = "quartScheduled";
    private static boolean isBusy = false;
    private static final int QUART_SCHEDULE_TIME = Props.instance().get("server.quart.schedule.time", 60);

    public QuartScheduledWatch() {
        this(new Event.TimedEngine(ENGINE_NAME, QUART_SCHEDULE_TIME){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    public QuartScheduledWatch(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (isBusy || !StoreContext.enable()) {
            return true;
        }
        try {
            try {
                Services.getQuartScheduleService().syncJob();
            }
            catch (Exception e) {
                e.printStackTrace();
                isBusy = false;
            }
        }
        finally {
            isBusy = false;
        }
        return false;
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
