/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.utils.Script;

public static class ServerCommandEngine.Worker.StopServiceMessage
extends JYMessage {
    @Override
    public void onReceive() {
        logger.info("stopService");
        String killcmd2 = "service tomcat stop";
        Script.runSimpleBashRemoteScript(killcmd2, 1200);
    }
}
