/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;

public static class ServerCommandEngine.Worker.EnterMaintanceMessage
extends JYMessage {
}
