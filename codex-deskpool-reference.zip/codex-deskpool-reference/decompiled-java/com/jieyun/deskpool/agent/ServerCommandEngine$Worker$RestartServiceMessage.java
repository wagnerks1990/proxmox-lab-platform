/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;

public static class ServerCommandEngine.Worker.RestartServiceMessage
extends JYMessage {
    @Override
    public void onReceive() {
        logger.info("restartService");
        try {
            Runtime.getRuntime().exec("nohup service tomcat restart &");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
