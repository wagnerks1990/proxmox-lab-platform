/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.QuartScheduledWatch;
import com.jieyun.deskpool.vm.Event;

class QuartScheduledWatch.1
extends Event.TimedEngine {
    QuartScheduledWatch.1(String $anonymous0, long $anonymous1) {
        super($anonymous0, $anonymous1);
    }

    @Override
    protected Event defaultEvent() {
        return new QuartScheduledWatch.Message();
    }
}
