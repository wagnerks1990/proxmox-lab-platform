/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.TCGroupWatch;
import com.jieyun.deskpool.vm.Event;

class TCGroupWatch.2
extends Event.TimedEngine {
    TCGroupWatch.2(String $anonymous0, long $anonymous1) {
        super($anonymous0, $anonymous1);
    }

    @Override
    protected Event defaultEvent() {
        return new TCGroupWatch.Message();
    }
}
