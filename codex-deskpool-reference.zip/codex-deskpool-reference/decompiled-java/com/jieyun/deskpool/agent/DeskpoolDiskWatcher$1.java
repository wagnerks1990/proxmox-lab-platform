/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;

class DeskpoolDiskWatcher.1
extends JYMessage {
    DeskpoolDiskWatcher.1() {
    }

    @Override
    public void onReceive() {
    }
}
