/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.vm.Event;

public static abstract class Agent.Impl
implements Agent {
    protected Event.Engine engine;

    protected Agent.Impl(Event.Engine engine) {
        this.engine = engine;
    }

    public Event.Engine engine() {
        return this.engine;
    }

    protected void subscribe(Class eventClass) {
        boolean bypass = true;
        this.engine().subscribe(eventClass, this, bypass);
    }

    @Override
    public abstract boolean receive(Event var1);

    public String toString() {
        return String.valueOf(this.getClass().getName()) + "<" + this.engine + ">";
    }
}
