/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.vm.Event;

public static class InstanceWatcher.Message
extends Agent.Message {
    private static final long serialVersionUID = 1L;
    private static String engineName = null;

    public void send() {
        this.send(Event.Router.lookup(engineName));
    }

    static /* synthetic */ String access$0() {
        return engineName;
    }

    static /* synthetic */ void access$1(String string) {
        engineName = string;
    }
}
