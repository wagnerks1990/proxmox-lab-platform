/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

static class PoolManager.AllocInfo {
    int allocate;
    int reuse;

    public PoolManager.AllocInfo(int alloc, int reuse) {
        this.allocate = alloc;
        this.reuse = reuse;
    }
}
