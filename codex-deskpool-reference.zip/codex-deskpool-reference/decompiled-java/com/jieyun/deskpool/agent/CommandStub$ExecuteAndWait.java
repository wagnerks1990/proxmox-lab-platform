/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axiom.om.OMDataSource
 *  org.apache.axiom.om.OMElement
 *  org.apache.axiom.om.OMFactory
 *  org.apache.axis2.databinding.ADBBean
 *  org.apache.axis2.databinding.ADBDataSource
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.BeanUtil
 *  org.apache.axis2.databinding.utils.ConverterUtil
 *  org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.ArrayList;
import java.util.Vector;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import org.apache.axiom.om.OMDataSource;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axis2.databinding.ADBBean;
import org.apache.axis2.databinding.ADBDataSource;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.BeanUtil;
import org.apache.axis2.databinding.utils.ConverterUtil;
import org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl;

public static class CommandStub.ExecuteAndWait
implements ADBBean {
    public static final QName MY_QNAME = new QName("http://tempuri.org/", "ExecuteAndWait", "ns4");
    protected String localSd;
    protected boolean localSdTracker = false;
    protected String localCommand;
    protected boolean localCommandTracker = false;
    protected String localParameters;
    protected boolean localParametersTracker = false;
    protected String localWorkingDir;
    protected boolean localWorkingDirTracker = false;
    protected String localStdIn;
    protected boolean localStdInTracker = false;
    protected int localMaxRunTimeInSeconds;
    protected boolean localMaxRunTimeInSecondsTracker = false;

    public boolean isSdSpecified() {
        return this.localSdTracker;
    }

    public String getSd() {
        return this.localSd;
    }

    public void setSd(String param) {
        this.localSdTracker = true;
        this.localSd = param;
    }

    public boolean isCommandSpecified() {
        return this.localCommandTracker;
    }

    public String getCommand() {
        return this.localCommand;
    }

    public void setCommand(String param) {
        this.localCommandTracker = true;
        this.localCommand = param;
    }

    public boolean isParametersSpecified() {
        return this.localParametersTracker;
    }

    public String getParameters() {
        return this.localParameters;
    }

    public void setParameters(String param) {
        this.localParametersTracker = true;
        this.localParameters = param;
    }

    public boolean isWorkingDirSpecified() {
        return this.localWorkingDirTracker;
    }

    public String getWorkingDir() {
        return this.localWorkingDir;
    }

    public void setWorkingDir(String param) {
        this.localWorkingDirTracker = true;
        this.localWorkingDir = param;
    }

    public boolean isStdInSpecified() {
        return this.localStdInTracker;
    }

    public String getStdIn() {
        return this.localStdIn;
    }

    public void setStdIn(String param) {
        this.localStdInTracker = true;
        this.localStdIn = param;
    }

    public boolean isMaxRunTimeInSecondsSpecified() {
        return this.localMaxRunTimeInSecondsTracker;
    }

    public int getMaxRunTimeInSeconds() {
        return this.localMaxRunTimeInSeconds;
    }

    public void setMaxRunTimeInSeconds(int param) {
        this.localMaxRunTimeInSecondsTracker = param != Integer.MIN_VALUE;
        this.localMaxRunTimeInSeconds = param;
    }

    public OMElement getOMElement(QName parentQName, OMFactory factory) throws ADBException {
        ADBDataSource dataSource = new ADBDataSource((ADBBean)this, MY_QNAME);
        return factory.createOMElement((OMDataSource)dataSource, MY_QNAME);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter) throws XMLStreamException, ADBException {
        this.serialize(parentQName, xmlWriter, false);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter, boolean serializeType) throws XMLStreamException, ADBException {
        String prefix = null;
        String namespace = null;
        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        this.writeStartElement(prefix, namespace, parentQName.getLocalPart(), xmlWriter);
        if (serializeType) {
            String namespacePrefix = this.registerPrefix(xmlWriter, "http://tempuri.org/");
            if (namespacePrefix != null && namespacePrefix.trim().length() > 0) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", String.valueOf(namespacePrefix) + ":ExecuteAndWait", xmlWriter);
            } else {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", "ExecuteAndWait", xmlWriter);
            }
        }
        if (this.localSdTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "sd", xmlWriter);
            if (this.localSd == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localSd);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localCommandTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "command", xmlWriter);
            if (this.localCommand == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localCommand);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localParametersTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "parameters", xmlWriter);
            if (this.localParameters == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localParameters);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localWorkingDirTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "workingDir", xmlWriter);
            if (this.localWorkingDir == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localWorkingDir);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localStdInTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "stdIn", xmlWriter);
            if (this.localStdIn == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localStdIn);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localMaxRunTimeInSecondsTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "maxRunTimeInSeconds", xmlWriter);
            if (this.localMaxRunTimeInSeconds == Integer.MIN_VALUE) {
                throw new ADBException("maxRunTimeInSeconds cannot be null!!");
            }
            xmlWriter.writeCharacters(ConverterUtil.convertToString((int)this.localMaxRunTimeInSeconds));
            xmlWriter.writeEndElement();
        }
        xmlWriter.writeEndElement();
    }

    private static String generatePrefix(String namespace) {
        if (namespace.equals("http://tempuri.org/")) {
            return "ns4";
        }
        return BeanUtil.getUniquePrefix();
    }

    private void writeStartElement(String prefix, String namespace, String localPart, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String writerPrefix = xmlWriter.getPrefix(namespace);
        if (writerPrefix != null) {
            xmlWriter.writeStartElement(namespace, localPart);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = CommandStub.ExecuteAndWait.generatePrefix(namespace);
            }
            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    private void writeAttribute(String prefix, String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    private void writeAttribute(String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    private void writeQNameAttribute(String namespace, String attName, QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String attributeNamespace = qname.getNamespaceURI();
        String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
        if (attributePrefix == null) {
            attributePrefix = this.registerPrefix(xmlWriter, attributeNamespace);
        }
        String attributeValue = attributePrefix.trim().length() > 0 ? String.valueOf(attributePrefix) + ":" + qname.getLocalPart() : qname.getLocalPart();
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    private void writeQName(QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String namespaceURI = qname.getNamespaceURI();
        if (namespaceURI != null) {
            String prefix = xmlWriter.getPrefix(namespaceURI);
            if (prefix == null) {
                prefix = CommandStub.ExecuteAndWait.generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }
            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(String.valueOf(prefix) + ":" + ConverterUtil.convertToString((QName)qname));
            } else {
                xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
            }
        } else {
            xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
        }
    }

    private void writeQNames(QName[] qnames, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (qnames != null) {
            StringBuffer stringToWrite = new StringBuffer();
            String namespaceURI = null;
            String prefix = null;
            int i = 0;
            while (i < qnames.length) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }
                if ((namespaceURI = qnames[i].getNamespaceURI()) != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);
                    if (prefix == null || prefix.length() == 0) {
                        prefix = CommandStub.ExecuteAndWait.generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }
                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":").append(ConverterUtil.convertToString((QName)qnames[i]));
                    } else {
                        stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                    }
                } else {
                    stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                }
                ++i;
            }
            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    private String registerPrefix(XMLStreamWriter xmlWriter, String namespace) throws XMLStreamException {
        String prefix = xmlWriter.getPrefix(namespace);
        if (prefix == null) {
            String uri;
            prefix = CommandStub.ExecuteAndWait.generatePrefix(namespace);
            NamespaceContext nsContext = xmlWriter.getNamespaceContext();
            while ((uri = nsContext.getNamespaceURI(prefix)) != null && uri.length() != 0) {
                prefix = BeanUtil.getUniquePrefix();
            }
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        return prefix;
    }

    public XMLStreamReader getPullParser(QName qName) throws ADBException {
        ArrayList<Object> elementList = new ArrayList<Object>();
        ArrayList attribList = new ArrayList();
        if (this.localSdTracker) {
            elementList.add(new QName("http://tempuri.org/", "sd"));
            elementList.add(this.localSd == null ? null : ConverterUtil.convertToString((String)this.localSd));
        }
        if (this.localCommandTracker) {
            elementList.add(new QName("http://tempuri.org/", "command"));
            elementList.add(this.localCommand == null ? null : ConverterUtil.convertToString((String)this.localCommand));
        }
        if (this.localParametersTracker) {
            elementList.add(new QName("http://tempuri.org/", "parameters"));
            elementList.add(this.localParameters == null ? null : ConverterUtil.convertToString((String)this.localParameters));
        }
        if (this.localWorkingDirTracker) {
            elementList.add(new QName("http://tempuri.org/", "workingDir"));
            elementList.add(this.localWorkingDir == null ? null : ConverterUtil.convertToString((String)this.localWorkingDir));
        }
        if (this.localStdInTracker) {
            elementList.add(new QName("http://tempuri.org/", "stdIn"));
            elementList.add(this.localStdIn == null ? null : ConverterUtil.convertToString((String)this.localStdIn));
        }
        if (this.localMaxRunTimeInSecondsTracker) {
            elementList.add(new QName("http://tempuri.org/", "maxRunTimeInSeconds"));
            elementList.add(ConverterUtil.convertToString((int)this.localMaxRunTimeInSeconds));
        }
        return new ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
    }

    public static class Factory {
        public static CommandStub.ExecuteAndWait parse(XMLStreamReader reader) throws Exception {
            CommandStub.ExecuteAndWait object = new CommandStub.ExecuteAndWait();
            String nillableValue = null;
            String prefix = "";
            String namespaceuri = "";
            try {
                String content;
                String fullTypeName;
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null && (fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type")) != null) {
                    String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1) {
                        nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix == null ? "" : nsPrefix;
                    String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);
                    if (!"ExecuteAndWait".equals(type)) {
                        String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                        return (CommandStub.ExecuteAndWait)CommandStub.ExtensionMapper.getTypeObject(nsUri, type, reader);
                    }
                }
                Vector handledAttributes = new Vector();
                reader.next();
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "sd").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setSd(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "command").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setCommand(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "parameters").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setParameters(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "workingDir").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setWorkingDir(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "stdIn").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setStdIn(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "maxRunTimeInSeconds").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                        throw new ADBException("The element: maxRunTimeInSeconds  cannot be null");
                    }
                    content = reader.getElementText();
                    object.setMaxRunTimeInSeconds(ConverterUtil.convertToInt((String)content));
                    reader.next();
                } else {
                    object.setMaxRunTimeInSeconds(Integer.MIN_VALUE);
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement()) {
                    throw new ADBException("Unexpected subelement " + reader.getName());
                }
            }
            catch (XMLStreamException e) {
                throw new Exception(e);
            }
            return object;
        }
    }
}
