/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.vm.Event;
import java.io.File;

public class Axis2TempFileWatcher.EventHandler
implements Event.Recipient {
    @Override
    public boolean receive(Event paramEvent) {
        File file = new File(System.getProperty("java.io.tmpdir"));
        if (file.exists()) {
            File[] subfiles;
            File[] fileArray = subfiles = file.listFiles();
            int n = subfiles.length;
            int n2 = 0;
            while (n2 < n) {
                File axisFile = fileArray[n2];
                if (axisFile.getName().contains("axis") && axisFile.isDirectory()) {
                    this.deleteInvalidateFile(axisFile);
                }
                ++n2;
            }
        }
        return true;
    }

    private void deleteInvalidateFile(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            File[] fileArray = files;
            int n = files.length;
            int n2 = 0;
            while (n2 < n) {
                File file = fileArray[n2];
                file.delete();
                ++n2;
            }
        }
        dir.delete();
    }
}
