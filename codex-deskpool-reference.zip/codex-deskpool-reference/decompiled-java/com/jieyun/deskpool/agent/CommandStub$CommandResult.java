/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axiom.om.OMDataSource
 *  org.apache.axiom.om.OMElement
 *  org.apache.axiom.om.OMFactory
 *  org.apache.axis2.databinding.ADBBean
 *  org.apache.axis2.databinding.ADBDataSource
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.BeanUtil
 *  org.apache.axis2.databinding.utils.ConverterUtil
 *  org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl
 */
package com.jieyun.deskpool.agent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import org.apache.axiom.om.OMDataSource;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axis2.databinding.ADBBean;
import org.apache.axis2.databinding.ADBDataSource;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.BeanUtil;
import org.apache.axis2.databinding.utils.ConverterUtil;
import org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl;

public static class CommandStub.CommandResult
implements ADBBean {
    public static final QName MY_QNAME = new QName("http://schemas.datacontract.org/2004/07/Citrix.VDI.Inside.Support", "CommandResult", "ns1");
    protected String localCommandResult;
    private static HashMap _table_ = new HashMap();
    public static final String _Unknown = ConverterUtil.convertToString((String)"Unknown");
    public static final String _OperationQueued = ConverterUtil.convertToString((String)"OperationQueued");
    public static final String _FailedAuthentication = ConverterUtil.convertToString((String)"FailedAuthentication");
    public static final String _Success = ConverterUtil.convertToString((String)"Success");
    public static final String _Failure = ConverterUtil.convertToString((String)"Failure");
    public static final String _NothingToDo = ConverterUtil.convertToString((String)"NothingToDo");
    public static final String _UserDisconnected = ConverterUtil.convertToString((String)"UserDisconnected");
    public static final String _RDPConnected = ConverterUtil.convertToString((String)"RDPConnected");
    public static final String _HDXConnected = ConverterUtil.convertToString((String)"HDXConnected");
    public static final String _OnHold = ConverterUtil.convertToString((String)"OnHold");
    public static final String _InProgress = ConverterUtil.convertToString((String)"InProgress");
    public static final String _CallFailed = ConverterUtil.convertToString((String)"CallFailed");
    public static final CommandStub.CommandResult Unknown = new CommandStub.CommandResult(_Unknown, true);
    public static final CommandStub.CommandResult OperationQueued = new CommandStub.CommandResult(_OperationQueued, true);
    public static final CommandStub.CommandResult FailedAuthentication = new CommandStub.CommandResult(_FailedAuthentication, true);
    public static final CommandStub.CommandResult Success = new CommandStub.CommandResult(_Success, true);
    public static final CommandStub.CommandResult Failure = new CommandStub.CommandResult(_Failure, true);
    public static final CommandStub.CommandResult NothingToDo = new CommandStub.CommandResult(_NothingToDo, true);
    public static final CommandStub.CommandResult UserDisconnected = new CommandStub.CommandResult(_UserDisconnected, true);
    public static final CommandStub.CommandResult RDPConnected = new CommandStub.CommandResult(_RDPConnected, true);
    public static final CommandStub.CommandResult HDXConnected = new CommandStub.CommandResult(_HDXConnected, true);
    public static final CommandStub.CommandResult OnHold = new CommandStub.CommandResult(_OnHold, true);
    public static final CommandStub.CommandResult InProgress = new CommandStub.CommandResult(_InProgress, true);
    public static final CommandStub.CommandResult CallFailed = new CommandStub.CommandResult(_CallFailed, true);

    protected CommandStub.CommandResult(String value, boolean isRegisterValue) {
        this.localCommandResult = value;
        if (isRegisterValue) {
            _table_.put(this.localCommandResult, this);
        }
    }

    public String getValue() {
        return this.localCommandResult;
    }

    public boolean equals(Object obj) {
        return obj == this;
    }

    public int hashCode() {
        return this.toString().hashCode();
    }

    public String toString() {
        return this.localCommandResult.toString();
    }

    public OMElement getOMElement(QName parentQName, OMFactory factory) throws ADBException {
        ADBDataSource dataSource = new ADBDataSource((ADBBean)this, MY_QNAME);
        return factory.createOMElement((OMDataSource)dataSource, MY_QNAME);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter) throws XMLStreamException, ADBException {
        this.serialize(parentQName, xmlWriter, false);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter, boolean serializeType) throws XMLStreamException, ADBException {
        String namespace = parentQName.getNamespaceURI();
        String _localName = parentQName.getLocalPart();
        this.writeStartElement(null, namespace, _localName, xmlWriter);
        if (serializeType) {
            String namespacePrefix = this.registerPrefix(xmlWriter, "http://schemas.datacontract.org/2004/07/Citrix.VDI.Inside.Support");
            if (namespacePrefix != null && namespacePrefix.trim().length() > 0) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", String.valueOf(namespacePrefix) + ":CommandResult", xmlWriter);
            } else {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", "CommandResult", xmlWriter);
            }
        }
        if (this.localCommandResult == null) {
            throw new ADBException("CommandResult cannot be null !!");
        }
        xmlWriter.writeCharacters(this.localCommandResult);
        xmlWriter.writeEndElement();
    }

    private static String generatePrefix(String namespace) {
        if (namespace.equals("http://schemas.datacontract.org/2004/07/Citrix.VDI.Inside.Support")) {
            return "ns1";
        }
        return BeanUtil.getUniquePrefix();
    }

    private void writeStartElement(String prefix, String namespace, String localPart, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String writerPrefix = xmlWriter.getPrefix(namespace);
        if (writerPrefix != null) {
            xmlWriter.writeStartElement(namespace, localPart);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = CommandStub.CommandResult.generatePrefix(namespace);
            }
            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    private void writeAttribute(String prefix, String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    private void writeAttribute(String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    private void writeQNameAttribute(String namespace, String attName, QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String attributeNamespace = qname.getNamespaceURI();
        String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
        if (attributePrefix == null) {
            attributePrefix = this.registerPrefix(xmlWriter, attributeNamespace);
        }
        String attributeValue = attributePrefix.trim().length() > 0 ? String.valueOf(attributePrefix) + ":" + qname.getLocalPart() : qname.getLocalPart();
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    private void writeQName(QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String namespaceURI = qname.getNamespaceURI();
        if (namespaceURI != null) {
            String prefix = xmlWriter.getPrefix(namespaceURI);
            if (prefix == null) {
                prefix = CommandStub.CommandResult.generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }
            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(String.valueOf(prefix) + ":" + ConverterUtil.convertToString((QName)qname));
            } else {
                xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
            }
        } else {
            xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
        }
    }

    private void writeQNames(QName[] qnames, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (qnames != null) {
            StringBuffer stringToWrite = new StringBuffer();
            String namespaceURI = null;
            String prefix = null;
            int i = 0;
            while (i < qnames.length) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }
                if ((namespaceURI = qnames[i].getNamespaceURI()) != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);
                    if (prefix == null || prefix.length() == 0) {
                        prefix = CommandStub.CommandResult.generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }
                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":").append(ConverterUtil.convertToString((QName)qnames[i]));
                    } else {
                        stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                    }
                } else {
                    stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                }
                ++i;
            }
            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    private String registerPrefix(XMLStreamWriter xmlWriter, String namespace) throws XMLStreamException {
        String prefix = xmlWriter.getPrefix(namespace);
        if (prefix == null) {
            String uri;
            prefix = CommandStub.CommandResult.generatePrefix(namespace);
            NamespaceContext nsContext = xmlWriter.getNamespaceContext();
            while ((uri = nsContext.getNamespaceURI(prefix)) != null && uri.length() != 0) {
                prefix = BeanUtil.getUniquePrefix();
            }
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        return prefix;
    }

    public XMLStreamReader getPullParser(QName qName) throws ADBException {
        return new ADBXMLStreamReaderImpl(MY_QNAME, new Object[]{"Element Text", ConverterUtil.convertToString((String)this.localCommandResult)}, null);
    }

    public static class Factory {
        public static CommandStub.CommandResult fromValue(String value) throws IllegalArgumentException {
            CommandStub.CommandResult enumeration = (CommandStub.CommandResult)_table_.get(value);
            if (enumeration == null && value != null && !value.equals("")) {
                throw new IllegalArgumentException();
            }
            return enumeration;
        }

        public static CommandStub.CommandResult fromString(String value, String namespaceURI) throws IllegalArgumentException {
            try {
                return Factory.fromValue(ConverterUtil.convertToString((String)value));
            }
            catch (Exception e) {
                throw new IllegalArgumentException();
            }
        }

        public static CommandStub.CommandResult fromString(XMLStreamReader xmlStreamReader, String content) {
            if (content.indexOf(":") > -1) {
                String prefix = content.substring(0, content.indexOf(":"));
                String namespaceUri = xmlStreamReader.getNamespaceContext().getNamespaceURI(prefix);
                return Factory.fromString(content, namespaceUri);
            }
            return Factory.fromString(content, "");
        }

        public static CommandStub.CommandResult parse(XMLStreamReader reader) throws Exception {
            CommandStub.CommandResult object = null;
            HashMap attributeMap = new HashMap();
            ArrayList extraAttributeList = new ArrayList();
            String nillableValue = null;
            String prefix = "";
            String namespaceuri = "";
            try {
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                Vector handledAttributes = new Vector();
                while (!reader.isEndElement()) {
                    if (reader.isStartElement() || reader.hasText()) {
                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                            throw new ADBException("The element: CommandResult  cannot be null");
                        }
                        String content = reader.getElementText();
                        if (content.indexOf(":") > 0) {
                            prefix = content.substring(0, content.indexOf(":"));
                            namespaceuri = reader.getNamespaceURI(prefix);
                            object = Factory.fromString(content, namespaceuri);
                            continue;
                        }
                        object = Factory.fromString(content, "");
                        continue;
                    }
                    reader.next();
                }
            }
            catch (XMLStreamException e) {
                throw new Exception(e);
            }
            return object;
        }
    }
}
