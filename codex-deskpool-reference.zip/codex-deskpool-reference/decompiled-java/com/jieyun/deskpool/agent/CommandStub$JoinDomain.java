/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axiom.om.OMDataSource
 *  org.apache.axiom.om.OMElement
 *  org.apache.axiom.om.OMFactory
 *  org.apache.axis2.databinding.ADBBean
 *  org.apache.axis2.databinding.ADBDataSource
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.BeanUtil
 *  org.apache.axis2.databinding.utils.ConverterUtil
 *  org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.ArrayList;
import java.util.Vector;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import org.apache.axiom.om.OMDataSource;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axis2.databinding.ADBBean;
import org.apache.axis2.databinding.ADBDataSource;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.BeanUtil;
import org.apache.axis2.databinding.utils.ConverterUtil;
import org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl;

public static class CommandStub.JoinDomain
implements ADBBean {
    public static final QName MY_QNAME = new QName("http://tempuri.org/", "JoinDomain", "ns4");
    protected String localSd;
    protected boolean localSdTracker = false;
    protected String localDomainName;
    protected boolean localDomainNameTracker = false;
    protected String localOrgUnit;
    protected boolean localOrgUnitTracker = false;
    protected String localAdminName;
    protected boolean localAdminNameTracker = false;
    protected String localPassword;
    protected boolean localPasswordTracker = false;
    protected boolean localEnableFastRefresh;
    protected boolean localEnableFastRefreshTracker = false;

    public boolean isSdSpecified() {
        return this.localSdTracker;
    }

    public String getSd() {
        return this.localSd;
    }

    public void setSd(String param) {
        this.localSdTracker = true;
        this.localSd = param;
    }

    public boolean isDomainNameSpecified() {
        return this.localDomainNameTracker;
    }

    public String getDomainName() {
        return this.localDomainName;
    }

    public void setDomainName(String param) {
        this.localDomainNameTracker = true;
        this.localDomainName = param;
    }

    public boolean isOrgUnitSpecified() {
        return this.localOrgUnitTracker;
    }

    public String getOrgUnit() {
        return this.localOrgUnit;
    }

    public void setOrgUnit(String param) {
        this.localOrgUnitTracker = true;
        this.localOrgUnit = param;
    }

    public boolean isAdminNameSpecified() {
        return this.localAdminNameTracker;
    }

    public String getAdminName() {
        return this.localAdminName;
    }

    public void setAdminName(String param) {
        this.localAdminNameTracker = true;
        this.localAdminName = param;
    }

    public boolean isPasswordSpecified() {
        return this.localPasswordTracker;
    }

    public String getPassword() {
        return this.localPassword;
    }

    public void setPassword(String param) {
        this.localPasswordTracker = true;
        this.localPassword = param;
    }

    public boolean isEnableFastRefreshSpecified() {
        return this.localEnableFastRefreshTracker;
    }

    public boolean getEnableFastRefresh() {
        return this.localEnableFastRefresh;
    }

    public void setEnableFastRefresh(boolean param) {
        this.localEnableFastRefreshTracker = true;
        this.localEnableFastRefresh = param;
    }

    public OMElement getOMElement(QName parentQName, OMFactory factory) throws ADBException {
        ADBDataSource dataSource = new ADBDataSource((ADBBean)this, MY_QNAME);
        return factory.createOMElement((OMDataSource)dataSource, MY_QNAME);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter) throws XMLStreamException, ADBException {
        this.serialize(parentQName, xmlWriter, false);
    }

    public void serialize(QName parentQName, XMLStreamWriter xmlWriter, boolean serializeType) throws XMLStreamException, ADBException {
        String prefix = null;
        String namespace = null;
        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        this.writeStartElement(prefix, namespace, parentQName.getLocalPart(), xmlWriter);
        if (serializeType) {
            String namespacePrefix = this.registerPrefix(xmlWriter, "http://tempuri.org/");
            if (namespacePrefix != null && namespacePrefix.trim().length() > 0) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", String.valueOf(namespacePrefix) + ":JoinDomain", xmlWriter);
            } else {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type", "JoinDomain", xmlWriter);
            }
        }
        if (this.localSdTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "sd", xmlWriter);
            if (this.localSd == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localSd);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localDomainNameTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "domainName", xmlWriter);
            if (this.localDomainName == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localDomainName);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localOrgUnitTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "orgUnit", xmlWriter);
            if (this.localOrgUnit == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localOrgUnit);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localAdminNameTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "adminName", xmlWriter);
            if (this.localAdminName == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localAdminName);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localPasswordTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "password", xmlWriter);
            if (this.localPassword == null) {
                this.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
            } else {
                xmlWriter.writeCharacters(this.localPassword);
            }
            xmlWriter.writeEndElement();
        }
        if (this.localEnableFastRefreshTracker) {
            namespace = "http://tempuri.org/";
            this.writeStartElement(null, namespace, "enableFastRefresh", xmlWriter);
            xmlWriter.writeCharacters(ConverterUtil.convertToString((boolean)this.localEnableFastRefresh));
            xmlWriter.writeEndElement();
        }
        xmlWriter.writeEndElement();
    }

    private static String generatePrefix(String namespace) {
        if (namespace.equals("http://tempuri.org/")) {
            return "ns4";
        }
        return BeanUtil.getUniquePrefix();
    }

    private void writeStartElement(String prefix, String namespace, String localPart, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String writerPrefix = xmlWriter.getPrefix(namespace);
        if (writerPrefix != null) {
            xmlWriter.writeStartElement(namespace, localPart);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = CommandStub.JoinDomain.generatePrefix(namespace);
            }
            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    private void writeAttribute(String prefix, String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    private void writeAttribute(String namespace, String attName, String attValue, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    private void writeQNameAttribute(String namespace, String attName, QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String attributeNamespace = qname.getNamespaceURI();
        String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
        if (attributePrefix == null) {
            attributePrefix = this.registerPrefix(xmlWriter, attributeNamespace);
        }
        String attributeValue = attributePrefix.trim().length() > 0 ? String.valueOf(attributePrefix) + ":" + qname.getLocalPart() : qname.getLocalPart();
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            this.registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    private void writeQName(QName qname, XMLStreamWriter xmlWriter) throws XMLStreamException {
        String namespaceURI = qname.getNamespaceURI();
        if (namespaceURI != null) {
            String prefix = xmlWriter.getPrefix(namespaceURI);
            if (prefix == null) {
                prefix = CommandStub.JoinDomain.generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }
            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(String.valueOf(prefix) + ":" + ConverterUtil.convertToString((QName)qname));
            } else {
                xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
            }
        } else {
            xmlWriter.writeCharacters(ConverterUtil.convertToString((QName)qname));
        }
    }

    private void writeQNames(QName[] qnames, XMLStreamWriter xmlWriter) throws XMLStreamException {
        if (qnames != null) {
            StringBuffer stringToWrite = new StringBuffer();
            String namespaceURI = null;
            String prefix = null;
            int i = 0;
            while (i < qnames.length) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }
                if ((namespaceURI = qnames[i].getNamespaceURI()) != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);
                    if (prefix == null || prefix.length() == 0) {
                        prefix = CommandStub.JoinDomain.generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }
                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":").append(ConverterUtil.convertToString((QName)qnames[i]));
                    } else {
                        stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                    }
                } else {
                    stringToWrite.append(ConverterUtil.convertToString((QName)qnames[i]));
                }
                ++i;
            }
            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    private String registerPrefix(XMLStreamWriter xmlWriter, String namespace) throws XMLStreamException {
        String prefix = xmlWriter.getPrefix(namespace);
        if (prefix == null) {
            String uri;
            prefix = CommandStub.JoinDomain.generatePrefix(namespace);
            NamespaceContext nsContext = xmlWriter.getNamespaceContext();
            while ((uri = nsContext.getNamespaceURI(prefix)) != null && uri.length() != 0) {
                prefix = BeanUtil.getUniquePrefix();
            }
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
        return prefix;
    }

    public XMLStreamReader getPullParser(QName qName) throws ADBException {
        ArrayList<Object> elementList = new ArrayList<Object>();
        ArrayList attribList = new ArrayList();
        if (this.localSdTracker) {
            elementList.add(new QName("http://tempuri.org/", "sd"));
            elementList.add(this.localSd == null ? null : ConverterUtil.convertToString((String)this.localSd));
        }
        if (this.localDomainNameTracker) {
            elementList.add(new QName("http://tempuri.org/", "domainName"));
            elementList.add(this.localDomainName == null ? null : ConverterUtil.convertToString((String)this.localDomainName));
        }
        if (this.localOrgUnitTracker) {
            elementList.add(new QName("http://tempuri.org/", "orgUnit"));
            elementList.add(this.localOrgUnit == null ? null : ConverterUtil.convertToString((String)this.localOrgUnit));
        }
        if (this.localAdminNameTracker) {
            elementList.add(new QName("http://tempuri.org/", "adminName"));
            elementList.add(this.localAdminName == null ? null : ConverterUtil.convertToString((String)this.localAdminName));
        }
        if (this.localPasswordTracker) {
            elementList.add(new QName("http://tempuri.org/", "password"));
            elementList.add(this.localPassword == null ? null : ConverterUtil.convertToString((String)this.localPassword));
        }
        if (this.localEnableFastRefreshTracker) {
            elementList.add(new QName("http://tempuri.org/", "enableFastRefresh"));
            elementList.add(ConverterUtil.convertToString((boolean)this.localEnableFastRefresh));
        }
        return new ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
    }

    public static class Factory {
        public static CommandStub.JoinDomain parse(XMLStreamReader reader) throws Exception {
            CommandStub.JoinDomain object = new CommandStub.JoinDomain();
            String nillableValue = null;
            String prefix = "";
            String namespaceuri = "";
            try {
                String content;
                String fullTypeName;
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null && (fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type")) != null) {
                    String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1) {
                        nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix == null ? "" : nsPrefix;
                    String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);
                    if (!"JoinDomain".equals(type)) {
                        String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                        return (CommandStub.JoinDomain)CommandStub.ExtensionMapper.getTypeObject(nsUri, type, reader);
                    }
                }
                Vector handledAttributes = new Vector();
                reader.next();
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "sd").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setSd(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "domainName").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setDomainName(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "orgUnit").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setOrgUnit(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "adminName").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setAdminName(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "password").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                        content = reader.getElementText();
                        object.setPassword(ConverterUtil.convertToString((String)content));
                    } else {
                        reader.getElementText();
                    }
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement() && new QName("http://tempuri.org/", "enableFastRefresh").equals(reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                    if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                        throw new ADBException("The element: enableFastRefresh  cannot be null");
                    }
                    content = reader.getElementText();
                    object.setEnableFastRefresh(ConverterUtil.convertToBoolean((String)content));
                    reader.next();
                }
                while (!reader.isStartElement() && !reader.isEndElement()) {
                    reader.next();
                }
                if (reader.isStartElement()) {
                    throw new ADBException("Unexpected subelement " + reader.getName());
                }
            }
            catch (XMLStreamException e) {
                throw new Exception(e);
            }
            return object;
        }
    }
}
