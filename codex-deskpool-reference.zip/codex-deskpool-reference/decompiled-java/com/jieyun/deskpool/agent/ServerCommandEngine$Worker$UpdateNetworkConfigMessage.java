/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.shared.NetworkConfigVO;

public static class ServerCommandEngine.Worker.UpdateNetworkConfigMessage
extends JYMessage {
    private NetworkConfigVO params;
    private IServerBean serverBean;

    public ServerCommandEngine.Worker.UpdateNetworkConfigMessage() {
    }

    public ServerCommandEngine.Worker.UpdateNetworkConfigMessage(NetworkConfigVO params, IServerBean serverBean) {
        this.params = params;
        this.serverBean = serverBean;
    }

    public NetworkConfigVO getParams() {
        return this.params;
    }

    public void setParams(NetworkConfigVO params) {
        this.params = params;
    }

    public IServerBean getServerBean() {
        return this.serverBean;
    }

    public void setServerBean(IServerBean serverBean) {
        this.serverBean = serverBean;
    }

    @Override
    public void onReceive() {
        this.serverBean.getNetworkConfig().reconfig(this.params.getType(), this.params.getIp(), this.params.isReboot());
    }
}
