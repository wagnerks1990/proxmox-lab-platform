/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.utils.Props;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AwakeningWatcher {
    private static final Logger logger = LoggerFactory.getLogger(AwakeningWatcher.class);
    private static long startTime = System.currentTimeMillis();
    private long last_awake = 0L;

    public boolean isAwakening() {
        boolean systemAwakening = false;
        long period = System.currentTimeMillis() - startTime;
        if (this.last_awake != 0L) {
            long wakupPeriod = Props.instance().get("server.wakeup.period", 120L);
            boolean bl = systemAwakening = period - this.last_awake > 1000L * wakupPeriod;
        }
        if (!systemAwakening) {
            this.last_awake = period;
        }
        if (systemAwakening) {
            logger.info("System is awakening ....");
        }
        return systemAwakening;
    }

    public void awaken() {
        this.last_awake = 0L;
    }
}
