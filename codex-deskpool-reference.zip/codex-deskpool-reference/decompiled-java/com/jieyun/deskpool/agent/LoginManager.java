/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.agent.PoolManager;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Deprecated
public class LoginManager
extends Agent.Impl {
    private static final Logger logger = LoggerFactory.getLogger(LoginManager.class);

    protected LoginManager(Event.Engine engine) {
        super(engine);
    }

    @Override
    public boolean receive(Event paramEvent) {
        return false;
    }

    public static boolean start(IInstanceBean instance, String computerIP, String username, String computername) {
        if (instance == null || StringUtils.isBlank((CharSequence)computerIP) || StringUtils.isBlank((CharSequence)username)) {
            logger.error("LoginManager failed to record instance:{} ip:{} user:{} computername:{}", new Object[]{instance, computerIP, username, computername});
            return false;
        }
        IAccountBean user = instance.getUser();
        if (user == null) {
            LoginManager.breach(instance);
            new TrackerService.Writer.Instance().login(instance, user).failure("error.desktop.connect.unassigned", new String[]{"$username", username, "$clientIP", ""});
            return false;
        }
        Props props = Props.instance();
        String userverify = props.get("policy.login.userverify", "false");
        if ("true".equalsIgnoreCase(userverify) && !username.equalsIgnoreCase(user.getName())) {
            LoginManager.breach(instance);
            new TrackerService.Writer.Instance().login(instance, user).failure("error.desktop.connect.user.wrong", new String[0]);
            return false;
        }
        instance = instance.getUpdate().setSessionActive(true).setVmParam("computername", computername).setLoginTime(new Date()).setIpaddress(computerIP).save();
        return true;
    }

    public static void breach(IInstanceBean instance) {
        Stopwatch timer = new Stopwatch("[LoginManager.breach(" + instance.toString() + ")]");
        try {
            instance.logoff();
        }
        finally {
            timer.stop();
        }
    }

    public static boolean end(IInstanceBean instance) {
        Stopwatch timer = new Stopwatch("[LoginManager.end(" + instance + ")]");
        try {
            if (instance == null) {
                logger.error("LoginManager.end given null instance");
                return false;
            }
            try {
                IAccountBean user = instance.getUser();
                String username = "";
                if (user != null) {
                    username = user.getName();
                }
                instance.terminate();
                new PoolManager.Message().send();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        finally {
            timer.stop();
        }
        return true;
    }

    private void timeout(IInstanceBean instance) {
    }
}
