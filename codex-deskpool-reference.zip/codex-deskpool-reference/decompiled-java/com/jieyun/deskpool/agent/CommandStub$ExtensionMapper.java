/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;

public static class CommandStub.ExtensionMapper {
    public static Object getTypeObject(String namespaceURI, String typeName, XMLStreamReader reader) throws Exception {
        if ("http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) && "guid".equals(typeName)) {
            return CommandStub.Guid.Factory.parse(reader);
        }
        if ("http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) && "duration".equals(typeName)) {
            return CommandStub.Duration.Factory.parse(reader);
        }
        if ("http://schemas.microsoft.com/2003/10/Serialization/".equals(namespaceURI) && "char".equals(typeName)) {
            return CommandStub._char.Factory.parse(reader);
        }
        if ("http://schemas.microsoft.com/Message".equals(namespaceURI) && "StreamBody".equals(typeName)) {
            return CommandStub.StreamBody.Factory.parse(reader);
        }
        if ("http://schemas.datacontract.org/2004/07/Citrix.VDI.Agent.Executer".equals(namespaceURI) && "PvdAction".equals(typeName)) {
            return CommandStub.PvdAction.Factory.parse(reader);
        }
        if ("http://schemas.datacontract.org/2004/07/Citrix.VDI.Inside.Support".equals(namespaceURI) && "CommandResult".equals(typeName)) {
            return CommandStub.CommandResult.Factory.parse(reader);
        }
        throw new ADBException("Unsupported type " + namespaceURI + " " + typeName);
    }
}
