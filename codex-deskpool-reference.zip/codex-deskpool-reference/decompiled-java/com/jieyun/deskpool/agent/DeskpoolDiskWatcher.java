/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.agent.utils.JYTimedEngine;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.TrackerService;
import com.jieyun.deskpool.utils.AppProps;
import com.jieyun.deskpool.utils.Script;
import com.jieyun.deskpool.vm.Event;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;

public class DeskpoolDiskWatcher
extends JYTimedEngine
implements ApplicationLifecycle.LifecycleListener {
    private static final Pattern pattern = Pattern.compile("(\\d+\\.*+\\d*)%");

    public DeskpoolDiskWatcher(String name, long seconds) {
        super(name, seconds);
        this.subscribe(JYMessage.class, new EventHandler());
    }

    @Override
    protected Event defaultEvent() {
        return new JYMessage(){

            @Override
            public void onReceive() {
            }
        };
    }

    @Override
    public void onStart() {
        this.start();
    }

    @Override
    public void onShutdown() {
        this.quit();
    }

    public class EventHandler
    implements Event.Recipient {
        @Override
        public boolean receive(Event paramEvent) {
            Matcher matcher;
            if (System.getProperty("os.name").contains("Windows")) {
                return true;
            }
            String cmd = "df";
            String result = Script.runSimpleBashRemoteScript(cmd, 1200);
            if (result != null && (matcher = pattern.matcher(result)).find()) {
                String usedCapStr = matcher.group(1);
                Double usedCap = Double.parseDouble(usedCapStr);
                String thresholdStr = AppProps.instance().get("deskpool.disk.capacity.warning.threshold");
                Double threshold = StringUtils.isBlank((String)thresholdStr) ? 60.0 : Double.parseDouble(thresholdStr);
                if (usedCap >= threshold) {
                    new TrackerService.Writer.Server().deskpoolDiskCapacityLow(ClusterNodeBean.instance().getLocalServer()).message("tracker.deskpool.disk.capacity.low.msg", new String[]{"$used", usedCapStr});
                }
            }
            return true;
        }
    }
}
