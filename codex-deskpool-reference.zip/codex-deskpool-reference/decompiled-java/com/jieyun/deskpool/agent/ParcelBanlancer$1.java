/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.ParcelBanlancer;
import com.jieyun.deskpool.vm.Event;

class ParcelBanlancer.1
extends Event.TimedEngine {
    ParcelBanlancer.1(String $anonymous0, long $anonymous1) {
        super($anonymous0, $anonymous1);
    }

    @Override
    protected Event defaultEvent() {
        return new ParcelBanlancer.Message();
    }
}
