/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.ConverterUtil
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.ConverterUtil;

public static class CommandStub.JoinWorkgroup.Factory {
    public static CommandStub.JoinWorkgroup parse(XMLStreamReader reader) throws Exception {
        CommandStub.JoinWorkgroup object = new CommandStub.JoinWorkgroup();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            String content;
            String fullTypeName;
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null && (fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type")) != null) {
                String nsPrefix = null;
                if (fullTypeName.indexOf(":") > -1) {
                    nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                }
                nsPrefix = nsPrefix == null ? "" : nsPrefix;
                String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);
                if (!"JoinWorkgroup".equals(type)) {
                    String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                    return (CommandStub.JoinWorkgroup)CommandStub.ExtensionMapper.getTypeObject(nsUri, type, reader);
                }
            }
            Vector handledAttributes = new Vector();
            reader.next();
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement() && new QName("http://tempuri.org/", "sd").equals(reader.getName())) {
                nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                    content = reader.getElementText();
                    object.setSd(ConverterUtil.convertToString((String)content));
                } else {
                    reader.getElementText();
                }
                reader.next();
            }
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement() && new QName("http://tempuri.org/", "workGroupName").equals(reader.getName())) {
                nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                if (!"true".equals(nillableValue) && !"1".equals(nillableValue)) {
                    content = reader.getElementText();
                    object.setWorkGroupName(ConverterUtil.convertToString((String)content));
                } else {
                    reader.getElementText();
                }
                reader.next();
            }
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement() && new QName("http://tempuri.org/", "enableFastRefresh").equals(reader.getName())) {
                nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                    throw new ADBException("The element: enableFastRefresh  cannot be null");
                }
                content = reader.getElementText();
                object.setEnableFastRefresh(ConverterUtil.convertToBoolean((String)content));
                reader.next();
            }
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            if (reader.isStartElement()) {
                throw new ADBException("Unexpected subelement " + reader.getName());
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
