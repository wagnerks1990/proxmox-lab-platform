/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.Store;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.Props;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.Stopwatch;
import com.jieyun.deskpool.vm.vmware.api.ServiceUtil;
import java.util.Calendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Heartbeat
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(Heartbeat.class);
    private static final String ENGINE_NAME = "Heartbeat";
    private static final int HEARTBEAT_TIME = 60;
    private static int CLEAR_INSTANCE_DAYS = 0;
    private static final long SINGLE_CONNECT_CHECKTIME = Props.instance().get("server.connection.single.checktime", 30);
    private static final boolean SINGLE_CONNECT = Props.instance().get("server.connection.single", true);
    public static volatile int stabilityCount = 0;
    private static long lastCheckTime = 0L;

    public Heartbeat() {
        this(new Event.TimedEngine(ENGINE_NAME, 60L){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    public Heartbeat(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable()) {
            return true;
        }
        this.tick();
        return false;
    }

    private void tick() {
        MasterCoordinator masterCoordinator;
        if (!StoreContext.enable()) {
            return;
        }
        if (this.isClearInstance() && (masterCoordinator = MasterCoordinator.instance()).isMasterLocal()) {
            logger.info("the account will clear LastInstance");
            Services.getAccountService().clearLastInstance();
        }
        if (this.checkNotReleasedConnection()) {
            for (String uuid : ServiceUtil.getReleaseMap().keySet()) {
                logger.info("the ServiceUtil[" + uuid + "]  not Released ! will Auto Released");
            }
        }
        if (StoreContext.isMergeScheduled()) {
            Stopwatch timer;
            block11: {
                logger.info("Heartbeat.tick: MergeScheduled={}", (Object)StoreContext.isMergeScheduled());
                if (stabilityCount++ <= 1) {
                    return;
                }
                timer = new Stopwatch("Heartbeat.tick()");
                timer.record("isMasterLocal\uff1a" + MasterCoordinator.instance().isMasterLocal());
                if (!MasterCoordinator.instance().isMasterLocal() && StoreContext.isMinorityNode()) break block11;
                StoreContext.setMergedFlag(false);
                timer.stop();
                return;
            }
            try {
                try {
                    timer.record("Store.resetFederation start");
                    Store.resetFederation();
                    timer.record("Store.resetFederation end");
                }
                catch (Exception e) {
                    timer.record(e.toString());
                    StoreContext.setMergedFlag(false);
                    timer.stop();
                }
            }
            catch (Throwable throwable) {
                StoreContext.setMergedFlag(false);
                timer.stop();
                throw throwable;
            }
            StoreContext.setMergedFlag(false);
            timer.stop();
        }
        stabilityCount = 0;
    }

    private boolean isClearInstance() {
        int clearHours = Props.instance().get("server.clearInstance.hours", 23);
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(5);
        if (day != CLEAR_INSTANCE_DAYS && calendar.get(11) == clearHours) {
            CLEAR_INSTANCE_DAYS = day;
            return true;
        }
        return false;
    }

    public boolean checkNotReleasedConnection() {
        if (SINGLE_CONNECT && System.currentTimeMillis() > lastCheckTime + SINGLE_CONNECT_CHECKTIME * 1000L * 60L) {
            lastCheckTime = System.currentTimeMillis();
            return true;
        }
        return false;
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
