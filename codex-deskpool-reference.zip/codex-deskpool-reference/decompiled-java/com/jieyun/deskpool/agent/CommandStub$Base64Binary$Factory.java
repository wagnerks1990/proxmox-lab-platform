/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axiom.util.stax.XMLStreamReaderUtils
 *  org.apache.axis2.databinding.ADBException
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axiom.util.stax.XMLStreamReaderUtils;
import org.apache.axis2.databinding.ADBException;

public static class CommandStub.Base64Binary.Factory {
    public static CommandStub.Base64Binary parse(XMLStreamReader reader) throws Exception {
        CommandStub.Base64Binary object = new CommandStub.Base64Binary();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
            if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                while (!reader.isEndElement()) {
                    reader.next();
                }
                return object;
            }
            Vector handledAttributes = new Vector();
            while (!reader.isEndElement()) {
                if (reader.isStartElement()) {
                    if (reader.isStartElement() && new QName("http://schemas.microsoft.com/2003/10/Serialization/", "base64Binary").equals(reader.getName())) {
                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                            object.setBase64Binary(null);
                            reader.next();
                            continue;
                        }
                        object.setBase64Binary(XMLStreamReaderUtils.getDataHandlerFromElement((XMLStreamReader)reader));
                        continue;
                    }
                    throw new ADBException("Unexpected subelement " + reader.getName());
                }
                reader.next();
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
