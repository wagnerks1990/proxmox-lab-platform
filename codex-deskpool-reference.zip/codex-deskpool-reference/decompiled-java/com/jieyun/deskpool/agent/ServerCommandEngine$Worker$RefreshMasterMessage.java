/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.utils.JYMessage;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.distributed.model.MasterCoordinator;
import com.jieyun.deskpool.service.Services;
import java.util.List;

public static class ServerCommandEngine.Worker.RefreshMasterMessage
extends JYMessage {
    @Override
    public void onReceive() {
        MasterCoordinator masterCoordinator = MasterCoordinator.instance();
        if (masterCoordinator.isMasterLocal()) {
            IServerBean currentServer = Services.getServerService().getCurrent();
            if (!currentServer.isMaster()) {
                logger.info("masterAddress:{}", masterCoordinator.getMasterIpAddress());
                currentServer.setMaster(true);
                currentServer.save();
            }
            List servers = Services.getServerService().findAll();
            for (IServerBean server : servers) {
                if (server.Id().equals(currentServer.Id()) || !server.isMaster()) continue;
                server.setMaster(false);
                server.save();
            }
        }
    }
}
