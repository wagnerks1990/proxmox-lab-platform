/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.bean.IInstanceBean;
import java.util.Comparator;

class PoolManager.2
implements Comparator<IInstanceBean> {
    PoolManager.2() {
    }

    @Override
    public int compare(IInstanceBean o1, IInstanceBean o2) {
        String o1Value = o1.getName();
        String o2Value = o2.getName();
        if (o1Value == null && o2Value == null) {
            return 0;
        }
        if (o1Value == null && o2Value != null) {
            return -1;
        }
        if (o1Value != null && o2Value == null) {
            return 1;
        }
        return -o1Value.compareTo(o2Value);
    }
}
