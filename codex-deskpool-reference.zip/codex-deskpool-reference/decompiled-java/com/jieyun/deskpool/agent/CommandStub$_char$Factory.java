/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.axis2.databinding.ADBException
 *  org.apache.axis2.databinding.utils.ConverterUtil
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.CommandStub;
import java.util.Vector;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.axis2.databinding.ADBException;
import org.apache.axis2.databinding.utils.ConverterUtil;

public static class CommandStub._char.Factory {
    public static CommandStub._char fromString(String value, String namespaceURI) {
        CommandStub._char returnValue = new CommandStub._char();
        returnValue.set_char(ConverterUtil.convertToInt((String)value));
        return returnValue;
    }

    public static CommandStub._char fromString(XMLStreamReader xmlStreamReader, String content) {
        if (content.indexOf(":") > -1) {
            String prefix = content.substring(0, content.indexOf(":"));
            String namespaceUri = xmlStreamReader.getNamespaceContext().getNamespaceURI(prefix);
            return CommandStub._char.Factory.fromString(content, namespaceUri);
        }
        return CommandStub._char.Factory.fromString(content, "");
    }

    public static CommandStub._char parse(XMLStreamReader reader) throws Exception {
        CommandStub._char object = new CommandStub._char();
        String nillableValue = null;
        String prefix = "";
        String namespaceuri = "";
        try {
            while (!reader.isStartElement() && !reader.isEndElement()) {
                reader.next();
            }
            Vector handledAttributes = new Vector();
            while (!reader.isEndElement()) {
                if (reader.isStartElement() || reader.hasText()) {
                    if (reader.isStartElement() || reader.hasText()) {
                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue)) {
                            throw new ADBException("The element: char  cannot be null");
                        }
                        String content = reader.getElementText();
                        object.set_char(ConverterUtil.convertToInt((String)content));
                        continue;
                    }
                    throw new ADBException("Unexpected subelement " + reader.getName());
                }
                reader.next();
            }
        }
        catch (XMLStreamException e) {
            throw new Exception(e);
        }
        return object;
    }
}
