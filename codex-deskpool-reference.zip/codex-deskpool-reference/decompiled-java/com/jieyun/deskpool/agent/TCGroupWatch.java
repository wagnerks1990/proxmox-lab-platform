/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.Agent;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.ITCGroupBean;
import com.jieyun.deskpool.service.ApplicationLifecycle;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.store.StoreContext;
import com.jieyun.deskpool.utils.MasccanUtils;
import com.jieyun.deskpool.vm.Event;
import com.jieyun.deskpool.vm.manager.TCGroupManagerImpl;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TCGroupWatch
extends Agent.Impl
implements ApplicationLifecycle.LifecycleListener {
    private static final Logger logger = LoggerFactory.getLogger(TCGroupWatch.class);
    private static final String TC_GROUP_WATCH_NAME = "tcGroupWatch";
    private static final int TC_GROUP_WATCH_TIME = 5;
    private static boolean isBusy = false;

    public TCGroupWatch() {
        this(new Event.TimedEngine(TC_GROUP_WATCH_NAME, 5L){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    public TCGroupWatch(Event.Engine engine, boolean asDaemon) {
        super(engine);
        if (asDaemon) {
            this.subscribe(Message.class);
            Message.engineName = engine.getName();
        }
    }

    public TCGroupWatch(Event.Engine engine) {
        this(new Event.TimedEngine(TC_GROUP_WATCH_NAME, 5L){

            @Override
            protected Event defaultEvent() {
                return new Message();
            }
        }, true);
    }

    @Override
    public void onStart() {
        this.engine.start();
    }

    @Override
    public void onShutdown() {
        this.engine.quit();
    }

    @Override
    public boolean receive(Event paramEvent) {
        if (!StoreContext.enable() || isBusy) {
            return true;
        }
        this.tick();
        return false;
    }

    private void tick() {
        isBusy = true;
        try {
            TCGroupManagerImpl tcGroupMgr = new TCGroupManagerImpl();
            if (tcGroupMgr.isBusy()) {
                for (ITCGroupBean tcGroupBean : Services.getTcGroupService().findAll()) {
                    if (!tcGroupBean.enableMonitoring()) continue;
                    tcGroupBean.sysncStatus();
                }
                return;
            }
            IServerBean server = Services.getServerService().getCurrent();
            if (server == null || !server.isMaster()) {
                return;
            }
            List<String> createConnectIpList = null;
            for (ITCGroupBean tcGroupBean : Services.getTcGroupService().findAll()) {
                if (!tcGroupBean.enableMonitoring()) continue;
                if (MasccanUtils.masscanFlag()) {
                    createConnectIpList = tcGroupBean.getAllOnLineIp();
                    tcGroupBean.sysncStatus(createConnectIpList);
                } else {
                    createConnectIpList = tcGroupBean.getAllIp();
                }
                tcGroupMgr.createConnect(tcGroupBean, createConnectIpList);
            }
        }
        finally {
            isBusy = false;
        }
    }

    public static class Message
    extends Agent.Message {
        private static String engineName = null;
        private boolean refreshHost;

        public Message() {
            this.refreshHost = false;
        }

        public boolean isRefreshHost() {
            return this.refreshHost;
        }

        public void setRefreshHost(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public Message(boolean refreshHost) {
            this.refreshHost = refreshHost;
        }

        public void send() {
            this.send(Event.Router.lookup(engineName));
        }

        static /* synthetic */ String access$0() {
            return engineName;
        }
    }
}
