/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.agent;

import com.jieyun.deskpool.agent.ServerCommandEngine;
import java.util.List;

class ServerCommandEngine.Worker.CreateClusterMessage.1
extends ServerCommandEngine.Worker.CreateClusterMessage.Response {
    ServerCommandEngine.Worker.CreateClusterMessage.1(List $anonymous0) {
        super($anonymous0);
    }
}
