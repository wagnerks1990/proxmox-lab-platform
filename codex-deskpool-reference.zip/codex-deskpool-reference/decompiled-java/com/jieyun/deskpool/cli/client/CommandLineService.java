/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.rpc.Service
 *  javax.xml.rpc.ServiceException
 */
package com.jieyun.deskpool.cli.client;

import com.jieyun.deskpool.cli.client.CommandLineServicePortType;
import java.net.URL;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface CommandLineService
extends Service {
    public String getCommandLineServiceHttpSoap11EndpointAddress();

    public CommandLineServicePortType getCommandLineServiceHttpSoap11Endpoint() throws ServiceException;

    public CommandLineServicePortType getCommandLineServiceHttpSoap11Endpoint(URL var1) throws ServiceException;
}
