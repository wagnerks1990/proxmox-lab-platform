/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cli.client;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CommandLineServicePortType
extends Remote {
    public String version() throws RemoteException;

    public String execute(String var1, String[] var2) throws RemoteException;

    public String api(String var1, String var2, String var3, String var4, String var5) throws RemoteException;
}
