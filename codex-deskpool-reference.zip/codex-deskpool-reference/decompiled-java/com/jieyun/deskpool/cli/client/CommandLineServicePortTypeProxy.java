/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.rpc.ServiceException
 *  javax.xml.rpc.Stub
 */
package com.jieyun.deskpool.cli.client;

import com.jieyun.deskpool.cli.client.CommandLineServiceLocator;
import com.jieyun.deskpool.cli.client.CommandLineServicePortType;
import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.Stub;

public class CommandLineServicePortTypeProxy
implements CommandLineServicePortType {
    private String _endpoint = null;
    private CommandLineServicePortType commandLineServicePortType = null;

    public CommandLineServicePortTypeProxy() {
        this._initCommandLineServicePortTypeProxy();
    }

    public CommandLineServicePortTypeProxy(String endpoint) {
        this._endpoint = endpoint;
        this._initCommandLineServicePortTypeProxy();
    }

    private void _initCommandLineServicePortTypeProxy() {
        try {
            this.commandLineServicePortType = new CommandLineServiceLocator().getCommandLineServiceHttpSoap11Endpoint();
            if (this.commandLineServicePortType != null) {
                if (this._endpoint != null) {
                    ((Stub)this.commandLineServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", (Object)this._endpoint);
                } else {
                    this._endpoint = (String)((Stub)this.commandLineServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
                }
            }
        }
        catch (ServiceException serviceException) {
            // empty catch block
        }
    }

    public String getEndpoint() {
        return this._endpoint;
    }

    public void setEndpoint(String endpoint) {
        this._endpoint = endpoint;
        if (this.commandLineServicePortType != null) {
            ((Stub)this.commandLineServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", (Object)this._endpoint);
        }
    }

    public CommandLineServicePortType getCommandLineServicePortType() {
        if (this.commandLineServicePortType == null) {
            this._initCommandLineServicePortTypeProxy();
        }
        return this.commandLineServicePortType;
    }

    @Override
    public String version() throws RemoteException {
        if (this.commandLineServicePortType == null) {
            this._initCommandLineServicePortTypeProxy();
        }
        return this.commandLineServicePortType.version();
    }

    @Override
    public String execute(String sd, String[] args) throws RemoteException {
        if (this.commandLineServicePortType == null) {
            this._initCommandLineServicePortTypeProxy();
        }
        return this.commandLineServicePortType.execute(sd, args);
    }

    @Override
    public String api(String sd, String operation, String entity, String para1, String para2) throws RemoteException {
        if (this.commandLineServicePortType == null) {
            this._initCommandLineServicePortTypeProxy();
        }
        return this.commandLineServicePortType.api(sd, operation, entity, para1, para2);
    }
}
