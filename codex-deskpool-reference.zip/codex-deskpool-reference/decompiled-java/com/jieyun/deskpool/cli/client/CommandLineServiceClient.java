/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cli.client;

import com.jieyun.deskpool.cli.client.ClientUtils;
import com.jieyun.deskpool.cli.client.CommandLineServiceLocator;
import com.jieyun.deskpool.cli.client.CommandLineServicePortType;
import java.net.URL;

public class CommandLineServiceClient {
    CommandLineServicePortType cmdLineService = null;
    String deskpoolAddress = "";

    public CommandLineServiceClient(String ipAddress) {
        this.deskpoolAddress = ipAddress;
    }

    public static CommandLineServiceClient newInstance(String ipAddress) {
        CommandLineServiceClient instance = new CommandLineServiceClient(ipAddress);
        if (!instance.createPort()) {
            instance = null;
        }
        return instance;
    }

    private boolean createPort() {
        CommandLineServiceLocator cmdLineLocator = new CommandLineServiceLocator();
        try {
            String endpointPrefix = "http://" + this.deskpoolAddress + ":" + this.getcmdLineServicePort();
            URL serviceUrl = new URL(String.valueOf(endpointPrefix) + "/axis2/services/CommandLineService");
            this.cmdLineService = cmdLineLocator.getCommandLineServiceHttpSoap11Endpoint(serviceUrl);
        }
        catch (Exception ex) {
            ClientUtils.info(ex.getMessage());
        }
        return this.cmdLineService != null;
    }

    private int getcmdLineServicePort() {
        return 8016;
    }

    public String execute(String[] args) {
        String result = "";
        try {
            String[] stringArray = args;
            int n = args.length;
            int n2 = 0;
            while (n2 < n) {
                String item = stringArray[n2];
                ClientUtils.info(" vdi args " + item);
                ++n2;
            }
            result = this.cmdLineService.execute("", args);
        }
        catch (Exception ex) {
            ClientUtils.info(ex.getMessage());
        }
        return result;
    }

    public static void main(String[] args) {
        CommandLineServiceClient client = CommandLineServiceClient.newInstance("192.168.1.94");
        System.out.println(client.execute(new String[]{"-c", "host_address=192.168.1.8", "-c", "host_user=administrator"}));
    }
}
