/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.rpc.ServiceException
 *  org.apache.axis.AxisFault
 *  org.apache.axis.EngineConfiguration
 *  org.apache.axis.client.Service
 *  org.apache.axis.client.Stub
 */
package com.jieyun.deskpool.cli.client;

import com.jieyun.deskpool.cli.client.CommandLineService;
import com.jieyun.deskpool.cli.client.CommandLineServicePortType;
import com.jieyun.deskpool.cli.client.CommandLineServiceSoap11BindingStub;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.Remote;
import java.util.HashSet;
import java.util.Iterator;
import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import org.apache.axis.AxisFault;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.client.Service;
import org.apache.axis.client.Stub;

public class CommandLineServiceLocator
extends Service
implements CommandLineService {
    private String CommandLineServiceHttpSoap11Endpoint_address = "http://192.168.1.165:8016/axis2/services/CommandLineService.CommandLineServiceHttpSoap11Endpoint/";
    private String CommandLineServiceHttpSoap11EndpointWSDDServiceName = "CommandLineServiceHttpSoap11Endpoint";
    private HashSet ports = null;

    public CommandLineServiceLocator() {
    }

    public CommandLineServiceLocator(EngineConfiguration config) {
        super(config);
    }

    public CommandLineServiceLocator(String wsdlLoc, QName sName) throws ServiceException {
        super(wsdlLoc, sName);
    }

    @Override
    public String getCommandLineServiceHttpSoap11EndpointAddress() {
        return this.CommandLineServiceHttpSoap11Endpoint_address;
    }

    public String getCommandLineServiceHttpSoap11EndpointWSDDServiceName() {
        return this.CommandLineServiceHttpSoap11EndpointWSDDServiceName;
    }

    public void setCommandLineServiceHttpSoap11EndpointWSDDServiceName(String name) {
        this.CommandLineServiceHttpSoap11EndpointWSDDServiceName = name;
    }

    @Override
    public CommandLineServicePortType getCommandLineServiceHttpSoap11Endpoint() throws ServiceException {
        URL endpoint;
        try {
            endpoint = new URL(this.CommandLineServiceHttpSoap11Endpoint_address);
        }
        catch (MalformedURLException e) {
            throw new ServiceException((Throwable)e);
        }
        return this.getCommandLineServiceHttpSoap11Endpoint(endpoint);
    }

    @Override
    public CommandLineServicePortType getCommandLineServiceHttpSoap11Endpoint(URL portAddress) throws ServiceException {
        try {
            CommandLineServiceSoap11BindingStub _stub = new CommandLineServiceSoap11BindingStub(portAddress, this);
            _stub.setPortName(this.getCommandLineServiceHttpSoap11EndpointWSDDServiceName());
            return _stub;
        }
        catch (AxisFault e) {
            return null;
        }
    }

    public void setCommandLineServiceHttpSoap11EndpointEndpointAddress(String address) {
        this.CommandLineServiceHttpSoap11Endpoint_address = address;
    }

    public Remote getPort(Class serviceEndpointInterface) throws ServiceException {
        try {
            if (CommandLineServicePortType.class.isAssignableFrom(serviceEndpointInterface)) {
                CommandLineServiceSoap11BindingStub _stub = new CommandLineServiceSoap11BindingStub(new URL(this.CommandLineServiceHttpSoap11Endpoint_address), this);
                _stub.setPortName(this.getCommandLineServiceHttpSoap11EndpointWSDDServiceName());
                return _stub;
            }
        }
        catch (Throwable t) {
            throw new ServiceException(t);
        }
        throw new ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    public Remote getPort(QName portName, Class serviceEndpointInterface) throws ServiceException {
        if (portName == null) {
            return this.getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("CommandLineServiceHttpSoap11Endpoint".equals(inputPortName)) {
            return this.getCommandLineServiceHttpSoap11Endpoint();
        }
        Remote _stub = this.getPort(serviceEndpointInterface);
        ((Stub)_stub).setPortName(portName);
        return _stub;
    }

    public QName getServiceName() {
        return new QName("http://client.cli.deskpool.jieyun.com", "CommandLineService");
    }

    public Iterator getPorts() {
        if (this.ports == null) {
            this.ports = new HashSet();
            this.ports.add(new QName("http://client.cli.deskpool.jieyun.com", "CommandLineServiceHttpSoap11Endpoint"));
        }
        return this.ports.iterator();
    }

    public void setEndpointAddress(String portName, String address) throws ServiceException {
        if (!"CommandLineServiceHttpSoap11Endpoint".equals(portName)) {
            throw new ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
        this.setCommandLineServiceHttpSoap11EndpointEndpointAddress(address);
    }

    public void setEndpointAddress(QName portName, String address) throws ServiceException {
        this.setEndpointAddress(portName.getLocalPart(), address);
    }
}
