/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.cli.client;

import com.jieyun.deskpool.cli.client.ClientUtils;
import com.jieyun.deskpool.cli.client.CommandLineServiceClient;
import org.apache.commons.lang3.StringUtils;

public class CommandLineClient {
    public static void main(String[] args) {
        String hostip = ClientUtils.getHostIP();
        if (ClientUtils.getPlatform().contains("win")) {
            hostip = "192.168.1.126";
        }
        if (!StringUtils.isBlank((CharSequence)hostip)) {
            CommandLineServiceClient client = CommandLineServiceClient.newInstance(hostip);
            System.out.println(client.execute(args));
        } else {
            System.out.println("Can't get host ip");
        }
        System.exit(0);
    }
}
