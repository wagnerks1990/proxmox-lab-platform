/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cli.client;

import com.jieyun.deskpool.utils.Script;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

public class ClientUtils {
    public static String platform = "win";

    public static void info(String msg) {
        System.out.println(msg);
    }

    public static String getSubstr(String src, String prefix) {
        String result = null;
        try {
            int start = src.indexOf(prefix) + prefix.length();
            int end = src.indexOf(" ", start + 1);
            result = src.substring(start, end);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return result;
    }

    public static String getPlatform() {
        String osname = System.getProperty("os.name");
        if (osname.contains("Linux") || osname.contains("linux")) {
            platform = "linux";
        }
        return platform;
    }

    public static String getHostIP() {
        String hostip = null;
        ClientUtils.getPlatform();
        if (platform.contains("win")) {
            try {
                InetAddress[] inet = InetAddress.getAllByName(null);
                InetAddress addr = InetAddress.getLocalHost();
                hostip = addr.toString();
                int index = hostip.indexOf(47);
                if (index > 0) {
                    hostip = hostip.substring(index + 1, hostip.length());
                }
            }
            catch (Exception inet) {}
        } else if (platform.contains("nux")) {
            try {
                NetworkInterface ni = NetworkInterface.getByName("eth0");
                Enumeration<InetAddress> inetAddresses = ni.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress ia = inetAddresses.nextElement();
                    if (ia.isLinkLocalAddress()) continue;
                    hostip = ia.getHostAddress();
                }
            }
            catch (SocketException e) {
                e.printStackTrace();
            }
        } else {
            try {
                String ifconfigCmd = "/sbin/ifconfig eth0";
                String ifconfig = Script.runSimpleBashScript(ifconfigCmd, 200);
                if (ifconfig != null && !ifconfig.isEmpty()) {
                    hostip = ClientUtils.getSubstr(ifconfig, "inet addr:");
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return hostip;
    }

    public static void main(String[] args) {
        System.out.println("System : " + System.getProperty("os.name"));
        System.out.println("args count " + args.length);
        if (args.length > 0) {
            System.out.println(" args1 " + args[0]);
        }
    }
}
