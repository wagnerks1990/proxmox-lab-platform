/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.cli.Option
 */
package com.jieyun.deskpool.cli.server;

import com.jieyun.deskpool.cli.server.ICommand;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.cli.Option;

public abstract class CommandBase
implements ICommand {
    private String cmd;
    private List<Option> options = new ArrayList<Option>();

    public CommandBase(String cmd) {
        this.cmd = cmd;
    }

    @Override
    public String getCmd() {
        return this.cmd;
    }

    @Override
    public List<Option> getOptions() {
        return this.options;
    }

    public void addOption(Option option) {
        this.options.add(option);
    }
}
