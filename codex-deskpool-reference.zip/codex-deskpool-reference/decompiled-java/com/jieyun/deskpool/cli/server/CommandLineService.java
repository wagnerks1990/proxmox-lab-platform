/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cli.server;

public interface CommandLineService {
    public String execute(String var1, String[] var2);

    public String api(String var1, String var2, String var3, String var4, String var5);

    public String version();

    public String login(String var1, String var2);

    public void logoff(String var1);
}
