/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.cli.server;

import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.GroupActionApi;
import com.jieyun.deskpool.api.GroupApi;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.ImageApi;
import com.jieyun.deskpool.api.InstanceActionApi;
import com.jieyun.deskpool.api.InstanceApi;
import com.jieyun.deskpool.api.PoolActionApi;
import com.jieyun.deskpool.api.PoolApi;
import com.jieyun.deskpool.api.ServerActionApi;
import com.jieyun.deskpool.api.ServerApi;
import com.jieyun.deskpool.api.SessionApi;
import com.jieyun.deskpool.api.UserApi;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.cli.server.CommandLineService;
import com.jieyun.deskpool.cli.server.CommandParse;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.utils.SpringUtils;
import javax.jws.WebService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebService(endpointInterface="com.jieyun.deskpool.cli.client", serviceName="CommandLineService", portName="CommandLineServicePort", targetNamespace="http://client.cli.deskpool.jieyun.com")
public class CommandLineServiceImpl
implements CommandLineService {
    private static final Logger logger = LoggerFactory.getLogger(CommandLineServiceImpl.class);
    private static final String version = "1.0";

    @Override
    public String execute(String sd, String[] args) {
        CommandParse cmdParse = CommandParse.getInstance();
        return cmdParse.parse(args);
    }

    @Override
    public String api(String sd, String operation, String entity, String para1, String para2) {
        IApiCall api;
        if ("image".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(ImageApi.class);
        } else if ("server".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(ServerApi.class);
        } else if ("serverAction".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(ServerActionApi.class);
        } else if ("session".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(SessionApi.class);
        } else if ("user".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(UserApi.class);
        } else if ("pool".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(PoolApi.class);
        } else if ("poolAction".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(PoolActionApi.class);
        } else if ("group".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(GroupApi.class);
        } else if ("groupAction".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(GroupActionApi.class);
        } else if ("instance".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(InstanceApi.class);
        } else if ("instanceAction".equalsIgnoreCase(entity)) {
            api = (IApiCall)SpringUtils.context.getBean(InstanceActionApi.class);
        } else {
            return new ApiResult().fail(ApiError.UNKNOW_ENTITY).toJson();
        }
        IAccountBean user = Services.getAccountService().checkCredential(sd);
        if (user == null || !user.checkACL(operation, entity, para1, para2)) {
            return new ApiResult().fail(ApiError.UNAUTHORIZED_OPERATION).toJson();
        }
        if ("get".equals(operation)) {
            return api.get(para1);
        }
        if ("create".equals(operation)) {
            return api.create(para1, para2);
        }
        if ("put".equals(operation)) {
            return api.put(para1, para2);
        }
        if ("delete".equals(operation)) {
            return api.delete(para1);
        }
        if ("list".equals(operation)) {
            return api.list(para1);
        }
        return null;
    }

    @Override
    public String version() {
        return version;
    }

    @Override
    public String login(String user, String password) {
        return Services.getAccountService().login(user, password);
    }

    @Override
    public void logoff(String sd) {
        Services.getAccountService().logoff(sd);
    }
}
