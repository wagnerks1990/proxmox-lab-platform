/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jieyun.deskpool.cache;

import com.jieyun.deskpool.cache.DeskpoolCache;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InstanceNameCacheManager {
    private static ConcurrentMap<String, DeskpoolCache> cacheMap = new ConcurrentHashMap<String, DeskpoolCache>();
    private static final Logger log = LoggerFactory.getLogger(InstanceNameCacheManager.class);
    private static final long DEFUALT_VALIDITY_TIME = 5000L;

    static {
        new Thread(new TimeoutTimerThread()).start();
    }

    public static synchronized void putCache(String instanceName) {
        DeskpoolCache cache = new DeskpoolCache();
        cache.setKey(instanceName);
        cache.setValue(instanceName);
        cache.setCreateTime(System.currentTimeMillis());
        cache.setExpired(false);
        cacheMap.put(instanceName, cache);
        log.info("Put.Cache={}", (Object)instanceName);
    }

    public static synchronized boolean hasCacheCheckTime(String instanceName) {
        DeskpoolCache cache;
        if (cacheMap.containsKey(instanceName) && (cache = (DeskpoolCache)cacheMap.get(instanceName)) != null) {
            return Math.abs(System.currentTimeMillis() - cache.getCreateTime()) < 5000L;
        }
        return false;
    }

    public static synchronized boolean hasCache(String instanceName) {
        return cacheMap.containsKey(instanceName);
    }

    private static synchronized List<DeskpoolCache> getList() {
        ArrayList<DeskpoolCache> list = new ArrayList<DeskpoolCache>();
        for (DeskpoolCache cache : cacheMap.values()) {
            list.add(cache);
        }
        return list;
    }

    public static synchronized void removeCache(String key) {
        cacheMap.remove(key);
    }

    static class TimeoutTimerThread
    implements Runnable {
        TimeoutTimerThread() {
        }

        @Override
        public void run() {
            while (true) {
                try {
                    while (true) {
                        this.clearInvalidCache();
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }
                break;
            }
        }

        private void clearInvalidCache() throws InterruptedException {
            for (DeskpoolCache cache : InstanceNameCacheManager.getList()) {
                if (Math.abs(System.currentTimeMillis() - cache.getCreateTime()) < 5000L) continue;
                log.error("\u5f00\u59cb\u6e05\u9664:cacheName={}", (Object)cache.getKey());
                cacheMap.remove(cache.getKey());
            }
            Thread.sleep(300000L);
        }
    }
}
