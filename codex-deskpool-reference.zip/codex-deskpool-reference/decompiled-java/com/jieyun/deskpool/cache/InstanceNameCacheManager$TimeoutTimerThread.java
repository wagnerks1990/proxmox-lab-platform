/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cache;

import com.jieyun.deskpool.cache.DeskpoolCache;
import com.jieyun.deskpool.cache.InstanceNameCacheManager;

static class InstanceNameCacheManager.TimeoutTimerThread
implements Runnable {
    InstanceNameCacheManager.TimeoutTimerThread() {
    }

    @Override
    public void run() {
        while (true) {
            try {
                while (true) {
                    this.clearInvalidCache();
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                continue;
            }
            break;
        }
    }

    private void clearInvalidCache() throws InterruptedException {
        for (DeskpoolCache cache : InstanceNameCacheManager.getList()) {
            if (Math.abs(System.currentTimeMillis() - cache.getCreateTime()) < 5000L) continue;
            log.error("\u5f00\u59cb\u6e05\u9664:cacheName={}", (Object)cache.getKey());
            cacheMap.remove(cache.getKey());
        }
        Thread.sleep(300000L);
    }
}
