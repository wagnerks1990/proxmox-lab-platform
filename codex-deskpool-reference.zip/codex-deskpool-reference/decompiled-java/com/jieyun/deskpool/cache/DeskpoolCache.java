/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cache;

import java.io.Serializable;

public class DeskpoolCache
implements Serializable {
    private static final long serialVersionUID = 1L;
    private String key;
    private Object value;
    private long createTime;
    private boolean expired;

    public DeskpoolCache() {
    }

    public DeskpoolCache(String key, Object value, long createTime, boolean expired) {
        this.key = key;
        this.value = value;
        this.createTime = createTime;
        this.expired = expired;
    }

    public String getKey() {
        return this.key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Object getValue() {
        return this.value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public long getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public boolean isExpired() {
        return this.expired;
    }

    public void setExpired(boolean expired) {
        this.expired = expired;
    }
}
