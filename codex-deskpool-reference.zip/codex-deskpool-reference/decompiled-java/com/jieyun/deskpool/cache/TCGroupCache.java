/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.cache;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class TCGroupCache {
    private static ConcurrentMap<String, Long> tcCache = new ConcurrentHashMap<String, Long>();
}
