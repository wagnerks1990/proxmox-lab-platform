/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.cache;

import com.jieyun.deskpool.utils.NetUtils;
import com.jieyun.deskpool.utils.Props;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.apache.commons.lang3.StringUtils;

public class DeskPoolCacheManager {
    public static String SERVER_IP = NetUtils.getHostIP();
    public static final long SEND_QUEUE_VALID_TIME = Props.instance().get("send.data.queue.valid.time", 300000);
    public static ConcurrentMap<String, Long> agentSendData = new ConcurrentHashMap<String, Long>();

    public static String getServerIp() {
        return SERVER_IP;
    }

    public static void setServerIp(String serverIP) {
        if (!StringUtils.equals((CharSequence)SERVER_IP, (CharSequence)serverIP)) {
            SERVER_IP = serverIP;
        }
    }

    public static void putAgentData(String instanceId) {
        agentSendData.put(instanceId, System.currentTimeMillis());
    }

    public static boolean containsAgentData(String instanceId) {
        return agentSendData.containsKey(instanceId);
    }

    public static void removeAgentData(String instanceId) {
        agentSendData.remove(instanceId);
    }

    public static void clearValidata() {
        long now = System.currentTimeMillis();
        for (Map.Entry entry : agentSendData.entrySet()) {
            if (Math.abs(now - (Long)entry.getValue()) < SEND_QUEUE_VALID_TIME) continue;
            agentSendData.remove(entry);
        }
    }
}
