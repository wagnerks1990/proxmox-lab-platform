/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.InstanceEntity;
import com.jieyun.deskpool.api.data.InstanceEntityBinding;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.domain.Instance;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="instanceApi")
public class InstanceApi
extends ApiCallBase<InstanceEntity>
implements IApiCall {
    @Autowired
    InstanceEntityBinding instanceEntityBinding;

    @Override
    public ApiResult<InstanceEntity> getImpl(Id id) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        IInstanceBean bean = (IInstanceBean)Services.getInstanceService().findOne(id);
        if (bean != null) {
            return bean.apiGet();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> putImpl(Id id, String json) {
        ApiResult<InstanceEntity> result = new ApiResult();
        InstanceEntity entity = (InstanceEntity)this.instanceEntityBinding.bindingForEntity(json);
        try {
            IInstanceBean bean = (IInstanceBean)Services.getInstanceService().findOne(Id.construct(entity.getId()));
            if (bean != null) {
                result = bean.apiPut(entity);
            } else {
                result.fail(ApiError.INVALID_OBJECT);
            }
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> deleteImpl(Id id) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        IInstanceBean bean = (IInstanceBean)Services.getInstanceService().findOne(id);
        if (bean != null) {
            return bean.apiDelete();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> createImpl(Id id, String json) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> listImpl(String condition) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        List instancelist = this.instanceEntityBinding.bindingForEntityList(Services.getInstanceService().find(new DpSpec().byClass(Instance.class).sortBy("name", "ASC").condition(condition)));
        result.setList(instancelist);
        return result;
    }
}
