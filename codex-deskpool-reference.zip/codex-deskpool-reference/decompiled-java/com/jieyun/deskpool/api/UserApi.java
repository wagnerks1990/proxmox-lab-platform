/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.UserEntity;
import com.jieyun.deskpool.api.data.UserEntityBinding;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.domain.Account;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="userApi")
public class UserApi
extends ApiCallBase<UserEntity>
implements IApiCall {
    @Autowired
    UserEntityBinding userEntityBinding;

    @Override
    public ApiResult<UserEntity> getImpl(Id id) {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        IAccountBean template = (IAccountBean)Services.getAccountService().findOne(id);
        if (template != null) {
            return template.apiGet();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<UserEntity> putImpl(Id id, String json) {
        ApiResult<UserEntity> result = new ApiResult();
        UserEntity entity = (UserEntity)this.userEntityBinding.bindingForEntity(json);
        try {
            IAccountBean bean = (IAccountBean)Services.getAccountService().findOne(Id.construct(entity.getId()));
            if (bean != null) {
                result = bean.apiPut(entity);
            } else {
                result.fail(ApiError.INVALID_OBJECT);
            }
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<UserEntity> deleteImpl(Id id) {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        IAccountBean bean = (IAccountBean)Services.getAccountService().findOne(id);
        if (bean != null) {
            return bean.apiDelete();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<UserEntity> createImpl(Id id, String json) {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<UserEntity> listImpl(String condition) {
        ApiResult<UserEntity> result = new ApiResult<UserEntity>();
        List accountList = Services.getAccountService().find(new DpSpec().byClass(Account.class).andNotEquals("name", "admin").sortBy("name", "ASC").condition(condition));
        List userlist = this.userEntityBinding.bindingForEntityList(accountList);
        result.setList(userlist);
        return result;
    }
}
