/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.ServerAction;
import com.jieyun.deskpool.api.data.ServerActionBinding;
import com.jieyun.deskpool.api.data.ServerEntity;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="serverActionApi")
public class ServerActionApi
extends ApiCallBase<ServerEntity>
implements IApiCall {
    @Autowired
    ServerActionBinding serverActionBinding;

    @Override
    public ApiResult<ServerEntity> getImpl(Id id) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<ServerEntity> putImpl(Id id, String json) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<ServerEntity> deleteImpl(Id id) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<ServerEntity> createImpl(Id id, String json) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        IServerBean server = id.empty() ? Services.getServerService().getCurrent() : Services.getServerService().findOne(id);
        if (server == null) {
            result.fail(ApiError.INVALID_OBJECT);
            return result;
        }
        ServerAction action = (ServerAction)this.serverActionBinding.bindingForAction(json);
        action.execute(server);
        return result;
    }

    @Override
    public ApiResult<ServerEntity> listImpl(String condition) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }
}
