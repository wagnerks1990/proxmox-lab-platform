/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.alibaba.fastjson.JSON;
import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.ServerEntity;
import com.jieyun.deskpool.api.data.ServerEntityBinding;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.domain.Server;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="serverApi")
public class ServerApi
extends ApiCallBase<ServerEntity>
implements IApiCall {
    @Autowired
    ServerEntityBinding serverEntityBinding;

    @Override
    public ApiResult<ServerEntity> getImpl(Id id) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        try {
            IServerBean bean = id.empty() ? Services.getServerService().getCurrent() : Services.getServerService().findOne(id);
            if (bean != null) {
                return bean.apiGet();
            }
            result.fail(ApiError.INVALID_OBJECT);
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<ServerEntity> putImpl(Id id, String json) {
        ApiResult<ServerEntity> result = new ApiResult();
        try {
            IServerBean bean = Services.getServerService().findOne(id);
            ServerEntity entity = (ServerEntity)JSON.parseObject((String)json, ServerEntity.class);
            if (bean != null) {
                result = bean.apiPut(entity);
            } else {
                result.fail(ApiError.INVALID_OBJECT);
            }
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<ServerEntity> deleteImpl(Id id) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<ServerEntity> createImpl(Id id, String json) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        try {
            ServerEntity entity = (ServerEntity)this.serverEntityBinding.bindingForEntity(json);
            IServerBean iServerBean = Services.getServerService().createServer(entity);
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<ServerEntity> listImpl(String condition) {
        ApiResult<ServerEntity> result = new ApiResult<ServerEntity>();
        List entityList = this.serverEntityBinding.bindingForEntityList(Services.getServerService().find(new DpSpec().byClass(Server.class).sortBy("name", "ASC").condition(condition)));
        result.setList(entityList);
        return result;
    }
}
