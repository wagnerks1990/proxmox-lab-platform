/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.PoolAction;
import com.jieyun.deskpool.api.data.PoolActionBinding;
import com.jieyun.deskpool.api.data.PoolEntity;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="poolActionApi")
public class PoolActionApi
extends ApiCallBase<PoolEntity>
implements IApiCall {
    @Autowired
    PoolActionBinding poolActionBinding;

    @Override
    public ApiResult<PoolEntity> getImpl(Id id) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> putImpl(Id id, String json) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> deleteImpl(Id id) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> createImpl(Id id, String json) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        ITemplateBean template = (ITemplateBean)Services.getTemplateService().findOne(id);
        if (template == null) {
            result.fail(ApiError.INVALID_OBJECT);
            return result;
        }
        PoolAction action = (PoolAction)this.poolActionBinding.bindingForAction(json);
        action.execute(template);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> listImpl(String condition) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }
}
