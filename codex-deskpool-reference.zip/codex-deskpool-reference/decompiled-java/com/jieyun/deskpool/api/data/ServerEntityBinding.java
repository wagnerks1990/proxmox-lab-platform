/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.ServerEntity;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.service.Services;
import org.springframework.stereotype.Service;

@Service(value="serverEntityBinding")
public class ServerEntityBinding
extends AbstractEntityBinding<ServerEntity, IServerBean> {
    @Override
    protected ServerEntity visitForEntity(ServerEntity entity, IServerBean bean) {
        entity.setId(bean.Id().getId());
        entity.setName(bean.getName());
        entity.setType(bean.getHost_type());
        entity.setAddress(bean.getHost_address());
        entity.setUsername(bean.getHost_user());
        entity.setPassword(bean.getHost_password());
        entity.setNetwork(bean.getNetwork());
        entity.setImagestore(bean.getImagestore());
        entity.setDiskstore(bean.getDiskstore());
        entity.setDatastore(bean.getDatastore());
        entity.setMgrAddress(bean.getNetworkConfig().address());
        return entity;
    }

    @Override
    protected IServerBean visitForBean(ServerEntity entity, IServerBean bean) {
        if (bean.Id().empty()) {
            bean.setHost_type(entity.getType());
            bean.setHost_address(entity.getAddress());
            bean.setHost_user(entity.getUsername());
            bean.setHost_password(entity.getPassword());
            bean.setNetwork(entity.getNetwork());
            bean.setDatastore(entity.getDatastore());
            bean.setImagestore(entity.getImagestore());
            bean.setDiskstore(entity.getDiskstore());
        } else {
            bean.setHost_type(entity.getType());
            bean.setHost_address(entity.getAddress());
            bean.setHost_user(entity.getUsername());
            bean.setHost_password(entity.getPassword());
            bean.setNetwork(entity.getNetwork());
            bean.setDatastore(entity.getDatastore());
            bean.setImagestore(entity.getImagestore());
            bean.setDiskstore(entity.getDiskstore());
        }
        return bean;
    }

    @Override
    public ServerEntity createNewEntity() {
        return new ServerEntity();
    }

    @Override
    protected IServerBean createNewBean() {
        return (IServerBean)Services.getServerService().createOne();
    }
}
