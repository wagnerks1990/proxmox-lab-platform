/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;

public class ActionObjectBase
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    private String action;

    public String getAction() {
        return this.action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
