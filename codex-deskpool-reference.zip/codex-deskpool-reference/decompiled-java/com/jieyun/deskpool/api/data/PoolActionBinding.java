/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractActionBinding;
import com.jieyun.deskpool.api.data.PoolAction;
import com.jieyun.deskpool.api.data.PoolRebuildAction;
import com.jieyun.deskpool.api.data.PoolRegenerateAction;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service(value="poolActionBinding")
public class PoolActionBinding
extends AbstractActionBinding<PoolAction> {
    Map<String, Class<?>> childClass = new HashMap();

    public PoolActionBinding() {
        this.registerActionClass("rebuild", PoolRebuildAction.class);
        this.registerActionClass("regenerate", PoolRegenerateAction.class);
    }
}
