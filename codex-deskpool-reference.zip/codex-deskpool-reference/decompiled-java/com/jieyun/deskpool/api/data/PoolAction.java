/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.ActionObjectBase;
import com.jieyun.deskpool.bean.ITemplateBean;

public abstract class PoolAction
extends ActionObjectBase {
    private static final long serialVersionUID = 1L;

    public abstract void execute(ITemplateBean var1);
}
