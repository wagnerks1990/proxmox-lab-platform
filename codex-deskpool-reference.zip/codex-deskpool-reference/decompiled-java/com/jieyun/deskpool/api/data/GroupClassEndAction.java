/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.GroupAction;
import com.jieyun.deskpool.bean.IGroupBean;

public class GroupClassEndAction
extends GroupAction {
    private static final long serialVersionUID = 1L;
    private Long template;

    @Override
    public void execute(IGroupBean group) {
        group.endClass(group.getActiveTemplateId());
    }

    public Long getTemplate() {
        return this.template;
    }

    public void setTemplate(Long template) {
        this.template = template;
    }
}
