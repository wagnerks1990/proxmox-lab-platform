/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.AgentStatus;
import com.jieyun.deskpool.shared.InstanceStatus;

public class InstanceEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    private String name;
    private String vmname;
    private InstanceStatus status;
    private String description;
    private String ipaddress;
    private Long template;
    private Long image;
    private Integer power;
    private AgentStatus agentStatus;
    private Long server;
    private String username;
    private String clientLocation;
    private String params;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVmname() {
        return this.vmname;
    }

    public void setVmname(String vmname) {
        this.vmname = vmname;
    }

    public InstanceStatus getStatus() {
        return this.status;
    }

    public void setStatus(InstanceStatus status) {
        this.status = status;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIpaddress() {
        return this.ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public Long getTemplate() {
        return this.template;
    }

    public void setTemplate(Long template) {
        this.template = template;
    }

    public Long getImage() {
        return this.image;
    }

    public void setImage(Long image) {
        this.image = image;
    }

    public Integer getPower() {
        return this.power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public AgentStatus getAgentStatus() {
        return this.agentStatus;
    }

    public void setAgentStatus(AgentStatus agentStatus) {
        this.agentStatus = agentStatus;
    }

    public Long getServer() {
        return this.server;
    }

    public void setServer(Long server) {
        this.server = server;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClientLocation() {
        return this.clientLocation;
    }

    public void setClientLocation(String clientLocation) {
        this.clientLocation = clientLocation;
    }

    public String getParams() {
        return this.params;
    }

    public void setParams(String params) {
        this.params = params;
    }
}
