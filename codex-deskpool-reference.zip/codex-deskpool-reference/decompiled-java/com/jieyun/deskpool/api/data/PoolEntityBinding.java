/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.PoolEntity;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import org.springframework.stereotype.Service;

@Service(value="poolEntityBinding")
public class PoolEntityBinding
extends AbstractEntityBinding<PoolEntity, ITemplateBean> {
    @Override
    protected PoolEntity visitForEntity(PoolEntity entity, ITemplateBean bean) {
        entity.setName(bean.getName());
        entity.setDescription(bean.getDescription());
        entity.setImage(bean.getImage().Id().getId());
        entity.setPrefix(bean.getPrefix());
        entity.setSuffix(bean.getSuffix());
        entity.setIsdefault(bean.isDefault());
        entity.setMemory(bean.getMemory());
        entity.setSockets(bean.getSockets());
        entity.setCores(bean.getCores());
        entity.setNetwork(bean.getNetwork());
        entity.setColorDepth(bean.getColorDepth());
        entity.setDevicmap(bean.getDevicmap());
        entity.setPoolType(bean.getPoolType());
        entity.setTemplatePolicy(bean.getPolicy());
        entity.setStoragePolicy(bean.getStoragePolicy());
        entity.setPoolInfo(bean.getPoolInfo());
        entity.setRfxAdaptor(bean.getRfxAdaptor());
        return entity;
    }

    @Override
    protected ITemplateBean visitForBean(PoolEntity entity, ITemplateBean bean) {
        ITemplateBean.Update update = bean.getUpdate();
        update.setName(entity.getName());
        update.setDescription(entity.getDescription());
        update.setImageId(Id.construct(entity.getImage()));
        update.setPrefix(entity.getPrefix());
        update.setSuffix(entity.getSuffix());
        update.setDefault(entity.getIsdefault());
        update.setMemory(entity.getMemory());
        update.setSockets(entity.getSockets());
        update.setCores(entity.getCores());
        update.setNetwork(entity.getNetwork());
        update.setColorDepth(entity.getColorDepth());
        update.setDevicmap(entity.getDevicmap());
        update.setPoolType(entity.getPoolType());
        update.setPolicy(entity.getTemplatePolicy());
        update.setStoragePolicy(entity.getStoragePolicy());
        update.setPoolInfo(entity.getPoolInfo());
        update.setRfxAdaptor(entity.getRfxAdaptor());
        return bean;
    }

    @Override
    public PoolEntity createNewEntity() {
        return new PoolEntity();
    }

    @Override
    protected ITemplateBean createNewBean() {
        return (ITemplateBean)Services.getTemplateService().createOne();
    }
}
