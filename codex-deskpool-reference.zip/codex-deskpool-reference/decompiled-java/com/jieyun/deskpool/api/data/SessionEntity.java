/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;

public class SessionEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    String user;
    String poolname;
    String vmname;
    String vmip;
    String vmmac;
    String clientip;
    String status;

    public String getUser() {
        return this.user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPoolname() {
        return this.poolname;
    }

    public void setPoolname(String poolname) {
        this.poolname = poolname;
    }

    public String getVmname() {
        return this.vmname;
    }

    public void setVmname(String vmname) {
        this.vmname = vmname;
    }

    public String getVmip() {
        return this.vmip;
    }

    public void setVmip(String vmip) {
        this.vmip = vmip;
    }

    public String getVmmac() {
        return this.vmmac;
    }

    public void setVmmac(String vmmac) {
        this.vmmac = vmmac;
    }

    public String getClientip() {
        return this.clientip;
    }

    public void setClientip(String clientip) {
        this.clientip = clientip;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
