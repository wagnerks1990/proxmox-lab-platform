/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.InstanceEntity;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.domain.Instance;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import org.springframework.stereotype.Service;

@Service(value="instanceEntityBinding")
public class InstanceEntityBinding
extends AbstractEntityBinding<InstanceEntity, IInstanceBean> {
    @Override
    protected InstanceEntity visitForEntity(InstanceEntity entity, IInstanceBean bean) {
        entity.setId(bean.Id().getId());
        entity.setName(bean.getName());
        entity.setDescription(bean.getDescription());
        entity.setStatus(bean.getStatus());
        entity.setIpaddress(bean.getIpaddress());
        Id id = bean.getServerId();
        entity.setServer(id == null ? 0L : id.getId());
        id = bean.getTemplateId();
        entity.setTemplate(id == null ? 0L : id.getId());
        id = bean.getImage().Id();
        entity.setImage(id == null ? 0L : id.getId());
        entity.setUsername(bean.getUsername());
        entity.setVmname(bean.getVmname());
        entity.setClientLocation(bean.getClientLocation());
        entity.setParams(((Instance)bean.getDomain()).getParams());
        return entity;
    }

    @Override
    protected IInstanceBean visitForBean(InstanceEntity entity, IInstanceBean bean) {
        IInstanceBean.Update update = bean.getUpdate();
        update.setName(entity.getName());
        update.setDescription(entity.getDescription());
        return update;
    }

    @Override
    public InstanceEntity createNewEntity() {
        return new InstanceEntity();
    }

    @Override
    protected IInstanceBean createNewBean() {
        return (IInstanceBean)Services.getInstanceService().createOne();
    }
}
