/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.InstanceAction;
import com.jieyun.deskpool.bean.IInstanceBean;

public class InstanceShutdownAction
extends InstanceAction {
    private static final long serialVersionUID = 1L;

    @Override
    public void execute(IInstanceBean instance) {
        instance.shutdown();
    }
}
