/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.ImageInfo;
import com.jieyun.deskpool.shared.ImageStatus;
import java.util.List;

public class ImageEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    private String name;
    private String description;
    private Desktop.ImageMode mode;
    private ImageStatus status;
    private String sourcevm;
    private String draftvm;
    private String targetvm;
    private String username;
    private String password;
    private Boolean autoInstallAgent;
    private List<String> versions;
    private String version;
    private ImageInfo imageinfo;

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Desktop.ImageMode getMode() {
        return this.mode;
    }

    public ImageStatus getStatus() {
        return this.status;
    }

    public String getSourcevm() {
        return this.sourcevm;
    }

    public String getDraftvm() {
        return this.draftvm;
    }

    public String getTargetvm() {
        return this.targetvm;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public Boolean getAutoInstallAgent() {
        return this.autoInstallAgent;
    }

    public List<String> getVersions() {
        return this.versions;
    }

    public String getVersion() {
        return this.version;
    }

    public ImageInfo getImageinfo() {
        return this.imageinfo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setMode(Desktop.ImageMode mode) {
        this.mode = mode;
    }

    public void setStatus(ImageStatus status) {
        this.status = status;
    }

    public void setSourcevm(String sourcevm) {
        this.sourcevm = sourcevm;
    }

    public void setDraftvm(String draftvm) {
        this.draftvm = draftvm;
    }

    public void setTargetvm(String targetvm) {
        this.targetvm = targetvm;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAutoInstallAgent(Boolean autoInstallAgent) {
        this.autoInstallAgent = autoInstallAgent;
    }

    public void setImageinfo(ImageInfo imageinfo) {
        this.imageinfo = imageinfo;
    }

    public void setVersions(List<String> versions) {
        this.versions = versions;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
