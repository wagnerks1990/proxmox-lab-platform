/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.bean.Bean;

public abstract class EntityVisiter<T extends AbstractEntityObject, B extends Bean<?>> {
    public abstract void postVisit(T var1, B var2);
}
