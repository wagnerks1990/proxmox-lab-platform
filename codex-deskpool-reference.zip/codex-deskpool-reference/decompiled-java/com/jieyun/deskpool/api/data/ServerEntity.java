/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;

public class ServerEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    String name;
    String description;
    String type;
    String address;
    String username;
    String password;
    String network;
    String datastore;
    String imagestore;
    String diskstore;
    String mgrAddress;
    String mgrGateway;
    String mgrNetmask;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNetwork() {
        return this.network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public String getDatastore() {
        return this.datastore;
    }

    public void setDatastore(String datastore) {
        this.datastore = datastore;
    }

    public String getImagestore() {
        return this.imagestore;
    }

    public void setImagestore(String imagestore) {
        this.imagestore = imagestore;
    }

    public String getDiskstore() {
        return this.diskstore;
    }

    public void setDiskstore(String diskstore) {
        this.diskstore = diskstore;
    }

    public String getMgrAddress() {
        return this.mgrAddress;
    }

    public void setMgrAddress(String mgrAddress) {
        this.mgrAddress = mgrAddress;
    }

    public String getMgrGateway() {
        return this.mgrGateway;
    }

    public void setMgrGateway(String mgrGateway) {
        this.mgrGateway = mgrGateway;
    }

    public String getMgrNetmask() {
        return this.mgrNetmask;
    }

    public void setMgrNetmask(String mgrNetmask) {
        this.mgrNetmask = mgrNetmask;
    }
}
