/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 */
package com.jieyun.deskpool.api.data;

import com.alibaba.fastjson.JSON;
import java.io.Serializable;

public abstract class AbstractEntityObject
implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    public Long getId() {
        return this.id;
    }

    public void setId(Long id2) {
        this.id = id2;
    }

    public int hashCode() {
        int prime = 31;
        int result = 1;
        result = 31 * result + (this.id == null ? 0 : this.id.hashCode());
        return result;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        AbstractEntityObject other = (AbstractEntityObject)obj;
        return !(this.id == null ? other.id != null : !this.id.equals(other.id));
    }

    public String toJson() {
        return JSON.toJSONString((Object)this);
    }
}
