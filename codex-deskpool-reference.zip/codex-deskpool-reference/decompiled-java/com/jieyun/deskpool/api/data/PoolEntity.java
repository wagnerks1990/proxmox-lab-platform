/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.Desktop;
import com.jieyun.deskpool.shared.DeviceMapping;
import com.jieyun.deskpool.shared.PoolInfo;
import com.jieyun.deskpool.shared.PoolType;
import com.jieyun.deskpool.shared.RfxAdaptor;
import com.jieyun.deskpool.shared.StoragePolicy;
import com.jieyun.deskpool.shared.TemplatePolicy;

public class PoolEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    private String name;
    private String description;
    private Long image;
    private String prefix;
    private String suffix;
    private Boolean isdefault;
    private Integer memory;
    private Integer sockets;
    private Integer cores;
    private String network;
    private Desktop.ColorDepth colorDepth;
    private DeviceMapping devicmap;
    private PoolType poolType;
    private TemplatePolicy templatePolicy;
    private StoragePolicy storagePolicy;
    private PoolInfo poolInfo;
    private RfxAdaptor rfxAdaptor;

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Long getImage() {
        return this.image;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public Boolean getIsdefault() {
        return this.isdefault;
    }

    public Integer getMemory() {
        return this.memory;
    }

    public Integer getSockets() {
        return this.sockets;
    }

    public Integer getCores() {
        return this.cores;
    }

    public String getNetwork() {
        return this.network;
    }

    public Desktop.ColorDepth getColorDepth() {
        return this.colorDepth;
    }

    public DeviceMapping getDevicmap() {
        return this.devicmap;
    }

    public PoolType getPoolType() {
        return this.poolType;
    }

    public TemplatePolicy getTemplatePolicy() {
        return this.templatePolicy;
    }

    public StoragePolicy getStoragePolicy() {
        return this.storagePolicy;
    }

    public PoolInfo getPoolInfo() {
        return this.poolInfo;
    }

    public RfxAdaptor getRfxAdaptor() {
        return this.rfxAdaptor;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImage(Long image) {
        this.image = image;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public void setIsdefault(Boolean isdefault) {
        this.isdefault = isdefault;
    }

    public void setMemory(Integer memory) {
        this.memory = memory;
    }

    public void setSockets(Integer sockets) {
        this.sockets = sockets;
    }

    public void setCores(Integer cores) {
        this.cores = cores;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public void setColorDepth(Desktop.ColorDepth colorDepth) {
        this.colorDepth = colorDepth;
    }

    public void setDevicmap(DeviceMapping devicmap) {
        this.devicmap = devicmap;
    }

    public void setPoolType(PoolType poolType) {
        this.poolType = poolType;
    }

    public void setTemplatePolicy(TemplatePolicy templatePolicy) {
        this.templatePolicy = templatePolicy;
    }

    public void setStoragePolicy(StoragePolicy storagePolicy) {
        this.storagePolicy = storagePolicy;
    }

    public void setPoolInfo(PoolInfo poolInfo) {
        this.poolInfo = poolInfo;
    }

    public void setRfxAdaptor(RfxAdaptor rfxAdaptor) {
        this.rfxAdaptor = rfxAdaptor;
    }
}
