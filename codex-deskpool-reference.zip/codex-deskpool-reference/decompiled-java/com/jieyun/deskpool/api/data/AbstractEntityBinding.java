/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.api.data;

import com.alibaba.fastjson.JSON;
import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.api.data.EntityVisiter;
import com.jieyun.deskpool.bean.Bean;
import com.jieyun.deskpool.shared.Id;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

public abstract class AbstractEntityBinding<F extends AbstractEntityObject, B extends Bean> {
    protected abstract F visitForEntity(F var1, B var2);

    protected abstract B visitForBean(F var1, B var2);

    public abstract F createNewEntity();

    protected abstract B createNewBean();

    public Id getIdFromLong(Long id) {
        return id == 0L ? null : Id.construct(id);
    }

    public Long getLongFromId(Id id) {
        return id == null ? 0L : id.getId();
    }

    public F bindingForEntity(F entity, B bean) {
        if (entity == null) {
            return null;
        }
        if (bean == null) {
            return null;
        }
        ((AbstractEntityObject)entity).setId(bean.Id().getId());
        this.visitForEntity(entity, bean);
        return entity;
    }

    public F bindingForEntity(F entity, String json) {
        if (entity == null) {
            return null;
        }
        if (StringUtils.isBlank((CharSequence)json)) {
            return null;
        }
        entity = (AbstractEntityObject)JSON.parseObject((String)json, entity.getClass());
        return entity;
    }

    public F bindingForEntity(String json) {
        if (StringUtils.isBlank((CharSequence)json)) {
            return null;
        }
        F entity = this.createNewEntity();
        return this.bindingForEntity(entity, json);
    }

    public List<F> bindingForEntityList(List<B> beanList) {
        if (beanList == null) {
            throw new RuntimeException(" beanList is null !");
        }
        ArrayList<F> entityList = new ArrayList<F>();
        for (Bean bean : beanList) {
            F entity = this.createNewEntity();
            entityList.add(this.bindingForEntity(entity, bean));
        }
        return entityList;
    }

    public List<F> bindingForEntityList(List<B> beanList, EntityVisiter<F, B> visiter) {
        if (beanList == null) {
            throw new RuntimeException(" beanList is null !");
        }
        ArrayList<F> entityList = new ArrayList<F>();
        for (Bean bean : beanList) {
            F entity = this.createNewEntity();
            this.bindingForEntity(entity, bean);
            visiter.postVisit(entity, bean);
            entityList.add(entity);
        }
        return entityList;
    }

    public B bindingForBean(F entity, B bean) {
        if (bean == null) {
            throw new RuntimeException(" bean is null !");
        }
        if (entity == null) {
            throw new RuntimeException(" entity is null !");
        }
        if (bean.Id() != null && !bean.Id().getId().equals(((AbstractEntityObject)entity).getId())) {
            throw new RuntimeException(" id is not equals !");
        }
        return this.visitForBean(entity, bean);
    }

    public B bindingForBean(F entity, B bean, boolean create) {
        if (create) {
            return this.bindingForBean(entity, this.createNewBean());
        }
        return this.bindingForBean(entity, bean);
    }
}
