/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.PoolAction;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.shared.Id;

public class PoolRebuildAction
extends PoolAction {
    private static final long serialVersionUID = 1L;
    private Long image;

    public Long getImage() {
        return this.image;
    }

    public void setImage(Long image) {
        this.image = image;
    }

    @Override
    public void execute(ITemplateBean template) {
        if (this.image == null || this.image == 0L) {
            template.getUpdate().rebuildRetiredInstances(null);
        } else {
            template.getUpdate().rebuildRetiredInstances(Id.construct(this.image));
        }
    }
}
