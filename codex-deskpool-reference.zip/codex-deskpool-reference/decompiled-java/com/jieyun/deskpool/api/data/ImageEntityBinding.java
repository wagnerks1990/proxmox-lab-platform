/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.ImageEntity;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.service.Services;
import org.springframework.stereotype.Service;

@Service(value="imageEntityBinding")
public class ImageEntityBinding
extends AbstractEntityBinding<ImageEntity, IImageBean> {
    @Override
    protected ImageEntity visitForEntity(ImageEntity entity, IImageBean bean) {
        entity.setId(bean.Id().getId());
        entity.setName(bean.getName());
        entity.setAutoInstallAgent(bean.isAutoInstallAgent());
        entity.setDescription(bean.getDescription());
        entity.setDraftvm(bean.getDraftvm());
        entity.setMode(bean.getMode());
        entity.setUsername(bean.getUsername());
        entity.setPassword(bean.getPassword());
        entity.setSourcevm(bean.getSourcevm());
        entity.setTargetvm(bean.getTargetvm());
        entity.setStatus(bean.getStatus());
        entity.setVersions(bean.getVersions());
        entity.setVersion(bean.getVersion());
        entity.setImageinfo(bean.getImageInfo());
        return entity;
    }

    @Override
    protected IImageBean visitForBean(ImageEntity entity, IImageBean bean) {
        IImageBean.Update update = bean.getUpdate();
        update.setDescription(entity.getDescription());
        update.setMode(entity.getMode());
        update.setUsername(entity.getUsername());
        update.setPassword(entity.getPassword());
        return update;
    }

    @Override
    public ImageEntity createNewEntity() {
        return new ImageEntity();
    }

    @Override
    protected IImageBean createNewBean() {
        return (IImageBean)Services.getImageService().createOne();
    }
}
