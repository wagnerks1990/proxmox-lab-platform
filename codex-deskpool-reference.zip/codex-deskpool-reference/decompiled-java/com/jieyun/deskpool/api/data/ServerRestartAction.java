/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.ServerAction;
import com.jieyun.deskpool.bean.IServerBean;

public class ServerRestartAction
extends ServerAction {
    private static final long serialVersionUID = 1L;

    @Override
    public void execute(IServerBean server) {
        server.restart();
    }
}
