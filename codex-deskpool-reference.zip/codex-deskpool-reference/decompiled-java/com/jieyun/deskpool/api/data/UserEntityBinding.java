/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.UserEntity;
import com.jieyun.deskpool.bean.IAccountBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service(value="userEntityBinding")
public class UserEntityBinding
extends AbstractEntityBinding<UserEntity, IAccountBean> {
    private List<Long> IdsToLongs(List<Id> ids) {
        ArrayList<Long> longIds = new ArrayList<Long>();
        if (ids != null) {
            for (Id item : ids) {
                longIds.add(item.getId());
            }
        }
        return longIds;
    }

    private List<Id> LongsToIds(List<Long> ids) {
        ArrayList<Id> idList = new ArrayList<Id>();
        if (ids != null) {
            for (Long item : ids) {
                idList.add(Id.construct(item));
            }
        }
        return idList;
    }

    @Override
    protected UserEntity visitForEntity(UserEntity entity, IAccountBean bean) {
        entity.setId(bean.Id().getId());
        entity.setName(bean.getName());
        entity.setFirstname(bean.getFirstname());
        entity.setLastname(bean.getLastname());
        entity.setGroups(this.IdsToLongs(bean.getGroupIDs()));
        entity.setEnable(bean.isEnable());
        entity.setPassword(bean.getPassword());
        entity.setRoles(bean.getRoles());
        entity.setSetting(bean.getSetting());
        entity.setTemplates(this.IdsToLongs(bean.getTemplateIDs()));
        return entity;
    }

    @Override
    protected IAccountBean visitForBean(UserEntity entity, IAccountBean bean) {
        IAccountBean.Update update = bean.getUpdate();
        update.setName(entity.getName());
        update.setFirstname(entity.getFirstname());
        update.setLastname(entity.getLastname());
        update.setGroupIDs(this.LongsToIds(entity.getGroups()));
        update.setEnable(entity.isEnable());
        update.setPassword(entity.getPassword());
        update.setRoles(entity.getRoles());
        update.setSetting(entity.getSetting());
        update.setTemplateIDs(this.LongsToIds(entity.getTemplates()));
        return update;
    }

    @Override
    public UserEntity createNewEntity() {
        return new UserEntity();
    }

    @Override
    protected IAccountBean createNewBean() {
        return (IAccountBean)Services.getAccountService().createOne();
    }
}
