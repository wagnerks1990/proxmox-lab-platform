/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractActionBinding;
import com.jieyun.deskpool.api.data.ServerAction;
import com.jieyun.deskpool.api.data.ServerRearmAction;
import com.jieyun.deskpool.api.data.ServerRestartAction;
import com.jieyun.deskpool.api.data.ServerShutdownAction;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service(value="serverActionBinding")
public class ServerActionBinding
extends AbstractActionBinding<ServerAction> {
    Map<String, Class<?>> childClass = new HashMap();

    public ServerActionBinding() {
        this.registerActionClass("shutdown", ServerShutdownAction.class);
        this.registerActionClass("restart", ServerRestartAction.class);
        this.registerActionClass("rearm", ServerRearmAction.class);
    }
}
