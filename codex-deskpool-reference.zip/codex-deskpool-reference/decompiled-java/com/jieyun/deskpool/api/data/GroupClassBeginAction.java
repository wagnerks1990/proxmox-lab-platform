/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.GroupAction;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.shared.Id;

public class GroupClassBeginAction
extends GroupAction {
    private static final long serialVersionUID = 1L;
    private Long template;

    public Long getTemplate() {
        return this.template;
    }

    public void setTemplate(Long template) {
        this.template = template;
    }

    @Override
    public void execute(IGroupBean group) {
        group.beginClass(Id.construct(this.template));
    }
}
