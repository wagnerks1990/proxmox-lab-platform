/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  org.apache.commons.lang3.StringUtils
 */
package com.jieyun.deskpool.api.data;

import com.alibaba.fastjson.JSON;
import com.jieyun.deskpool.api.data.ActionObjectBase;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public abstract class AbstractActionBinding<F extends ActionObjectBase> {
    Map<String, Class<?>> childClass = new HashMap();

    public void registerActionClass(String action, Class<?> clazz) {
        this.childClass.put(action, clazz);
    }

    public Class<?> getActionClass(String action) {
        Class<?> clazz = this.childClass.get(action);
        if (clazz != null) {
            return clazz;
        }
        return null;
    }

    public F bindingForAction(F action, String json) {
        if (action == null) {
            return null;
        }
        if (StringUtils.isBlank((CharSequence)json)) {
            return null;
        }
        action = (ActionObjectBase)JSON.parseObject((String)json, action.getClass());
        return action;
    }

    public F bindingForAction(String json) {
        if (StringUtils.isBlank((CharSequence)json)) {
            return null;
        }
        ActionObjectBase baseAction = (ActionObjectBase)JSON.parseObject((String)json, ActionObjectBase.class);
        Class<?> clazz = this.getActionClass(baseAction.getAction());
        ActionObjectBase actionObject = (ActionObjectBase)JSON.parseObject((String)json, clazz);
        return (F)actionObject;
    }
}
