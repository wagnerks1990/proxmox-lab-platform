/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.ServerAction;
import com.jieyun.deskpool.bean.IClusterBean;
import com.jieyun.deskpool.bean.IServerBean;
import com.jieyun.deskpool.bean.local.ClusterNodeBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.utils.DpStringUtils;
import java.util.Date;

public class ServerRearmAction
extends ServerAction {
    private static final long serialVersionUID = 1L;

    @Override
    public void execute(IServerBean server) {
        ClusterNodeBean.instance().saveClusterName("deskpool-cluster-" + DpStringUtils.getRandomStr(5));
        ClusterNodeBean.instance().generateLicense();
        IClusterBean clusterBean = Services.getClusterService().getCluster();
        if (clusterBean != null) {
            clusterBean.getUpdate().setCreateTime(new Date()).save();
        }
    }
}
