/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.PoolAction;
import com.jieyun.deskpool.bean.ITemplateBean;

public class PoolRegenerateAction
extends PoolAction {
    private static final long serialVersionUID = 1L;

    @Override
    public void execute(ITemplateBean template) {
        template.getUpdate().regenerateInstances();
    }
}
