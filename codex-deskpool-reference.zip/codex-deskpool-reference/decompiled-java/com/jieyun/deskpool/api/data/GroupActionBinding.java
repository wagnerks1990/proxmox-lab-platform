/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractActionBinding;
import com.jieyun.deskpool.api.data.GroupAction;
import com.jieyun.deskpool.api.data.GroupClassBeginAction;
import com.jieyun.deskpool.api.data.GroupClassEndAction;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service(value="groupActionBinding")
public class GroupActionBinding
extends AbstractActionBinding<GroupAction> {
    Map<String, Class<?>> childClass = new HashMap();

    public GroupActionBinding() {
        this.registerActionClass("classBegin", GroupClassBeginAction.class);
        this.registerActionClass("classEnd", GroupClassEndAction.class);
    }
}
