/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.Desktop;

public class GroupEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    private String name;
    private String description;
    private String templates;
    private Desktop.GroupType groupType;
    private String accessCode;
    private Long activeTemplate;
    private boolean enable = true;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTemplates() {
        return this.templates;
    }

    public void setTemplates(String templates) {
        this.templates = templates;
    }

    public String getAccessCode() {
        return this.accessCode;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public Long getActiveTemplate() {
        return this.activeTemplate;
    }

    public void setActiveTemplate(Long activeTemplate) {
        this.activeTemplate = activeTemplate;
    }

    public boolean isEnable() {
        return this.enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public Desktop.GroupType getGroupType() {
        return this.groupType;
    }

    public void setGroupType(Desktop.GroupType groupType) {
        this.groupType = groupType;
    }

    public boolean isClassroom() {
        return Desktop.GroupType.CLASSROOM.equals((Object)this.getGroupType());
    }
}
