/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractActionBinding;
import com.jieyun.deskpool.api.data.InstanceAction;
import com.jieyun.deskpool.api.data.InstanceRestartAction;
import com.jieyun.deskpool.api.data.InstanceShutdownAction;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service(value="instanceActionBinding")
public class InstanceActionBinding
extends AbstractActionBinding<InstanceAction> {
    Map<String, Class<?>> childClass = new HashMap();

    public InstanceActionBinding() {
        this.registerActionClass("shutdown", InstanceShutdownAction.class);
        this.registerActionClass("restart", InstanceRestartAction.class);
    }
}
