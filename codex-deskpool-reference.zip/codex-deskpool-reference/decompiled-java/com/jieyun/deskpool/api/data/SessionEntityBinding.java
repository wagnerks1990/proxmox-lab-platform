/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.SessionEntity;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import org.springframework.stereotype.Service;

@Service(value="sessionEntityBinding")
public class SessionEntityBinding
extends AbstractEntityBinding<SessionEntity, IUserSessionBean> {
    @Override
    protected SessionEntity visitForEntity(SessionEntity entity, IUserSessionBean bean) {
        entity.setId(bean.Id().getId());
        entity.setUser(bean.getAccountName());
        entity.setClientip(bean.getClientIP());
        entity.setPoolname(bean.getTemplateName());
        entity.setStatus(bean.getStatus().toString());
        entity.setVmip(bean.getInstanceIP());
        entity.setVmmac("");
        entity.setVmname(bean.getInstanceName());
        return entity;
    }

    @Override
    public SessionEntity createNewEntity() {
        return new SessionEntity();
    }

    @Override
    protected IUserSessionBean visitForBean(SessionEntity entity, IUserSessionBean bean) {
        return null;
    }

    @Override
    protected IUserSessionBean createNewBean() {
        return null;
    }
}
