/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.RoleType;
import com.jieyun.deskpool.shared.UserSetting;
import java.util.List;

public class UserEntity
extends AbstractEntityObject {
    private static final long serialVersionUID = 1L;
    private String name;
    private String firstname;
    private String lastname;
    private String password;
    private List<RoleType> roles;
    private UserSetting setting;
    private List<Long> templates;
    private List<Long> groups;
    private boolean enable = true;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFirstname() {
        return this.firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return this.lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<RoleType> getRoles() {
        return this.roles;
    }

    public void setRoles(List<RoleType> roles) {
        this.roles = roles;
    }

    public UserSetting getSetting() {
        return this.setting;
    }

    public void setSetting(UserSetting setting) {
        this.setting = setting;
    }

    public List<Long> getTemplates() {
        return this.templates;
    }

    public void setTemplates(List<Long> templates) {
        this.templates = templates;
    }

    public List<Long> getGroups() {
        return this.groups;
    }

    public void setGroups(List<Long> groups) {
        this.groups = groups;
    }

    public boolean isEnable() {
        return this.enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }
}
