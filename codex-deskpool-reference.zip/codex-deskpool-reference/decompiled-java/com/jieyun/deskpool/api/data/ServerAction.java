/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.ActionObjectBase;
import com.jieyun.deskpool.bean.IServerBean;

public abstract class ServerAction
extends ActionObjectBase {
    private static final long serialVersionUID = 1L;

    public abstract void execute(IServerBean var1);
}
