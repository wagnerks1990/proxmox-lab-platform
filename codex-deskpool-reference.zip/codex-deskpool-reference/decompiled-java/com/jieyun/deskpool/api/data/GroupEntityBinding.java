/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api.data;

import com.jieyun.deskpool.api.data.AbstractEntityBinding;
import com.jieyun.deskpool.api.data.GroupEntity;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.domain.Groups;
import com.jieyun.deskpool.service.Services;
import org.springframework.stereotype.Service;

@Service(value="groupEntityBinding")
public class GroupEntityBinding
extends AbstractEntityBinding<GroupEntity, IGroupBean> {
    @Override
    protected GroupEntity visitForEntity(GroupEntity entity, IGroupBean bean) {
        entity.setId(bean.Id().getId());
        entity.setName(bean.getName());
        entity.setDescription(bean.getDescription());
        entity.setAccessCode(bean.getAccessCode());
        entity.setActiveTemplate(this.getLongFromId(bean.getActiveTemplateId()));
        entity.setEnable(bean.isEnable());
        entity.setTemplates(((Groups)bean.getDomain()).getTemplates());
        return entity;
    }

    @Override
    protected IGroupBean visitForBean(GroupEntity entity, IGroupBean bean) {
        bean.setName(entity.getName());
        bean.setDescription(entity.getDescription());
        bean.setAccessCode(entity.getAccessCode());
        bean.setActiveTemplateId(this.getIdFromLong(entity.getActiveTemplate()));
        bean.setEnable(entity.isEnable());
        ((Groups)bean.getDomain()).setTemplates(entity.getTemplates());
        return bean;
    }

    @Override
    public GroupEntity createNewEntity() {
        return new GroupEntity();
    }

    @Override
    protected IGroupBean createNewBean() {
        return (IGroupBean)Services.getGroupService().createOne();
    }
}
