/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.ImageEntity;
import com.jieyun.deskpool.api.data.ImageEntityBinding;
import com.jieyun.deskpool.bean.IImageBean;
import com.jieyun.deskpool.domain.Image;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="imageApi")
public class ImageApi
extends ApiCallBase<ImageEntity>
implements IApiCall {
    @Autowired
    ImageEntityBinding imageEntityBinding;

    @Override
    public ApiResult<ImageEntity> getImpl(Id id) {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        IImageBean image = Services.getImageService().findOne(id);
        if (image != null) {
            return image.apiGet();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<ImageEntity> putImpl(Id id, String json) {
        ApiResult<ImageEntity> result = new ApiResult();
        ImageEntity entity = (ImageEntity)this.imageEntityBinding.bindingForEntity(json);
        try {
            IImageBean bean = Services.getImageService().findOne(Id.construct(entity.getId()));
            if (bean != null) {
                result = bean.apiPut(entity);
            } else {
                result.fail(ApiError.INVALID_OBJECT);
            }
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<ImageEntity> deleteImpl(Id id) {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        IImageBean bean = Services.getImageService().findOne(id);
        if (bean != null) {
            return bean.apiDelete();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<ImageEntity> createImpl(Id id, String json) {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<ImageEntity> listImpl(String condition) {
        ApiResult<ImageEntity> result = new ApiResult<ImageEntity>();
        List imagelist = this.imageEntityBinding.bindingForEntityList(Services.getImageService().find(new DpSpec().byClass(Image.class).sortBy("name", "ASC").condition(condition)));
        result.setList(imagelist);
        return result;
    }
}
