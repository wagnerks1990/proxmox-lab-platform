/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.GroupEntity;
import com.jieyun.deskpool.api.data.GroupEntityBinding;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.domain.Groups;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="groupApi")
public class GroupApi
extends ApiCallBase<GroupEntity>
implements IApiCall {
    @Autowired
    GroupEntityBinding groupEntityBinding;

    @Override
    public ApiResult<GroupEntity> getImpl(Id id) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        IGroupBean bean = (IGroupBean)Services.getGroupService().findOne(id);
        if (bean != null) {
            return bean.apiGet();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> putImpl(Id id, String json) {
        ApiResult<GroupEntity> result = new ApiResult();
        GroupEntity entity = (GroupEntity)this.groupEntityBinding.bindingForEntity(json);
        try {
            IGroupBean bean = (IGroupBean)Services.getGroupService().findOne(Id.construct(entity.getId()));
            if (bean != null) {
                result = bean.apiPut(entity);
            } else {
                result.fail(ApiError.INVALID_OBJECT);
            }
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<GroupEntity> deleteImpl(Id id) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        IGroupBean bean = (IGroupBean)Services.getGroupService().findOne(id);
        if (bean != null) {
            return bean.apiDelete();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> createImpl(Id id, String json) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> listImpl(String condition) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        List grouplist = this.groupEntityBinding.bindingForEntityList(Services.getGroupService().find(new DpSpec().byClass(Groups.class).sortBy("name", "ASC").condition(condition)));
        result.setList(grouplist);
        return result;
    }
}
