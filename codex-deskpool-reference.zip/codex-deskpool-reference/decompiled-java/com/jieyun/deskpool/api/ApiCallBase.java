/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.context.support.ApplicationObjectSupport
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.Id;
import org.springframework.context.support.ApplicationObjectSupport;

public abstract class ApiCallBase<T extends AbstractEntityObject>
extends ApplicationObjectSupport
implements IApiCall {
    public abstract ApiResult<T> getImpl(Id var1);

    public abstract ApiResult<T> putImpl(Id var1, String var2);

    public abstract ApiResult<T> deleteImpl(Id var1);

    public abstract ApiResult<T> createImpl(Id var1, String var2);

    public abstract ApiResult<T> listImpl(String var1);

    public ApiResult<T> createImpl(String json) {
        return this.createImpl(null, json);
    }

    public ApiResult<T> getImpl(Long id) {
        Id objId = Id.construct(id);
        return this.getImpl(objId);
    }

    public ApiResult<T> putImpl(Long id, String json) {
        Id objId = Id.construct(id);
        return this.putImpl(objId, json);
    }

    public ApiResult<T> deleteImpl(Long id) {
        Id objId = Id.construct(id);
        return this.deleteImpl(objId);
    }

    @Override
    public String get(String id) {
        Id objId = Id.construct(id);
        return this.getImpl(objId).toJson();
    }

    @Override
    public String put(String id, String json) {
        Id objId = Id.construct(id);
        return this.putImpl(objId, json).toJson();
    }

    @Override
    public String delete(String id) {
        Id objId = Id.construct(id);
        return this.deleteImpl(objId).toJson();
    }

    @Override
    public String create(String id, String json) {
        Id objId = Id.construct(id);
        return this.createImpl(objId, json).toJson();
    }

    @Override
    public String list(String condition) {
        return this.listImpl(condition).toJson();
    }
}
