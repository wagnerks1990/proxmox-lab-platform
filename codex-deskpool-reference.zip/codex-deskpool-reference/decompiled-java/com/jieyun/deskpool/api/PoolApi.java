/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.PoolEntity;
import com.jieyun.deskpool.api.data.PoolEntityBinding;
import com.jieyun.deskpool.bean.ITemplateBean;
import com.jieyun.deskpool.domain.Template;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="poolApi")
public class PoolApi
extends ApiCallBase<PoolEntity>
implements IApiCall {
    @Autowired
    PoolEntityBinding poolEntityBinding;

    @Override
    public ApiResult<PoolEntity> getImpl(Id id) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        ITemplateBean template = (ITemplateBean)Services.getTemplateService().findOne(id);
        if (template != null) {
            return template.apiGet();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> putImpl(Id id, String json) {
        ApiResult<PoolEntity> result = new ApiResult();
        PoolEntity entity = (PoolEntity)this.poolEntityBinding.bindingForEntity(json);
        try {
            ITemplateBean bean = (ITemplateBean)Services.getTemplateService().findOne(Id.construct(entity.getId()));
            if (bean != null) {
                result = bean.apiPut(entity);
            } else {
                result.fail(ApiError.INVALID_OBJECT);
            }
        }
        catch (Exception ex) {
            return result.fail(ApiError.UNKONW_ERROR, ex.getMessage());
        }
        return result;
    }

    @Override
    public ApiResult<PoolEntity> deleteImpl(Id id) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        ITemplateBean bean = (ITemplateBean)Services.getTemplateService().findOne(id);
        if (bean != null) {
            return bean.apiDelete();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> createImpl(Id id, String json) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<PoolEntity> listImpl(String condition) {
        ApiResult<PoolEntity> result = new ApiResult<PoolEntity>();
        List poollist = this.poolEntityBinding.bindingForEntityList(Services.getTemplateService().find(new DpSpec().byClass(Template.class).sortBy("name", "ASC").condition(condition)));
        result.setList(poollist);
        return result;
    }
}
