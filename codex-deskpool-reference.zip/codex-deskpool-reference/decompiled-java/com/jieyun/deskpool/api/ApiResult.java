/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  org.apache.commons.lang.StringUtils
 */
package com.jieyun.deskpool.api;

import com.alibaba.fastjson.JSON;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.data.AbstractEntityObject;
import com.jieyun.deskpool.shared.ErrorMessage;
import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class ApiResult<T extends AbstractEntityObject>
implements Serializable {
    private static final long serialVersionUID = 1L;
    int code;
    String message;
    T entity;
    List<T> list;

    public ApiResult() {
        this.fail(ApiError.SUCCESS);
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getEntity() {
        return this.entity;
    }

    public void setEntity(T entity) {
        this.entity = entity;
    }

    public List<T> getList() {
        return this.list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public String toJson() {
        return JSON.toJSONString((Object)this);
    }

    public ApiResult<T> fail(ApiError error) {
        this.code = error.code();
        this.message = error.message();
        return this;
    }

    public ApiResult<T> fail(ApiError error, String errormsg) {
        this.code = error.code();
        this.message = errormsg;
        return this;
    }

    public ApiResult<T> fail(ApiError error, List<ErrorMessage> errList) {
        this.code = error.code();
        if (errList != null) {
            this.message = "";
            for (ErrorMessage msg : errList) {
                this.message = StringUtils.isEmpty((String)this.message) ? msg.getDefaultMsg() : String.valueOf(this.message) + ";" + msg.getDefaultMsg();
            }
        }
        return this;
    }

    public ApiResult<T> fail(int error, String errormsg) {
        this.code = error;
        this.message = errormsg;
        return this;
    }
}
