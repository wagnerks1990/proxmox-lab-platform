/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.GroupAction;
import com.jieyun.deskpool.api.data.GroupActionBinding;
import com.jieyun.deskpool.api.data.GroupEntity;
import com.jieyun.deskpool.bean.IGroupBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="groupActionApi")
public class GroupActionApi
extends ApiCallBase<GroupEntity>
implements IApiCall {
    @Autowired
    GroupActionBinding groupActionBinding;

    @Override
    public ApiResult<GroupEntity> getImpl(Id id) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> putImpl(Id id, String json) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> deleteImpl(Id id) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> createImpl(Id id, String json) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        IGroupBean group = (IGroupBean)Services.getGroupService().findOne(id);
        if (group == null) {
            result.fail(ApiError.INVALID_OBJECT);
            return result;
        }
        GroupAction action = (GroupAction)this.groupActionBinding.bindingForAction(json);
        action.execute(group);
        return result;
    }

    @Override
    public ApiResult<GroupEntity> listImpl(String condition) {
        ApiResult<GroupEntity> result = new ApiResult<GroupEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }
}
