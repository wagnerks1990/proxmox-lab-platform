/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.SessionEntity;
import com.jieyun.deskpool.api.data.SessionEntityBinding;
import com.jieyun.deskpool.bean.usersession.IUserSessionBean;
import com.jieyun.deskpool.domain.UserSession;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import com.jieyun.deskpool.store.spec.DpSpec;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="sessoinApi")
public class SessionApi
extends ApiCallBase<SessionEntity>
implements IApiCall {
    @Autowired
    SessionEntityBinding sessionEntityBinding;

    @Override
    public ApiResult<SessionEntity> getImpl(Id id) {
        ApiResult<SessionEntity> result = new ApiResult<SessionEntity>();
        IUserSessionBean bean = (IUserSessionBean)Services.getUserSessionService().findOne(id);
        if (bean != null) {
            return bean.apiGet();
        }
        result.fail(ApiError.INVALID_OBJECT);
        return result;
    }

    @Override
    public ApiResult<SessionEntity> listImpl(String condition) {
        ApiResult<SessionEntity> result = new ApiResult<SessionEntity>();
        List imagelist = this.sessionEntityBinding.bindingForEntityList(Services.getUserSessionService().find(new DpSpec().byClass(UserSession.class).sortBy("name", "ASC").condition(condition)));
        result.setList(imagelist);
        return result;
    }

    @Override
    public ApiResult<SessionEntity> putImpl(Id id, String json) {
        return null;
    }

    @Override
    public ApiResult<SessionEntity> deleteImpl(Id id) {
        return null;
    }

    @Override
    public ApiResult<SessionEntity> createImpl(Id id, String json) {
        return null;
    }
}
