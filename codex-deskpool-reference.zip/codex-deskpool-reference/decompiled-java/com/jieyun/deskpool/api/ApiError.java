/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api;

public enum ApiError {
    SUCCESS("success"),
    INVALID_OBJECT("invalid object"),
    UNSUPPORTED_OPERATION("operation is not supported"),
    UNKNOW_ENTITY("entity is not supported"),
    UNAUTHORIZED_OPERATION("unauthorized operation"),
    UNKONW_ERROR("unknow error");

    String _message;

    private ApiError(String message) {
        this._message = message;
    }

    public int code() {
        return this.ordinal();
    }

    public String message() {
        return this._message;
    }

    public String toString() {
        return this._message;
    }
}
