/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jieyun.deskpool.api;

import com.jieyun.deskpool.api.ApiCallBase;
import com.jieyun.deskpool.api.ApiError;
import com.jieyun.deskpool.api.ApiResult;
import com.jieyun.deskpool.api.IApiCall;
import com.jieyun.deskpool.api.data.InstanceAction;
import com.jieyun.deskpool.api.data.InstanceActionBinding;
import com.jieyun.deskpool.api.data.InstanceEntity;
import com.jieyun.deskpool.bean.IInstanceBean;
import com.jieyun.deskpool.service.Services;
import com.jieyun.deskpool.shared.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="instanceActionApi")
public class InstanceActionApi
extends ApiCallBase<InstanceEntity>
implements IApiCall {
    @Autowired
    InstanceActionBinding instanceActionBinding;

    @Override
    public ApiResult<InstanceEntity> getImpl(Id id) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> putImpl(Id id, String json) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> deleteImpl(Id id) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> createImpl(Id id, String json) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        IInstanceBean instance = (IInstanceBean)Services.getInstanceService().findOne(id);
        if (instance == null) {
            result.fail(ApiError.INVALID_OBJECT);
            return result;
        }
        InstanceAction action = (InstanceAction)this.instanceActionBinding.bindingForAction(json);
        action.execute(instance);
        return result;
    }

    @Override
    public ApiResult<InstanceEntity> listImpl(String condition) {
        ApiResult<InstanceEntity> result = new ApiResult<InstanceEntity>();
        result.fail(ApiError.UNSUPPORTED_OPERATION);
        return result;
    }
}
