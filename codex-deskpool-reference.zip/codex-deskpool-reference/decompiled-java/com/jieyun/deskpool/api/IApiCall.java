/*
 * Decompiled with CFR 0.152.
 */
package com.jieyun.deskpool.api;

public interface IApiCall {
    public String get(String var1);

    public String put(String var1, String var2);

    public String delete(String var1);

    public String create(String var1, String var2);

    public String list(String var1);
}
