/*
 * Decompiled with CFR 0.152.
 */
package com.deskpool.constant;

import com.jieyun.deskpool.domain.Config;
import com.jieyun.deskpool.utils.Props;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DeskpoolConfigConstant {
    public static final boolean HACLUSTER = Props.instance().get("server.ha.cluster", false);
    public static final boolean LADP_SYSNC_BY_ACCOUNT = Props.instance().get("server.ladp.sysnc.account", false);
    public static final String LINUX_OS = "Linux";
    public static final boolean MISS_CREATE = Props.instance().get("server.missstatus.create", false);
    public static final List<String> LINUX_NOCHECKED = new ArrayList<String>(Arrays.asList("reason.os.not.importable", "reason.rdp.not.available", "reason.port139.not.available"));
    public static final boolean PVE_VGPU_EANBLE = Props.instance().get("server.proxmox.vgpu", false);
    public static final String PVE_VGPU_HOSTPCI0 = Props.instance().get("server.proxmox.hostpci0", "");
    public static final String PVE_BACKUP_STORAGE = Props.instance().get("server.proxmox.backup", "local");
    public static final String NOT_VMID_STORAGE = Props.instance().get("server.not.vm.id.storage", "lvmthin,rbd,zfspool");
    public static final boolean VM_LINKED_CLONE = Props.instance().get("vm.linkedclone", true);
    public static final int PVE_STOP_WAIT_TIME = Props.instance().get("config.pve.stop.timeout", 90);
    public static final int IMAGE_INSTANCE_CORES = Props.instance().get("image.instance.cores", 4);

    public static boolean isEnableTotp() {
        return Props.instance().get("enable.totp", false);
    }

    public static int getImageInstanceRam() {
        return Props.instance().get("image.instance.ram", 4096);
    }

    public static boolean isPve() {
        return Config.VM.Type.pve.name().equals(Props.instance().get("config.vm.server.type"));
    }

    public static String getHostAddress() {
        return Config.Store.get().vm().getParam("host_address");
    }
}
