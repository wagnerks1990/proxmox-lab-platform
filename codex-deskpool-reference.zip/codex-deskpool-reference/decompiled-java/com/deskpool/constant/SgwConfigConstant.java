/*
 * Decompiled with CFR 0.152.
 */
package com.deskpool.constant;

import java.io.File;

public interface SgwConfigConstant {
    public static final String INSTALL_PATH = "/usr";
    public static final String CONFIG_PATH = SgwConfigConstant.class.getClassLoader().getResource("sgw").getPath();
    public static final String SGWS_INI = "sgws.ini";
    public static final String SGWC_INI = "sgwc.ini";
    public static final String COMMON_KEY = "common";
    public static final String DESKPOOL = "deskpool";
    public static final String SGWS_FILE_DIR = String.valueOf(CONFIG_PATH) + File.separator + "sgws";
    public static final String SGWC_FILE_DIR = String.valueOf(CONFIG_PATH) + File.separator + "sgwc";
    public static final String SGWS_SORFWARE_PATH = "/usr" + File.separator + "sgws";
    public static final String SGWC_SORFWARE_PATH = "/usr" + File.separator + "sgwc";
    public static final String SGWC_EXCE_FILE = String.valueOf(SGWC_SORFWARE_PATH) + File.separator + "sgwc";
    public static final String SGWC_EXCE_INI = String.valueOf(SGWC_SORFWARE_PATH) + File.separator + "sgwc.ini";
    public static final String SGWS_INSTALL_SCRIPT = String.valueOf(SGWS_SORFWARE_PATH) + File.separator + "install.sh";
    public static final String CHECK_SGWC_COMMD = "pidof -s " + SGWC_EXCE_FILE;
}
